import { get, post } from '@/service'

export interface LoginData {
  username: string
  password: string
  code: string
  uuid: string
}

// 登录方法
export const login = (data: LoginData) => {
  const headers = {
    isToken: false,
    repeatSubmit: false,
  }
  return post({ url: '/login', headers, data })
}

// 注册方法
export const register = (data: any) => {
  const headers = { isToken: false }
  return post({ url: '/register', headers, data })
}

// 获取用户详细信息
export const getInfo = () => {
  return get({ url: '/getInfo' })
}

// 退出方法
export const logout = () => {
  return post({ url: '/logout' })
}

// 获取验证码
export const getCodeImg = () => {
  const headers = { isToken: false }
  return get({ url: '/captchaImage', headers, timeout: 20000 })
}
