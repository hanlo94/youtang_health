import service from './service'

const request = (option: any) => {
  const { headersType, headers, ...otherOption } = option
  return service({
    ...otherOption,
    headers: {
      'Content-Type': headersType || 'application/json',
      ...headers,
    },
  })
}

export const get = async (option: any) => {
  const res = await request({ method: 'GET', ...option })
  return res
}

export const post = async <T = any>(option: any) => {
  const res = await request({ method: 'POST', ...option })
  return res as unknown as Promise<T>
}

export const del = async <T = any>(option: any) => {
  const res = await request({ method: 'DELETE', ...option })
  return res as unknown as Promise<T>
}

export const put = async <T = any>(option: any) => {
  const res = await request({ method: 'PUT', ...option })
  return res as unknown as Promise<T>
}

export const download = async <T = any>(option: any) => {
  const res = await request({ method: 'GET', responseType: 'blob', ...option })
  return res as unknown as Promise<T>
}

export const upload = async <T = any>(option: any) => {
  option.headersType = 'multipart/form-data'
  const res = await request({ method: 'POST', ...option })
  return res as unknown as Promise<T>
}

export default request
