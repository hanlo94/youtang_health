const { defineConfig } = require('eslint-define-config');
const OFF = 0;
const WARN = 1;
const ERROR = 2;

module.exports = defineConfig({
  env: {
    browser: true,
    es2021: true,
    node: true,
  },
  extends: [
    'plugin:vue/vue3-recommended',
    'plugin:import/recommended', // 添加 import 插件
    'plugin:unicorn/recommended', // 添加 unicorn 插件
    'prettier',
    'plugin:prettier/recommended',
  ],
  parser: 'vue-eslint-parser',
  parserOptions: {
    ecmaFeatures: {
      impliedStrict: true,
      jsx: true,
    },
    ecmaVersion: 12,
    sourceType: 'module',
  },
  plugins: ['vue', 'promise', 'import', 'unicorn', 'prettier'], // 添加 import 和 unicorn 插件
  rules: {
    'import/extensions': [
      ERROR,
      'ignorePackages',
      {
        vue: 'never',
        ts: 'never',
        tsx: 'never',
        js: 'never',
      },
    ],
    'import/no-extraneous-dependencies': [ERROR, { devDependencies: true }],
    'import/prefer-default-export': OFF,
    'import/no-unresolved': [
      ERROR,
      {
        ignore: ['^./'], // @ 是设置的路径别名
      },
    ],
    'import/no-dynamic-require': OFF,
    'unicorn/better-regex': ERROR,
    'unicorn/prevent-abbreviations': OFF,
    'unicorn/filename-case': [
      ERROR,
      {
        cases: {
          // 中划线
          kebabCase: true,
          // 小驼峰
          camelCase: true,
          // 下划线
          snakeCase: false,
          // 大驼峰
          pascalCase: true,
        },
      },
    ],
    'unicorn/no-array-instanceof': WARN,
    'unicorn/no-for-loop': WARN,
    'unicorn/prefer-add-event-listener': [
      ERROR,
      {
        excludedPackages: ['koa', 'sax'],
      },
    ],
    'unicorn/prefer-query-selector': ERROR,
    'unicorn/no-null': OFF,
    'unicorn/no-array-reduce': OFF,
    'unicorn/no-process-exit': OFF,
    'unicorn/consistent-func': OFF,
    'unicorn/consistent-destructuring': OFF,
    'unicorn/consistent-function-scoping': WARN,
    'unicorn/no-array-for-each': OFF,
    'unicorn/prefer-module': OFF,
    'unicorn/prefer-spread': OFF,
    'unicorn/prefer-logical-operator-over-ternary': OFF,
    'unicorn/numeric-separators-style': OFF,

    // '@typescript-eslint/no-useless-constructor': ERROR,
    // '@typescript-eslint/no-empty-function': WARN,
    // '@typescript-eslint/no-var-requires': OFF,
    // '@typescript-eslint/explicit-function-return-type': OFF,
    // '@typescript-eslint/explicit-module-boundary-types': OFF,
    // '@typescript-eslint/no-explicit-any': OFF,
    // '@typescript-eslint/no-use-before-define': ERROR,
    // '@typescript-eslint/no-unused-vars': WARN,
    'no-unused-vars': OFF,

    'vue/no-setup-props-destructure': 'off',
    'vue/script-setup-uses-vars': 'error',
    'vue/no-reserved-component-names': 'off',
    'vue/custom-event-name-casing': 'off',
    'vue/attributes-order': 'off',
    'vue/one-component-per-file': 'off',
    'vue/html-closing-bracket-newline': 'off',
    'vue/max-attributes-per-line': 'off',
    'vue/multiline-html-element-content-newline': 'off',
    'vue/singleline-html-element-content-newline': 'off',
    'vue/attribute-hyphenation': 'off',
    'vue/require-default-prop': 'off',
    'vue/require-explicit-emits': 'off',
    'vue/require-toggle-inside-transition': 'off',
    'vue/html-self-closing': [
      'error',
      {
        html: {
          void: 'always',
          normal: 'never',
          component: 'always',
        },
        svg: 'always',
        math: 'always',
      },
    ],
    'vue/multi-word-component-names': 'off',
    'vue/no-v-html': 'off',

    'jsx-a11y/click-events-have-key-events': OFF,
    'jsx-a11y/no-noninteractive-element-interactions': OFF,
    'jsx-a11y/no-static-element-interactions': OFF,
    'jsx-a11y/anchor-is-valid': OFF,
    'jsx-a11y/label-has-associated-control': OFF,

    'lines-between-class-members': [ERROR, 'always'],
    // indent: [ERROR, 2, { SwitchCase: 1 }],
    'linebreak-style': [OFF, 'unix'],
    // 'linebreak-style': [0, 'error', 'windows'],
    quotes: [ERROR, 'single'],
    semi: [ERROR, 'always'],
    'no-unused-expressions': WARN,
    'no-plusplus': OFF,
    'no-console': OFF,

    'jsx-quotes': [ERROR, 'prefer-single'],
    'global-require': OFF,
    'no-use-before-define': OFF,
    'no-restricted-syntax': OFF,
    'no-continue': OFF,
    'no-param-reassign': OFF, // 禁止对函数参数再赋值
    'no-shadow': OFF,
    // '@typescript-eslint/no-shadow': ERROR,
    'no-useless-return': OFF,
    'promise/always-return': OFF,
    'promise/catch-or-return': OFF,
    radix: OFF,
    'consistent-return': WARN, // 异步函数中不允许return
    'no-underscore-dangle': OFF, // 标识符不能以_开头或结尾
    'prefer-destructuring': WARN, // 数组不允许索引取值赋值
    'no-useless-escape': OFF,
    'no-new-func': OFF,
    'no-template-curly-in-string': OFF,
    'one-var': OFF,
    'class-methods-use-this': OFF,
    'no-return-assign': OFF,
    'unicorn/prefer-ternary': OFF,
  },
});
