import { defineConfig, loadEnv } from 'vite';
import path from 'path';
import createVitePlugins from './vite/plugins';

export default defineConfig(({ mode, command }) => {
  const env = loadEnv(mode, process.cwd());
  const {VITE_BASE_URL, VITE_DROP_DEBUGGER, VITE_DROP_CONSOLE, VITE_SOURCEMAP, VITE_BASE_PATH, VITE_OUT_DIR } = env;
  return {
    // 部署生产环境和开发环境下的URL。
    base: VITE_BASE_PATH,
    plugins: createVitePlugins(env, command === 'build'),
    resolve: {
      alias: {
        // 设置路径
        '~': path.resolve(__dirname, './'),
        // 设置别名
        '@': path.resolve(__dirname, './src'),
      },
      extensions: ['.mjs', '.js', '.ts', '.jsx', '.tsx', '.json', '.scss', '.css', '.vue'],
    },
    // vite 相关配置
    server: {
      port: 80,
      host: true,
      open: true,
      proxy: {
        '/dev-api': {
          target: VITE_BASE_URL,
          changeOrigin: true,
          rewrite: (p) => p.replace(/^\/dev-api/, ''),
        },
      },
    },
    css: {
      postcss: {
        plugins: [
          {
            postcssPlugin: 'internal:charset-removal',
            AtRule: {
              charset: (atRule) => {
                if (atRule.name === 'charset') {
                  atRule.remove();
                }
              },
            },
          },
        ],
      },
    },
    build: {
      minify: 'terser',
      outDir: VITE_OUT_DIR || 'dist',
      sourcemap: VITE_SOURCEMAP === 'true' ? 'inline' : false,
      // brotliSize: false,
      terserOptions: {
        compress: {
          drop_debugger: VITE_DROP_DEBUGGER === 'true',
          drop_console: VITE_DROP_CONSOLE === 'true',
        },
      },
      rollupOptions: {
        output: {
          manualChunks: {
            echarts: ['echarts'], // 将 echarts 单独打包
          },
        },
      },
    },
  };
});
