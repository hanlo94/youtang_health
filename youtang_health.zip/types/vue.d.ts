export {};

declare module "vue" {
  export interface GlobalComponents extends JSX.IntrinsicElements {
    /** Note: Vue 在 runtime 中将 JSX.IntrinsicElements 通过 index signature 重复声明标签
     * 这会导致插件无法正常跳转类型，可以手动覆盖声明标签活得更好的体验，参考如下：
     * 'scroll-view': JSX.IntrinsicElements['scroll-view']
     */
  }
}

import axios, {
  AxiosDefaults,
  AxiosInterceptorManager,
  AxiosRequestConfig,
  AxiosResponse,
  InternalAxiosRequestConfig
} from 'axios'

type AxiosRes<T> = {
  code:number;
  message:string;
  data:T;
  recordList:T;
}

declare module 'axios' {
  export interface AxiosInstance {
    request<T = any, R = AxiosRes<T>, D = any>(config: AxiosRequestConfig<D>): Promise<R>;
    get<T = any, R = AxiosRes<T>, D = any>(url: string, config?: AxiosRequestConfig<D>): Promise<R>;
    post<T = any, R = AxiosRes<T>, D = any>(url: string, data?: D, config?: AxiosRequestConfig<D>): Promise<R>;
  }
}
