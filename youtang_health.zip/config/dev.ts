module.exports = {
    env: {
        NODE_ENV: '"development"',
        BASE_URL: '"https://xcxtest.youtang120.com"',
        VERSION: '"1.3.2"',
        APP_VERSION: 42,
        VERSION_CODE: '"8"',
        APP_SECRET: '"B0933B768AB8AA86D3BB8473D054AD9D"',
        SERVICE_PACK: '"https://h5test.youtang120.com/youtang/ServicePack.html"',
        PRIVACY: '"https://h5test.youtang120.com/privacy.html"',
        SERVICE_ITEM: '"https://h5test.youtang120.com/service.html"',
        POINT_RULE: '"https://h5test.youtang120.com/youtang/pointRule.html"',
        CUSTOMER_SERVICE_PHONE: '"400 886 0919"'
    },
    defineConstants: {},
    mini: {},
    h5: {},
};
