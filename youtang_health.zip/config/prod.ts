module.exports = {
    env: {
        NODE_ENV: '"production"',
        BASE_URL: '"https://xcx.youtang120.com"',
        VERSION: '"1.4.0"',
        APP_VERSION: 43,
        VERSION_CODE: '"10"',
        APP_SECRET: '"4E2B2DC021814CF81027CC8EE6C8676C"',
        SERVICE_PACK: '"https://h5.youtang120.com/youtang/ServicePack.html"',
        PRIVACY: '"https://h5.youtang120.com/privacy.html"',
        SERVICE_ITEM: '"https://h5.youtang120.com/service.html"',
        POINT_RULE: '"https://h5.youtang120.com/youtang/pointRule.html"',
        CUSTOMER_SERVICE_PHONE: '"400 886 0919"'
    },
    defineConstants: {},
    mini: {},
    h5: {
        /**
         * WebpackChain 插件配置
         * @docs https://github.com/neutrinojs/webpack-chain
         */
        // webpackChain (chain) {
        //   /**
        //    * 如果 h5 端编译后体积过大，可以使用 webpack-bundle-analyzer 插件对打包体积进行分析。
        //    * @docs https://github.com/webpack-contrib/webpack-bundle-analyzer
        //    */
        //   chain.plugin('analyzer')
        //     .use(require('webpack-bundle-analyzer').BundleAnalyzerPlugin, [])
        //   /**
        //    * 如果 h5 端首屏加载时间过长，可以使用 prerender-spa-plugin 插件预加载首页。
        //    * @docs https://github.com/chrisvfritz/prerender-spa-plugin
        //    */
        //   const path = require('path')
        //   const Prerender = require('prerender-spa-plugin')
        //   const staticDir = path.join(__dirname, '..', 'dist')
        //   chain
        //     .plugin('prerender')
        //     .use(new Prerender({
        //       staticDir,
        //       routes: [ '/pages/index/index' ],
        //       postProcess: (context) => ({ ...context, outputPath: path.join(staticDir, 'index.html') })
        //     }))
        // }
    },
};
