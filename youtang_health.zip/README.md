# release date 2024-10-31  versionName=1.3.0 AppVersionCode=40  releaseVersionCode=6
# release date 2024-11-30  versionName=1.3.2 AppVersionCode=42  releaseVersionCode=8
# release date 2025-01-17  versionName=1.3.3 AppVersionCode=43  releaseVersionCode=9