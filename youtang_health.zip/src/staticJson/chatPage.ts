
export const quesstionList = ['优唐健康是干什么的', '什么是糖无忧', '贝塔素是什么']
export const chatMsg = {
    logoIcon: '@/assets/common/logo.png',
    chatMsg: '你好，我是优小唐-智能助手，专门解答你在糖尿病健康管理过程中遇到的问题',
}