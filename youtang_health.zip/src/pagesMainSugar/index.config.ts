export default definePageConfig({
    navigationBarTitleText: "记血糖",
    usingComponents:{
        'ec-canvas':'@/component/ec-canvas/ec-canvas'
    }
});
