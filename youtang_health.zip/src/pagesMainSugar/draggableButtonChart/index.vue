<template>
  <view class="drag-container" id="containerBox">
    <view class="charts">
      <ec-canvas
        id="chart-dom-area"
        canvas-id="chart-area"
        :ec="ec"
        force-use-old-canvas="true"
      ></ec-canvas>

      <ec-canvas
        id="chart-base"
        canvas-id="chart-base"
        :ec="ecBase"
        force-use-old-canvas="true"
        class="base-style"
      ></ec-canvas>
    </view>
    <view
      class="button"
      ref="button"
      :style="buttonStyle"
      @touchstart="startDrag"
      @touchend="endDrag"
      @touchmove="dragMove"
    ></view>
  </view>
</template>

<script setup lang="ts">
// import * as echarts from "@/component/ec-canvas/echarts";
import { ref, defineEmits, reactive, watch, onMounted } from "vue";
import { throttle, cloneDeep } from "lodash";
const echarts = require("@/component/ec-canvas/echarts");
import Taro from "@tarojs/taro";

interface IProps {
  keyBoardValue: string;
}
const props = withDefaults(defineProps<IProps>(), {
  keyBoardValue: "0",
});
const emit = defineEmits<{
  (event: "getDragCount", value: number): void;
}>();
let chartOption = {
  animation: false,
  series: [
    {
      type: "pie",
      radius: ["75%", "90%"],
      startAngle: 90,
      silent: true,
      label: { show: false },
      data: [
        { value: 0, itemStyle: { color: "#fff" } },
        { value: 360, itemStyle: { color: "transparent" } },
      ],
    },
  ],
};

// 页面布局变量
const radius = ref<number>(0); // 按钮移动的半径
const radiusInter = ref<number>(24); //适配ipad
//中心点
const centerX = ref<number>(0);
const centerY = ref<number>(0);

const button = ref<HTMLDivElement | null>(null); //按钮的 DOM 引用
const buttonStyle = ref({
  left: `${centerX.value}px`,
  top: `${centerY.value - radius.value}px`,
}); // 按钮的样式
let dragging = false; // 拖拽逻辑
let angle = 0; // 初始角度
//拖拽图表
const chart = ref();
const ec = reactive({
  onInit: initChart,
});

//底图环形图
const chartBase = ref();
const ecBase = reactive({
  onInit: initChartBase,
});

//输入数值更新图表
watch(
  () => props.keyBoardValue,
  () => {
    angle = convertValueToAngle(Number(props.keyBoardValue));
    updateButtonPosition(angle);
    updateChart(angle);
  }
);

onMounted(() => {
  // 在组件挂载时更新中心点位置
  updateCenterPosition();
});

const updateCenterPosition = () => {
  Taro.createSelectorQuery()
    .select(`#containerBox`)
    .boundingClientRect((rect) => {
      getStstemInfo();
      // rect 包含元素的尺寸和位置信息
      centerX.value = (rect as any)?.width / 2;
      centerY.value = (rect as any)?.height / 2;
      radius.value = (rect as any)?.width / 2 - radiusInter.value;
    })
    .exec();
};

const getStstemInfo = () => {
  wx?.getSystemInfo({
    success: (res) => {
      // console.log('系统信息:', res);
      if (res.screenWidth >= 768) {
        radiusInter.value = 44;
      }
    },
    fail: (err) => {
      console.error("获取系统信息失败:", err);
    },
  });
};

function initChartBase(canvas: any, width: any, height: any) {
  chartBase.value = echarts.init(canvas, null, {
    width,
    height,
  });
  loadChartBase();
  return chartBase;
}
const loadChartBase = () => {
  let cloneData = cloneDeep(chartOption);
  cloneData.series[0].data = [
    { value: 0, itemStyle: { color: "rgba(255, 255, 255, 0.3)" } },
    { value: 360, itemStyle: { color: "rgba(255, 255, 255, 0.3)" } },
  ];
  chartBase.value.setOption(cloneData);
};

// echarts.init初始化
function initChart(canvas: any, width: any, height: any) {
  chart.value = echarts.init(canvas, null, {
    width,
    height,
  });
  loadChart();
  return chart;
}

const loadChart = () => {
  if (chart && chart.value) {
    chart.value.setOption(chartOption);
    updateButtonPosition(angle);
  }
};

/**
 * 更新按钮位置
 */
const updateButtonPosition = (angle: number) => {
  const radian = ((angle - 90) * Math.PI) / 180;
  const x = centerX.value + radius.value * Math.cos(radian);
  const y = centerY.value + radius.value * Math.sin(radian);
  if (button.value) {
    buttonStyle.value = { left: `${x}px`, top: `${y}px` };
  }
};

// 更新 ECharts 图表
const updateChart = (angle: number) => {
  let data: any = [];
  if (angle === 360 || angle === 0) {
    data = [
      { value: 0, itemStyle: { color: "transparent" } },
      { value: 360, itemStyle: { color: "transparent" } },
    ];
  } else {
    data = [
      {
        value: angle,
        itemStyle: {
          color: "#fff",
          borderRadius: 80,
          borderColor: "#fff",
          borderWidth: 2,
        },
      },
      { value: 360 - angle, itemStyle: { color: "transparent" } },
    ];
  }

  //增量更新
  chart &&
    chart.value.setOption({
      series: [{ data }],
    },
    { lazyUpdate: true }
  );
  //draggint 避免多次更新父组件
  dragging && emit("getDragCount", convertAngleToRange(angle));
};

const startDrag = () => {
  dragging = true;
};

const endDrag = () => {
  dragging = false;
};

const dragMove = (e: TouchEvent) => {
  throttledHandleDrag(e);
};

/**
 * 添加节流函数，通过按钮移动距离计算角度
 * 更新按钮位置，渲染环形图
 */
const throttledHandleDrag = throttle((e) => {
  if (!dragging) return;
  const touch = e.touches[0];
  const dx =
    touch.clientX -
    centerX.value -
    ((button.value?.offsetParent as any)?.offsetLeft || 0);
  const dy =
    touch.clientY -
    centerY.value -
    ((button.value?.offsetParent as any)?.offsetTop || 0);
  let newAngle = Math.atan2(dy, dx) * (180 / Math.PI) + 90;

  if (newAngle < 0) newAngle += 360;

  // 顺时针增加角度，逆时针减少逻辑
  if (newAngle > angle + 5) {
    angle = newAngle % 360;
  } else if (newAngle < angle - 5) {
    angle = (360 + newAngle) % 360;
  }

  //提高重回优先级
  requestAnimationFrame(() => {
    updateChart(angle);
    updateButtonPosition(angle);
  });

}, 32); //

// 根据角度计算 [0, 33] 区间内的数值
function convertAngleToRange(angle: number): number {
  if (angle >= 0 && angle <= 360) {
    let convertedValue = (angle / 360) * 33;
    return Math.round(convertedValue * 10) / 10;
  } else {
    throw new Error("Angle must be between 0 and 360");
  }
}

// 根据数值计算角度 [0, 360]
function convertValueToAngle(value: number): number {
  if (value >= 0 && value <= 33) {
    let angle = (value / 33) * 360;
    return angle;
  } else {
    throw new Error("Value must be between 0 and 33");
  }
}
</script>

<style lang="less">
.drag-container {
  width: 500px;
  height: 500px;
  position: absolute;
  top: 0;
  left: 0;
  margin: 70px 106px;

  .charts {
    height: 500px;
    position: relative;

    .base-style {
      width: 100%;
      height: 100%;
      position: absolute;
      top: 0;
      left: 0;
    }
  }

  .button {
    width: 80px;
    height: 80px;
    position: absolute;
    background-color: #ffffff;
    border-radius: 50%;
    cursor: pointer;
    transform: translate(-50%, -50%);
    z-index: 10;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
  }
}
</style>
