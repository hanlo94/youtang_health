<template>
	<view class="container_sugar">
		<view class="view_root">
			<nut-tabs class="tab" @click="onTabClick" v-model="active" title-scroll title-gutter="10" color="#64A4F5"
					  background="#ffffff" name="sugar_tab">
				<nut-tab-pane :title="item.value" v-for="(item,index) in tabList" :key="index"></nut-tab-pane>
			</nut-tabs>
			<view class="view_content">
				<view :class="roundClassName()" class="round" @click.stop="onKeyBoard">
					<view class="input">{{ isEmpty(keyBoardValue) ? "请输入血糖值" : keyBoardValue }}</view>
					<view class="border"></view>
					<view class="unit">mmol/L</view>
				</view>

				<view class="view_item" @click.stop="onClickShowDateDialog">
					<text>测量日期</text>
					<view class="arr_text">
						<text style="color: #666666;">{{ formatSelectDate }}</text>
						<IconFont name="rect-right" size="14" color='#bbbbbb'/>
					</view>

				</view>

				<view class="view_input">
					<text>备注</text>
					<textarea class="input_remark" v-model="sugarRecord.remark"
							  placeholder="今天有啥特殊情况，如心情不佳，劳累等等。"/>
				</view>
			</view>
			<button class="btn_save" size="default" @click="onClickSubmit">保存</button>
			<nut-popup position="bottom" v-model:visible="showDateDialog" title="选择测量日期" round
					   style="padding-top: 20px"
					   @click.stop="onClickShowDateDialog">
				<nut-date-picker
					v-model="currentDate"
					:min-date="minDate"
					type="datetime"
					:max-date="maxDate"
					is-show-chinese
					:show-toolbar="false"
				/>
				<button class="btn_save" size="default" @click.stop="onClickShowDateDialog">确定</button>
			</nut-popup>
      <nut-popup @update:visible="onSugarDialogVisible" v-model:visible="showSugarDialog"
                 position="center" :style="{ height: '60%' }"
                 style="background: transparent">
				<!--        低1  中 2  高3-->
				<view class="sugar_dialog">
					<img :src="sugarDialog.img"/>
					<view class="sugar_dialog_content">
						<view class="sugar_content">
							<view v-if="sugarRecord.sugarvalueType === 1">
								您的
								<text style="color:#ED8E36 ">血糖偏低</text>
								哦！请注意合理饮食，定期监测。请及时咨询您的健康管理师。
							</view>
							<view v-else-if="sugarRecord.sugarvalueType === 2">您的血糖控制的很好，请继续保持哦 ~</view>
							<view v-else>您的
								<text style="color:#DD3542 ">血糖偏高</text>
								哦！请注意科学饮食，合理运动。请及时咨询您的健康管理师。
							</view>
						</view>
						<view class="sugar_result_btn" @click="onClickDialogHealthManager">联系健康管理师</view>
            <img :src="closePop" @click.stop="onClosePop" />
					</view>
				</view>
<!--				<view class="dialog" v-else-if="sugarRecord.sugarvalueType === 2">-->
<!--					<img src="https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/sugar/normal_pic.png"/>-->
<!--					<view class="dialog_content">-->
<!--						<view class="content">您的血糖控制的很好，请继续保持哦 ~</view>-->
<!--						<view class="btn" @click="onClickDialogHealthManager">联系健康管理师</view>-->
<!--					</view>-->
<!--				</view>-->
<!--				<view class="dialog" v-else>-->
<!--					<img src="https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/sugar/high_pic.png"/>-->
<!--					<view class="dialog_content">-->
<!--						<view class="content">您的-->
<!--							<text style="color:#DD3542 ">血糖偏高</text>-->
<!--							哦！请注意科学饮食，合理运动。请及时咨询您的健康管理师。-->
<!--						</view>-->
<!--						<view class="btn" @click="onClickDialogHealthManager">联系健康管理师</view>-->
<!--					</view>-->
<!--				</view>-->
			</nut-popup>


<!--			<KeyBoard v-model:show-key-board="showKeyBoard" >-->

<!--			</KeyBoard>-->
<!--			<NutNumberKeyboard v-model:visible="showKeyBoard" @input="input" @delete="onClickDeleteValue"-->
<!--							   @close="onClickSubmit"-->
<!--							   type="rightColumn"-->
<!--							   :custom-key="customKey"-->
<!--							   confirm-text="保存"-->
<!--							   v-model:value="keyBoardValue"-->
<!--							   maxlength="4"> </NutNumberKeyboard>-->

			<nut-popup position="bottom" :overlay=false :catch-move="true" v-model:visible="showKeyBoard">
				<view class="pop_key_board">
					<view class="key_number">
						<nut-grid :column-num="3">
							<nut-grid-item
								:text="item.value"
								v-for="(item, index) in keyBoardList"
								:key="index"
								@click="onKeyBoardItemClick(item)"
							>
								<img v-if="item.id === 12" :src="keyBoardDown"
									 style="width: 20px;height: 20px;margin-top: 15px"/>
							</nut-grid-item>
						</nut-grid>
					</view>
					<view class="key_controls">
						<view class="view_del" @click="onClickDeleteValue">
							<img :src="keyBoardDel" style="width: 20px;height: 20px"/></view>
						<view class="view_save" @click.stop="onClickSubmit">保存</view>
					</view>
				</view>
			</nut-popup>

      <point_dialog :show-point-dialog="showPointDialog" :rewards=rewardPoint @closeDialog="onClosePointDialog"/>
		</view>
	</view>
</template>

<script setup lang="ts">
import point_dialog from '@/component/point/index.vue'
import {computed, onBeforeMount, ref, watch} from "vue";
import {formatCurrentIndex, formatTime} from "@/utils/util";
import SugarApi from "@/api/modules/sugar";
import {useDateFormat} from '@vueuse/core'
import {IconFont} from '@nutui/icons-vue-taro';
import {timeType} from "@/config/sugar/sugarConfig";
import Taro from "@tarojs/taro";
import {showErrorToast, showToast} from "@/utils/toastUtils";
import {useMainPageStore} from "@/utils/storeUtils";
import {getCurrentInstance} from "@tarojs/runtime";
import {ISugarItem} from "@/pagesSugarAnalysis/ts/types";
import {IKeyBoardItem, keyBoardList} from "@/pagesFood/ts/optionsUtils";
import {isEmpty} from "lodash";
import imgUrlFormat from "@/utils/imgUtils";

const showPointDialog=ref<boolean>(false)
const rewardPoint=ref<string>()


const keyBoardDown = imgUrlFormat('sugar/food/keyboard_down.png')
// const customKey = reactive(['.']);

// const close=(res)=>{
// 	console.log("index.vue.close.",JSON.stringify(res));
// 	showKeyBoard.value=false
//
// }

const input=(res)=>{
	console.log("index.vue.input.",JSON.stringify(res),'; keyBoardValue',JSON.stringify(keyBoardValue.value));
	if (keyBoardValue.value.length < 4) {
		keyBoardValue.value += res;
	}
	if(Number(keyBoardValue.value)==0){
		keyBoardValue.value="0"
	}else if (keyBoardValue.value.indexOf("0")==0){
		keyBoardValue.value = keyBoardValue.value.substring(1);
	}
}

const mainPageStore = useMainPageStore();

const tabList = ref(timeType);

const active = ref(formatCurrentIndex())//默认选中index 默认为0
/**
 * 键盘上的文字
 */
const keyBoardValue = ref("");
const showKeyBoard = ref(false);
const keyBoardDel = imgUrlFormat('sugar/food/keyboard_del.png')
const closePop = imgUrlFormat('close_pop.png')


const showDateDialog = ref(false);
const currentDate = ref(new Date());
const currentSelDate = ref(new Date());
const minDate = ref(new Date(2018, 0, 1));
const maxDate = ref(new Date());

const remark = ref('') //备注

const sugarRecord = ref({
	value: null,
	type: tabList.value[Number(active.value)]?.key,
	sugarvalueType: 1,
	time: formatTime(new Date()),
	id: 0,
	remark: ''
})


const sugarDialog = computed(() => {
	let img;
	if (sugarRecord.value.sugarvalueType === 1) {
		img = imgUrlFormat('sugar/low_pic.png')
	} else if (sugarRecord.value.sugarvalueType === 2) {
		img = imgUrlFormat('sugar/normal_pic.png')
	} else {
		img = imgUrlFormat('sugar/high_pic.png')
	}
	const res = {
		img
	}
	return res;
})


/**
 * 血糖结果提示弹窗
 */
const showSugarDialog = ref(false);

onBeforeMount(() => {
	let {data} = getCurrentInstance().router?.params
	if (data) {
		let sugarRecordInfo = JSON.parse(data) as ISugarItem;
		console.log("index.vue.onBeforeMount.", data, ' ; JSON.parse(data)=', sugarRecordInfo);
		keyBoardValue.value = sugarRecordInfo.sugarValuesSugarValue + ""
		console.log("index.vue.onBeforeMount.keyBoardValue=", keyBoardValue.value);
		sugarRecord.value.type = sugarRecordInfo.sugarValuesTimeTypeId
		active.value = (sugarRecordInfo.sugarValuesTimeTypeId + 1) % tabList.value.length
		sugarRecord.value.time = sugarRecordInfo.sugarValuesRecordTime
		sugarRecord.value.id = sugarRecordInfo.dataId
		sugarRecord.value.remark = sugarRecordInfo.sugarValuesRemarks
		currentDate.value = new Date(sugarRecordInfo.sugarValuesRecordTime)
		currentSelDate.value = currentDate.value;
	}
})

// 屏蔽时段与时间关联 肖 2024-01-10 10:24:45
const onTabClick = (res) => {
	// let sugarTimeByType = timeType[res.paneKey]
	// if (sugarTimeByType) {
	// 	const year = currentDate.value.getFullYear()
	// 	const month = formatNumber(currentDate.value.getMonth() + 1)
	// 	const day = formatNumber(currentDate.value.getDate())
	// 	let date = year + "/" + month + "/" + day
	// 	currentDate.value = new Date(date + " " + sugarTimeByType.time)
	// 	currentSelDate.value = currentDate.value
	// }
}

const formatSelectDate = computed(() => {
	return useDateFormat(currentSelDate.value, 'YYYY年M月D日 HH:mm').value;
})

const onClickShowDateDialog = () => {
	showDateDialog.value = !showDateDialog.value;
	currentSelDate.value = currentDate.value;
}

watch(() => keyBoardValue.value, (newVal, oldVAl) => {
	// console.log("index.vue.watch keyboardValue.newVal=", newVal, '; oldVal=', oldVAl);
	if (isEmpty(newVal)) {
		return
	}
	if (parseFloat(newVal) > 33.1) {
		showToast("请输入正确范围数值")
		onClickDeleteValue()
	}
})


// 空腹4.4-7  其他4.4-10
const roundClassName = () => {
	let value = keyBoardValue.value
	if (isEmpty(value)) {
		sugarRecord.value.sugarvalueType = 2;
		return "view_round_blue"
	} else {
		value = parseFloat(value)
		if (value <= 4.4) {
			sugarRecord.value.sugarvalueType = 1;
			return "view_round_orange"
		} else {
			let limitUp = active.value === 1 ? 7 : 10;
			if (value > 4.4 && value < limitUp) {
				sugarRecord.value.sugarvalueType = 2;
				return "view_round_blue"
			} else {
				sugarRecord.value.sugarvalueType = 3;
				return "view_round_red"
			}
		}
	}

	// if (active.value === '0') {//空腹
	// 	if (sugarValue.value == null) {
	// 		sugarvalueType.value = 2;
	// 		return "view_round_blue"
	// 	} else if (sugarValue.value <= 4.4) {
	// 		sugarvalueType.value = 1;
	// 		return "view_round_orange"
	// 	} else if (sugarValue.value > 4.4 && sugarValue.value < 7) {
	// 		sugarvalueType.value = 2;
	// 		return "view_round_blue"
	// 	} else {
	// 		sugarvalueType.value = 3;
	// 		return "view_round_red"
	// 	}
	// } else {
	// 	if (sugarValue.value == null) {
	// 		sugarvalueType.value = 2;
	// 		// console.log('view_round_blue', sugarValue.value);
	// 		return "view_round_blue"
	// 	} else if (sugarValue.value <= 4.4) {
	// 		sugarvalueType.value = 1;
	// 		// console.log('view_round_orange', sugarValue.value);
	// 		return "view_round_orange"
	// 	} else if (sugarValue.value > 4.4 && sugarValue.value < 10) {
	// 		sugarvalueType.value = 2;
	// 		// console.log('view_round_blue2', sugarValue.value);
	// 		return "view_round_blue"
	// 	} else {
	// 		sugarvalueType.value = 3;
	// 		// console.log('view_round_red', sugarValue.value);
	// 		return "view_round_red"
	// 	}
	// }
}


const onSugarDialogVisible = (res) => {
	console.log("index.vue.onSugarDialogVisible.", JSON.stringify(res));
	if (!res) {
		Taro.redirectTo({
			url: '/pagesSugarAnalysis/sugarAnalysis'
		})
	}
}

/**
 * 联系健康管理师
 */
const onClickDialogHealthManager = () => {
	Taro.makePhoneCall({
		phoneNumber: '4008860919'
	})
}

const onClosePop=()=>{
  showSugarDialog.value = false;
}


/**
 * 点击保存
 */
const onClickSubmit = () => {
	let value = keyBoardValue.value
	if (isEmpty(value)) {
		Taro.showToast({
			title: '请输入正确的血糖值',
			icon: 'none',
		})
		return;
	} else {
		value = parseFloat(value)
		if (value > 33.1 || value <= 0) {
			Taro.showToast({
				title: '请输入正确的血糖值',
				icon: 'none',
			})
			return;
		}
	}
	showKeyBoard.value = false

	sugarRecord.value.type = tabList.value[Number(active.value)]?.key
	sugarRecord.value.time = formatTime(currentDate.value)
	sugarRecord.value.value = keyBoardValue.value

	SugarApi.addOrEditSugar(sugarRecord.value).then(res => {
		if (res && res.code == 1) {
			showToast("保存成功")
      mainPageStore.refreshPage()
      if (res.data) {
        rewardPoint.value = res.data
        showPointDialog.value = true
      }else{
        onFinal()
      }
		} else {
			showErrorToast("保存失败，请重试")
		}
	}, err => {
		console.log("index.vue.addOrEditSugar .failure", JSON.stringify(err));
		showErrorToast(err ?? "保存失败，请重试")
	});
}

const onKeyBoard = () => {
	console.log("index.vue.onKeyBoard.",);
	showKeyBoard.value = !showKeyBoard.value
}

/**
 * 点击键盘
 * @param item
 */
const onKeyBoardItemClick = (item: IKeyBoardItem) => {
	// console.log("index.vue.onKeyBoardItemClick.item=",JSON.stringify(item));
	if (item.id === 12) {
		// keyBoardValue.value = "";
		showKeyBoard.value = false;
	} else {
		if (keyBoardValue.value.length <= 3) {
			keyBoardValue.value += item.value;
		}
	}
	// console.log("index.vue.onKeyBoardItemClick.finally keyBoardValue.value=", keyBoardValue.value);
};
/**
 * 点击键盘上的删除
 */
const onClickDeleteValue = () => {
	if (!isEmpty(keyBoardValue.value)) {
		keyBoardValue.value = keyBoardValue.value.substring(
			0,
			keyBoardValue.value.length - 1
		);
	}
};

const onClosePointDialog=()=>{
  console.log('index.onClosePointDialog.showPointDialog=', showPointDialog)
  showPointDialog.value=false
  onFinal()
}

const onFinal=()=>{
  showSugarDialog.value = true;
}

</script>


<style lang="less">
.container_sugar {


	.view_root {
		display: flex;
		width: 100%;
		flex-direction: column;
	}

	.view_content {
		display: flex;
		flex-direction: column;
		margin: 20px;
		background: #fff;
		flex: 1;
		overflow: auto;
		border-radius: 15px;

		.round {
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: center;


			.unit {
				height: 70px;
				font-size: 50px;
				margin-top: 10px;
			}

			.input {
				height: 100px;
				color: #fff;
				font-weight: bold;
				text-align: center;
				background: transparent;
				max-lines: 1;
				//border-bottom: #fff solid 1px;
				padding: 0;
				font-size: 60px;
			}

			.border {
				height: 1px;
				width: 300px;
				background: #fff;
			}

		}
	}

	.view_round_blue {
		width: 500px;
		border-radius: 50%;
		margin: 70px auto;
		height: 500px;
		background: linear-gradient(229deg, #53C3FF 14%, #0E86FC 85%);
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		color: #fff;
	}

	.view_round_orange {
		width: 500px;
		border-radius: 50%;
		margin: 70px auto;
		height: 500px;
		background: linear-gradient(229deg, #FFCA56 14%, #FF8900 85%);
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		color: #fff;
	}

	.view_round_red {
		width: 500px;
		border-radius: 50%;
		margin: 70px auto;
		height: 500px;
		background: linear-gradient(229deg, #FF5DC2 14%, #F41337 85%);
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		color: #fff;
	}

	.placeholder_input {
		color: #fff;
		font-weight: lighter;
	}


	.view_item {
		display: flex;
		flex-direction: row;
		padding-bottom: 34px;
		margin-left: 25px;
		margin-right: 25px;
		justify-content: space-between;
		border-bottom: #efefee solid 1px;

	}

	.arr_text {
		display: flex;
		align-items: center;
	}

	.view_input {
		display: flex;
		margin: 20px;
		flex-direction: column;
		margin-bottom: 50px;
	}

	.input_remark {
		border: #efefef solid 1px;
		border-radius: 20px;
		width: 640px;
		margin: 20px auto;
		padding: 15px;

	}

	.btn_save {

		margin: 15px;
		background: #64A4F5;
		border-radius: 15px;
		color: white;
	}

	.nut-tabs__content {
		display: none;
	}

	.sugar_dialog {
		position: relative;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;

		img {
			width: 560px;
			height: 520px;
		}

		.sugar_dialog_content {
			display: flex;
			top: 260px;
			padding: 20px;
			width: 74vw;
			flex-direction: column;
			align-items: center;
      position: absolute;


      img{
        width: 70px;
        height: 70px;
        margin-top: 40rpx;
      }

			.sugar_content {
				font-size: 25px;
				height: 100px;
				margin: 20px;
				color: #5D5D5D;
			}

			.sugar_result_btn {
				width: 450px;
				margin: 6px auto;
				height: 80px;
				text-align: center;
				line-height: 80px;
				color: white;
				background: #6AA4FC;
				border-radius: 10px;
			}
		}
	}

	//.pop_root {
	//	display: flex;
	//	flex-direction: column;
	//	width: 100%;
	//margin-top: 20px;

	.pop_key_board {
		display: flex;
		width: 750px;
		height: 568px;
		flex-direction: row;
		align-items: center;
		border-top: #f5f5f5 solid 1px;

		.key_number {
			width: 550px;

		}

		.key_controls {
			display: flex;
			width: 200px;
			height: 568px;
			flex-direction: column;
			justify-content: space-around;
			align-items: center;

			.view_del {
				width: 100%;
				display: flex;
				align-items: center;
				justify-content: center;
				flex: 1;
			}

			.view_save {
				width: 100%;
				background: #6aa4fc;
				display: flex;
				color: white;
				align-items: center;
				justify-content: center;
				flex: 1;
			}
		}
	}

	//}

	.nut-grid-item__text {
		font-size: 44px;
	}
}
</style>
