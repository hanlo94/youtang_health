<template>
  <view class="comp_scale">
    <view class="comp_scale_title">
      <view class="left">{{ title }}</view>
      <view class="center">
        <input :type="inputType" :maxlength="maxLength" v-model="num" :min="min" :max="max"></view>
      <view class="right">{{unit}}</view>
    </view>
    <!--  微信组件  -->
    <view class="loading" v-if="loading">
      <IconFont name="refresh2" color="#8A8484" class="nut-icon-am-rotate nut-icon-am-infinite"></IconFont>
    </view>
    <wxscale v-else :active="num" :min="min" :max="max" :int="int" @change="handleChange"></wxscale>
  </view>
</template>
<script setup lang="ts">
import {computed, nextTick, ref} from "vue";
import { IconFont } from '@nutui/icons-vue-taro';

interface IProps {
  title: string;
  unit:string;
  min:number;
  max:number;
  int:boolean;
  value?:number;
  maxLength?:number;
  inputType?:string;
  loading: boolean;
}

const props = withDefaults(defineProps<IProps>(), {
  int: false,
  inputType: 'digit',
  maxLength: 4,
  loading: true
})

const emits = defineEmits<{
  (e: 'update:value', val: number): void
}>()

const getActive = (()=>{
  if(!props.value || props.value<props.min || props.value>props.max){
    return props.min
  }else{
    return props.value
  }
})

const num = ref(getActive())
const handleChange = (data) => {
  num.value = data.detail.newVal
  emits('update:value', Number(num.value))
}
</script>
<style lang="less">
.comp_scale {
  width: 100%;
  padding: 0 20.4px;
  background: white;

  .loading{
    height: 145px;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .comp_scale_title {
    height: 102px;
    display: flex;
    align-items: center;
    justify-content: space-between;

    .left {
      width: 30%;
      font-size: 33.33px;
      font-weight: normal;
      color: #353535;
      text-align: left;
    }

    .center {
      width: 208px;
      border-bottom: 1px solid #BBBBBB;
      text-align: center;
      color: #64A4F5;
      font-size: 50px;
    }

    .right {
      width: 30%;
      font-size: 33.33px;
      font-weight: normal;
      color: #00000045;
      text-align: right;
    }
  }
}
</style>
