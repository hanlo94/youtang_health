<!-- 
Description：
Created on 2023/9/9
Author :  郭 -->
<template>
  <view style="display: flex;justify-content: flex-end;align-items: center">
    <!--      低1  中 2  高3-->
    <img :src="down" v-if="isNormal === 1" style="height: 15px;width: 15px" alt=""/>
    <text v-else-if="isNormal === 2" style="height: 15px;width: 15px"></text>
    <img :src="up" v-else style="height: 15px;width: 15px" alt=""/>
    <text style="  font-size: 18px;color: #333333;" >{{ sugarValue }}{{showUnity}}</text>
  </view>
</template>
<script setup lang="ts">

import imgUrlFormat from "@/utils/imgUtils";

const up = imgUrlFormat('sugar/up.png')
const down = imgUrlFormat('sugar/down.png')




defineProps({
  sugarValue: {
    type: Number,
    default: 0,
    required: true
  },
  isNormal: { // 低1  中 2  高3
    type: Number,
    default: 2,
    required: true
  },
  showUnity: {//是否展示单位
    type: String,
    default: '',
  }

})

</script>

<style scoped lang="less">

</style>