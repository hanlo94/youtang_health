import {ref} from "vue";

export interface TimeOutCallback {
    (): void
}

const timer = ref<number>(0)

/**
 * 扫描计时器
 * @param timeOutCallBack
 * @param timeout 默认10s超时
 */
export const startTimer = (timeOutCallBack: TimeOutCallback | null = null, timeout: number = 20000) => {
    console.log('index.startTimer.current time is ', Date.now(),'; timeout=',timeout)
    // @ts-ignore
    timer.value = setTimeout(() => {
        clearTimer()
        timeOutCallBack && timeOutCallBack()
    }, timeout)
}

export const clearTimer = () => {
    console.log('Timer.clearTimer. timer.value=', timer.value)
    if (timer.value) {
        clearInterval(timer.value)
        timer.value = 0
    }
}


const heartCheck = ref<number>(0)

/**
 * 扫描计时器
 * @param callback
 * @param timeout 单位 ms ,默认50s超时
 */
export const startHeartCheck = (callback: TimeOutCallback, timeout: number = 30000) => {
    console.log('index.startHeartCheck.current time is ', Date.now())
    // @ts-ignore
    heartCheck.value = setInterval(() => {
        console.log('Timer.heartCheck timeout and restart.',Date.now(),' heartCheck.value=',heartCheck.value)
        clearHeartCheck()
        callback()
    }, timeout)

}


export const clearHeartCheck = () => {
    console.log('Timer.clearHeartCheck.heartCheck.value=', heartCheck.value)
    // if (heartCheck.value) {
        clearInterval(heartCheck.value.valueOf())
        // heartCheck.value = 0
    // }
}

