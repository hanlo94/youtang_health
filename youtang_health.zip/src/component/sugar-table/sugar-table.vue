<!--
Description：
Created on 2023/9/10
Author :  郭 -->
<template>
	<view class="table">
		<view class="tab_parent color_bg ">
			<view class="tab_item_title item_hight ">日期</view>
			<view class="tab_item_title item_hight">凌晨</view>
			<view class="tab_item_title item_column">
				<view>早餐</view>
				<view class="food_time">
					<view class="child_item right_line">前</view>
					<view class="child_item ">后</view>
				</view>
			</view>
			<view class="tab_item_title item_column">
				<view>午餐</view>
				<view class="food_time">
					<view class="child_item right_line">前</view>
					<view class=" child_item ">后</view>
				</view>
			</view>
			<view class="tab_item_title item_column">
				<view>晚餐</view>
				<view class="food_time">
					<view class="child_item right_line">前</view>
					<view class="child_item ">后</view>
				</view>
			</view>
			<view class="tab_item_title item_hight">睡前</view>
			<view class="tab_item_title none_line item_hight">随机</view>
		</view>
		<!--    此处替换3位datalist-->
		<view class="tab_parent none_top_line" v-for="(item,index) in recordList" :key="index">
			<view class="tab_item_title item_hight ">{{ item.date }}</view>
			<sugar-color-text class="tab_item_title item_hight "
							  :sugar="mapper(item.earlyMorningRecord)"></sugar-color-text>
			<view class="data_item  ">
				<sugar-color-text class="right_line" :sugar="mapper(item.beforeBreakfastRecord)"
								  :is-empty="true"></sugar-color-text>
				<sugar-color-text :sugar="mapper(item.afterBreakfastRecord)"></sugar-color-text>
			</view>
			<view class="data_item  ">
				<sugar-color-text class="right_line" :sugar="mapper(item.beforeLunchRecord)"></sugar-color-text>
				<sugar-color-text :sugar="mapper(item.afterLunchRecord)"></sugar-color-text>
			</view>
			<view class="data_item ">
				<sugar-color-text class="right_line" :sugar="mapper(item.beforeDinnerRecord)"></sugar-color-text>
				<sugar-color-text :sugar="mapper(item.afterDinnerRecord)"></sugar-color-text>
			</view>
			<sugar-color-text class="tab_item_title item_hight"
							  :sugar="mapper(item.beforeSleepRecord)"></sugar-color-text>
			<sugar-color-text class="tab_item_title item_hight none_line " :sugar="mapper(item.randomTimeRecord)">
			</sugar-color-text>
		</view>
		<view v-if="isEmpty(recordList)" class="no_data">
			暂时还没有数据哦~
		</view>
	</view>
</template>
<script setup lang="ts">

import SugarColorText from "@/component/sugar-table/sugar-color-text.vue";
import {SugarRecord, SugarTableRecord} from "@/pagesSugarAnalysis/ts/types";
import {isEmpty} from "lodash";


interface Props {
	recordList: Array<SugarTableRecord>;
}

withDefaults(defineProps<Props>(), {
	recordList: () => []
});

const mapper = (record: SugarRecord) => {
	if (record) {
		return record.value
	} else return null
}

</script>

<style lang="less">

.table {
	.tab_parent {
		height: 68px;
		display: flex;
		border: #BBBBBB solid 1px;


		.tab_item_title {
			flex: 1;
			text-align: center;
			color: #333333;
			font-size: 24px;

			border-right: #BBBBBB solid 1px;


		}

		.item_column {
			display: flex;
			flex-direction: column;

			.food_time {
				display: flex;

				.child_item {
					flex: 1;
					border-top: #BBBBBB solid 1px;
				}
			}
		}

		.none_line {
			border-right: none;
		}

		.item_hight {
			line-height: 68px;
		}


	}

	.color_bg {
		background-color: #EBF6FF;
	}

	.data_item {
		flex: 1;
		text-align: center;
		color: #333333;
		line-height: 68px;
		font-size: 24px;
		display: flex;
		border-right: #BBBBBB solid 1px;

		view {
			flex: 1;
		}
	}

	.right_line {
		border-right: #BBBBBB solid 1px;
	}

	.none_top_line {
		border-top: none;
	}

	.no_data{
		align-content: center;
		align-items: center;
		text-align: center;
		color: #666666;
		font-size: 26px;
	}
}
</style>
