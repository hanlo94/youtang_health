<!--
Description：
Created on 2023/9/25
Author :  郭 -->
<template>

<!--  空腹-->
  <view v-if="fpg">
    <view style="color:#ED8E36 " v-if="sugar<= 4.4">{{sugar=== 0 ? '' :sugar}}</view>
    <view style="color:#64A4F5 " v-else-if="sugar> 4.4 && sugar <7">{{sugar=== 0 ? '' :sugar}}</view>
    <view style="color:#DD3542 " v-else>{{sugar=== 0 ? '' :sugar}}</view>
  </view>
  <view v-else>
    <view style="color:#ED8E36 " v-if="sugar<= 4.4">{{sugar=== 0 ? '' :sugar}}</view>
    <view style="color:#64A4F5 " v-else-if="sugar> 4.4 && sugar <10">{{sugar=== 0 ? '' :sugar}}</view>
    <view style="color:#DD3542 " v-else>{{sugar=== 0 ? '' :sugar}}</view>
  </view>

</template>
<script setup lang="ts">

interface IProps {
	sugar?:number;
	fpg?:boolean;
}

const props = withDefaults(defineProps<IProps>(), {
	fpg: false
})

</script>

<style scoped lang="less">

</style>
