<template>
  <view class="title_box">
    <text class="title">{{ title }}</text>
    <navigator v-if="actionType === 'navigator'" class="more_action" :url="url"  hover-class="none">
      <text>查看更多</text>
      <image src="@/assets/image/common/fold.png"></image>
    </navigator>
    <view v-else class="more_action" @click.stop="doAction">
      <text>换一批</text>
      <image :class="[loading?'loading_animation':'']" src="@/assets/image/common/reload.png" mode="heightFix"></image>
    </view>
  </view>
</template>
<script setup lang="ts">
import {ref} from "vue";

type Props = {
  title: string;
  actionType: 'navigator' | 'refresh';
  url?:string;
  func?: () => Promise<any>
}
const props = withDefaults(defineProps<Props>(), {})

const loading = ref(false)

const doAction = () => {
  if (props.func) {
    loading.value = true;
    setTimeout(()=>{
      loading.value = false
    },1000)
    props.func().finally(() => {
      loading.value = false
    })
  }
}
</script>

<style lang="less">
.title_box {
  width: 100%;
  display: flex!important;
  justify-content: space-between;
  align-items: center;

  .title {
    font-size: 33.33px;
    font-weight: 600;
  }

  .more_action {
    display: flex;
    justify-content: center;
    align-items: center;

    > text {
      font-size: 30.56px;
      font-weight: normal;
      margin-right: 11.11px;
    }

    > image {
      width: 30.56px;
      height: 30.56px;
    }
  }
}

.loading_animation {
  //定义动画名,持续时间,动画状态,以及持续运行
  animation: rotate 1s infinite linear;
  //控制暂停和播放
  animation-play-state: play;
}

@keyframes rotate {
  form {
    transform: rotate(0);
  }

  to {
    transform: rotate(360deg);
  }
}

</style>
