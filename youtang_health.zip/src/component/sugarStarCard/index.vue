<template>
  <view class="container_star" @click.stop="gotoDetailPage">
    <image class="avatar" :src="item.thumb" mode="aspectFill" ></image>
    <text class="name mt">{{item.name}}</text>
    <text class="status mt">{{item.sickLength}}｜{{item.diabetesType}}</text>
  </view>
</template>
<script setup lang="ts">
import Taro from "@tarojs/taro";
import PageNavigation from "@/utils/pageNavigation";

type Props = {
  item:any
}
const props = withDefaults(defineProps<Props>(), {})

const gotoDetailPage = ()=>{
	console.log("index.vue.gotoDetailPage.",props.item.url);
	PageNavigation.navigationToWebView(props.item.url)
  // item.url
  // Taro.navigateTo({
  //   url: `/pages/webview/index?src=${encodeURIComponent(props.item.url)}&title=`
  // })
}
</script>
<style lang="less">
.container_star{
  width: 250px;
  height: 353.47px;
  background: white;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  border-radius: 16.67px;

  .avatar{
    width: 119.68px;
    height: 119.68px;
    border-radius: 100%;
    background: #64A4F5;
    object-fit: cover;
  }
  .name{
    font-size: 30.59px;
    color: #353535;
    margin-top: 21.28px;
  }
  .status{
    font-size: 27.93px;
    color: #5F5F5F;
    margin-top: 21.28px;
  }
}

</style>
