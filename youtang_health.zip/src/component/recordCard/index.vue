<template>
  <view class="box">
    <navigator class="left_box" :url="recordUrl" hover-class="none">
      <view class="title_box">
        <slot name="icon"></slot>
        <view>{{ title }}</view>
<!--        <view v-if="showBindStatus" :class="[bindStatus === 1?'bind':'unbind']">-->
<!--          {{ bindStatus === 1 ? '已绑定' : '未绑定' }}-->
<!--        </view>-->
      </view>
      <view class="slot">
        <slot>{{ emptyText }}</slot>
      </view>

    </navigator>
    <navigator class="right_box" :url="addUrl" hover-class="none" v-if="addUrl">
      <image mode="widthFix" class="add_icon" :src="imgUrlFormat('sugar/add_lg.png')"></image>
      <view class="add_text">添加</view>
    </navigator>
  </view>
</template>

<script lang="ts" setup>
import {computed} from "vue";
import imgUrlFormat from "@/utils/imgUtils";

type Props = {
  title: string;
  emptyText: string;
  addUrl?: string;
  recordUrl: string;
  showBindStatus?: boolean;
  bindStatus?: number;
}
const props = withDefaults(defineProps<Props>(), {
  bindStatus: 0
})

const img = computed(() => {
  if (props.icon) {
    console.log(props.icon)
    // const i =  import(props.icon)
    // console.log(i)
  }

})

</script>
<style lang="less">
.box {
  width: 100%;
  height: auto;
  border-radius: 8.335px;
  background: #FFFFFF;

  padding: 33px 20px;

  box-sizing: border-box;

  display: flex !important;
  flex-direction: row;
  justify-content: space-between;

  .title_box {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: flex-start !important;

    font-size: 33px;
    font-weight: 600;
  }


  .left_box {
    flex: 1;
  }

  .icon {
    width: 44px;
    height: 44px;
    margin-right: 11px;
  }


  .bind {
    border-radius: 5.56px;

    /* 64A4F5主色调 */
    background: #64A4F5;
    color: white;
    font-size: 25px;
    padding: 2px 11px;
    margin-left: 11px;
  }

  .unbind {
    background: #BBBBBB;
    color: white;
    border-radius: 5.56px;
    font-size: 25px;
    padding: 2px 11px;
    margin-left: 11px;
  }

  .none {
    display: none;
  }

  .slot {
    font-size: 29.17px;
    font-weight: normal;
    margin-top: 26px;
  }

  .default {
    font-size: 29.17px;
    font-weight: normal;
    color: #5F5F5F;
    margin-top: 26px;
  }

  .right_box {
    width: 80px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
  }

  .add_icon {
    width: 65px;
    height: 65px;
  }

  .add_text {
    font-size: 29px;
    margin-top: 12px;
    color: #5F5F5F;
  }

}


</style>
