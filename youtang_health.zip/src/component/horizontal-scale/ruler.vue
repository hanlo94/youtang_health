<!--
Description：
Created on 2023/9/16
Author :  郭 -->
<template>
  <div class="compo-ruler">
    <div class="num">
      <div class="num-in">
        <span ref="numRef" id="num">0.0{{state.unit}}</span>
      </div>
    </div>
    <div class="ruler" data-offset="0">
      <div ref="rulerRef" id="ruler" class="ruler-content">
        <div id="leftBlank" class="leftBlank"></div>
        <ul ref="rulerUlRef" id="ruler-ul" class="ruler-ul">
          <li class="marker" v-for="(item ,index) in state.marks" :key="index">
          <span>{{item}}</span>
          </li>
        </ul>
        <div id="rightBlank" class="rightBlank">
          <span>{{state.max}}</span>
        </div>
      </div>
      <div class="pointer"></div>
    </div>
    <div class="mask"></div>
  </div>
</template>
<script setup lang="ts">
import {nextTick, onMounted, reactive, ref} from "vue";

const state = reactive({
  step: 1, // 刻度步长
  min: 0, // 最小刻度值
  max: 100, // 最大刻度值
  marks: [],
  unit: "g/L", // 单位

});

const numRef = ref();
    const rulerUlRef = ref();
    const rulerRef = ref();

function setMarkers() {
  const {step, min, max} = state;
  let arr = [];
  console.log("step", step);
  for (let i = 0; i < Math.ceil(max / step); i++) {
    arr.push(i * step);
  }
  state.marks = arr
  console.log(" state.marks",  state.marks.length);
}

const init = () => {
  const {max, unit} = state;
  setMarkers();

  console.log('1--->',rulerUlRef.value)
  rulerRef.value?.addEventListener(
      "touchmove",
      function () {
        let rulerLength = rulerUlRef.value?.width;
        console.log(rulerLength)
        //上一次计算出的刻度尺移动距离
        var offset = rulerRef.value?.scrollLeft;
        let movePercent = (offset / rulerLength).toFixed(4);
        // 滑动到底
        if (rulerRef.value.scrollWidth - rulerRef.value.scrollLeft === rulerRef.value.clientWidth) {
          movePercent = 1;
        }
        if (movePercent >= 0 && movePercent <= 10) {
          numRef.value.innerText = (movePercent * max).toFixed(1) + unit;
        }
        console.log("offset",offset);
        console.log("numRef.innerText",numRef.value.innerText);
      },
      true
  );

};
onMounted(async () => {
await nextTick();
  init();
})


</script>

<style lang="less">
.compo-ruler {
  width: 630px;
  height: 500px;
  position: relative;
  margin: 0 auto;
  margin-top: 200px;
  overflow: hidden;

  .mask {
    width: 100%;
    height: 200px;
    position: absolute;
    left: 0;
    top: 0;
    pointer-events: none;
    background: linear-gradient(90deg, rgba(255, 255, 255, 1) 0%, rgba(255, 255, 255, 0) 50%, rgba(255, 255, 255, 1) 100%);
  }

  .num {
    display: inline-block;
    padding: 1.6px;
    line-height: 72px;
    text-align: center;
    border-radius: 20px;
    font-size: 36px;
    color: #FFFFFF;
    position: relative;
    left: 50%;
    transform: translateX(-50%);
    margin-bottom: 20px;
    background-image: linear-gradient(319deg, #48bb7f 0%, #95da58 100%);

    .num-in {
      width: 100%;
      height: 100%;
      background: #46c26b;
      border-radius: 20px;

      span {
        padding: 0 16px;
      }
    }
  }

  .ruler {
    width: 100%;
    height: 100%;
    position: relative;

    .pointer {
      position: absolute;
      left: 50%;
      top: 0px;
      width: 4px;
      height: 40px;
      background: #44BA45;
      border-radius: 2px;
      transform: translateX(-50%);
    }
  }

  .ruler-content {
    width: 100%;
    height: 100%;
    position: relative;
    overflow-x: scroll;
    display: flex;
  }

  .ruler-ul {
    height: 200px;
    display: inline-flex;
    flex-shrink: 0;

    li:first-of-type {
      border-left: 2px solid #5D5D5D;
    }
  }

  .leftBlank {
    width: 50%;
    height: 1px;
    flex-shrink: 0;
  }

  .rightBlank {
    width: 50%;
    height: 1px;
    flex-shrink: 0;

    span {
      position: relative;
      top: 44px;
      left: -14px;
      font-size: 28px;
      color: #CCCCCC;
    }
  }

  .ruler-ul .marker {
    flex-shrink: 0;
    width: 100px;
    height: 24px;
    border-right: 2px solid #113344;
    border-top: 2px solid #5D5D5D;
    position: relative;
    box-sizing: border-box;

  }

  .ruler-ul .marker::before {
    content: '';
    position: absolute;
    left: 50%;
    width: 2px;
    height: 8px;
    background: #5D5D5D;
  }

  .ruler-ul .marker span {
    position: relative;
    top: 44px;
    left: -14px;
    font-size: 28px;
    color: #CCCCCC;
  }
}


</style>
