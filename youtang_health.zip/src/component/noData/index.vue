<template>
  <view class="comp_no_data">
    <view class="inner">
      <image mode="aspectFit" :src="imgUrlFormat('common/nodata.png')"></image>
      <view class="sl"><slot>未搜索到相关内容</slot></view>
    </view>
  </view>
</template>
<script setup lang="ts">

import imgUrlFormat from "@/utils/imgUtils";
</script>

<style lang="less">
.comp_no_data{
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;

  .inner{
    width: 100%;
    display: flex;
    align-items: center;
    flex-direction: column;

    image{
      width: 70%;
      margin: 0 auto;
    }
    .sl{
      font-size: 28rpx;
      font-weight: normal;
      line-height: 20.74px;
      text-align: center;
      color: #5F5F5F;
    }
  }


}
</style>
