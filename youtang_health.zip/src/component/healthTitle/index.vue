<script setup lang="ts">
import {ref, watch} from "vue";

interface IProps {
  title: string;
  status: string;
  value: number;
  color: string;
}

const props = withDefaults(defineProps<IProps>(), {})

const style = ref({
  background:props.color
})

watch(()=>props.value,()=>{
  style.value.background = props.color
})

</script>

<template>
  <view class="comp_title">
    <view class="title">
      <view class="left">{{ title }}</view>
      <view class="right">
        <view class="status" :style=style>{{ status }}</view>
        <view class="num">{{ value }}</view>
      </view>
    </view>
    <view class="content">
      <slot></slot>
    </view>

  </view>
</template>

<style lang="less">
.comp_title {
  width: 100%;

  background: white;
  padding: 0 20.4px;

  .title {
    height: 102px;
    display: flex;
    align-items: center;
    justify-content: space-between;

    .left {
      font-size: 33.33px;
      font-weight: normal;
      color: #353535;
    }

    .right {
      display: flex;
      align-items: center;

      .status {
        font-size: 22.22px;
        color: white;
        padding: 5.5px 21px;
        border-radius: 22.92px;
        margin-right: 11.2px;
      }

      .num {
        font-size: 33.33px;
        color: #353535;

      }

      .ok {
        background: #64A4F5;
      }

      .fail {
        background: #DD3542;
      }


    }
  }

  .content {
    font-size: 31.94px;
    color: #5F5F5F;
    line-height: 38.19px;
  }
}
</style>
