<template>
  <view>
    <nut-popup position="center" v-model:visible="pointDialogVisible" :style="{ height: '50%' }"
               style="background: transparent">
      <view class="signin-dialog">
        <view class="dialog-pop">
          <img class=bg :src="bgImg"/>
          <view class="dialog_content">
            <view class="content vertical">
              <view class="horizontal" style="justify-content: center">
                奖励您
                <text style="color:#4aa4fc;font-size: 36rpx ">{{ props.rewards }}</text>
                个积分
              </view>
              <view>{{ rewardTips }}</view>
            </view>
            <view class="btn" @click="onCloseSignInDialog">开心收下</view>
          </view>
        </view>
        <img class="close" :src="imgUrlFormat('point/close.png')" @click.stop="onCloseSignInDialog"/>
      </view>
    </nut-popup>
  </view>
</template>
<script setup lang="ts">
import {computed, onMounted, ref, watch} from "vue";
import imgUrlFormat from "@/utils/imgUtils";

const pointDialogVisible = ref(false);

const rewardTips = computed(() => {
  return props.dialogType === 1 ? '连续签到送额外积分～' : '继续保持记录的好习惯哦～'
})

const bgImg = computed(() => {
  return props.dialogType === 1 ? imgUrlFormat('point/pop1.png') : imgUrlFormat('point/pop2.png')
})

interface IProps {
  showPointDialog: boolean
  // 1 签到 2 奖励积分
  dialogType: number,
  rewards: string,
}

const props = withDefaults(defineProps<IProps>(), {
  showPointDialog: false,
  dialogType: 2,
})

watch(() => props.showPointDialog, () => {
  pointDialogVisible.value = props.showPointDialog
})

const emits = defineEmits(['closeDialog'])

const onCloseSignInDialog = () => {
  console.log('index.onCloseSignInDialog.')
  pointDialogVisible.value = false
  emits('closeDialog', {},);
}

</script>

<style lang="less">
.signin-dialog {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;

  .dialog-pop {
    display: flex;
    position: relative;
    box-sizing: border-box;
    align-items: center;
    justify-content: center;

    .bg {
      width: 566px;
      height: 553px;
    }

    .dialog_content {
      position: absolute;
      display: flex;
      top: 240px;
      width: 70vw;
      flex-direction: column;
      align-items: center;

      .content {
        font-size: 32rpx;
        height: 94rpx;
        margin: 40px 20px 10px 20px;
        color: #5D5D5D;
      }

      .btn {
        width: 502px;
        margin: 20px;
        height: 90px;
        text-align: center;
        line-height: 90px;
        color: white;
        background: #6AA4FC;
        border-radius: 16px;
      }
    }

  }

  .close {
    width: 70rpx;
    height: 70rpx;
    position: absolute;
    bottom: 0;
    left: calc(50% - 35rpx);
  }

}

</style>
