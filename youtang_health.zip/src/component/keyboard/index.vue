<template>
	<view>
		<nut-popup :position="position" :overlay=false :catch-move="true" v-model:visible="keyBoardVisible">
			<!--				<view class="pop_root">-->
			<view class="pop_key_board">
				<view class="key_number">
					<nut-grid :column-num="3">
						<nut-grid-item
							:text="item.value"
							v-for="(item, index) in keyBoardList"
							:key="index"
							@click="onKeyBoardItemClick(item)"
						>
							<img v-if="item.id === 12" :src="keyBoardDown"
								 style="width: 20px;height: 20px;margin-top: 15px"/>
						</nut-grid-item>
					</nut-grid>
				</view>
				<view class="key_controls">
					<view class="view_del" @click="onClickDeleteValue">
						<img :src="keyBoardDel" style="width: 20px;height: 20px"/></view>
					<view class="view_save" @click.stop="onClickSubmit">保存</view>
				</view>
			</view>
			<!--				</view>-->
		</nut-popup>
	</view>
</template>
<script setup lang="ts">

import imgUrlFormat from "@/utils/imgUtils";
import {IKeyBoardItem, keyBoardList} from "@/pagesFood/ts/optionsUtils";
import {isEmpty} from "lodash";
import {ref} from "vue/dist/vue";
import {watch} from "vue";


interface IProps {
	position: string,
	showKeyBoard: boolean,
	value?: string
}

let props = withDefaults(defineProps<IProps>(), {
	position: 'center',
	showKeyBoard: false,
	value: ""
})

watch(() => props.showKeyBoard, () => {
	keyBoardVisible.value = props.showKeyBoard
})

watch(() => props.value, () => {
	keyBoardValue.value = props.value
})

const emits = defineEmits<{
	(e: 'onValueChange', val: number): void
	(e: 'onSubmit', val: number): void
}>()

/**
 * 键盘上的文字
 */
const keyBoardValue = ref("");
const keyBoardVisible = ref(false);
const keyBoardDel = imgUrlFormat('sugar/food/keyboard_del.png')
const keyBoardDown = imgUrlFormat('sugar/food/keyboard_down.png')

/**
 * 点击键盘
 * @param item
 */
const onKeyBoardItemClick = (item: IKeyBoardItem) => {
	// console.log("index.vue.onKeyBoardItemClick.item=",JSON.stringify(item));
	if (item.id === 12) {
		// keyBoardValue.value = "";
		keyBoardVisible.value=false
	} else {
		if (keyBoardValue.value.length <= 3) {
			keyBoardValue.value = keyBoardValue.value += item.value;
		}
	}
	// console.log("index.vue.onKeyBoardItemClick.finally keyBoardValue.value=", keyBoardValue.value);
};

/**
 * 点击键盘上的删除
 */
const onClickDeleteValue = () => {
	if (!isEmpty(keyBoardValue.value)) {
		keyBoardValue.value = keyBoardValue.value.substring(
			0,
			keyBoardValue.value.length - 1
		);
		emits('onValueChange', Number(keyBoardValue.value))
	}
};

const onClickSubmit=()=>{
	console.log("index.vue.onClickSubmit.keyBoardValue.value=", keyBoardValue.value);
	emits('onSubmit', Number(keyBoardValue.value))
}

</script>

<style lang="less">

</style>
