
/**
 * 日历日期状态
 */
export interface ICalendarDateStatus {
	date: string;
	/**
	 * 状态值 0 无数据 1 偏低 2 正常 3偏高
	 */
	state: number;
	calorie: number;
}

export interface ICalendarDate{
	year: number,
	month: number,
	date: number,
	disable: boolean,
	value: string,
	state:number
}
