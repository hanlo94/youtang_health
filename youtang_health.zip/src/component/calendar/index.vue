<template>
	<view class="comp_calendar">
		<view class="calendar">
			<view class="calendar-toolbar">
				<view class="prev" @click="prevMonth">上个月</view>
				<view class="current.value">{{ currentDateStr }}</view>
				<view class="next" @click="nextMonth">下个月</view>
			</view>
			<view class="calendar-week">
				<view class="week-item" v-for="item of weekList" :key="item">{{ item }}</view>
			</view>
			<view class="calendar-inner">
				<view
					class="calendar-item"
					v-for="(item, index) of calendarList"
					:key="index"
					@click.stop="dateSelected(item.value)"
				>
					<view class="date"
						  :class="[item.disable ? 'disabled' : '', item.value==props.selectedDate ? 'checked' : '']">
						{{ item.date }}
					</view>
					<view class="status status_orange" v-if="item.state === 1"></view>
					<view class="status status_blue" v-else-if="item.state === 2"></view>
					<view class="status status_red" v-else-if="item.state === 3"></view>
					<view class="status " v-else></view>
				</view>
			</view>
		</view>
		<view class="bottom_box">
			<view class="left">
				<view class="status_item">
					<view class="status status_orange"></view>
					吃少了
				</view>
				<view class="status_item">
					<view class="status status_blue"></view>
					正常
				</view>
				<view class="status_item">
					<view class="status status_red"></view>
					吃多了
				</view>
			</view>
			<view class="right" @click.stop="reset">回到今天</view>
		</view>
	</view>
</template>
<script setup lang="ts">
import {computed, ref, onMounted, reactive, watch} from "vue";
import {formatDate} from "@/utils/util";
import {ICalendarDate, ICalendarDateStatus} from "@/component/calendar/types";
import {isEmpty} from "lodash";


interface IProps {
	selectedDate: string
	statusDateList: ICalendarDateStatus[]
}

const props = withDefaults(defineProps<IProps>(), {
	selectedDate: formatDate(new Date()),
	statusDateList: () => {
		return [] as ICalendarDateStatus[];
	},
})


const emits = defineEmits(['update:selectedDate', 'change'])

/**
 * 观测状态数据变化 ，发生变化讲日历与状态数据合成一个list
 */
watch(() => props.statusDateList, () => {
		initState()
	}
)

watch(() => props.selectedDate, () => {
		if (!isEmpty(props.selectedDate)) {
			setCurrent(new Date(props.selectedDate))
			calendarCreator()
		}
	}
)

// watch(() => calendarList.value, (newValue, oldValue) => {
// 	emits('change', {startDate: newValue[0].value,date:newValue[newValue.length/2].value, endDate: newValue[newValue.length - 1].value});
// })

const monthChange = () => {
	// console.log("index.vue.monthChange.calendarList.length", calendarList.value.length, '; length/2=', calendarList.value.length / 2,'; value=',calendarList.value[(calendarList.value.length) / 2]);
	emits('change', {
		// startDate: calendarList.value[0].value,
		// 任意取本月当中一天即可
		date: calendarList.value[10].value,
		// endDate: calendarList.value[calendarList.value.length - 1].value
	});
}

const dateSelected = (date) => {
	emits('update:selectedDate', date)
}

const reset = () => {
	dateSelected(formatDate(new Date()))
}

let current = ref({
	year: 2023,
	month: 11,
	date: 11,
	disable: false,
})   // 当前时间
const weekList = ['一', '二', '三', '四', '五', '六', '日']
let calendarList = ref<Array<ICalendarDate>>([] as ICalendarDate[])  // 用于遍历显示
let shareDate = new Date() // 享元模式，用来做优化的

const currentDateStr = computed(() => {
	let {year, month} = current.value;
	return `${year}年${pad(month + 1)}月`;
})

onMounted(() => {
	init();
	initState()
})

const init = () => {
	setCurrent(props.selectedDate?new Date(props.selectedDate):new Date());
	calendarCreator();
}

// 判断当前月有多少天
function getDaysByMonth(year, month) {
	return new Date(year, month + 1, 0).getDate();
}

function getFirstDayByMonths(year, month) {
	return new Date(year, month, 1).getDay();
}

function getLastDayByMonth(year, month) {
	return new Date(year, month + 1, 0).getDay();
}

// 对小于 10 的数字，前面补 0
function pad(str) {
	return str < 10 ? `0${str}` : str;
}

// 点击上一月
function prevMonth() {
	current.value.month--;
	// 因为 month的变化 会超出 0-11 的范围， 所以需要重新计算
	correctCurrent();
	// 生成新日期
	calendarCreator();
	monthChange()
}

// 点击下一月
function nextMonth() {
	current.value.month++;
	// 因为 month的变化 会超出 0-11 的范围， 所以需要重新计算
	correctCurrent();
	// 生成新日期
	calendarCreator();
	monthChange()
}

// 格式化时间，与主逻辑无关
function stringify(year, month, date) {
	let str = [year, pad(month + 1), pad(date)].join('-');
	return str;
}

// 设置或初始化 current.value
function setCurrent(d = new Date()) {
	let year = d.getFullYear();
	let month = d.getMonth();
	let date = d.getDate();
	current.value = {
		disable: false,
		year,
		month,
		date
	}
}

// 修正 current.value
function correctCurrent() {
	let {year, month, date} = current.value;

	let maxDate = getDaysByMonth(year, month);
	// 预防其他月跳转到2月，2月最多只有29天，没有30-31
	date = Math.min(maxDate, date);

	let instance = new Date(year, month, date);
	setCurrent(instance);
}

// 生成日期
function calendarCreator() {
	// 一天有多少毫秒
	const oneDayMS = 24 * 60 * 60 * 1000;

	let list = [] as ICalendarDate[];
	let {year, month} = current.value;

	// 当前月份第一天是星期几, 0-6
	let firstDay = getFirstDayByMonths(year, month);
	// 填充多少天
	let prefixDaysLen = firstDay === 0 ? 6 : firstDay - 1;
	// 毫秒数
	let begin = new Date(year, month, 1).getTime() - oneDayMS * prefixDaysLen;

	// 当前月份最后一天是星期几, 0-6
	let lastDay = getLastDayByMonth(year, month);
	// 填充多少天， 和星期的排放顺序有关
	let suffixDaysLen = lastDay === 0 ? 0 : 7 - lastDay;
	// 毫秒数
	let end = new Date(year, month + 1, 0).getTime() + oneDayMS * suffixDaysLen;

	while (begin <= end) {
		// 享元模式，避免重复 new Date
		shareDate.setTime(begin);
		let year = shareDate.getFullYear();
		let curMonth = shareDate.getMonth();
		let date = shareDate.getDate();
		list.push({
			year: year,
			month: curMonth,
			date: date,
			disable: curMonth !== month,
			value: stringify(year, curMonth, date),
			state: 0
		});
		begin += oneDayMS;
	}

	calendarList.value = list;
	// console.log("index.vue.calendarCreator.",JSON.stringify(calendarList.value));
}

const initState = () => {
	if (!isEmpty(props.statusDateList)) {
		calendarList.value = calendarList.value.map((item, index) => {
			let dateStatus = props.statusDateList.find(statusItem => statusItem.date == item.value);
			return {
				...item,
				state: dateStatus ? dateStatus.state : 0,
			}
		})
	}
}

</script>

<style lang="less">
.comp_calendar {
	width: 100%;
	height: 700px;
	padding: 0 20px;
	box-sizing: border-box;
	display: flex;
	flex-direction: column;
	justify-content: space-between;

	.calendar {
		.calendar-toolbar {
			display: flex;
			width: 100%;
			margin: 0 auto;
			text-align: center;
		}

		.calendar-toolbar .current.value {
			flex: 1;
		}

		.calendar-week {
			display: flex;
			margin-top: 10px;
			text-align: center;
		}

		.calendar-week .week-item {
			flex: 1;
			width: 40px;
		}

		.calendar-inner {
			display: flex;
			flex-direction: row;
			justify-content: space-between; /* 子元素之间的空间平均分布 */
			align-items: stretch; /* 子元素沿行方向拉伸以填充容器 */
			flex-wrap: wrap; /* 如果子元素宽度总和超过容器宽度，则换行 */

			.calendar-item {
				width: 101.39px;
				height: 62px;
				margin-top: 21px;


				display: flex;
				flex-direction: column;
				justify-content: flex-start;
				align-items: center;

				.date {
					color: #5F5F5F;
					width: 44px;
					min-width: 44px;
					height: 44px;
					min-height: 44px;
					border-radius: 50%;
					text-align: center;
					font-size: 29.17px;
					line-height: 44px;
				}

				.disabled {
					color: #bbb;
				}

				.checked {
					color: white;
					background: #64A4F5;
				}
			}
		}
	}

	.bottom_box {
		display: flex;
		justify-content: space-between;
		align-items: center;
		height: 85px;

		.left {
			font-size: 25px;
			color: #5F5F5F;

			display: flex;
			justify-content: center;
			align-items: center;

			.status_item {
				display: flex;
				align-items: center;
				justify-content: center;
				margin-right: 15px;

				.status {
					margin-right: 5px;
					margin-top: 2px;
				}
			}
		}

		.right {
			font-size: 25px;
			color: #64A4F5;
		}
	}

	.status {
		width: 11px;
		height: 11px;
		border-radius: 50%;
		margin-top: 8px;
	}

	.status_orange {
		background: #ED8E36;
	}

	.status_blue {
		background: #64A4F5;
	}

	.status_red {
		background: #DD3542;
	}


}

</style>
