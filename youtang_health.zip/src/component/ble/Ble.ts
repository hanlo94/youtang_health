import {realTimeLogger} from "@/component/realTimeLogger";
import Taro, {Events} from '@tarojs/taro'
import {MagnetDeviceUUID, MagnetScanMeasureState} from "@/pagesComposite/MagnetConstants";
import {showToast, showToastLong} from "@/utils/toastUtils";
import {ref} from "vue";
import {DeviceUUID} from "@/pagesMine/yasiGlm/config/YasiGluConstants";
import {clearTimer, startTimer} from "@/component/Timer";
import {ScaleMeasure} from "@/config/device/bodyfat";

const logger = realTimeLogger()

export function ab2hex(buffer) {
    const hexArr = Array.prototype.map.call(
        new Uint8Array(buffer),
        function (bit) {
            return ('00' + bit.toString(16)).slice(-2)
        }
    )
    return hexArr.join('');
}

export function hex2ArrayBuffer(hexString: string): ArrayBuffer {
    const bytes = hexString.match(/.{1,2}/g)?.map(byte => parseInt(byte, 16)) ?? [];
    const arrayBuffer = new ArrayBuffer(bytes.length);
    const uint8Array = new Uint8Array(arrayBuffer);
    uint8Array.set(bytes);
    return arrayBuffer;
}



const scaleMeasureState = ref<ScaleMeasure>()
const bindState = ref<boolean>(false)

// 是否已连接
const connected = ref<boolean>(false)
// @ts-ignore
const connecting = ref<boolean>(false)
// @ts-ignore
const scanning = ref<boolean>(false)

const connectedDevice = ref()

const event = new Events()

export const BLE_STATE = 'bleState'

const triggerBleState = () => {
    event.trigger(BLE_STATE, scaleMeasureState)
}


// TODO 补充蓝牙状态，连接状态、特征监听和读写监听对外通知


// TODO 补充外部传参 设备过滤条件：设备SN、设备名称、设备服务、


// region 蓝牙权限与蓝牙适配器状态操作

/**
 * 检验蓝牙授权状态
 */
export const checkBlePermission = (silent: boolean = false) => {
    console.log('index.checkBlePermission.silent=', silent)
    Taro.getSetting({
        success(res) {
            logger.log("index.vue.checkBlePermission.getSetting.success.res.authSetting=", res.authSetting);
            if (!res.authSetting['scope.bluetooth']) {
                Taro.authorize({
                    scope: 'scope.bluetooth',
                    success: (res) => {
                        // showShortToast('蓝牙授权成功')
                        logger.log("checkBlePermission.authorize.success.", JSON.stringify(res));
                        openBluetoothAdapter()
                    },
                    fail: (res) => {
                        // showShortToast('蓝牙授权失败')
                        logger.log('蓝牙授权失败', JSON.stringify(res))
                        if (!silent) {
                            showBleAuthorizeModal()
                        }
                        onBleAuthorize()
                    }
                })
            } else {
                // checkBleAdapterState()
                openBluetoothAdapter()
            }
        },
        fail(res) {
            console.log('index.checkBlePermission.fail.', JSON.stringify(res))
            if (!silent) {
                showBleAuthorizeModal()
            }
            onBleAuthorize()
        }
    })
}

/**
 * 校验蓝牙适配器状态
 */
// @ts-ignore
export const checkBleAdapterState = () => {
    Taro.getBluetoothAdapterState({
        success: (res) => {
            console.log("index.vue.checkBleAdapterState.success.", JSON.stringify(res));
            // startScan()
        },
        fail: (failure) => {
            console.log("index.vue.checkBleAdapterState.fail.", JSON.stringify(failure));
            // openBluetoothAdapter()
        }
    })
}

/**
 * 打开蓝牙适配器
 */
export const openBluetoothAdapter = () => {
    const systemSetting = Taro.getSystemSetting()
    const bleEnabled = systemSetting.bluetoothEnabled;
    const locationEnabled = systemSetting.locationEnabled;
    Taro.openBluetoothAdapter({
        success: (res) => {
            logger.log("index.vue.openBluetoothAdapter.success.", JSON.stringify(res));
            if (locationEnabled) {
                startScan()
                updateState(bindState.value ? MagnetScanMeasureState.BIND_TO_SCAN : MagnetScanMeasureState.UNBIND)
            } else {
                updateState(MagnetScanMeasureState.LOCATION_CLOSE)
                showBleDisableModal(MagnetScanMeasureState.LOCATION_CLOSE.subState)
            }
        },
        fail: (res) => {
            logger.log("index.vue.openBluetoothAdapter.fail.", JSON.stringify(res), '; JSON.stringify(res).indexOf(\'openBluetoothAdapter:fail already opened = ', JSON.stringify(res).indexOf('openBluetoothAdapter:fail already opened'));
            if (JSON.stringify(res).indexOf('openBluetoothAdapter:fail already opened') != -1) {
                console.log('index.openBluetoothAdapter,already opened.start scan')
                if (locationEnabled) {
                    startScan()
                    updateState(bindState.value ? MagnetScanMeasureState.BIND_TO_SCAN : MagnetScanMeasureState.UNBIND)
                } else {
                    updateState(MagnetScanMeasureState.LOCATION_CLOSE)
                    showBleDisableModal(MagnetScanMeasureState.LOCATION_CLOSE.subState)
                }
            } else {
                console.log('index.openBluetoothAdapter,failed')
                let str: string
                if (!bleEnabled && !locationEnabled) {
                    str = '手机蓝牙、定位未打开，请先打开手机蓝牙、定位权限'
                } else if (!bleEnabled) {
                    str = MagnetScanMeasureState.BLE_DISABLE.subState
                } else {
                    str = MagnetScanMeasureState.LOCATION_CLOSE.subState
                }
                showBleDisableModal(str)
                onBleDisable()
            }
        },
        complete: () => {
            onBleAdapterState()
        }
    })
}


export const closeBleAdapter = () => {
    Taro.closeBluetoothAdapter({
        success: (res) => {
            logger.log("index.vue.closeConnect.success.", JSON.stringify(res));
        },
        fail: (res) => {
            logger.log("index.vue.closeConnect.fail.", JSON.stringify(res));
        }
    })
}

export const onBleAdapterState = () => {
    Taro.onBluetoothAdapterStateChange(res => {
        if (res.available) {
            // 蓝牙适配器可用
            logger.log("onBluetoothAdapterStateChange 蓝牙适配器可用, scaleMeasureState.value?.state=", scaleMeasureState.value?.state);
            if (scaleMeasureState.value?.state == MagnetScanMeasureState.BLE_DISABLE.state) {
                const systemSetting = Taro.getSystemSetting()
                if (systemSetting.locationEnabled) {
                    updateState(bindState.value ? MagnetScanMeasureState.BIND_TO_SCAN : MagnetScanMeasureState.UNBIND)
                    restart()
                } else {
                    updateState(MagnetScanMeasureState.LOCATION_CLOSE)
                    showToastLong("位置信息未开启，请先打开")
                }
            }
        } else {
            // 蓝牙适配器不可用
            logger.log("onBluetoothAdapterStateChange 蓝牙适配器不可用");
            stopBle(false)
            onBleDisable()
        }
    })
}

//
export const onBleDisable = () => {
    updateState(MagnetScanMeasureState.BLE_DISABLE)
}

export const onBleAuthorize = () => {
    updateState(MagnetScanMeasureState.BLE_AUTHORIZE)
}


export const showBleDisableModal = (str: string | null = null) => {
    Taro.showModal({
        content: str || '手机蓝牙未开启，请先打开手机蓝牙',
        showCancel: false,
        confirmText: '知道了'
    })
}

export const showBleAuthorizeModal = () => {
    Taro.showModal({
        content: '请先打开小程序设置，允许蓝牙授权',
        showCancel: false,
        confirmText: '知道了',
        success: () => {
            Taro.openSystemBluetoothSetting({
                success: (res) => {
                    console.log('index.showBleAuthorizeModal.BLE_AUTHORIZE.success.res=', JSON.stringify(res))
                }
            })
            // Taro.openSetting({
            //   success: (res) => {
            //     console.log('index.showBleAuthorizeModal.BLE_AUTHORIZE.success.res=', JSON.stringify(res))
            //   }
            // })
        }
    })
}

// region  扫描与连接

const startScan = () => {
    console.log('index.startScan.')
    Taro.startBluetoothDevicesDiscovery({
        allowDuplicatesKey: false,
        services: [
            MagnetDeviceUUID.MAGNET_UUID
        ],
        complete: (res) => {
            // 扫描结束
            logger.log("startScan 开启扫描结束 ", JSON.stringify(res));
        },
        success: (res) => {
            console.log('index.startScan.success.', JSON.stringify(res))
            scanning.value = true
            onBluetoothDeviceFound(res)
            updateState(bindState.value ? MagnetScanMeasureState.BIND_SCANING : MagnetScanMeasureState.UNBIND_SCANING)
            //TODO 扫描超时
            startTimer(() => {
                console.log('Ble.scan time out.')
            });
            showToastLong("开始扫描治疗仪")
        },
        fail: (res) => {
            logger.log("index.vue.startScan.fail.", JSON.stringify(res), '; res.errMsg=', res.errMsg, ';res.errMsg.indexOf(\'already discovering devices\') != -1=', (res.errMsg.indexOf('already discovering devices') != -1));
            if (res.errMsg && res.errMsg.indexOf('already discovering devices') != -1) {
                // 已开启扫描
                console.log('index.startScan.fail.already stop then start ')
            } else {
                updateState(bindState.value ? MagnetScanMeasureState.BIND_SCAN_FAILURE : MagnetScanMeasureState.UNBIND_SCAN_FAILURE)
                logger.log('index.start scan fail. update state', scaleMeasureState.value?.mainState)
            }
        }
    })
}

const stopScan = (callback) => {
    console.log('index.stopScan.scanning.value=', scanning.value)
    if (scanning.value) {
        console.log('index.stopScan.scanning.value=', scanning.value)
        Taro.stopBluetoothDevicesDiscovery({
            success: (res) => {
                logger.log("index.vue.stopScan.success.", JSON.stringify(res));
                scanning.value = false
                callback && callback()
            },
            fail: (res) => {
                logger.log("index.vue.stopScan.fail.", JSON.stringify(res));
            },
            complete: (res) => {
                console.log('index.complete.stopBluetoothDevicesDiscovery', JSON.stringify(res))
            }
        })
    } else {
        callback && callback()
    }
}

/**
 * 扫描发现治疗仪监听
 * @param res
 */
const onBluetoothDeviceFound = (res) => {
    console.log('index.onBluetoothDeviceFound.', JSON.stringify(res))
    Taro.onBluetoothDeviceFound((res) => {
        res.devices.forEach(device => {
            if (!device.name && !device.localName) {
                console.log('index.onBluetoothDeviceFound 过滤设备名称为空')
                return
            }
            if (device.name.indexOf("未知") != -1) {
                console.log('index.onBluetoothDeviceFound 过滤 设备名称异常')
                return;
            }
            if (!device.advertisServiceUUIDs || device.advertisServiceUUIDs.length === 0) {
                console.log('index.onBluetoothDeviceFound 过滤开放服务为空 deviceId=', device.deviceId)
                return
            }
            //     "00001808-0000-1000-8000-00805f9b34fb",
            //     "0000180a-0000-1000-8000-00805f9b34fb"
            if (device.advertisServiceUUIDs.indexOf(DeviceUUID.SERV_GLUCOSE_UUID) != -1 || device.advertisServiceUUIDs.indexOf(DeviceUUID.SERV_GLUCOSE_UUID_UPPER) != -1) {
                console.log('index.onBluetoothDeviceFound index of 发现匹配服务', device.advertisServiceUUIDs)
            } else {
                console.log('index.onBluetoothDeviceFound index of 未找到匹配服务', device.advertisServiceUUIDs)
                return;
            }
            console.log('onBluetoothDeviceFound device=', JSON.stringify(device), '; connectedDevice.value=', connectedDevice.value)
            if (!connectedDevice.value) {
                connectedDevice.value = device
                showToast('扫描成功，找到匹配治疗仪')
                updateState(MagnetScanMeasureState.BIND_SCAN_SUCCESS)
            }
            stopScan(() => {
                console.log('Ble.stop scan .')
            })
            startConnect()
            // const foundDevices = this.data.devices
            // const idx = inArray(foundDevices, 'deviceId', device.deviceId)
            // const data = {}
            // if (idx === -1) {
            //   data[`devices[${foundDevices.length}]`] = device
            // } else {
            //   data[`devices[${idx}]`] = device
            // }

        })
    })
}

const startConnect = () => {
    if (connected.value) {
        // 已连接
        logger.log("startConnect 已连接 不重复连接")
        return
    }
    if (!connecting.value) {
        connecting.value = true
    } else {
        // 连接中
        logger.log("startConnect 连接中不重复连接")
        return
    }
    updateState(MagnetScanMeasureState.CONNECTING)
    console.log('index.startConnect.device.value=', connectedDevice.value)
    let {deviceId} = connectedDevice.value
    Taro.createBLEConnection({
        deviceId,
        success: function (res) {
            console.log('index.createBLEConnection.success.', JSON.stringify(res))
            onConnectionStateChange()
        },
        fail: function (res) {
            console.log('index.startConnect.createBLEConnection.fail.', JSON.stringify(res))
            updateState(MagnetScanMeasureState.CONNECT_FAILURE)
        }
    })

}

const onConnectFailure = () => {
    logger.log("onConnectFailure.")
    connected.value = false
    connecting.value = false
    updateState(MagnetScanMeasureState.LOST_CONNECT)
}

const onConnectSuccess = () => {
    console.log('index.onConnectSuccess.')
    connected.value = true
    updateState(MagnetScanMeasureState.CONNECT_SUCCESS)
    startMeasure()
}

const onConnectionStateChange = () => {
    console.log('index.onConnectionStateChange.')
    Taro.onBLEConnectionStateChange((res) => {
        console.log('onConnectionStateChange', `device ${res.deviceId} state has changed, connected: ${res.connected}`)
        if (res.connected) {
            onConnectSuccess()
        } else {
            onConnectFailure()
        }
    })
}

const offBLEConnectionStateChange = () => {
    Taro.offBLEConnectionStateChange((res) => {
        console.log('onConnectionStateChange', `device ${res.deviceId} state has changed, connected: ${res.connected}`)
    })
}

const startMeasure = () => {
    console.log('index.startMeasure.')
    let {deviceId} = connectedDevice.value
    Taro.getBLEDeviceServices({
        deviceId,
        success: (res) => {
            console.log('index.getBLEDeviceServices.success.', JSON.stringify(res))
            // 查找特定服务 ，找到继续查找特征值，找不到直接反馈失败
            let bleService;
            if (res.services && res.services.length > 0) {
                bleService = res.services.find(service =>
                    service.uuid.indexOf(DeviceUUID.SERV_GLUCOSE_UUID_PREFIX) != -1
                );
            }
            if (bleService) {
                updateState(MagnetScanMeasureState.BIND_MEASURING)
                showToastLong("开始测量")
                getBleCharacteristics(deviceId, bleService.uuid)
            } else {
                updateState(MagnetScanMeasureState.SERVICE_NOT_FOUND)
            }

        },
        fail: (res) => {
            logger.log('index.getBLEDeviceServices.fail.', JSON.stringify(res))
            updateState(MagnetScanMeasureState.SERVICE_NOT_EXIST)
        }
    })
}

const getBleCharacteristics = (deviceId: string, serviceId: string) => {
    Taro.getBLEDeviceCharacteristics({
        deviceId,
        serviceId,
        success: (res) => {
            console.log('index.getBLEDeviceCharacteristics.success.', JSON.stringify(res))
            let characteristic
            if (res.characteristics && res.characteristics.length > 0) {
                characteristic = res.characteristics.find(characteristic =>
                    characteristic.uuid.toUpperCase().indexOf(DeviceUUID.GLUCOSE_MEAS_UUID) != -1
                );
            }
            if (characteristic) {
                // 找到特征值
                console.log('index.getBLEDeviceCharacteristics.success. 找到特征值', JSON.stringify(characteristic))
                // 开始读特征值
                notifyCharacteristicValueChange(deviceId, serviceId, characteristic.uuid)
            } else {
                updateState(MagnetScanMeasureState.SERVICE_NOT_FOUND)
            }
        },
        fail: (res) => {
            logger.log('index.getBLEDeviceCharacteristics.fail.', JSON.stringify(res))
            updateState(MagnetScanMeasureState.SERVICE_NOT_EXIST)
        }
    })
}

const notifyCharacteristicValueChange = (deviceId: string, serviceId: string, uuid: string) => {
    Taro.notifyBLECharacteristicValueChange({
        state: true,
        deviceId,
        serviceId,
        characteristicId: uuid,
        success: (res) => {
            logger.log('index.notifyBLECharacteristicValueChange.success.', JSON.stringify(res))
            onCharacteristicValueChange()
        },
        fail: (res) => {
            logger.log('index.notifyBLECharacteristicValueChange.fail.', JSON.stringify(res))
        }
    })
}

const onCharacteristicValueChange = () => {
    logger.log("onCharacteristicValueChange.")
    Taro.onBLECharacteristicValueChange((res) => {
        let hexString = ab2hex(res.value);
        logger.log(`onBLECharacteristicValueChange.characteristic ${res.characteristicId} has changed, now is ${res.value}`, '; parseValue=', hexString)
        // 470000e707011e0408240000f08a11 TODO 数据分析

        // analysisData(hexString)
    })
}

const offCharacteristicValueChange = () => {
    logger.log("offCharacteristicValueChange.")
    Taro.offBLECharacteristicValueChange((res) => {
        logger.log('index.onBLECharacteristicValueChange', JSON.stringify(res))
    })
}

const disConnect = () => {
    logger.log("disConnect.", connectedDevice.value)
    const {deviceId} = connectedDevice.value
    offBLEConnectionStateChange()
    Taro.closeBLEConnection({
        deviceId,
        success: (res) => {
            logger.log('index.closeBLEConnection.success.', JSON.stringify(res))
            connected.value = false
            connecting.value = false
            connectedDevice.value = null
        },
        fail: (res) => {
            logger.log('index.closeBLEConnection.fail.', JSON.stringify(res))
        }
    })
}


/**
 * 停止蓝牙活动
 * 1、
 * 2、关闭连接
 * 3、停止扫描
 * 4、关闭蓝牙适配器
 */
const stopBle = function (closeBle: boolean = true) {
    if (connected.value) {
        offCharacteristicValueChange()
        disConnect()
    }
    clearTimer()
    stopScan(() => {
        console.log('Ble.stop scan in stop ble.')
    })
    if (closeBle) {
        closeBleAdapter()
    }
}

/**
 * 刷新蓝牙
 */
const restart = () => {
    console.log('index.restart.')
    if (connected.value) {
        offCharacteristicValueChange()
        disConnect()
    }
    stopScan(() => {
        startScan()
    })
}

// endregion

export const updateState = (state) => {
    console.log("index.vue.updateState.", JSON.stringify(state));
    scaleMeasureState.value = state
    triggerBleState()
}