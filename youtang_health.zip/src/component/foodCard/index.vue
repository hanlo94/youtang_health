<script setup lang="ts">
import { IGiItem} from "@/api/types";
type Props = {
  item: IGiItem
}
const props = withDefaults(defineProps<Props>(), {})
</script>

<template>
  <view class="comp_food">
    <image class="img" :src="item.thumb" mode="aspectFill"></image>
    <view class="right">
      <view class="name">{{item.name}}</view>
      <view class="content">
        <slot>

        </slot>
      </view>
    </view>
  </view>
</template>

<style lang="less">
.comp_food{
  width: 100%;
  height: 177.78px;
  background: white;
  border-radius: 16.67px;

  display: flex;
  align-content: center;

  padding: 28px 21px;

  .img{
    width: 122.22px;
    height: 122.22px;
    border-radius: 11.57px;
  }
  .right{
    margin-left: 16.67px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;

    .name{
      color: #353535;
      font-size: 30px;
    }
    .content{
      color: #5F5F5F;
      font-size: 29.17px;
    }
  }
}
</style>
