<template>
  <view class="comp_article_box" @click.stop="gotoDetailPage(item.wordUrl)">
    <image class="cover" :src="item.imgUrl" mode="scaleToFit"></image>
    <div class="info">
      <text class="name">{{item.wordTitle}}</text>
      <text v-show="item.wordBrowserNum" class="at">{{item.wordBrowserNum}}人看过</text>
    </div>
  </view>
</template>
<script setup lang="ts">
import {IWordItem} from "@/api/types";
import Taro from "@tarojs/taro";
import PageNavigation from "@/utils/pageNavigation";

type Props = {
  item:IWordItem;
}
const props = withDefaults(defineProps<Props>(), {})

const gotoDetailPage = (url:string) => {
	PageNavigation.navigationToWebView(url)
  // const encodeUrl = encodeURIComponent(url)
  // Taro.navigateTo({
  //   url: `/pages/webview/index?src=${encodeUrl}`
  // })
}
</script>
<style lang="less">
.comp_article_box{
  width: 100%;
  height: 233.33px;
  background: white;
  border-radius: 16.67px;
  padding: 33.33px 20.83px ;

  display: flex;
  align-items: center;

  .cover{
    width: 222.22px;
    min-width: 222.22px;
    height: 166.67px;
    border-radius: 11.11px;
    margin-right: 20.83px;
  }

  .info{
    width: 65%;
    height: 155px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;

    .name{
      width: 100%;
      font-size: 33px;
      font-weight: 600;
      line-height: 58px;
      color: #353535;
      //white-space:pre-wrap;
      //word-break:break-all;

      overflow: hidden; /*超出部分隐藏*/
      white-space: nowrap; /*禁止换行*/
      text-overflow: ellipsis; /*省略号*/
    }

    .at{
      font-size: 30px;
      color: #5F5F5F;
    }
  }
}

</style>
