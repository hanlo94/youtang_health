import Taro from "@tarojs/taro";

export const realTimeLogger = () => {
    const realTimeLogger = Taro.getRealtimeLogManager && Taro.getRealtimeLogManager()
    const wxLogger =
        Taro.getLogManager &&
        Taro.getLogManager({
            level: 0,
        });
    const log = (...params) => {
        console.log(...params);
        realTimeLogger && realTimeLogger.info(...params)
        wxLogger && wxLogger.log(...params);
    };
    return {
        log,
    };
};