import Taro from "@tarojs/taro";
import {defineStore} from 'pinia'


const KEYS = {
    SESSION: 'session',
    OPENID: 'openId',
    UNIONID: 'unionId',
    PATIENTID: 'patientId',
    HEIGHT: 'height',
    WEIGHT: 'weight',
    BIRTHDAY: 'birthday',
    LABORINTENSITY: 'LaborIntensity',
    GENDER: 'gender'
}

interface MainPageState {
    refresh: boolean,
    filesCount: number
}

export const useMainPageStore = defineStore('mainPage', {
    state: (): MainPageState => ({
        refresh: false,
        filesCount: 0
    }),
    actions: {
        refreshPage(): void {
            this.refresh = !this.refresh
        },
        setFilesCount(count: number): void {
            this.filesCount = count
        }
    },
})

/**
 * 全局统一存储方法
 */
const storeUtils = {

    saveUserInfo(data) {
        setData('userInfo', data)
    },
    saveSession(sessionKey) {
        setData(KEYS.SESSION, sessionKey)
    },

    readSession(): string {
        return getData(KEYS.SESSION)
    },

    saveOpenId(data) {
        setData(KEYS.OPENID, data)
    },

    readOpenId(): string {
        return getData(KEYS.OPENID)
    },

    saveUnionId(data) {
        setData(KEYS.UNIONID, data)
    },

    readUnionId(): string {
        return getData(KEYS.UNIONID)
    },

    savePatientId(data) {
        setData(KEYS.PATIENTID, data)
    },

    readPatientId(): number {
//   登录用户ID
        return getData(KEYS.PATIENTID, undefined)
        // return 12141906
        // return 12194298
        // return 13550681
        // return 13550365
        // return 13562424
    },
    savePatientHeight(data) {
        setData(KEYS.HEIGHT, data)
    },

    readPatientHeight(): number {
        return getData(KEYS.HEIGHT)
    },
    savePatientWeight(data) {
        setData(KEYS.WEIGHT, data)
    },

    readPatientWeight(): number {
        return getData(KEYS.WEIGHT)
    },
    savePatientGender(data) {
        setData(KEYS.GENDER, data)
    },

    readPatientGender(): number {
        return getData(KEYS.GENDER, 1)
    },

    savePatientBirthday(data) {
        setData(KEYS.BIRTHDAY, data)
    },

    readPatientBirthday(): number {
        return getData(KEYS.BIRTHDAY)
    },

    savePatientLaborIntensity(data) {
        setData(KEYS.LABORINTENSITY, data)
    },

    readPatientLaborIntensity(): number {
        return getData(KEYS.LABORINTENSITY)
    },


    clearCache() {
        Taro.clearStorage()
    },

}

/**
 * 统一存储
 * @param key
 * @param value
 */
function setData(key: string, value: string) {
    Taro.setStorageSync(key, value);
}

/**
 * 统一取值方法
 * @param key
 */
function getData(key: string, defaultValue?: number | string): any | number | string {
    return Taro.getStorageSync(key) ?? defaultValue;
}

export default storeUtils;
