/**
 * Description：
 * Created on 2023/7/20
 * Author :  郭
 */
const imgUrl = 'https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/'


const imgUrlFormat = (imgName:string) => {
  return imgUrl+imgName;
}

export default imgUrlFormat;