import { reactive } from "vue";
import Taro from "@tarojs/taro";
import common from "@/api/modules/common";
import { URL_PATH_COM, requestParams } from "@/api/api";
const BASE_URL = process.env.BASE_URL;

export interface ImageFile {
  url: string;
  status?: "pending" | "uploading" | "done" | "error";
  progress?: number;
}

export function useImageUpload(max = 9) {
  let files = reactive<ImageFile[]>([]);

  /**
   * 选择图片类型
   * @param sourceType
   */
  const chooseImage = async (sourceType: ("album" | "camera")[]) => {
    try {
      /**
       * 上传图片
       */
      const res = await Taro.chooseImage({
        count: max,
        sizeType: ["compressed"],
        sourceType,
      });
      res.tempFilePaths.forEach((tempPath) => {
        // 为每个文件创建独立状态
        const newFile: ImageFile = {
          url: tempPath,
          status: "pending",
          progress: 0,
        };
        files.push(newFile);

        // 开始上传（使用闭包保存对应索引）
        uploadFile(newFile, files.length - 1);
      });
    } catch (error) {
      handleError("选择图片失败");
    }
  };

  const uploadFile = async (file: ImageFile, index: number, type?: string) => {
    //type 主要是上传音频文件，不能修改files
    try {
      file.status = "uploading";
      // 使用 Taro.uploadFile 进行 FormData 上传
      const uploadTask = Taro.uploadFile({
        url: BASE_URL + URL_PATH_COM + 1001002, // 替换为实际接口地址
        filePath: file.url,
        name: "file",
        formData: {
          extraParam: "value",
          ...requestParams(),
        },
        header: {
          "Content-Type": "multipart/form-data",
        },
        success: (res: any) => {
          if(type){
            return
          }
          if (res.statusCode === 200) {
            const data = JSON.parse(res.data);
            files[index] = {
              ...file,
              url: data.data,
              status: "done",
            };
          } else {
            throw new Error("上传失败");
          }
        },
        fail: (err) => {
          throw err;
        },
      });
      if(type) {
        return
      }
      // 上传进度监听
      uploadTask.progress(({ progress }) => {
        files[index].progress = progress;
      });
    } catch (error) {
      files[index].status = "error";
      handleError("上传失败");
    }
  };

  // const uploadFile = async (file: ImageFile, index: number) => {
  //   console.log("开始上传图片", file);
  //   try {
  //     file.status = "uploading";

  //     const base64 = Taro.getFileSystemManager().readFileSync(
  //       file.url,
  //       "base64"
  //     );

  //     const res = await common.uploadFile(base64);
  //     if (res.code === 10000) {
  //       // 正确更新对应文件状态
  //       files[index] = {
  //         ...file,
  //         url: res.data as string,
  //         status: "done"
  //       };
  //     }
  //   } catch (error) {
  //     files[index].status = "error";
  //     handleError("上传失败");
  //   }
  // };

  /**
   * 删除图片
   * @param index
   */
  const deleteImage = async (index: number) => {
    // try {
    //   const delUrl = files[index].url;
    //   const delRes = await common.delFile(delUrl);
    //   if (delRes.code !== 10000) {
    //     handleError("删除失败");
    //     return;
    //   }
      files.splice(index, 1);
    // } catch (error) {
    //   handleError("删除失败");
    // }
  };

  const clearImage = () => {
    files.splice(0, files.length); 
  };

  const handleError = (msg: string) => {
    Taro.showToast({ title: msg, icon: "none", duration: 2000 });
  };

  return {
    files,
    chooseImage,
    // uploadAll: () =>
    //   files.filter((f) => f.status === "pending").forEach(uploadFile),
    uploadFile,
    deleteImage,
    clearImage,
  };
}
