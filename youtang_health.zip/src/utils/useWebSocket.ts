import { ref } from 'vue'

interface WebSocketOptions {
  onOpen?: () => void
  onClose?: () => void
  onMessage?: (data: string) => void
}

export default function useWebSocket(options: WebSocketOptions) {
  const socket = ref<WebSocket | null>(null)

  const connect = (url: string) => {
    socket.value = new WebSocket(url)

    socket.value.onopen = () => {
      console.log('WebSocket连接成功')
      options.onOpen && options.onOpen()
    }

    socket.value.onclose = () => {
      console.log('WebSocket连接关闭')
      options.onClose && options.onClose()
    }

    socket.value.onmessage = (event) => {
      console.log('接收数据:', event.data)
      options.onMessage && options.onMessage(event.data)
    }
  }

  const sendMessage = (message: string) => {
    if (socket.value?.readyState === WebSocket.OPEN) {
      socket.value.send(message)
    } else {
      console.error('WebSocket未连接')
    }
  }

  const close = () => {
    socket.value?.close()
  }

  return {
    connect,
    sendMessage,
    close,
  }
}
