import {BmiRecord} from "@/pagesBmi/ts/types";
import {addDays, formatDate, formatMd} from "@/utils/dateUtils";
import {isEmpty} from "lodash";

/**
 * 时间类型X轴
 * @param recordData [['2023-08-30 17:38:27',12]......]
 * @param startDate 开始日期
 * @param endDate   结束日期
 * @returns {animation: boolean}
 */
// @ts-ignore
function timeChartOptions(recordData: [string, number][], startDate: string, endDate: string): any {
    // 超过四个点连线 否则散点
    const option: any = {
        animation: false,
    };
    // X 轴
    option.xAxis = generateXAxisConfig('time');
    option.visualMap = generateVisualMapConfig();
    // 曲线配置
    option.series = generateSeriesConfig();
    option.series.type = getChartType(recordData.length);
    option.series.data = recordData;
    //Y 轴配置
    option.yAxis = generateYAxisConfig();
    if (startDate && endDate) {
        option.xAxis.interval = 6 * 3600 * 1000;
        option.xAxis.min = startDate + ' 00:00:00';
        option.xAxis.max = endDate + ' 00:00:00';
        option.xAxis.maxSize = 7;
        //X轴时间坐标格式化
        option.xAxis.axisLabel.formatter = function (val: string) {
            return xAxisLabelFormatterHM(val)
        }
    } else {
        option.xAxis.axisLabel.rotate = getxAxisLabelRotate(recordData.length);
        option.xAxis.axisLabel.formatter = function (val: string) {
            // 记录数不足3个 显示 月日时分  否则显示月日
            if (recordData.length <= 2) {
                return xAxisLabelFormatterMDHM(val);
            } else {
                return xAxisLabelFormatterMD(val);
            }
        }
    }
    return option;
}

// @ts-ignore
function timeChartOptionsBack(recordData: [string, number][], startDate: string, endDate: string): any {
    // 超过四个点连线 否则散点
    let chartType = recordData.length > 4 ? 'line' : 'scatter';
    const option: any = {
        animation: false,
        tooltip: {
            trigger: "axis",
            show: true,
            formatter: "{c}"
        },
        toolbox: {
            feature: {
                dataView: {
                    show: true,
                    readOnly: true
                },
                magicType: {
                    show: false,
                    type: ["line", "bar"]
                },
                restore: {
                    show: true
                },
                saveAsImage: {
                    show: true
                },
                mark: {
                    show: true
                }
            },
            show: false
        },
        xAxis: {
            triggerEvent: false,
            slient: true,
            type: 'time',
            boundaryGap: false,
            axisLine: {
                show: true,
                lineStyle: {
                    color: '#e7e7e7'
                }
            },
            axisTick: {
                show: false,
            },
            nameTextStyle: {
                fontSize: 12
            },
            axisLabel: {
                show: true,
                showMinLabel: true,
                showMaxLabel: true,
                color: '#666',
                margin: 5,
                align: 'center',
                fontSize: 12,
                splitArea: {
                    show: true
                },
            },
            splitLine: {
                show: true,
                lineStyle: {
                    color: '#e7e7e7'
                }
            },
        },
        yAxis: {
            type: 'value',
            scale: false,
            position: "left",
            nameLocation: "start",
            axisTick: {
                show: false
            },
            silent: true,
            axisLine: {
                show: true,
                lineStyle: {
                    color: '#e7e7e7'
                }
            },
            nameTextStyle: {
                fontSize: 12
            },
            axisLabel: {
                show: true,
                showMinLabel: true,
                showMaxLabel: false,
                color: '#666',
                margin: 5,
                align: 'right',
                fontSize: 12,
                rich: {}
            },
            splitLine: {
                show: true,
                lineStyle: {
                    color: '#e7e7e7'
                }
            },
            boundaryGap: false,
        },
        visualMap: {
            pieces: [{
                lte: 4.5,
                color: '#feb433'
            }, {
                lte: 9.9,
                color: '#87ceea'
            }],
            outOfRange: {
                color: '#e64a4a'
            },
            show: false
        },
        series: [{
            data: recordData,
            type: chartType,
            width: 0,
            showAllSymbol: false,
            smooth: true,
            yAxisIndex: 0,
            itemStyle: {
                normal: {
                    label: {
                        position: "bottom"
                    }
                }
            },
            markLine: {
                silent: true,
                symbol: 'none',
                data: [
                    {
                        yAxis: 3.9,
                        lineStyle: {
                            color: '#FF9C42'
                        },
                        symbolSize: 1,
                    },
                    {
                        yAxis: 6.1,
                        lineStyle: {
                            color: '#6CB2FC'
                        },
                        symbolSize: 1,
                    },
                    {
                        yAxis: 7.8,
                        lineStyle: {
                            color: '#6CB2FC'
                        },
                        symbolSize: 1,
                    },
                    {
                        yAxis: 13.9,
                        lineStyle: {
                            color: '#F54B5F'
                        },
                        symbolSize: 1,
                    }
                ]
            },
        }]
    };
    if (startDate && endDate) {
        option.xAxis.interval = 6 * 3600 * 1000;
        option.xAxis.min = startDate + ' 00:00:00';
        option.xAxis.max = endDate + ' 00:00:00';
        option.xAxis.maxSize = 7;
        //X轴时间坐标格式化
        option.xAxis.axisLabel.formatter = function (val: string) {
            let date = new Date(val);
            return addZero(date.getHours()) + ":" + addZero(date.getMinutes())
        }
        // option.yAxis.maxInterval = 3;
        // option.yAxis.minInterval = 1;
        // option.yAxis.interval = 3;
    } else {
        option.xAxis.axisLabel.formatter = function (val: string) {
            let date = new Date(val);
            // 记录数不足3个 显示 月日时分  否则显示月日
            if (recordData.length <= 2) {
                return addZero(date.getMonth() + 1) + "/" + addZero(date.getDate() + " " + addZero(date.getHours()) + ":" + addZero(date.getMinutes()));
            } else {
                return addZero(date.getMonth() + 1) + "/" + addZero(date.getDate());
            }
        }
    }
    console.log("chart.js", '.timeChartOptions', option);
    return option;
}

/**
 * 血压曲线
 */
export function categoryPressureChartOptions(xAxisData: any[]): any {
    console.log('xAxisData', xAxisData);
    let length = xAxisData.length;
    const option: any = {
        animation: false,
        grid: {
            left: '10%',
            right: '10%',
            top: '20%',
            bottom: '15%'
        },
        xAxis:{
            ...generateXAxisConfig('category',getxAxisLabelRotate(length),),
            data:xAxisData.map(item => item.recordDate.slice(5,11)),
            // axisLabel: {
            //     rotate: getxAxisLabelRotate(length),
            // }
        },
        yAxis: {
            name: 'mmHg',
            nameLocation: "end",
            silent: true,
            triggerEvent: true,
            type: "value",
            scale: true,
            position: "left",
            maxInterval: 200,
            minInterval: 50,
            axisTick: {
                show: false,
            },
            splitLine: {
                lineStyle: {
                    color: '#e7e7e7'
                },
                show: true
            },
            axisLine: {
                show: false
            },
            axisLabel: {
                rotate: 0,
                color: '#666',
                //Y轴 字体 配置
                textStyle: {
                    fontSize: '13'
                }
            }
        },
        color:['#4aa4fc', '#FF8900'],
        legend:{
            data: ['收缩压', '舒张压']
        },
        series:[
            {
                name: '收缩压',
                type: 'line',
                data: xAxisData.map(item => item.systolic),
                smooth: true,
                symbol: 'circle',
                itemStyle: {
                    color: "#4aa4fc",
                },
                lineStyle: {
                    color: "#4aa4fc"
                },
            },
            {
                name: '舒张压',
                type: 'line',
                data: xAxisData.map(item => item.diastolic),
                smooth: true,
                symbol: 'circle',
                itemStyle: {
                    color: "#ff8900",
                    normal: {
                        color: "#FF8900",
                        lineStyle: {
                            color: "#FF8900"
                        }
                    }
                },
                markLine: {
                    symbol: "none",
                    silent: true,
                    data: [{
                        yAxis: 60
                    }, {
                        yAxis: 90
                    }, {
                        yAxis: 140
                    }]
                }
            },
        ]
    };
    return option;
}

export function categoryPressureChartOptions2(xAxisData: string[], systolic: number[], diastolic: number[], startDate: string, endDate: string): any {
    const option: any = {
        animation: false,
    };
    let length = xAxisData.length;
    // X 轴
    option.xAxis = generateXAxisConfig('category', getxAxisLabelRotate(length));
    option.xAxis.data = xAxisData;
    option.xAxis.axisLabel.rotate = getxAxisLabelRotate(length);
    option.xAxis.min = startDate + ' 00:00:00';
    option.xAxis.max = endDate + ' 00:00:00';
    option.xAxis.minInterval = 1;
    option.xAxis.maxInterval = 16;
    option.xAxis.axisLabel.formatter = function (val: string) {
        return val.replace("\'", '').replace('\'', '');
    }
    // 曲线配置
    option.series = generateWHRSeriesConfig();
    //Y 轴配置
    option.yAxis = {
        name: 'mmhg',
        nameLocation: "end",
        silent: true,
        triggerEvent: true,
        type: "value",
        scale: true,
        position: "left",
        maxInterval: 250,
        minInterval: 20,
        axisTick: {
            show: false,
        },
        splitLine: {
            lineStyle: {
                color: '#e7e7e7'
            },
            show: true
        },
        axisLine: {
            show: false
        },
        axisLabel: {
            rotate: 0,
            color: '#666',
            //Y轴 字体 配置
            textStyle: {
                fontSize: '13'
            }
        }
    };
    option.color = ['#4aa4fc', '#FF8900'];
    option.legend = {
        data: ['收缩压', '舒张压']
    };
    option.series = [
        {
            name: '收缩压',
            type: getChartType(xAxisData.length),
            data: systolic,
            smooth: true,
            symbol: 'circle',
            itemStyle: {
                color: "#4aa4fc",
            },
            lineStyle: {
                color: "#4aa4fc"
            },
            markLine: {
                symbol: "none",
                silent: true,
                data: [{
                    yAxis: 60
                }, {
                    yAxis: 90
                }, {
                    yAxis: 140
                }]
            }
        },
        {
            name: '舒张压',
            type: getChartType(xAxisData.length),
            data: diastolic,
            smooth: true,
            symbol: 'circle',
            itemStyle: {
                color: "#ff8900",
                normal: {
                    color: "#FF8900",
                    lineStyle: {
                        color: "#FF8900"
                    }
                }
            },
        },
    ];
    return option;
}

// hba1c
export function categoryHba1cChartOptions(xAxisData: any[]): any {
    let length = xAxisData.length;
    const option: any = {
        animation: false,
        grid: {
            left: '10%',
            right: '10%',
            top: '10%',
            bottom: '15%'
        },
        xAxis: {
            ...generateXAxisConfig('category', getxAxisLabelRotate(length)),
            data: xAxisData.map(item => item.recordTime.slice(5,11)),
            // axisLabel: {
            //     rotate: getxAxisLabelRotate(length),
            // }
        },
        yAxis: {
            name: '',
            nameLocation: "end",
            silent: true,
            triggerEvent: true,
            type: "value",
            scale: true,
            position: "left",
            maxInterval: 50,
            minInterval: 0,
            axisTick: {
                show: false,
            },
            splitLine: {
                lineStyle: {
                    color: '#e7e7e7'
                },
                show: true
            },
            axisLine: {
                show: false
            },
            axisLabel: {
                rotate: 0,
                color: '#666',
                //Y轴 字体 配置
                textStyle: {
                    fontSize: '13'
                }
            }
        },
        color:['#4aa4fc', '#FF8900'],
        legend:{
            enabled: false,
            align: 'center',
            verticalAlign: 'top',
            padding: -15,
            lineWidth: 2
        },
        series:[
            {
                name: '',
                symbol: 'circle',
                type: 'line',
                smooth: true,
                data: xAxisData.map(item => item.hba1c),
                marker: {
                    symbol: 'circle',
                    radius: 3
                },
                color: '#4AA4FC',
                showInLegend: false,
                markLine: {
                    silent: true,
                    symbol: 'none',
                    data: [
                        {
                            yAxis: 6.5,
                            lineStyle: {
                                color: '#6CB2FC'
                            },
                            symbolSize: 1,
                        },
                    ]
                },
            },
        ],
        noData: {
            style: {
                fontWeight: 'bold',
                fontSize: '15px',
                color: '#f00'
            }
        }
    };

    return option;
}

/**
 * category类型X轴
 * @param xAxisData
 * @param yAxisData
 * @param startDate
 * @param endDate
 */
export function categoryChartOptions(xAxisData: string[], yAxisData: number[]|string[], startDate: string, endDate: string): any {
    const option: any = {
        animation: false,
        grid: {
            left: '10%',
            right: '10%',
            top: '10%',
            bottom: '20%'
        },
        // legend:{
        //     z:-1
        // },
    };
    let length = xAxisData.length;
    // X 轴
    option.xAxis = generateXAxisConfig('category', getxAxisLabelRotate(length));
    option.xAxis.data = xAxisData;
    option.xAxis.axisLabel.rotate = getxAxisLabelRotate(length);
    option.xAxis.min = startDate + ' 00:00:00';
    option.xAxis.max = endDate + ' 00:00:00';
    option.xAxis.axisLabel.formatter = function (val: string) {
        return val.replace("\'", '').replace('\'', '');
    }
    option.visualMap = generateVisualMapConfig();
    // 曲线配置
    option.series = generateSeriesConfig();
    option.series.type = getChartType(yAxisData.length);
    option.series.data = yAxisData;
    //Y 轴配置
    option.yAxis = generateYAxisConfig();
    return option;
}

export function categoryWeightChartOptions(xAxisData: string[], yAxisData: number[], startDate: string, endDate: string): any {
    const option: any = {
        animation: false,
    };
    let length = xAxisData.length;
    // X 轴
    option.xAxis = generateXAxisConfig('category', getxAxisLabelRotate(length));
    option.xAxis.data = xAxisData;
    option.xAxis.axisLabel.rotate = getxAxisLabelRotate(length);
    option.xAxis.min = startDate + ' 00:00:00';
    option.xAxis.max = endDate + ' 00:00:00';
    option.xAxis.minInterval = 1;
    option.xAxis.maxInterval = 16;
    option.xAxis.axisLabel.formatter = function (val: string) {
        return val.replace("\'", '').replace('\'', '')
    }
    option.visualMap = {
        pieces: [{
            lte: 0,
            color: '#feb433'
        }, {
            lte: 150,
            color: '#87ceea'
        }],
        outOfRange: {
            color: '#e64a4a'
        },
        show: false
    };
    // 曲线配置
    option.series = {
        smooth: true,
        yAxisIndex: 0,
        showAllSymbol: false,
        itemStyle: {
            normal: {
                label: {
                    position: "bottom"
                }
            }
        },
    }
    option.series.type = getChartType(yAxisData.length);
    option.series.data = yAxisData;
    //Y 轴配置
    option.yAxis = {
        name: 'kg',
        silent: true,
        triggerEvent: true,
        type: "value",
        scale: true,
        position: "left",
        nameLocation: "end",
        maxInterval: 150,
        minInterval: 30,
        axisTick: {
            show: false,
        },
        splitLine: {
            lineStyle: {
                color: '#e7e7e7'
            },
            show: true
        },
        axisLine: {
            show: false
        },
        axisLabel: {
            show: true,
            showMinLabel: true,
            showMaxLabel: false,
            color: '#666',
            margin: 5,
            align: 'right',
            fontSize: 12,
            rich: {}
        },
    }
    return option;
}

// 身高体重
export function categoryBMIChartOptions(xAxisData: BmiRecord[]): any {
    const option: any = {
        animation: false,
        grid: {
            left: '10%',
            right: '10%',
            top: '10%',
            bottom: '15%'
        },
    };
    let length = xAxisData.length;
    // X 轴
    option.xAxis = generateXAxisConfig('category', getxAxisLabelRotate(length));
    option.xAxis.data = xAxisData.map(item => item.recordDate.slice(5,11));
    option.xAxis.axisLabel.rotate = getxAxisLabelRotate(length);
    // option.xAxis.min = startDate + ' 00:00:00';
    // option.xAxis.max = endDate + ' 00:00:00';
    // option.xAxis.minInterval = 1;
    // option.xAxis.maxInterval = 16;
    option.visualMap = {
        pieces: [{
            lte: 18.5,
            color: '#feb433'
        }, {
            lte: 24,
            color: '#87ceea'
        }],
        outOfRange: {
            color: '#e64a4a'
        },
        show: false
    };
    // 曲线配置
    option.series = generateBMISeriesConfig();
    option.series.type = getChartType(xAxisData.length);
    option.series.data = xAxisData.map(item => item.bmi);
    //Y 轴配置
    option.yAxis = {
        silent: true,
        triggerEvent: true,
        type: "value",
        scale: true,
        position: "left",
        nameLocation: "start",
        maxInterval: 40,
        minInterval: 1,
        interval:4,
        axisTick: {
            show: false,
        },
        splitLine: {
            lineStyle: {
                color: '#e7e7e7'
            },
            show: true
        },
        axisLine: {
            show: false
        },
        axisLabel: {
            rotate: 0,
            color: '#666',
            //Y轴 字体 配置
            textStyle: {
                fontSize: '13'
            }
        }
    }
    return option;
}

/**
 * 备份BMI曲线 带默认图形
 * @param bmiRecordArray
 */
export function categoryBMIChartOptionsBack(bmiRecordArray: BmiRecord[]): any {
    const option: any = {
        animation: false,
        grid: {
            left: '10%',
            right: '10%',
            top: '10%',
            bottom: '15%'
        },
    };
    let length = bmiRecordArray ?bmiRecordArray.length:14;
    // X 轴
    option.xAxis = generateXAxisConfig('category', getxAxisLabelRotate(length));
    let currentDate = formatDate(new Date());
    let dataArray;
    let xAxisData:string[]
    if (!isEmpty(bmiRecordArray)) {
        xAxisData= bmiRecordArray.map(item => formatMd(item.recordDate));
        dataArray = bmiRecordArray.map(item => item.bmi);
    }else{
        xAxisData = []
        dataArray = []
        let periodCount = -length;
        for (let i = periodCount; i < 0; i++) {
            xAxisData.push(addDays(currentDate, i));
        }
        xAxisData.push(addDays(currentDate, 1));
        dataArray[xAxisData.length - 1] = 26;
    }
    option.xAxis.data = xAxisData
    option.xAxis.axisLabel.rotate = getxAxisLabelRotate(length);
    option.xAxis.min = option.xAxis.data[0] + ' 00:00:00';
    option.xAxis.max = currentDate + ' 00:00:00';
    // option.xAxis.minInterval = 1;
    // option.xAxis.maxInterval = 16;
    option.visualMap = {
        pieces: [{
            lte: 18.5,
            color: '#feb433'
        }, {
            lte: 24,
            color: '#87ceea'
        }],
        outOfRange: {
            color: '#e64a4a'
        },
        show: false
    };
    // 曲线配置
    option.series = generateBMISeriesConfig();
    option.series.type = getChartType(bmiRecordArray.length);
    option.series.data = dataArray
    //Y 轴配置
    option.yAxis = {
        silent: true,
        triggerEvent: true,
        type: "value",
        scale: true,
        position: "left",
        nameLocation: "start",
        maxInterval: 40,
        minInterval: 1,
        interval:4,
        axisTick: {
            show: false,
        },
        splitLine: {
            lineStyle: {
                color: '#e7e7e7'
            },
            show: true
        },
        axisLine: {
            show: false
        },
        axisLabel: {
            rotate: 0,
            color: '#666',
            //Y轴 字体 配置
            textStyle: {
                fontSize: '13'
            }
        }
    }
    return option;
}

/**
 * 生成BMI曲线线条配置，不带数据与线条类型配置
 */
export function generateBMISeriesConfig(): any {
    const series: any = {
        symbol: 'circle',
        smooth: true,
        yAxisIndex: 0,
        showAllSymbol: false,
        itemStyle: {
            normal: {
                label: {
                    position: "bottom"
                }
            }
        },
        markLine: {
            silent: true,
            symbol: 'none',
            data: [
                {
                    yAxis: 18.5,
                    lineStyle: {
                        color: '#6CB2FC'
                    },
                },
                {
                    yAxis: 24,
                    lineStyle: {
                        color: '#6CB2FC'
                    },
                }
            ]
        },
    }
    return series;
}

export function generateHba1cSeriesConfig(): any {
    return [{
        name: '',
        data: [6],
        marker: {
            symbol: 'circle',
            radius: 3
        },
        color: '#4AA4FC',
        showInLegend: false
    }, {
        name: '',
        data: [6.5],
        marker: {
            symbol: 'circle',
            radius: 0
        },
        color: '#4AA4FC',
        showInLegend: false
    }];
}

export function generateWHRSeriesConfig(): any {
    const series: any = {
        smooth: true,
        yAxisIndex: 0,
        showAllSymbol: false,
        itemStyle: {
            normal: {
                label: {
                    position: "bottom"
                }
            }
        },
        markLine: {
            silent: true,
            data: [
                {
                    yAxis: 0.85,
                    lineStyle: {
                        color: '#6CB2FC'
                    },
                    symbolSize: 1,
                },
                {
                    yAxis: 0.9,
                    lineStyle: {
                        color: '#6CB2FC'
                    },
                    symbolSize: 1,
                }
            ]
        },
    };
    return series;
}

// 体脂记录
export function categoryBodyFatChartOptions(xAxisData: any[], gender: number): any {
    const option: any = {
        animation: false,
        grid: {
            left: '10%',
            right: '10%',
            top: '10%',
            bottom: '15%'
        },
    };
    let length = xAxisData.length;
    // X 轴
    option.xAxis = generateXAxisConfig('category', getxAxisLabelRotate(length));
    option.xAxis.data = xAxisData.map(item => item.recordTime.slice(5,11));
    option.xAxis.axisLabel.rotate = getxAxisLabelRotate(length);
    // option.xAxis.min = startDate + ' 00:00:00';
    // option.xAxis.max = endDate + ' 00:00:00';
    option.xAxis.minInterval = 1;
    option.xAxis.maxInterval = 16;
    option.xAxis.axisLabel.formatter = function (val: string) {
        return val.replace("\'", '').replace('\'', '');
    }
    option.visualMap = {
        pieces: [{
            lte: 18.5,
            color: '#feb433'
        }, {
            lte: 24,
            color: '#87ceea'
        }],
        outOfRange: {
            color: '#e64a4a'
        },
        show: false
    };
    // 曲线配置
    option.series = generateBodyFatSeriesConfig(gender);
    option.series.type = getChartType(xAxisData.length);
    option.series.data = xAxisData.map(item => item.bmi);
    //Y 轴配置
    option.yAxis = {
        silent: true,
        triggerEvent: true,
        type: "value",
        scale: true,
        position: "left",
        nameLocation: "start",
        maxInterval: 30,
        minInterval: 5,
        interval: 5,
        axisTick: {
            show: false,
        },
        splitLine: {
            lineStyle: {
                color: '#e7e7e7'
            },
            show: true
        },
        axisLine: {
            show: false
        },
        axisLabel: {
            rotate: 0,
            //Y轴 字体 配置
            textStyle: {
                color: '#666',
                fontSize: '13'
            }
        }
    }
    return option;
}

export function generateBodyFatSeriesConfig(gender: number): any {
    const series: any = {
        symbol: 'circle',
        smooth: true,
        yAxisIndex: 0,
        showAllSymbol: false,
        itemStyle: {
            normal: {
                label: {
                    position: "bottom"
                }
            }
        },
        markLine: {
            silent: true,
            symbol: 'none',
            data: [
                {
                    yAxis: gender == 1 ? 15 : 20,
                    lineStyle: {
                        color: '#6CB2FC'
                    },
                    symbolSize: 1,
                },
                {
                    yAxis: gender == 1 ? 18 : 25,
                    lineStyle: {
                        color: '#6CB2FC'
                    },
                    symbolSize: 1,
                }
            ]
        },
    };
    return series;
}

// 营养素饼图
export function nutritionChartOptions(carbohydrateRate: number, proteinRate: number, fatRate: number): any {
    let options: any = {
        series: [
            {
                // name: "营养素",
                type: 'pie',
                radius: ['100%'],
                label: {
                    normal: {
                        position: 'inner',
                        show: false
                    }
                },
                data: [
                    {
                        value: carbohydrateRate,
                        name: '',
                        itemStyle: {
                            normal: {
                                color: '#64A4F5',
                            }
                        },
                    },
                    {
                        value: proteinRate,
                        name: '',
                        itemStyle: {
                            normal: {
                                color: '#F8DC70',
                            }
                        },
                    },
                    {
                        value: fatRate,
                        name: '',
                        itemStyle: {
                            normal: {
                                color: '#EF9B66',
                            }
                        },
                    }
                ],
            }
        ]
    };
    return options;
}

// 膳食纤维
export function fibreChartOptions(actualFibre: number, recommendFibre: number): any {
    let options: any = {
        title: {text: ''},
        grid: {
            x: 120,
            width: 140,
        },
        tooltip: {},
        xAxis: {
            data: [""]
        },
        yAxis: {
            name: '单位(g)',
            type: 'value',
            max: 30
        },
        series: [{
            name: '',
            type: 'bar',
            barWidth: 20,
            data: [actualFibre],
            label: {
                normal: {
                    show: true,
                    position: 'right',
                    fontSize: 8,
                    formatter: '实际摄入' + (actualFibre ? ('(' + actualFibre + 'g)') : '(0g)'),
                },
            },
            itemStyle: {
                normal: {
                    color: '#409EFF',
                    label: {
                        show: true,
                        position: 'top',
                        fontSize: 10,
                    }
                }
            },
            markPoint: {
                itemStyle: {
                    color: '#4aa4fc',
                },
                data: [
                    {
                        itemStyle: {
                            normal: {
                                color: '#4aa4fc'
                            }
                        },
                        type: 'max',
                        name: '最大值'
                    },
                    {
                        itemStyle: {
                            normal: {
                                color: '#4aa4fc'
                            }
                        },
                        type: 'min',
                        name: '最小值'
                    }
                ]
            },
            markLine: {
                silent: true,
                label: {
                    normal: {
                        show: true,
                        position: 'end',
                        fontSize: 8,
                        formatter: '推荐摄入' + (recommendFibre ? ('(>' + recommendFibre + 'g)') : ''),
                    },
                },
                data: [{
                    yAxis: recommendFibre,
                    itemStyle: {
                        normal: {
                            color: '#ff8900',
                            lineStyle: {
                                width: 0.7,
                                type: 'dashed',
                            }
                        }
                    }
                }]
            },
        }]
    };
    return options;
}

//三餐饼图
export function mealChartOptions(breakfastCalorieRate: number, lunchCalorieRate: number, supperCalorieRate: number): any {
    let options: any = {
        series: [
            {
                // name: "三餐",
                type: 'pie',
                label: {
                    normal: {
                        position: 'inner',
                        show: false
                    }
                },
                radius: ['100%'],
                data: [
                    {
                        value: breakfastCalorieRate,
                        name: '',
                        itemStyle: {
                            normal: {
                                color: '#64A4F5',
                            }
                        },
                    },
                    {
                        value: lunchCalorieRate,
                        name: '',
                        itemStyle: {
                            normal: {
                                color: '#F8DC70',
                            }
                        },
                    },
                    {
                        value: supperCalorieRate,
                        name: '',
                        itemStyle: {
                            normal: {
                                color: '#EF9B66',
                            }
                        },
                    }
                ],
            }
        ]
    };
    return options;
}

/**
 * 血糖曲线线条配置，不带数据与线条类型配置
 */
export function generateSeriesConfig(): any {
    const series: any = {
        smooth: true,
        yAxisIndex: 0,
        showAllSymbol: false,
        itemStyle: {
            normal: {
                label: {
                    position: "bottom"
                }
            }
        },
        markLine: {
            symbol: 'none',
            silent: true,
            data: [
                {
                    yAxis: 3.9,
                    lineStyle: {
                        color: '#FF9C42'
                    },
                    symbolSize: 1,
                },
                {
                    yAxis: 6.1,
                    lineStyle: {
                        color: '#6CB2FC'
                    },
                    symbolSize: 1,
                },
                {
                    yAxis: 7.8,
                    lineStyle: {
                        color: '#6CB2FC'
                    },
                    symbolSize: 1,
                },
                {
                    yAxis: 13.9,
                    lineStyle: {
                        color: '#F54B5F'
                    },
                    symbolSize: 1,
                }
            ]
        },
    }
    return series;
}

/**
 * Get the chart type, line if there are more than four points, otherwise scatter
 * @param recordCount
 * @returns {string}
 */
// @ts-ignore
export function getChartType(recordCount: number): string {
    // return recordCount > 4 ? 'line' : 'scatter';
    return 'line';
}

/**
 * Generate basic configuration for X-axis without type configuration
 */
export function generateXAxisConfig(type: string, rotate?: number): any {
    const xAxis = {
        triggerEvent: false,
        silent: true,
        type: type,
        boundaryGap: false,
        axisLine: {
            lineStyle: {
                color: '#e7e7e7'
            },
            show: true
        },
        axisTick: {
            show: false
        },
        splitLine: {
            show: true,
            lineStyle: {
                color: '#e7e7e7'
            }
        },
        nameTextStyle: {
            color: "#e7e7e7",
        },
        axisLabel: {
            rotate: rotate ? rotate : 0,
            textStyle: {
                "color": "#666",
                "fontSize": "13"
            }
        },
    }
    return xAxis;
}

/**
 * Generate basic configuration for Y-axis
 */
export function generateYAxisConfig(): any {
    const yAxis = {
        silent: true,
        triggerEvent: true,
        type: "value",
        scale: false,
        position: "left",
        nameLocation: "start",
        maxInterval: 6,
        minInterval: 2,
        min: 0,
        axisTick: {
            show: false,
        },
        splitLine: {
            lineStyle: {
                color: '#e7e7e7'
            },
            show: true
        },
        axisLine: {
            show: false
        },
        axisLabel: {
            rotate: 0,
            // Y-axis font configuration
            textStyle: {
                color: '#666',
                fontSize: '13'
            }
        }
    }
    return yAxis;
}

/**
 * Generate color configuration for segmented curve
 */
export function generateVisualMapConfig(): any {
    const visualMap = {
        pieces: [{
            lte: 4.5,
            color: '#feb433'
        }, {
            lte: 9.9,
            color: '#87ceea'
        }],
        outOfRange: {
            color: '#e64a4a'
        },
        show: false
    };
    return visualMap;
}

/**
 * Format X-axis label as HH:mm
 * @param val
 * @returns {string}
 */
export function xAxisLabelFormatterHM(val: string): string {
    let date = new Date(val);
    return addZero(date.getHours()) + ":" + addZero(date.getMinutes());
}

/**
 * Format X-axis label as MM/dd HH:mm
 * @param val
 * @returns {string}
 */
export function xAxisLabelFormatterMDHM(val: string): string {
    let date = new Date(val);
    return addZero(date.getMonth() + 1) + "/" + addZero(date.getDate()) + " " + addZero(date.getHours()) + ":" + addZero(date.getMinutes());
}

/**
 * Format X-axis label as MM/dd
 * @param val
 * @returns {string}
 */
export function xAxisLabelFormatterMD(val: string): string {
    let date = new Date(val);
    return addZero(date.getMonth() + 1) + "/" + addZero(date.getDate());
}

/**
 * Get the rotation angle for X-axis labels
 * @param recordCount
 * @returns {number}
 */
export function getxAxisLabelRotate(recordCount: number): number {
    return recordCount > 6 ? 45 : 0;
}

/**
 * Add leading zero to a number if it is a single digit
 * @param num
 * @returns {string}
 */
export function addZero(num: number | string): string {
    num = String(num);
    if (num.length == 1) {
        num = '0' + num;
    }
    return num;
}
