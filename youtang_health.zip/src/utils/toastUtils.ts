/**
 * Description：
 * Created on 2023/7/20
 * Author :  郭
 */
import Taro from "@tarojs/taro";

export const showErrorToast = (msg:string) =>{
    Taro.showToast({
        title: msg,
        icon: 'error',
    })
}

export const showSuccessToast = (msg:string) =>{
    Taro.showToast({
        title: msg,
        icon: 'success',
    })
}

export const showToast = (msg:string) =>{
    Taro.showToast({
        title: msg,
        icon: 'none',
    });
}
export const showToastLong = (msg:string) =>{
    Taro.showToast({
        title: msg,
        icon: 'none',
        duration:3000
    })
}
