/**
 * Description：
 * Created on 2023/7/20
 * Author :  郭
 */
import {h} from "vue";
import PageNavigation from "@/utils/pageNavigation";

/**
 * 创建一个div 并赋值 默认响应点击事件到webview
 * @param url 需要打开的地址
 * @param value  要显示的文本
 * @param onclick
 */
export const createRender = (url:any,value:string,onclick?:Function) => {
    return h("div", {
        onClick: () => {
            if (onclick) {
                onclick(url)
            } else {
                PageNavigation.navigationToWebView(url);
            }
        }
    }, value)
}

/**
 * 默认不处理点击
 * @param value
 * @param param
 * @param onclick
 */
export const createRenderV2 = (value: string, param?: any, onclick?: Function) => {
    return h("div", {
        onClick: () => {
            onclick && onclick(param)
        }
    }, value)
}

export const header=(title:string,key:string,defaultValue?:any)=>{
    return {
        title,
        key,
        stylehead: 'font-size:10px;color:#666666;height:30px; background:#EBF6FF; width:10%',
        stylecolumn: 'font-size:10px;color:#666666; text-align:center',
        align: "center",
        render: (record) => createRenderV2(record[key]??defaultValue)
    }
}
