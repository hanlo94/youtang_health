/**
 * Description：
 * Created on 2023/7/20
 * Author :  郭
 */


/**
 * 根据mealType 获取 是什么餐 早餐、 午餐 、 晚餐
 */
export const getFoodTypeByMealType = (mealType: number) => {
    if (mealType === 1) {
        return "早餐";
    } else if (mealType === 2) {
        return "早加餐";
    } else if (mealType === 3) {
        return "午餐";
    } else if (mealType === 4) {
        return "午加餐";
    } else if (mealType === 5) {
        return "晚餐";
    } else if (mealType === 6) {
        return "晚加餐";
    }
}