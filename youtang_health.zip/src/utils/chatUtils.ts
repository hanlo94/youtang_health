import Taro from "@tarojs/taro";
import { marked } from "marked";
const renderer = new marked.Renderer();

/**
 * 将markdown解析成html
 */
export function parseMarkdown(markdown: string) {
  //  // 覆盖列表项渲染逻辑
  renderer.listitem = (text: string) => {
    return `
      <li style="margin-left: 0; padding-left: 0">${text}</li>
    `; // 直接控制缩进
  };
  marked.setOptions({
    gfm: true,
    breaks: true,
    // renderer
  });

  try {
    // console.log(markdown, 'markdown')
    let parse = marked.parse(markdown);
    const processedHtml = parse
        .replace(/<ol/gi, '<ol style="padding-left: 20px; margin-left: 0;"')
        .replace(/<ul/gi, '<ul style="padding-left: 20px; margin-left: 0;"')
        .split(/(<[^>]+?>)/g).map((part, index) => {
          return index % 2 === 0 ? part.replace(/\s+/g, '') : part;
        }).join('');;
        // console.log('processedHtml', processedHtml)
    return processedHtml;
  } catch (error) {
    console.log("markdown 转换失败", error);
    return markdown;
  }
}

interface StreamChunk {
  id: string;
  conversation_id: string;
  type: "answer" | "verbose";
  content?: string;
  [key: string]: any;
}

interface ProcessResult {
  content: string;
  // isFinished: boolean;
  metadata: {
    id?: string;
  };
}

// 通用 ArrayBuffer 转字符串工具函数
export const bufferToStrings = (data: any): string => {
  // 1.获取对象的准确的类型
  let txt = "";
  const type = Object.prototype.toString.call(data); // Uni8Array的原型对象被更改了所以使用字符串的信息进行判断。
  if (type === "[object Uint8Array]") {
    // Taro.showToast({
    //   title: "Uint8Array转换失败",
    //   icon: "none",
    //   duration: 8000,
    // });
    // console.log("Uint8Array");
    txt = decodeURIComponent(escape(String.fromCharCode(...data)));
  } else if (data instanceof ArrayBuffer) {
    // 将ArrayBuffer转换为Uint8Array
    // Taro.showToast({
    //   title: "ArrayBuffer转换",
    //   icon: "none",
    //   duration: 8000,
    // });
    // console.log("ArrayBuffer");
    const uint8Array = new Uint8Array(data);
    txt = decodeURIComponent(escape(String.fromCharCode(...uint8Array)));
  }
  return txt;
};


/**
 * 处理流式数据
 * @param chunkStr 流数据
*/
export const extractAndConcatenateContent = (
  chunkStr: string
): ProcessResult => {
  const lines = chunkStr.split('\n').filter(line => line.trim() !== '');
  let content = '';
  const metadata = { id: '' }; // 存储关联的 id

  for (const line of lines) {
    let payload = line.trim();

    // 处理 "data:" 前缀和结束标记
    if (payload.startsWith('data:')) {
      payload = payload.slice(5).trim();
      if (payload === '[DONE]') break;
    }

    if (!payload) continue;

    try {
      const data: any = JSON.parse(payload);
      if (data.content && typeof data.content === 'string') {
        content += data.content;
        // 当存在 id 时记录到 metadata
        if (data.id) {
          metadata.id = data.id;
        }
      }
    } catch (error) {
      // 忽略解析错误
    }
  }

  return { 
    content, 
    metadata
  };
};

export const extractAndConcatenateContent1 = (
  chunkStr: string
): ProcessResult => {
  let contentDelta = "";
  let isFinished = false;
  let id: string | undefined;

  const lines = chunkStr
    .split("\n")
    .filter((line) => line.trim().startsWith("data:"));

  for (const line of lines) {
    const jsonStr = line.replace(/^data:\s*/, "").trim();

    // 处理流结束标记
    if (jsonStr === "[DONE]") {
      isFinished = true;
      break;
    }

    try {
      const data: StreamChunk = JSON.parse(jsonStr);

      // 处理回答内容
      if (data.type === "answer" && data.content) {
        contentDelta += data.content;
        // console.log("chat.streamChat.data.content=", data.content,);
        if (data.id) id = data.id;
      }

      // 处理结束标志
      if (data.type === "verbose" && data.content) {
        try {
          const verboseData = JSON.parse(data.content);
          if (verboseData.msg_type === "generate_answer_finish") {
            isFinished = true;
          }
        } catch (e) {
          console.warn("Verbose 内容解析失败", e);
        }
      }
    } catch (error) {
      console.warn("流数据解析异常", error);
    }
  }

  return {
    content: contentDelta,
    // isFinished,
    metadata: {
      id,
    },
  };
};



