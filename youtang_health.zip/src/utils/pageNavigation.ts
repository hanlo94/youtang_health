import Taro from "@tarojs/taro";
import {PointRuleConstants} from "@/pagesMine/api/points";

const PageNavigation = {
    // navigateTo(page,map:Map<any, any>){
    //
    // 	Taro.navigateTo({
    // 		url:page
    // 	})
    // }


    openPointRule() {
        this.navigationToWebView(process.env.POINT_RULE)
    },

    openPrivacy() {
        this.navigationToWebView(process.env.PRIVACY)
    },

    openServiceItem() {
        this.navigationToWebView(process.env.SERVICE_ITEM)
    },

    navigationToWebView(url, title?: string) {
        Taro.navigateTo({
            url: `/pageWebview/index?src=${encodeURIComponent(url)}&title=${title ?? ''}`
        })
    },
    navigationToLandscapeWebView(url, title?: string) {
        Taro.navigateTo({
            url: `/pagesCommon/webview/landscape?src=${encodeURIComponent(url)}&title=${title ?? ''}`
        })
    },

    redirectToLogin() {
        Taro.redirectTo({
            url: '/pagesLogin/login'
        })
    },

    navigationToLogin() {
        Taro.navigateTo({
            url: '/pagesLogin/login'
        })
    },

    notifyLastPage(event, data) {
        const page = Taro.getCurrentPages()
        const current = page[page.length - 1] /* 从堆栈中获取当前界面的属性 */
        const eventChannel = current.getOpenerEventChannel()
        eventChannel.emit(event, data)
    },

    goDeduction() {
        // 打开小程序
        console.log('index.goDeduction.')
        Taro.navigateToMiniProgram({
            appId: 'wx0f46682f8af98432',
            path: '/pages/integral/goods/list',
            success(res) {
                // 打开成功
                console.log("mall.js.success.", JSON.stringify(res));
            },
            fail(res) {
                console.log("mall.js.fail.", JSON.stringify(res));
            }
        })
    },

    onTaskClick(item) {
        console.log('index.onTaskItemClick.item=', item)
        if (item) {
            if (item.ruleOperation == '已完成') {
                // 已完成 点击不做处理
            } else {
                if (item.rulePointsOperationType == PointRuleConstants.ACADEMY_READ) {
                    Taro.switchTab({url: item.mpPagePath})
                } else if (item.rulePointsOperationType == PointRuleConstants.SHOPPING) {
                    this.goDeduction()
                } else if (item.rulePointsOperationType == PointRuleConstants.MARKET_SHARING) {

                } else if (item.mpPagePath) {
                    Taro.navigateTo({
                        url: item.mpPagePath
                    })
                }
            }
        }
    },
}

export default PageNavigation
