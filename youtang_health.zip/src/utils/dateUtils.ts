/**
 * Description：
 * Created on 2023/7/20
 * Author :  郭
 */

import {formatNumber} from "@/utils/util";


/**
 * 服务器时间 转成年月日 周
 * @returns {*} 2023-06-20 周二
 * @param time
 */
export const formatDate2YmdWeek = (time: string): string => {
    let date = new Date(time);
    const year = date.getFullYear()
    const month = date.getMonth() + 1
    const day = date.getDate()
    const week = date.getDay()
// 获取当前时间戳（以毫秒为单位）
    let now = Date.now();

// 计算今天零点的时间戳（转换为天数）
    let today = Math.floor(now / (1000 * 60 * 60 * 24));

// 计算记录日期的零点时间戳（转换为天数）
    let start = Math.floor(date.getTime() / (1000 * 60 * 60 * 24));

// 计算时间差
    let timeDifference = start - today;

    if (timeDifference === 0) {
        return `${[year, month, day].map(formatNumber).join('-')}` + " 今天";
    } else if (timeDifference === -1) {
        return `${[year, month, day].map(formatNumber).join('-')}` + " 昨天";
    } else {
        return `${[year, month, day].map(formatNumber).join('-')}` + ` 周${["日", '一', '二', '三', '四', '五', '六'][week]}`
    }
}


/**
 * 服务器时间 转成月日
 * @returns {*} 2023-06-20 周二
 * @param time
 */
export const formatDate2md = (date: Date): string => {
    const month = date.getMonth() + 1
    const day = date.getDate()
    return `${[month, day].map(formatNumber).join('-')}`
}

/**
 * 服务器时间 转分秒
 * 16:01
 * @param time
 */
export const formatDate2Hm = (time: string): string => {
    let date = new Date(time)
    return `${[date.getHours(), date.getMinutes()].map(formatNumber).join(':')}`;
}


/**
 * 服务器时间 转时分
 * 16:01
 * @param time
 */
export const formatDateTohm = (date: Date): string => {
    return `${[date.getHours(), date.getMinutes()].map(formatNumber).join(':')}`;
}
export const formatDateTohms = (date: Date): string => {
    return `${[date.getHours(), date.getMinutes(),date.getSeconds()].map(formatNumber).join(':')}`;
}

/**
 * 转年月日 2023-06-20
 * @param time
 */
export const formatDate2Ymd = (time: string): string => {
    let date = new Date(time);
    return formatDate(date)
}

export const formatDate = date => {
    const year = date.getFullYear()
    const month = date.getMonth() + 1
    const day = date.getDate()
    return `${[year, month, day].map(formatNumber).join('-')}`
}

/**
 * date转16:01
 * @param date
 */
export const formatDateToStr = (date: Date) => {
    return `${formatDate(date)} ${[date.getHours(), date.getMinutes()].map(formatNumber).join(':')}`
}

export const formatFullDateToStr = (date: Date) => {
    return `${formatDate(date)} ${[date.getHours(), date.getMinutes(),date.getSeconds()].map(formatNumber).join(':')}`
}

export const formatMd = (date: Date | string): string => {
    const result = date instanceof Date ? date : new Date(date)
    return `${[result.getMonth() + 1, result.getDate()].map(formatNumber).join('/')}`
}

export const addDays = (date: Date | string, days: number): string => {
    const result = new Date(date);
    result.setDate(result.getDate() + days);
    return formatMd(result)
}
export const addMinutes = (date: Date | string, minutes: number): string => {
    const result = new Date(date);
    result.setTime(result.getTime() + minutes * 60 * 1000);
    return formatFullDateToStr(result)
}



