import Taro from "@tarojs/taro";

const formatTime = date => {
    const year = date.getFullYear()
    const month = date.getMonth() + 1
    const day = date.getDate()
    const hour = date.getHours()
    const minute = date.getMinutes()
    const second = date.getSeconds()

    return `${[year, month, day].map(formatNumber).join('-')} ${[hour, minute, second].map(formatNumber).join(':')}`
}

/**
 * 基于分隔符 格式化数据
 * @param date
 * @param split
 * @returns {`${string} ${string}`}
 */
const formatTimeBySplit = (date, split) => {
    const year = date.getFullYear()
    const month = date.getMonth() + 1
    const day = date.getDate()
    const hour = date.getHours()
    const minute = date.getMinutes()
    const second = date.getSeconds()
    return `${[year, month, day].map(formatNumber).join(split)} ${[hour, minute, second].map(formatNumber).join(':')}`
}

const formatDate = date => {
    const year = date.getFullYear()
    const month = date.getMonth() + 1
    const day = date.getDate()
    return `${[year, month, day].map(formatNumber).join('-')}`
}


export const formatNumber = n => {
    n = n.toString()
    return n[1] ? n : `0${n}`
}
/**
 * 当前血糖时段index
 * @returns {number}
 */
const formatCurrentIndex = (hour) => {
    if (hour===undefined) {
        hour = new Date().getHours();
    }
    if (hour >= 5 && hour < 8) { // 早餐前
        return 1;
    } else if (hour >= 9 && hour < 11) { // 早餐后
        return 2;
    } else if (hour === 11) { // 午餐前
        return 3;
    } else if (hour >= 12 && hour < 16) { // 午餐后
        return 4;
    } else if (hour >= 16 && hour < 19) { // 晚餐前
        return 5;
    } else if (hour >= 10 && hour < 21) { // 晚餐后
        return 6;
    } else if (hour >= 21 && hour < 24) {
        return 7; // 睡前
    } else { // 凌晨
        return 0;
    }
}

const showShortToast = (msg) => {
    Taro.showToast({
        title: msg,
        icon: 'none',
        duration: 2000
    })
}

/**
 * 显示年月日
 * @param type
 * @param option
 */
export const formatter = (type, option) => {
    switch (type) {
        case 'year':
            option.text += '年';
            break;
        case 'month':
            option.text += '月';
            break;
        case 'day':
            option.text += '日';
            break;
        case 'hour':
            option.text += '时';
            break;
        case 'minute':
            option.text += '分';
            break;
        default:
            option.text += '';
    }
    return option;
};

export function fileToBase64(file) {
    return new Promise((resolve, reject) => {
        // 创建一个新的 FileReader 对象
        const reader = new FileReader();
        // 读取 File 对象
        reader.readAsDataURL(file);
        // 加载完成后
        reader.onload = function () {
            // 将读取的数据转换为 base64 编码的字符串
            const base64String = reader.result.split(",")[1];
            // 解析为 Promise 对象，并返回 base64 编码的字符串
            resolve(base64String);
        };
        // 加载失败时
        reader.onerror = function () {
            reject(new Error("Failed to load file"));
        };
    });
}

export {
    formatDate, formatTime, formatTimeBySplit, formatCurrentIndex, showShortToast
}
