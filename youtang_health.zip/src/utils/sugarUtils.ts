/**
 * Description：
 * Created on 2023/7/20
 * Author :  郭
 */

import {timeType} from "@/config/sugar/sugarConfig";

/**
 * 获取当前血糖值高低
 * @param sugarValue 血糖值
 * @param type 0空腹
 */
export const formatSugarUpNormalLow = (sugarValue: number, type: number): number => {
    if (type === 0) {//空腹
        if (sugarValue == null || sugarValue <= 4.4) {
            return 1
        } else if (sugarValue > 4.4 && sugarValue < 7) {
            return 2
        } else {
            return 3
        }
    } else {
        if (sugarValue == null || sugarValue <= 4.4) {
            return 1
        } else if (sugarValue > 4.4 && sugarValue < 10) {
            return 2
        } else {
            return 3
        }
    }
}

/**
 * bmi计算
 * @param height
 * @param weight
 */
export function getBmi(height: number | string, weight: number | string):IMetricStatus {
    const h = Number(height)/100*Number(height)/100;
    const w = Number(weight);

    const value = Number(Number(w / h).toFixed(1));
    let status = '';
    let color='';

    console.log('value',value)

    if (value <= 18.5) {
        status = '偏瘦'
        color='#97b8f5';
    } else if (value > 18.5 && value <= 24) {
        status = '正常'
        color='#64A4F5';
    } else if (value > 24 && value <= 28) {
        status = '过重'
        color='#ffa861';
    } else if (value > 28 && value <= 32) {
        status = '肥胖'
        color='#ff7961';
    } else {
        status = '重度肥胖'
        color='#DD3542';
    }

    return {
        value, status, color
    }
}

// 腰臀比计算
export function getWh(waist:number|string,hip:number|string,gender:number):IMetricStatus{
    const w = Number(waist);
    const h = Number(hip)

    const value = Number(Number(w/h).toFixed(2))
    let status = '';
    let color = '';

    if(gender===1){
        if(value>=0.9){
            status = '未达标';
            color = '#DD3542'
        }else{
            status = '达标'
            color = '#64A4F5'
        }
    }else{
        if(value>=0.85){
            status = '未达标';
            color = '#DD3542'
        }else{
            status = '达标'
            color = '#64A4F5'
        }
    }

    return {
        value,status,color
    }
}

export function getBp(diastolic:number,systolic:number):IMetricStatus{
    const value = Number(Number(diastolic - systolic).toFixed(1));
    let status = '';
    let color = '';


    if (value < 40) {
        status = '过低'
        color='#DD3542';
    } else if (value > 60) {
        status = '过高'
        color='#DD3542';
    } else {
        status = '正常'
        color='#64A4F5';
    }

    return {
        value, status, color
    }

}

/**
 * 根据type 获取文本
 */
export const getSugarTimeByType = (type: number) => {
    return  timeType.find(item => item.key == type);
}

interface IMetricStatus {
    value:number;
    status:string;
    color:string;
}
