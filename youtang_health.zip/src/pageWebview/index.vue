<template>
	<view>
		<web-view :src='decodeSrc' @message="handleMessage"/>
	</view>
</template>

<script setup lang="ts">
import {getCurrentInstance} from "@tarojs/runtime";
import Taro from "@tarojs/taro";
import StoreUtils from "@/utils/storeUtils";

const {src, title} = (getCurrentInstance().router?.params)
if (title) {
	Taro.setNavigationBarTitle({
		title
	})
}

console.log("webview source url=", src);

const decodeUrl = (url) => {
	if (url.indexOf('%') < 0) {
		return url
	} else {
		const newUrl = decodeURIComponent(url)
		return decodeUrl(newUrl)
	}
}

let decodeSrc = decodeUrl(src)

if (decodeSrc.indexOf('http:') != -1) {
	decodeSrc = decodeSrc.replace('http:', 'https:')
}
if (decodeSrc.indexOf('?') != -1) {
  decodeSrc += '&clientSn=xcx&patientId='+StoreUtils.readPatientId()
}else{
  decodeSrc += '?clientSn=xcx&patientId='+StoreUtils.readPatientId()
}

console.log("webview .. url=", decodeSrc);
const handleMessage = (e) => {
  console.log('index.handleMessage.',e)
}

Taro.showShareMenu({
	withShareTicket: true
})


</script>


<style scoped lang="less">

</style>
