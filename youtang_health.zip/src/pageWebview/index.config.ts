export default definePageConfig({
  enableShareAppMessage:true,
  enableShareTimeline:true
});
