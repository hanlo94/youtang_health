import {postRequest} from "@/api/api";


export const MagnetApi = {
    getRecordList(page: number, _pageSize: number) {
        return postRequest<MagnetRecord[]>({
            pageNum: page,
            pageSize: _pageSize
        }, 'patient/device/composite/list')
    },

    uploadMagnetStartup(params: MagnetUpload) {
        return postRequest<{}>(params, 'patient/device/composite/upload/start')
    },

    uploadMagnetFinish(params: MagnetUpload) {
        return postRequest<{}>(params, 'patient/device/composite/upload/end')
    },

}

/**
 * 运行数据
 */
export class MagnetUpload {

    deviceSn: string;

    /**
     * 治疗模式：
     * 1-控制血糖；2-综合调理；3-血管并发症；4-糖尿病眼病；
     * 5-肾脏调理；6-头晕失眠；7-神经病变；8-糖尿病足；
     */
    mode?: number;

    /**
     * 开始运行时间
     */
    startTime?: string;

    time: string;

    deviceId: string;

    /**
     * 结束运行时间
     */
    endTime?: string;

    /**
     * 治疗强度：1-中;2-高
     */
    powerLevel?: number;

    /**
     * 运行时长 ，单位：秒
     */
    runTime: number;

    type: number
}


export interface MagnetRecord {

    dataId: number;

    /**
     * Device Serial Number
     */
    deviceSn?: string;

    /**
     * Treatment Mode:
     * 1-控制血糖；2-综合调理；3-血管并发症；4-糖尿病眼病；
     * 5-肾脏调理；6-头晕失眠；7-神经病变；8-糖尿病足；
     */
    mode?: number;

    /**
     * Start Time
     */
    startTime?: string;

    /**
     * End Time
     */
    endTime?: string;

    /**
     * Treatment Power Level: 1-中; 2-高
     */
    powerLevel?: number;

    /**
     * Run Time, in seconds
     */
    runTime?: number;

    /**
     * Mode Name
     */
    modeName: string;

    /**
     * Level Name
     */
    levelName: string;

    count?: string;
}
