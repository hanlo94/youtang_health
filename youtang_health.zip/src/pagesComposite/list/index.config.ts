export default definePageConfig({
    navigationBarTitleText: "复合磁记录",
    usingComponents:{

    }
});
