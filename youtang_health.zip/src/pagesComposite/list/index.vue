<template>
  <view class="container_magnet">

    <view class="view_bg ">
      <scroll-view class="magnet_list" :scrollY="true" show-scrollbar="{{false}}" @scrollToLower="scroll" flexed
                   :refresherThreshold="50"
                   :lowerThreshold="150">
        <view class="table">
          <nut-table :columns="columns" :data="list" bordered>
            <template #nodata>
              <div class="no-data"> 暂时还没有数据哦~</div>
            </template>
          </nut-table>
        </view>
        <!--      <template v-for="item in list" :key="item.dataId">-->
        <!--        <view class="item" >-->
        <!--          <view class="list_magnet">-->
        <!--            <text class="text_title">治疗时间：</text>-->
        <!--            <text class="text_value">{{ item.startTime }}</text>-->
        <!--          </view>-->
        <!--          <view class=" text-wrapper">-->
        <!--            <text class="text_title">治疗模式：</text>-->
        <!--            <text class="text_value">{{ item.modeName }}</text>-->
        <!--            <text class="text_title"> 治疗强度：</text>-->
        <!--            <text class="text_value">{{ item.levelName }}</text>-->
        <!--            <text class="text_title"> 治疗时长：</text>-->
        <!--            <text class="text_value">{{ item.runTime }}</text>-->
        <!--          </view>-->
        <!--        </view>-->
        <!--      </template>-->

        <!--      <NoData v-if="showEmpty"></NoData>-->
        <!--      <view v-else v-show="showFinish" class="on_the_bottom">已经到底了</view>-->
      </scroll-view>
    </view>

  </view>

</template>
<script setup lang="ts">
import {onBeforeMount, onUnmounted, reactive, ref} from "vue";
import {showShortToast} from "@/utils/util";
import Taro from "@tarojs/taro";
import {MagnetApi, MagnetRecord} from "@/pagesComposite/MagnetApi";
import {header} from "@/utils/pubUtils";
import {getCurrentInstance} from "@tarojs/runtime";

const params = Taro.getCurrentInstance().router?.params;
console.log('params', params)

const columns = [
  header('日期', 'startTime'),
  header('治疗模式', 'modeName'),
  header('治疗强度', 'levelName'),
  header('次/13分钟', 'count', '1次')
]

const state = reactive({
  page: 1,
  pageSize: 20,
  finished: false,
})

// 数据列表
const list = ref<MagnetRecord[]>([] as MagnetRecord[]);

// 区分页面来源 治疗页面进入则返回时返回治疗页面上一层
let from

onBeforeMount(() => {
  from = getCurrentInstance().router?.params
})

onUnmounted(() => {
  if (from) {
    Taro.navigateBack({
      delta: 1 // 默认值是1，表示返回的页面层数
    })
  }
})


//获取记录列表
const getRecordList = () => {
  console.log('index.getRecordList.page=', state.page)
  if (state.page === 1) {
    list.value = [];
    state.finished = false;
  }
  if (state.finished) {
    return;
  }

  MagnetApi.getRecordList(state.page, state.pageSize).then(res => {
    if (!res.data || res.data.length == 0) {
      state.finished = true;
      console.log('index.getRecordList.没有更多.')
      return;
    }
    list.value.push(...res.data)
    console.log('index.getRecordList.after push =', list.value.length)
    // if (res.data.length==state.pageSize){
    //   // 还有更多 自动请求下一页
    //   state.page+=1;
    //   console.log('index.getRecordList.has more request next page =',state.page)
    //   getRecordList()
    // }
  })
}

getRecordList();

const scroll = () => {
  console.log('index.scroll.state.finished=', state.finished)
  if (state.finished) {
    showShortToast("没有更多了")
    return
  }
  state.page++;
  getRecordList();
}

// const refresh = () => {
//   console.log('index.refresh.')
//   state.page = 1;
//   state.finished = false;
//   getRecordList();
// }

</script>
<style lang="less">

.container_magnet {
  height: 100vh;
  padding: 20.83rpx 28rpx 20.83rpx 28rpx;
  display: flex;
  font-size: 29rpx;
  color: #333333;
  box-sizing: border-box;
  background-color: #f8f8f8;
  flex-direction: column;

  .magnet_list {
    flex: 1;
    min-height: 95vh;
  }

  .view_bg {
    display: flex;
    background: white;
    padding: 30px;
    border-radius: 15px;
    flex-direction: column;

    .table {

    }
  }

}
</style>
