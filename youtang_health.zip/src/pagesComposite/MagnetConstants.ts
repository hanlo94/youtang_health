import imgUrlFormat from "@/utils/imgUtils";
import {ScaleMeasure} from "@/config/device/bodyfat";

/**
 * 复合磁 UUID配置
 */
export const MagnetDeviceUUID = {
    // 设备服务UUID
    MAGNET_UUID: "0000fff0-0000-1000-8000-00805f9b34fb",
    MAGNET_UUID_UPPER: "0000FFF0-0000-1000-8000-00805F9B34FB",
    MAGNET_UUID_PREFIX: "FFF0",


    //设备特征UUID
    SERV_MAGNET_UUID: "0000fff1-0000-1000-8000-00805f9b34fb",
    SERV_MAGNET_UUID_UPPER: "0000FFF1-0000-1000-8000-00805F9B34FB",
    SERV_MAGNET_UUID_PREFIX: "FFF1",
    SERV_MAGNET_WRITE_UUID: "0000fff2-0000-1000-8000-00805f9b34fb",
    SERV_MAGNET_WRITE_UUID_UPPER: "0000FFF2-0000-1000-8000-00805F9B34FB",
    SERV_MAGNET_WRITE_UUID_PREFIX: "FFF2",
};

export class MagnetScaleMeasure extends ScaleMeasure {
    cureStateImg?: string = imgUrlFormat("device/mg_connecting2.png")

    constructor(state: number, mainState: string, subState: string, icon?: string | null, iconAnimation?: boolean, retryBtnText?: string | null, cureStateImg?: string | null) {
        super(state, mainState, subState, icon, iconAnimation, retryBtnText);
        if (cureStateImg) {
            this.cureStateImg = cureStateImg;
        }
    }
}

// 绑定、治疗过程状态
export const MagnetScanMeasureState =
    {
        LOCATION_CLOSE: new MagnetScaleMeasure(-6,
            "未开启定位",
            "请先打开系统定位才能更快地找到治疗仪哦~",
            imgUrlFormat('common/fail.png'), false, '连接仪器'),

        BLE_CLOSE: new MagnetScaleMeasure(-5,
            "蓝牙已关闭",
            "请先打开蓝牙才能记录治疗数据哦~",
            imgUrlFormat('common/fail.png'), false, '打开蓝牙'),

        BLE_AUTHORIZE: new MagnetScaleMeasure(-4,
            "蓝牙未授权",
            "请先打开小程序设置，允许蓝牙授权",
            imgUrlFormat('common/fail.png'), false, '打开设置'),
        BLE_DISABLE: new MagnetScaleMeasure(-1,
            "蓝牙未开启",
            "请先打开手机蓝牙才能记录治疗数据哦~",
            imgUrlFormat('common/fail.png'), false, '打开蓝牙'),

        /**
         * SDK初始化 异常
         */
        SDK_ERROR: new MagnetScaleMeasure(-2, "蓝牙初始化异常", "请联系客服进行咨询", imgUrlFormat('common/fail.png')),

        /**
         * SDK扫描异常
         */
        SCAN_ERROR: new MagnetScaleMeasure(-3, "扫描异常", "请联系客服进行咨询", imgUrlFormat('common/fail.png')),

        /**
         * 未绑定状态
         */
        UNBIND: new MagnetScaleMeasure(0, "治疗仪绑定", "为数据上传成功，请持续开启蓝牙。请勿关闭。"),

        /**
         * 绑定失败
         */
        BIND_FAILURE: new MagnetScaleMeasure(
            1,
            "治疗仪绑定失败",
            "注意将手机蓝牙打开，并打开治疗仪进行绑定",
            imgUrlFormat('common/fail.png'),
            false,
            "重新绑定",
        ),

        /**
         * 未绑定-扫描中
         */
        UNBIND_SCANING: new MagnetScaleMeasure(
            2,
            "治疗仪绑定",
            "请耐心等待扫描完成哦~",
            imgUrlFormat('common/load_mark.png'),
            true,
        ),

        /**
         * 未绑定-扫描超时
         */
        UNBIND_SCAN_TIMEOUT: new MagnetScaleMeasure(
            3,
            "扫描超时",
            "注意将手机蓝牙打开，并打开治疗仪进行绑定",
            imgUrlFormat('common/fail.png'),
            false,
            "重新扫描",
        ),

        /**
         * 未绑定-扫描失败
         */
        UNBIND_SCAN_FAILURE: new MagnetScaleMeasure(
            4,
            "治疗仪绑定",
            "扫描结束，请重新扫描",
            imgUrlFormat('common/fail.png'),
            true,
            "重新扫描",
        ),

        /**
         * 已绑定-待开始扫描
         */
        BIND_TO_SCAN: new MagnetScaleMeasure(5, "治疗仪治疗", "为数据上传成功，请持续开启蓝牙。请勿关闭。"),

        /**
         * 已绑定-扫描中
         */
        BIND_SCANING: new MagnetScaleMeasure(
            6,
            "正在扫描治疗仪",
            "请耐心等待扫描完成哦~",
            imgUrlFormat('common/load_mark.png'),
            true,
        ),

        /**
         * 已绑定-扫描超时
         */
        BIND_SCAN_TIMEOUT: new MagnetScaleMeasure(
            7,
            "扫描超时",
            "注意将手机蓝牙打开，并打开治疗仪进行治疗",
            imgUrlFormat('common/fail.png'),
            false,
            "重新扫描",
        ),

        /**
         * 已绑定-扫描失败
         */
        BIND_SCAN_FAILURE: new MagnetScaleMeasure(
            8,
            "扫描失败",
            "注意将手机蓝牙打开，并打开治疗仪进行治疗",
            imgUrlFormat('common/fail.png'),
            false,
            "重新扫描",
        ),

        SCAN_EMPTY: new MagnetScaleMeasure(
            9,
            "扫描结束",
            "注意将手机蓝牙打开，并打开治疗仪进行治疗",
            null,
            false,
            "重新扫描"
        ),

        CONNECTING: new MagnetScaleMeasure(
            10,
            "连接治疗仪",
            "正在连接中，请稍候",
            imgUrlFormat('common/success.png')
        ),

        CONNECT_SUCCESS: new MagnetScaleMeasure(
            12,
            "连接成功",
            "请开始进行治疗",
            imgUrlFormat('common/success.png'),
            false,
            null,
            imgUrlFormat("device/mg_waiting2.png")
        ),
        CONNECT_FAILURE: new MagnetScaleMeasure(
            11,
            "连接失败",
            "注意将手机蓝牙打开，并打开治疗仪进行连接",
            imgUrlFormat('common/fail.png'), false,
            "重新连接"
        ),

        /**
         * 已绑定-扫描成功-找到绑定的治疗仪
         */
        BIND_SCAN_SUCCESS: new MagnetScaleMeasure(
            13,
            "治疗仪治疗",
            "扫描成功，即将开始连接，请准备进行治疗",
            imgUrlFormat('common/success.png'),
            true,
            null,
            imgUrlFormat("device/mg_waiting2.png")
        ),

        /**
         * 已绑定-治疗中
         */
        BIND_MEASURING: new MagnetScaleMeasure(
            14,
            "正在治疗",
            "请耐心等待",
            imgUrlFormat('common/load_mark.png'),
            true,
            null,
            imgUrlFormat("device/mg_curing2.png")
        ),

        /**
         * 治疗失败
         */
        BIND_MEASURE_FAILURE: new MagnetScaleMeasure(
            15,
            "治疗失败",
            "",
            imgUrlFormat('common/fail.png'),
        ),

        /**
         * 治疗成功
         */
        BIND_MEASURE_SUCCESS: new MagnetScaleMeasure(
            16,
            "治疗成功",
            "恭喜您运行数据上传成功",
            imgUrlFormat('common/success.png'),
            false,
            null,
            imgUrlFormat("device/mg_finish2.png")
        ),

        BIND_MEASURE_FINISH: new MagnetScaleMeasure(17,
            "治疗结束",
            "本次治疗结束",
            imgUrlFormat('common/success.png'),
            false, null,
            imgUrlFormat("device/mg_finish2.png")
        ),
        /**
         * 断开连接
         */
        LOST_CONNECT: new MagnetScaleMeasure(
            18,
            "连接已断开",
            "为数据上传成功，请持续开启蓝牙。请勿关闭。",
            imgUrlFormat('common/fail.png'),
            false, "重新连接",
        ),
        SERVICE_NOT_EXIST: new MagnetScaleMeasure(
            19,
            "治疗异常",
            "请联系客服进行咨询",
        ),
        SERVICE_NOT_FOUND: new MagnetScaleMeasure(
            20,
            "治疗失败",
            "请联系客服进行咨询",
        ),
        UPLOAD_FAILURE: new MagnetScaleMeasure(
            21,
            "上传失败",
            "请稍等几秒钟重新上传",
            "重新上传"
        ),
        MEASURE_TIMEOUT: new MagnetScaleMeasure(
            22,
            "治疗超时",
            "请稍等几秒钟重新上传",
            "重新上传"
        ),

    };

export const CompositePlanState = {
    FUTURE: 1,
    TOBEGIN: 2,
    NORMAL: 3,
    FINISH: 4,
    EXPIRED: 5,
    ABORT: 6
}

export class IMagnetScheduleState {
    state: number;
    mainState: string;
    subState?: string;
    retryCount?: number;

    constructor(state: number, mainState: string, subState?: string, retryCount?: number) {
        this.state = state;
        this.mainState = mainState;
        this.subState = subState;
        this.retryCount = retryCount;
    }
}

export const MagnetScheduleState = {

    LOCATION_CLOSE: new IMagnetScheduleState(-7,
        "未开启定位",
        "请先打开系统定位才能更快地找到治疗仪哦~",
    ),

    BLE_CLOSE: new IMagnetScheduleState(-6,
        "蓝牙已关闭",
        "请先打开蓝牙才能记录治疗数据哦~",
    ),

    BLE_AUTHORIZE: new IMagnetScheduleState(-5,
        "蓝牙未授权",
        "请先打开小程序设置，允许蓝牙授权",
    ),

    /**
     * 蓝牙未开启
     */
    BLE_DISABLE: new IMagnetScheduleState(
        -4,
        "打开蓝牙",
        "请先打开蓝牙才能进行治疗哦~",
    ),
    INIT_ERROR: new IMagnetScheduleState(
        -3,
        "数据异常",
        "请联系客服处理",
    ),

    /**
     * SDK扫描异常
     */
    SCAN_ERROR: new IMagnetScheduleState(
        -2,
        "重新扫描",
        "扫描异常",
        3
//        "请联系客服进行咨询",
    ),

    /**
     * 断开连接
     */
    LOST_CONNECT: new IMagnetScheduleState(
        -1,
        "重新连接",
        null,
        3
    ),

    /**
     * 已绑定-待开始扫描
     */
    BIND_TO_SCAN: new IMagnetScheduleState(
        1,
        "开始扫描",
//        "开始扫描",
//        "为数据上传成功，请持续开启蓝牙。请勿关闭。",
    ),

    /**
     * 已绑定-扫描中
     */
    BIND_SCANNING: new IMagnetScheduleState(
        2,
        "正在扫描",
//        "请耐心等待扫描完成哦~",
    ),

    /**
     * 已绑定-扫描超时
     */
    BIND_SCAN_TIMEOUT: new IMagnetScheduleState(
        3,
        "重新扫描",
        "扫描超时，请点击重新开始扫描",
//        "注意将手机蓝牙打开，并打开治疗仪进行治疗",
    ),

    /**
     * 已绑定-扫描失败
     */
    BIND_SCAN_FAILURE: new IMagnetScheduleState(
        4,
        "重新扫描",
        "扫描失败，请点击重新开始扫描",
//        "注意将手机蓝牙打开，并打开治疗仪进行治疗",
    ),

    SCAN_EMPTY: new IMagnetScheduleState(
        5,
        "重新扫描",
        "扫描结束，请点击重新开始扫描",
//        "注意将手机蓝牙打开，并打开治疗仪进行治疗",
    ),

    /**
     * 扫描成功-找到绑定的治疗仪
     */
    BIND_SCAN_SUCCESS: new IMagnetScheduleState(
        6,
        "扫描成功",
//        "扫描成功，即将开始连接，请准备进行治疗",
    ),

    CONNECTING: new IMagnetScheduleState(
        7,
        "正在连接",
        "正在连接中，请稍候",
    ),
    CONNECT_SUCCESS: new IMagnetScheduleState(
        8,
        "连接成功",
        "复合磁治疗仪连接成功"
//        "请佩戴好输出器后，再进行治疗~",
    ),
    CONNECT_FAILURE: new IMagnetScheduleState(
        9,
        "重新连接",
        "连接失败，请点击重新连接",
        3
//        "注意将手机蓝牙打开，并打开治疗仪进行连接",
    ),

    /**
     * 下发方案成功
     */
    SEND_SCHEME: new IMagnetScheduleState(
        10,
        "等待开始",
        "请点击治疗仪开始治疗"
//        "请耐心等待",
    ),

    /**
     * 下发失败
     */
    SEND_FAILURE: new IMagnetScheduleState(
        11,
        "重新下发",
        "方案下发失败，请点击重新下发",
        3
    ),

    /**
     * 治疗中
     */
    MEASURING: new IMagnetScheduleState(
        12,
        "正在治疗",
    ),

    /**
     * 治疗成功
     */
    MEASURE_SUCCESS: new IMagnetScheduleState(
        13,
        "治疗结束",
        "恭喜您数据上传成功",
    ),

    UPLOAD_FAILURE: new IMagnetScheduleState(
        14,
        "重新上传",
        "数据上传失败，请重新上传",
        3
    ),
    SERVICE_NOT_EXIST: new IMagnetScheduleState(
        15,
        "治疗异常",
        "请联系客服进行咨询",
    ),
    SERVICE_NOT_FOUND: new IMagnetScheduleState(
        16,
        "治疗失败",
        "请联系客服进行咨询",
    )
};

// Constants
export const CMD_PREFIX_DEVICE = "AA";
export const CMD_SUFFIX = "A5";
export const CMD_PREFIX_APP = "AB";
export const MAGNET_NAME_PREFIX = "YT:01";

// Enumerations
export enum MagnetCmdState {
    Measuring = 0x01,
    MeasureFinish = 0x02,
    HeartCheck = 0x04,
    ReportsStartUp = 0x08,
    ///APP下发方案
    DeliveryScheme = 0x10
}

export const MagnetMode = {
    GlucoseControl: {modeName: "控制血糖", mode: 0x01},
    ComprehensiveTreatment: {modeName: "综合调理", mode: 0x02},
    VascularComplications: {modeName: "血管并发症", mode: 0x03},
    DiabeticRetinopathy: {modeName: "糖尿病眼病", mode: 0x04},
    KidneyCare: {modeName: "肾脏调理", mode: 0x05},
    DizzinessInsomnia: {modeName: "头晕失眠", mode: 0x06},
    Neuropathy: {modeName: "神经病变", mode: 0x07},
    DiabeticFoot: {modeName: "糖尿病足", mode: 0x08},
}

export const MagnetStrength = {
    Middle: {strengthName: "中档", strength: 0x1},
    High: {strengthName: "强档", strength: 0x2},
}

// Base class
export class MagnetCmd {
    prefix: string;
    control: number;
    netLoad: string;
    checkSum: number;
    suffix: string = CMD_SUFFIX;

    init(prefix: string, control: number, checkSum: number) {
        this.prefix = prefix;
        this.control = control;
        this.checkSum = checkSum;
    }

    constructor() {
    }

    toString(): string {
        return `MagnetCmd(prefix=${JSON.stringify(this.prefix)}, control=${this.control}, netLoad=${JSON.stringify(this.netLoad)}, checkSum=${this.checkSum}, suffix=${JSON.stringify(this.suffix)})`;
    }
}

// Derived classes
export class MagnetStartMeasureCmd extends MagnetCmd {
    mode: string;
    modeStrength: string;
    strength: string;
    time1: string;
    time2: string;

    constructor(cmd: MagnetCmd) {
        super();
        super.init(cmd.prefix, cmd.control, cmd.checkSum);
    }

    toString(): string {
        return `MagnetStartMeasureCmd(mode=${JSON.stringify(this.mode)}, strength=${JSON.stringify(this.strength)}, time1=${JSON.stringify(this.time1)}, time2=${JSON.stringify(this.time2)}) ${super.toString()}`;
    }
}

export class MagnetRunningTimeReportCmd extends MagnetCmd {
    time1: string;
    time2: string;

    constructor(cmd: MagnetCmd) {
        super();
        super.init(cmd.prefix, cmd.control, cmd.checkSum);
    }

    toString(): string {
        return `MagnetRunningTimeReportCmd(time1=${JSON.stringify(this.time1)}, time2=${JSON.stringify(this.time2)}) ${super.toString()}`;
    }
}

export class MagnetHeartCheckCmd extends MagnetCmd {
    modeStrength: string;
    runningState: string;
    time1: string;
    time2: string;

    constructor(cmd: MagnetCmd) {
        super();
        super.init(cmd.prefix, cmd.control, cmd.checkSum);
    }

    toString(): string {
        return `MagnetHeartCheckCmd(time1=${JSON.stringify(this.time1)}, time2=${JSON.stringify(this.time2)}) ${super.toString()}`;
    }
}






