export default definePageConfig({
    navigationBarTitleText: "复合磁治疗仪",
});
