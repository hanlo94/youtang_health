<template>
  <view class="container_body_magnet">

    <view @click.stop="goPlan">
      <image class="banner-img" :src="banner" alt=""/>
    </view>
    <view class="card_bg">
      <view class="card">

        <view class="top_tips">
          <image class="icon" :src="measureState.icon" mode="widthFix"></image>
          <view>{{ measureState.mainState }}</view>
        </view>
        <view class="sub_tips">{{ measureState.subState }}</view>

        <view class="tips">
          注意事项：
          <ul>
            <li>1.请将手机蓝牙调整为开启状态，并启动治疗仪进行绑定/治疗</li>
            <li>2.治疗开始前，请先将输出器佩戴好，再进行治疗</li>
          </ul>
        </view>

        <!--    背景    -->
        <view class="magnet_cure_box">
          <view class="magnet_round">
            <image class="magnet_cure_img" :src="measureState.cureStateImg" alt=""/>
          </view>
        </view>
      </view>
    </view>
    <!--  按钮  -->
    <view v-if="scaleMeasureState?.retryBtnText" class="retry" @click.stop="onRetryBtnClick">
      <nut-button type="info" class="btn">{{ scaleMeasureState?.retryBtnText }}</nut-button>
    </view>
  </view>
</template>
<script lang="ts" setup>
import Taro from "@tarojs/taro";
import {computed, onBeforeMount, onMounted, onUnmounted, ref} from "vue";
import {showToast, showToastLong} from "@/utils/toastUtils";
import {getCurrentInstance} from "@tarojs/runtime";
import imgUrlFormat from "@/utils/imgUtils";
import {
  CMD_PREFIX_APP,
  CMD_SUFFIX,
  MAGNET_NAME_PREFIX,
  MagnetCmdState,
  MagnetDeviceUUID,
  MagnetRunningTimeReportCmd,
  MagnetScaleMeasure,
  MagnetScanMeasureState,
  MagnetStartMeasureCmd
} from "@/pagesComposite/MagnetConstants";
import {MagnetCommandProcessor} from "@/pagesComposite/MagnetProcessor";
import {realTimeLogger} from "@/component/realTimeLogger";
import {clearHeartCheck, clearTimer, startHeartCheck, startTimer} from "@/component/Timer";
import {ab2hex, closeBleAdapter, hex2ArrayBuffer} from "@/component/ble/Ble";
import {addMinutes, formatFullDateToStr} from "@/utils/dateUtils";
import {MagnetApi, MagnetUpload} from "@/pagesComposite/MagnetApi";
import SugarApi from "@/api/modules/sugar";
import {showShortToast} from "@/utils/util";
import {DeviceBrand, DeviceCategory} from "@/config/device/deviceConfig";
import StoreUtils from "@/utils/storeUtils";
import storeUtils from "@/utils/storeUtils";

const banner = imgUrlFormat('sugar/magnet.png')

const scaleMeasureState = ref<MagnetScaleMeasure>()
const bindState = ref<boolean>(false)

let deviceSn: string = ''

// 复合磁解析处理
const processor = new MagnetCommandProcessor()

// 是否已连接
const connected = ref<boolean>(false)
const connecting = ref<boolean>(false)
const scanning = ref<boolean>(false)

const connectedDevice = ref()
const measureState = computed(() => {
  return {
    state: scaleMeasureState.value?.state,
    icon: scaleMeasureState.value?.icon,
    mainState: scaleMeasureState.value?.mainState,
    subState: scaleMeasureState.value?.subState,
    retryBtn: scaleMeasureState.value?.retryBtnText,
    cureStateImg: scaleMeasureState.value?.cureStateImg
  };
})


const logger = realTimeLogger()

// region 页面生命周期

onBeforeMount(() => {
  console.log('index.onBeforeMount.')
  let {isBind} = getCurrentInstance().router?.params
  bindState.value = isBind
  if (isBind) {
    let _deviceSn = getCurrentInstance().router?.params.deviceSn
    if (typeof _deviceSn === "string") {
      deviceSn = _deviceSn
    }
    console.log('index.onBeforeMount. deviceSn=', _deviceSn, '; isBInd=', isBind, '; deviceSn.value=', deviceSn, '; ', JSON.stringify(deviceSn), '; typeof ', typeof deviceSn)
  }
})

onMounted(() => {
  console.log('index.onMounted.')
  updateState(MagnetScanMeasureState.BIND_TO_SCAN)
  checkBlePermission()
})

onUnmounted(() => {
  console.log('index.onUnmounted.')
  stopBle(false)
})

// endregion

// region 蓝牙权限与蓝牙适配器状态操作

/**
 * 检验蓝牙授权状态
 */
const checkBlePermission = (silent: boolean = false) => {
  console.log('index.checkBlePermission.silent=', silent)
  Taro.getSetting({
    success(res) {
      logger.log("index.vue.checkBlePermission.getSetting.success.res.authSetting=", res.authSetting);
      if (!res.authSetting['scope.bluetooth']) {
        Taro.authorize({
          scope: 'scope.bluetooth',
          success: (res) => {
            // showShortToast('蓝牙授权成功')
            logger.log("checkBlePermission.authorize.success.", JSON.stringify(res));
            openBluetoothAdapter()
          },
          fail: (res) => {
            // showShortToast('蓝牙授权失败')
            logger.log('蓝牙授权失败', JSON.stringify(res))
            if (!silent) {
              showBleAuthorizeModal()
            }
            onBleAuthorize()
          }
        })
      } else {
        openBluetoothAdapter()
      }
    },
    fail(res) {
      console.log('index.checkBlePermission.fail.', JSON.stringify(res))
      if (!silent) {
        showBleAuthorizeModal()
      }
      onBleAuthorize()
    }
  })
}

/**
 * 打开蓝牙适配器
 */
const openBluetoothAdapter = () => {
  const systemSetting = Taro.getSystemSetting();
  console.log("index..openBluetoothAdapter.setting=", JSON.stringify(systemSetting));
  const bleEnabled = systemSetting.bluetoothEnabled;
  const locationEnabled = systemSetting.locationEnabled;
  console.log("index..openBluetoothAdapter.bleEnabled=", bleEnabled, '; locationEnabled=', locationEnabled);
  Taro.openBluetoothAdapter({
    success: (res) => {
      logger.log("index.vue.openBluetoothAdapter.success.", JSON.stringify(res));
      if (locationEnabled) {
        startScan()
        updateState(bindState.value ? MagnetScanMeasureState.BIND_TO_SCAN : MagnetScanMeasureState.UNBIND)
      } else {
        updateState(MagnetScanMeasureState.LOCATION_CLOSE)
        showBleDisableModal(MagnetScanMeasureState.LOCATION_CLOSE.subState)
      }
    },
    fail: (res) => {
      logger.log("index.vue.openBluetoothAdapter.fail.", JSON.stringify(res), '; JSON.stringify(res).indexOf(\'openBluetoothAdapter:fail already opened = ', JSON.stringify(res).indexOf('openBluetoothAdapter:fail already opened'));
      if (JSON.stringify(res).indexOf('openBluetoothAdapter:fail already opened') != -1) {
        console.log('index.openBluetoothAdapter,already opened.start scan')
        if (locationEnabled) {
          startScan()
          updateState(bindState.value ? MagnetScanMeasureState.BIND_TO_SCAN : MagnetScanMeasureState.UNBIND)
        } else {
          updateState(MagnetScanMeasureState.LOCATION_CLOSE)
          showBleDisableModal(MagnetScanMeasureState.LOCATION_CLOSE.subState)
        }
      } else {
        console.log('index.openBluetoothAdapter,failed')
        let str
        if (!bleEnabled && !locationEnabled) {
          str = '手机蓝牙、定位未打开，请先打开手机蓝牙、定位权限'
        } else if (!bleEnabled) {
          str = MagnetScanMeasureState.BLE_DISABLE.subState
        } else {
          str = MagnetScanMeasureState.LOCATION_CLOSE.subState
        }
        showBleDisableModal(str)
        onBleDisable()
      }
    },
    complete: () => {
      onBleAdapterState()
    }
  })
}

const onBleAdapterState = () => {
  Taro.onBluetoothAdapterStateChange(res => {
    if (res.available) {
      // 蓝牙适配器可用
      logger.log("onBluetoothAdapterStateChange 蓝牙适配器可用, scaleMeasureState.value?.state=", scaleMeasureState.value?.state);
      if (scaleMeasureState.value?.state == MagnetScanMeasureState.BLE_DISABLE.state) {
        const systemSetting = Taro.getSystemSetting()
        if (systemSetting.locationEnabled) {
          updateState(bindState.value ? MagnetScanMeasureState.BIND_TO_SCAN : MagnetScanMeasureState.UNBIND)
          restart()
        } else {
          updateState(MagnetScanMeasureState.LOCATION_CLOSE)
          showToastLong("位置信息未开启，请先打开")
        }
      }
    } else {
      // 蓝牙适配器不可用
      logger.log("onBluetoothAdapterStateChange 蓝牙适配器不可用");
      stopBle(false)
      onBleDisable()
    }
  })
}

//
const onBleDisable = () => {
  updateState(MagnetScanMeasureState.BLE_DISABLE)
}

const onBleAuthorize = () => {
  updateState(MagnetScanMeasureState.BLE_AUTHORIZE)
}

// endregion

// region  扫描与连接

const startScan = () => {
  console.log('index.startScan.')
  Taro.startBluetoothDevicesDiscovery({
    allowDuplicatesKey: false,
    services: [
      MagnetDeviceUUID.MAGNET_UUID,
      MagnetDeviceUUID.MAGNET_UUID_UPPER,
    ],
    complete: (res) => {
      // 扫描结束
      logger.log("startScan 开启扫描结束 ", JSON.stringify(res));
    },
    success: (res) => {
      console.log('index.startScan.success.', JSON.stringify(res))
      scanning.value = true
      onBluetoothDeviceFound(res)
      updateState(bindState.value ? MagnetScanMeasureState.BIND_SCANING : MagnetScanMeasureState.UNBIND_SCANING)
      startScanTimer();
      showToastLong("开始扫描治疗仪")
    },
    fail: (res) => {
      logger.log("index.vue.startScan.fail.", JSON.stringify(res), '; res.errMsg=', res.errMsg, ';res.errMsg.indexOf(\'already discovering devices\') != -1=', (res.errMsg.indexOf('already discovering devices') != -1));
      if (res.errMsg && res.errMsg.indexOf('already discovering devices') != -1) {
        // 已开启扫描
        console.log('index.startScan.fail.already stop then start ')
      } else {
        updateState(bindState.value ? MagnetScanMeasureState.BIND_SCAN_FAILURE : MagnetScanMeasureState.UNBIND_SCAN_FAILURE)
        logger.log('index.start scan fail. update state', scaleMeasureState.value?.mainState)
      }
    }
  })
}

const stopScan = (callback: ActionCallback | null = null) => {
  console.log('index.stopScan.scanning.value=', scanning.value, '; time is ', Date.now())
  if (scanning.value) {
    console.log('index.stopScan.scanning.value=', scanning.value, '; time is ', Date.now())
    Taro.stopBluetoothDevicesDiscovery({
      success: (res) => {
        logger.log("index.vue.stopScan.success.", JSON.stringify(res));
        scanning.value = false
        callback && callback()
      },
      fail: (res) => {
        logger.log("index.vue.stopScan.fail.", JSON.stringify(res));
      },
      complete: (res) => {
        console.log('index.complete.stopBluetoothDevicesDiscovery', JSON.stringify(res))
      }
    })
  } else {
    callback && callback()
  }
}

/**
 * 扫描发现治疗仪监听
 * @param res
 */
const onBluetoothDeviceFound = (res) => {
  console.log('index.onBluetoothDeviceFound.start', JSON.stringify(res))
  Taro.onBluetoothDeviceFound((res) => {
    console.log('index.Taro.onBluetoothDeviceFound.res=', JSON.stringify(res))
    res.devices.forEach(device => {
      console.log('index.onDeviceFound .deviceSn=', deviceSn, '; device.name=', device.name, (deviceSn && device.name != deviceSn))
      // console.log('index.onBluetoothDeviceFound.res.devices.forEach.device=',JSON.stringify(device))
      if (!device.name && !device.localName) {
        console.log('index.onBluetoothDeviceFound 过滤设备名称为空 name:', device.name, '; localName:', device.localName)
        return
      }
      if (device.name.indexOf(MAGNET_NAME_PREFIX) == -1) {
        console.log('index.过滤 设备名称前缀 deviceId=', device.deviceId, '; name=', device.name, ' ; localName=', device.localName, '; deviceSn=', deviceSn)
        return;
      } else {
        console.log('index.onBluetoothDeviceFound.res.devices.forEach.device.name=', device.name, '; device.localName=', device.localName, '; device.deviceId=', device.deviceId, '; device.name.indexOf(MAGNET_NAME_PREFIX)=', device.name.indexOf(MAGNET_NAME_PREFIX), '; ', MAGNET_NAME_PREFIX)
      }
      if (!device.advertisServiceUUIDs || device.advertisServiceUUIDs.length === 0) {
        console.log('index.onBluetoothDeviceFound 过滤开放服务为空 deviceId=', device.deviceId)
        return
      }
      // onBluetoothDeviceFound.res= {"devices":[{"deviceId":"20:24:4A:00:00:01","name":"YT:01000001","RSSI":-68,"connectable":true,"advertisData":{},"advertisServiceUUIDs":["0000FFF0-0000-1000-8000-00805F9B34FB"],"localName":"YT:01000001","serviceData":{}}]}
      // index.js:1 index.onDeviceFound .deviceSn= undefined ; device.name= YT:01000001 true
      // index.js:1 index.onBluetoothDeviceFound.res.devices.forEach.device.name= YT:01000001 ; device.localName= YT:01000001 ; device.deviceId= 20:24:4A:00:00:01 ; device.name.indexOf(MAGNET_NAME_PREFIX)= 0 ;  YT:01

      if (deviceSn != 'undefined' && deviceSn != undefined && deviceSn.length > 0 && deviceSn && device.name != deviceSn) {
        // 已绑定但扫描到其他设备
        console.log('index.onBluetoothDeviceFound 过滤 绑定设备名 deviceId=', device.deviceId, '; name=', device.name, ' ; localName=', device.localName, '; deviceSn=', deviceSn)
        return;
      }
      // notifyResultList.value.push("过滤服务" + device.advertisServiceUUIDs.join(","))
      if (device.advertisServiceUUIDs.join(",").toUpperCase().indexOf(MagnetDeviceUUID.MAGNET_UUID_PREFIX) != -1) {
        console.log('index.onBluetoothDeviceFound index of 发现匹配服务', device.advertisServiceUUIDs)
      } else {
        console.log('index.onBluetoothDeviceFound index of 未找到匹配服务', device.advertisServiceUUIDs)
        return;
      }
      // deviceList.value.push(device)
      console.log('onBluetoothDeviceFound device=', JSON.stringify(device), '; connectedDevice.value=', connectedDevice.value)
      if (!connectedDevice.value) {
        connectedDevice.value = device
        showToast('扫描成功，找到匹配治疗仪')
        updateState(MagnetScanMeasureState.BIND_SCAN_SUCCESS)
      }
      stopScan()
      clearTimer()
      startConnect()
    })
  })
}

const startConnect = () => {
  if (connected.value) {
    // 已连接
    logger.log("startConnect 已连接 不重复连接")
    return
  }
  if (!connecting.value) {
    connecting.value = true
  } else {
    // 连接中
    logger.log("startConnect 连接中不重复连接")
    return
  }
  updateState(MagnetScanMeasureState.CONNECTING)
  // notifyResultList.value.push("找到设备，开始连接," + Date.now())
  console.log('index.startConnect.device.value=', connectedDevice.value)
  let {deviceId} = connectedDevice.value
  startScanTimer()
  Taro.createBLEConnection({
    deviceId,
    timeout: 5000,
    success: function (res) {
      console.log('index.createBLEConnection.success.', JSON.stringify(res))
      onConnectionStateChange()
      onConnectSuccess()
    },
    fail: function (res) {
      console.log('index.startConnect.createBLEConnection.fail.', JSON.stringify(res))
      // notifyResultList.value.push("连接失败" + prints(res))
      updateState(MagnetScanMeasureState.CONNECT_FAILURE)
      clearTimer()
    },
    complete: (res) => {
      // notifyResultList.value.push("建立连接调用结束," + Date.now())
      onConnectionStateChange()
    }
  })

}

const onConnectFailure = () => {
  logger.log("onConnectFailure.")
  if (connectedDevice.value && scaleMeasureState.value?.state === MagnetScanMeasureState.BIND_MEASURING.state) {
    disConnect(() => {
      startConnect()
    })
  } else {
    connected.value = false
    connecting.value = false
    updateState(MagnetScanMeasureState.LOST_CONNECT)
    uploadDeviceShutDown()
    clearTimer()
    clearHeartCheck()
  }
}

const onConnectSuccess = () => {
  console.log('index.onConnectSuccess.')
  connected.value = true
  updateState(MagnetScanMeasureState.CONNECT_SUCCESS)
  startMeasure()
  // notifyResultList.value.push("连接成功，开始监听服务")
  heartCheck()
  bindDevice()
}

const onConnectionStateChange = () => {
  console.log('index.onConnectionStateChange.')
  Taro.onBLEConnectionStateChange((res) => {
    console.log('onConnectionStateChange', `device ${res.deviceId} state has changed, connected: ${res.connected}`)
    if (res.connected) {
      // onConnectSuccess()
      // heartCheck()
    } else {
      onConnectFailure()
    }
  })
}

const offBLEConnectionStateChange = () => {
  Taro.offBLEConnectionStateChange((res) => {
    console.log('onConnectionStateChange', `device ${res.deviceId} state has changed, connected: ${res.connected}`)
  })
}

const startMeasure = () => {
  console.log('index.startMeasure.')
  let {deviceId} = connectedDevice.value
  // notifyCharacteristicValueChange(deviceId, MagnetDeviceUUID.MAGNET_UUID_UPPER, MagnetDeviceUUID.SERV_MAGNET_UUID_UPPER)
  // // notifyResultList.value.push("直接对指定服务开始监听")

  Taro.getBLEDeviceServices({
    deviceId,
    success: (res) => {
      console.log('index.getBLEDeviceServices.success.', JSON.stringify(res))
      // 查找特定服务 ，找到继续查找特征值，找不到直接反馈失败
      if (res.services && res.services.length > 0) {
        deviceServiceId = res.services.find(service =>
            service.uuid.toUpperCase().indexOf(MagnetDeviceUUID.MAGNET_UUID_PREFIX) != -1
        );
      }
      if (deviceServiceId) {
        // notifyResultList.value.push("找到对应服务，正式准备开始监听")
        getBleCharacteristics(deviceId, deviceServiceId.uuid)
      } else {
        updateState(MagnetScanMeasureState.SERVICE_NOT_FOUND)
      }

    },
    fail: (res) => {
      logger.log('index.getBLEDeviceServices.fail.', JSON.stringify(res))
      updateState(MagnetScanMeasureState.SERVICE_NOT_EXIST)
    }
  })
}

let deviceServiceId: Taro.getBLEDeviceServices.BLEService | undefined,
    notifyCharacteristic: Taro.getBLEDeviceCharacteristics.BLECharacteristic | undefined,
    writeCharacteristic: Taro.getBLEDeviceCharacteristics.BLECharacteristic | undefined

const getBleCharacteristics = (deviceId: string, serviceId: string) => {
  Taro.getBLEDeviceCharacteristics({
    deviceId,
    serviceId,
    success: (res) => {
      console.log('index.getBLEDeviceCharacteristics.success.', JSON.stringify(res))
      if (res.characteristics && res.characteristics.length > 0) {
        notifyCharacteristic = res.characteristics.find(characteristic =>
            characteristic.uuid.toUpperCase().indexOf(MagnetDeviceUUID.SERV_MAGNET_UUID_PREFIX) != -1
        );
        // notifyResultList.value.push("解析监听特征值：" + notifyCharacteristic?.uuid)
        writeCharacteristic = res.characteristics.find(characteristic =>
            characteristic.uuid.toUpperCase().indexOf(MagnetDeviceUUID.SERV_MAGNET_WRITE_UUID_PREFIX) != -1
        );
        // notifyResultList.value.push("解析写入特征值：" + writeCharacteristic?.uuid)
      }
      if (notifyCharacteristic) {
        // 找到特征值
        console.log('index.getBLEDeviceCharacteristics.success. 找到特征值', JSON.stringify(notifyCharacteristic))
        // 开始读特征值
        notifyCharacteristicValueChange(deviceId, serviceId, notifyCharacteristic.uuid)
        // notifyResultList.value.push("找到特征值 开始监听")
      } else {
        updateState(MagnetScanMeasureState.SERVICE_NOT_FOUND)
      }
    },
    fail: (res) => {
      logger.log('index.getBLEDeviceCharacteristics.fail.', JSON.stringify(res))
      updateState(MagnetScanMeasureState.SERVICE_NOT_EXIST)
    }
  })
}

const notifyCharacteristicValueChange = (deviceId: string, serviceId: string, uuid: string) => {
  Taro.notifyBLECharacteristicValueChange({
    state: true,
    deviceId,
    serviceId,
    characteristicId: uuid,
    success: (res) => {
      logger.log('index.notifyBLECharacteristicValueChange.success.', JSON.stringify(res))
      onNotifyResponse()
      checkDevicePowerOn()
    },
    fail: (res) => {
      logger.log('index.notifyBLECharacteristicValueChange.fail.', JSON.stringify(res))
    }
  })
}

/**
 * 监听蓝牙特征值反馈
 */
const onNotifyResponse = () => {
  logger.log("onCharacteristicValueChange.")
  Taro.onBLECharacteristicValueChange((res) => {
    let hexString = ab2hex(res.value);
    logger.log(`onBLECharacteristicValueChange.characteristic ${res.characteristicId} has changed, now is ${res.value}`, '; parseValue=', hexString)
    // 470000e707011e0408240000f08a11
    let cmd = processor.analysisHexCmd(hexString);
    const cmdMode = cmd.control
    // notifyResultList.value.push("控制字：" + cmdMode + "; hex=" + hexString + "")
    if (cmdMode == MagnetCmdState.Measuring) {
      const startMeasureCmd = processor.analysisStartMeasure(cmd);
      console.log(`CompositeMagnetPresenter.onCharacteristicChanged.Measuring.startMeasureCmd=${startMeasureCmd}`);
      modeStrength = startMeasureCmd.modeStrength;
      // notifyResultList.value.push("startMeasureCmd 开始治疗：modeStrength:" + modeStrength)
      writeToDevice(CMD_PREFIX_APP + hexString.substring(2));
      uploadStartMeasure(startMeasureCmd);
      updateState(MagnetScanMeasureState.BIND_MEASURING);
    } else if (cmdMode == MagnetCmdState.MeasureFinish) {
      const magnetCmd = processor.analysisStopMeasure(cmd);
      // notifyResultList.value.push("MeasureFinish：治疗结束")
      updateState(MagnetScanMeasureState.BIND_MEASURE_SUCCESS);
      uploadMeasureFinish();
      console.log(`CompositeMagnetPresenter.onCharacteristicChanged.MeasureFinish.magnetCmd=${magnetCmd}`);
      let ms;
      if (modeStrength == undefined || modeStrength.length == 0) {
        // 默认以控制血糖、强档 避免出现无反馈
        ms = "21";
      } else {
        ms = modeStrength;
      }
      const checkSum = MagnetCmdState.MeasureFinish + parseInt(ms, 16);
      writeToDevice(CMD_PREFIX_APP + MagnetCmdState.MeasureFinish.toString(16) + ms + "000000" + checkSum.toString(16) + CMD_SUFFIX);

    } else if (cmdMode == MagnetCmdState.ReportsStartUp) {
      const startUpCmd = processor.analysisStartupReport(cmd);
      console.log(`CompositeMagnetPresenter.onCharacteristicChanged: ReportsStartUp.startUpCmd=${startUpCmd}`);
      uploadDeviceStartUp(startUpCmd);
      // notifyResultList.value.push("ReportsStartUp：上报开机时间")
    } else if (cmdMode == MagnetCmdState.HeartCheck) {
      const heartCheck = processor.analysisHeartCheck(cmd);
      if (modeStrength == undefined || modeStrength.length == 0) {
        modeStrength = heartCheck.modeStrength;
      }
      if (scaleMeasureState.value?.state == MagnetScanMeasureState.CONNECT_SUCCESS.state) {
        if (parseInt(modeStrength) > 0 && parseInt(heartCheck.runningState) == 1) {
          // 当前模式非空且正在运行
          updateState(MagnetScanMeasureState.BIND_MEASURING);
        }
      }
      // notifyResultList.value.push("心跳检测 " + Date.now())
      // showToast("心跳检测反馈 " + hexString)
      console.log("CompositeMagnetPresenter.onCharacteristicChanged: HeartCheck");
    }
  })
}

const offCharacteristicValueChange = () => {
  logger.log("offCharacteristicValueChange.")
  Taro.offBLECharacteristicValueChange((res) => {
    logger.log('index.onBLECharacteristicValueChange', JSON.stringify(res))
  })
}

const writeToDevice = (content: string) => {
  if (connectedDevice.value) {
    let {deviceId} = connectedDevice.value
    // writeList.value.push("writeToDevice " + content)
    Taro.writeBLECharacteristicValue({
      // 这里的 deviceId 需要在 getBluetoothDevices 或 onBluetoothDeviceFound 接口中获取
      deviceId,
      // 这里的 serviceId 需要在 getBLEDeviceServices 接口中获取
      // serviceId: MagnetDeviceUUID.MAGNET_UUID_UPPER,
      serviceId: deviceServiceId.uuid,
      // 这里的 characteristicId 需要在 getBLEDeviceCharacteristics 接口中获取
      // characteristicId: MagnetDeviceUUID.SERV_MAGNET_WRITE_UUID_UPPER,
      characteristicId: writeCharacteristic.uuid,
      // 这里的value是ArrayBuffer类型
      value: hex2ArrayBuffer(content),
      success: function (res) {
        // writeList.value.push("writeToDevice success:" + prints(res))
        console.log("writeBLECharacteristicValue success&", res.errMsg)
      },
      fail: function (res) {
        // writeList.value.push("writeToDevice fail:" + prints(res))
      },
      complete: (res) => {
        // writeList.value.push("writeToDevice complete:" + JSON.stringify(res))
      }
    })
  }
  // Taro.writeBLECharacteristicValue({
  //   // 这里的 deviceId 需要在 getBluetoothDevices 或 onBluetoothDeviceFound 接口中获取
  //   deviceId,
  //   // 这里的 serviceId 需要在 getBLEDeviceServices 接口中获取
  //   serviceId: deviceServiceId.uuid,
  //   // 这里的 characteristicId 需要在 getBLEDeviceCharacteristics 接口中获取
  //   characteristicId: writeCharacteristic.uuid,
  //   // 这里的value是ArrayBuffer类型
  //   value: new TextEncoder().encode(content).buffer,
  //   success: function (res) {
  //     writeList.value.push(JSON.stringify(res))
  //     console.log("writeBLECharacteristicValue success&", res.errMsg)
  //   }
  // })
}

const prints = (res) => {

  const keys: string[] = [];
  const values: string[] = [];
  if (res && res.keys) {
    res.keys.forEach((key) => {
      keys.push(key);
      values.push(res[key])
    })
  }
  // for (const key in jsonObject) {
  //   keys.push(key);
  //   values.push(jsonObject[key])
  // }
  return keys.join(",") + "\n" + values.join(",")
}

const disConnect = (callback?: () => void) => {
  logger.log("disConnect.", connectedDevice.value)
  const {deviceId} = connectedDevice.value
  offBLEConnectionStateChange()
  Taro.closeBLEConnection({
    deviceId,
    success: (res) => {
      logger.log('index.closeBLEConnection.success.', JSON.stringify(res))
      connected.value = false
      connecting.value = false
      connectedDevice.value = null
      callback && callback()
    },
    fail: (res) => {
      logger.log('index.closeBLEConnection.fail.', JSON.stringify(res))
    }
  })
}


/**
 * 停止蓝牙活动
 * 1、
 * 2、关闭连接
 * 3、停止扫描
 * 4、关闭蓝牙适配器
 */
const stopBle = function (closeBle: boolean = true) {
  if (connected.value) {
    offCharacteristicValueChange()
    console.log('index.stopBle.ready to disconnect')
    disConnect()
  }
  clearTimer()
  clearHeartCheck()
  stopScan()
  if (closeBle) {
    closeBleAdapter()
  }
}

/**
 * 刷新蓝牙
 */
const restart = () => {
  console.log('index.restart.')
  if (connected.value) {
    offCharacteristicValueChange()
    disConnect()
  }
  stopScan(() => {
    startScan()
  })
}

// 下发方案 暂时无用
const sendScheme = () => {
  console.log('index.sendScheme.')
  writeToDevice("AB102101000032A5");
  // writeList.value.push("sendScheme")
}

// const clear = () => {
//   // notifyResultList.value = []
//   writeList.value = []
// }

const checkDevicePowerOn = () => {
  writeToDevice("AB080000000008A5");
  // writeList.value.push("checkDevicePowerOn")
}

// endregion

// region 扫描计时器与心跳检测

/**
 * 扫描计时器
 */
const startScanTimer = () => {
  console.log('index.startTimer.current time is ', Date.now())
  startTimer(() => {
    if (!connectedDevice.value) {
      updateState(MagnetScanMeasureState.BIND_SCAN_TIMEOUT)
      showToastLong("扫描失败，请重新点击连接治疗仪")
      stopScan()
    }
  })
}

interface ActionCallback {
  (): void
}

const heartCheck = () => {
  startHeartCheck(() => {
    console.log('index.startHeartCheck.heartCheck timeout.', Date.now())
    writeToDevice("AB040000000004A5")
    // writeList.value.push("heartCheck")
    heartCheck()
  })
}


// endregion

// region 页面逻辑操作
const goPlan = () => {

  // scaleMeasureState.value = MagnetScanMeasureState.BIND_MEASURING

  if (
      scaleMeasureState.value?.state == MagnetScanMeasureState.CONNECTING.state ||
      scaleMeasureState.value?.state == MagnetScanMeasureState.CONNECT_SUCCESS.state ||
      scaleMeasureState.value?.state == MagnetScanMeasureState.BIND_SCAN_SUCCESS.state
  ) {
    disConnect();
    Taro.navigateTo({
      url: '/pagesTreatment/index/index?from=1'
    })
  } else if (scaleMeasureState.value?.state == MagnetScanMeasureState.BIND_MEASURING.state) {
    // 正在治疗中  显示弹窗
    Taro.showModal({
      title: '提示',
      content: '正在治疗中，退出本页面将中断治疗',
      confirmText: '确定',
      success: function (res) {
        if (res.confirm) {
          stopBle();
          Taro.navigateTo({
            url: '/pagesTreatment/index/index?from=1'
          })
          updateState(MagnetScanMeasureState.BIND_TO_SCAN)
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  } else {
    Taro.navigateTo({
      url: '/pagesTreatment/index/index?from=1'
    })
  }
};

const bindDevice = () => {
  // notifyResultList.value.push("bindDevice bindState.value=" + bindState.value + "; name=" + connectedDevice.value.name + "; deviceId=" + connectedDevice.value.deviceId)
  // if (!(bindState.value.valueOf())) {
  SugarApi.bindDevice(connectedDevice.value.name, DeviceBrand.MAGNET.brand, DeviceCategory.MAGNET.valueOf()).then((res) => {
    console.log("item.vue.bindDevice..success", JSON.stringify(res));
    Taro.eventCenter.trigger('bind', {})
    // showShortToast('绑定成功')
  }, (failure) => {
    showShortToast(failure)
  })
  // }
}

/**
 * 上报开机
 * @param startUpCmd
 */
const uploadDeviceStartUp = (startUpCmd: MagnetRunningTimeReportCmd) => {
  console.log('index.uploadDeviceStartUp.', JSON.stringify(startUpCmd))
  let request = new MagnetUpload();
  request.deviceSn = connectedDevice.value.name
  request.deviceId = connectedDevice.value.deviceId
  request.mode = 0;
  // 依据协议 时间单位 分
  const minutes = parseInt(startUpCmd.time1) * 100 + parseInt(startUpCmd.time2);
  if (minutes > 0) {
    request.time = addMinutes(new Date(), -minutes);
  }
  if (request.time == null) {
    request.time = formatFullDateToStr(new Date());
  }
  // notifyResultList.value.push("uploadDeviceStartUp=" + JSON.stringify(request))
  MagnetApi.uploadMagnetStartup(request)
}

/**
 * 上报关机
 */
const uploadDeviceShutDown = () => {
  console.log('index.uploadDeviceShutDown.')
  let request = new MagnetUpload();
  request.deviceSn = connectedDevice.value.name
  request.deviceId = connectedDevice.value.deviceId
  request.mode = 0;
  request.time = formatFullDateToStr(new Date());
  // notifyResultList.value.push("uploadDeviceShutDown=" + JSON.stringify(request))
  MagnetApi.uploadMagnetFinish(request)
  clearHeartCheck()
}

/**
 * 治疗结束
 */
const uploadMeasureFinish = () => {
  let request = new MagnetUpload();
  request.deviceId = connectedDevice.value.deviceId
  request.deviceSn = connectedDevice.value.name
  request.mode = currentMode;
  request.runTime = runTime;
  request.powerLevel = powerLevel;
  request.time = formatFullDateToStr(new Date());
  // notifyResultList.value.push("uploadStartFinish=" + JSON.stringify(request))
  stopBle()
  MagnetApi.uploadMagnetFinish(request).then(res => {
    // 上传完毕 关闭当前页面 前往列表页面 增加参数后缀，用以区分页面入口来源
    Taro.navigateTo({
      url: '/pagesComposite/list/index?from=' + 1,
    })
  })
}

let modeStrength
let currentMode;
let powerLevel;
let runTime;

/**
 * 开始治疗
 * @param startMeasureCmd
 */
const uploadStartMeasure = (startMeasureCmd: MagnetStartMeasureCmd) => {
  let request = new MagnetUpload();
  request.deviceSn = connectedDevice.value.name
  request.deviceId = connectedDevice.value.deviceId
  request.mode = parseInt(startMeasureCmd.mode);
  modeStrength = startMeasureCmd.modeStrength
  currentMode = request.mode
  request.runTime = parseInt(startMeasureCmd.time1) * 100 + parseInt(startMeasureCmd.time2);
  request.powerLevel = parseInt(startMeasureCmd.strength);
  powerLevel = request.powerLevel
  request.time = formatFullDateToStr(new Date());
  // notifyResultList.value.push("uploadStartMeasure=" + JSON.stringify(request))
  MagnetApi.uploadMagnetStartup(request).then(res => {
    console.log('index.uploadMagnetStartup.response=', JSON.stringify(res))
  })
}

// endregion

// region 页面更新、响应页面事件
const onRetryBtnClick = () => {
  console.log('index.onRetryBtnClick.scaleMeasureState.value=', scaleMeasureState.value)

  switch (scaleMeasureState.value?.state) {
    case MagnetScanMeasureState.BIND_TO_SCAN.state:
    case MagnetScanMeasureState.UNBIND.state:
      if (!scanning.value) {
        updateState(MagnetScanMeasureState.BIND_TO_SCAN)
        checkBlePermission()
      } else {
        restart()
      }
      break;
    case MagnetScanMeasureState.LOCATION_CLOSE.state:
      const systemSetting = Taro.getSystemSetting()
      const locationEnabled = systemSetting.locationEnabled;
      if (locationEnabled) {
        checkBlePermission()
      } else {
        showBleDisableModal(MagnetScanMeasureState.LOCATION_CLOSE.subState)
      }
      break;
    case MagnetScanMeasureState.BIND_SCAN_TIMEOUT.state:
    case MagnetScanMeasureState.UNBIND_SCAN_TIMEOUT.state:
    case MagnetScanMeasureState.BIND_SCAN_FAILURE.state:
    case MagnetScanMeasureState.UNBIND_SCAN_FAILURE.state:
    case MagnetScanMeasureState.LOST_CONNECT.state:
    case MagnetScanMeasureState.CONNECT_FAILURE.state:
    case MagnetScanMeasureState.BIND_MEASURE_SUCCESS.state:
      updateState(bindState.value ? MagnetScanMeasureState.BIND_TO_SCAN : MagnetScanMeasureState.UNBIND)
      // restart()
      checkBlePermission()
      break;
    case MagnetScanMeasureState.BIND_MEASURE_FAILURE.state:

      break;
    case MagnetScanMeasureState.BLE_DISABLE.state:
      // let systemInfo = Taro.getSystemInfoSync();
      // if (systemInfo.platform === 'ios') {
      //   Taro.showModal({
      //     title: '提示',
      //     content: '请先打开手机蓝牙开关？',
      //     showCancel: false,
      //
      //   })
      // } else {
      //   Taro.openSystemBluetoothSetting(
      //       {
      //         success: (res) => {
      //           console.log("index.vue.updateState..success", res);
      //           checkBleAdapterState()
      //           onBleAdapterState()
      //         },
      //         fail: (res) => {
      //           console.log("index.vue.updateState..fail", res);
      //         }
      //       }
      //   );
      // }
      showBleDisableModal();
      // checkBlePermission();
      break;
    case MagnetScanMeasureState.BLE_AUTHORIZE.state:
      logger.log('index.onRetryBtnClick.BLE_AUTHORIZE')
      Taro.openSystemBluetoothSetting({
        success: (res) => {
          console.log('index.onRetryBtnClick.BLE_AUTHORIZE.success.res=', JSON.stringify(res))
        }
      })
      break;
    case MagnetScanMeasureState.UNBIND_SCANING.state:
    case MagnetScanMeasureState.BIND_SCANING.state:
      showToastLong("正在扫描治疗仪，请稍候")
      break;
    default:
      console.log('index.onRetryBtnClick.default')
      break;
  }
}


const showBleDisableModal = (str: string | null = null) => {
  Taro.showModal({
    content: str || '手机蓝牙未开启，请先打开手机蓝牙',
    showCancel: false,
    confirmText: '知道了'
  })
}

const showBleAuthorizeModal = () => {
  Taro.showModal({
    content: MagnetScanMeasureState.BLE_AUTHORIZE.subState,
    showCancel: false,
    confirmText: '知道了',
    success: (res) => {
      Taro.openSystemBluetoothSetting({
        success: (res) => {
          console.log('index.showBleAuthorizeModal.BLE_AUTHORIZE.success.res=', JSON.stringify(res))
        }
      })
      // Taro.openSetting({
      //   success: (res) => {
      //     console.log('index.showBleAuthorizeModal.BLE_AUTHORIZE.success.res=', JSON.stringify(res))
      //   }
      // })
    }
  })
}

const updateState = (state) => {
  console.log("index.vue.updateState.", JSON.stringify(state));
  scaleMeasureState.value = state
  // notifyResultList.value.push("updateState=" + state.mainState)
}

const showPageBleState = () => {
  console.log('index.showPageBleState. state =', scaleMeasureState.value)
  // // if (scaleMeasureState.value?.retryBtnText) {
  // btButton.value = scaleMeasureState.value?.retryBtnText!!
  // // }
  // if (!btButton.value || btButton.value == '重新扫描') {
  //   btButton.value = "连接治疗仪"
  // }
  switch (scaleMeasureState.value?.state) {

    case MagnetScanMeasureState.BLE_AUTHORIZE.state:

      break;
    case MagnetScanMeasureState.LOCATION_CLOSE.state:

      break;
    case MagnetScanMeasureState.BLE_DISABLE.state:

      break;
    case MagnetScanMeasureState.BIND_TO_SCAN.state:
    case MagnetScanMeasureState.UNBIND.state:

      break;
    case MagnetScanMeasureState.BIND_SCANING.state:
    case MagnetScanMeasureState.UNBIND_SCANING.state:
      // 开启扫描成功

      break;
    case MagnetScanMeasureState.BIND_SCAN_FAILURE.state:
    case MagnetScanMeasureState.UNBIND_SCAN_FAILURE.state:
      // // 开启扫描失败
      // btIcon.value = imgUrlFormat('sugar/bluetooth_false.png');
      // btContent.value = "请扫描治疗仪蓝牙"
      // break;
    case MagnetScanMeasureState.BIND_SCAN_TIMEOUT.state:
      // btIcon.value = imgUrlFormat('sugar/bluetooth_false.png');
      // btContent.value = "连接治疗仪失败，请重新扫描治疗仪蓝牙"
      break;
    case MagnetScanMeasureState.SERVICE_NOT_EXIST.state:
    case MagnetScanMeasureState.SERVICE_NOT_FOUND.state:
      // 设备服务异常
      // btIcon.value = imgUrlFormat('sugar/bluetooth_false.png');
      // btContent.value = "治疗仪异常，请联系客服"
      showToastLong("治疗仪异常")
      break
    case MagnetScanMeasureState.CONNECT_FAILURE.state:
      showToastLong("治疗仪连接失败");
    case MagnetScanMeasureState.LOST_CONNECT.state:
      // btIcon.value = imgUrlFormat('sugar/bluetooth_true.png');
      // btTitle.value = "设备未连接"
      // btContent.value = "为数据上传成功，请持续开启蓝牙。请勿关闭。"
      break
    case MagnetScanMeasureState.BIND_MEASURING.state:
      // 开始测量
      showToastLong("请开始治疗");
      // btContent.value = MagnetScanMeasureState.BIND_MEASURING.subState
      break
    case MagnetScanMeasureState.BIND_SCAN_SUCCESS.state:
      // 开始测量
      showToastLong("发现治疗仪，开始扫描");
      break
    case MagnetScanMeasureState.CONNECT_SUCCESS.state:
      // 连接成功
      // btIcon.value = imgUrlFormat('sugar/bluetooth_true.png');
      // btTitle.value = "雅斯76L血糖仪设备已连接"
      // btContent.value = MagnetScanMeasureState.CONNECT_SUCCESS.subState
      // btButton.value = "查看数据"
      showToastLong("复合磁治疗仪连接成功");
      break;
    default:
      // btContent.value = "为数据上传成功，请持续开启蓝牙。请勿关闭。"
      break;
  }
}

// endregion


</script>
<style lang="less">
.icon {
  width: 44px;
  height: 44px;
}

.container_body_magnet {
  padding: 27.78px 20.84px;
  border-radius: 16.67px;

  .banner-img {
    width: 100%;
    height: 140rpx;
  }


  .card_bg {
    background: white;
    z-index: -2;
    margin-top: 20.84px;
    position: relative;
    min-height: 1150px;
    border-radius: 16.67px;

    .card {
      padding: 0 20.84px;

      .top_tips {
        font-size: 39.17px;
        font-weight: 600;

        display: flex;
        justify-content: center;
        align-items: center;
        padding-top: 50px;

        .icon {
          width: 27.78px;
          height: 27.78px;
          margin-right: 15px;
        }
      }

      .sub_tips {
        font-size: 33.17px;
        font-weight: 600;
        text-align: center;
        margin-top: 10px;
      }

      .tips {
        font-size: 30px;
        color: #5F5F5F;
        margin-top: 560px;
      }

    }


  }

  .btn {
    width: 666.67px;
    height: 97.22px;
    border-radius: 16.67px;
    background: #64A4F5;
    color: white;
    border: none;
    bottom: 50px;
    left: 41px;
    position: fixed;
  }

  .btn1 {
    width: 666.67px;
    height: 50.22px;
    border-radius: 16.67px;
    background: #64A4F5;
    color: white;
    border: none;
    bottom: 250px;
    left: 41px;
    position: fixed;
  }

  .btn2 {
    width: 666.67px;
    height: 50.22px;
    border-radius: 16.67px;
    background: #64A4F5;
    color: white;
    border: none;
    bottom: 170px;
    left: 41px;
    position: fixed;
  }

  .btn3 {
    width: 200px;
    height: 50.22px;
    border-radius: 16.67px;
    background: #64A4F5;
    color: white;
    border: none;
    bottom: 300px;
    left: 41px;
    position: fixed;
  }

  .magnet_cure_box {
    position: absolute;
    z-index: -1;
    top: 64px;
    left: 10px;

    display: flex;
    align-items: center;
    justify-content: center;

    .magnet_round {
      width: 694px;
      height: 840px;
      display: flex;
      align-items: center;
      justify-content: center;

    }
  }

  .magnet_cure_img {
    width: 450px;
    height: 450px;
  }
}
</style>
