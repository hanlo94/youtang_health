import {
    CMD_PREFIX_DEVICE,
    CMD_SUFFIX,
    MagnetCmd, MagnetHeartCheckCmd,
    MagnetRunningTimeReportCmd,
    MagnetStartMeasureCmd
} from "@/pagesComposite/MagnetConstants";

export class MagnetCommandProcessor {


    /**
     * Validates the correctness of a hexadecimal command.
     * @param hexStr The hexadecimal command string.
     * @returns True if the command is valid, false otherwise.
     */
    public validateHexCmd(hexStr: string): boolean {
        if (hexStr != null && hexStr.length > 0) {
            hexStr = hexStr.toUpperCase();
            return hexStr.startsWith(CMD_PREFIX_DEVICE) && hexStr.endsWith(CMD_SUFFIX);
        }
        return false;
    }

    /**
     * Analyzes a hexadecimal command string and returns a `MagnetCmd` object.
     * @param hexStr The hexadecimal command string.
     * @returns A `MagnetCmd` object representing the parsed command.
     */
    public analysisHexCmd(hexStr: string): MagnetCmd {
        const cmd = new MagnetCmd();
        cmd.prefix = hexStr.substring(0, 2);
        cmd.control = parseInt(hexStr.substring(2, 4), 16);
        cmd.netLoad = hexStr.substring(4, 12);
        if (hexStr.length >= 14) {
            cmd.checkSum = parseInt(hexStr.substring(12, 14), 16);
            if (hexStr.length >= 16) {
                cmd.suffix = hexStr.substring(14, 16);
            }
        }
        return cmd;
    }

    /**
     * Analyzes a `MagnetCmd` object and returns a `MagnetStartMeasureCmd` object.
     * @param cmd The `MagnetCmd` object to analyze.
     * @returns A `MagnetStartMeasureCmd` object representing the parsed command.
     */
    public analysisStartMeasure(cmd: MagnetCmd): MagnetStartMeasureCmd {
        const startMeasureCmd = new MagnetStartMeasureCmd(cmd);
        const netLoad = cmd.netLoad;
        startMeasureCmd.modeStrength = netLoad.substring(0, 2);
        startMeasureCmd.strength = netLoad.substring(0, 1);
        startMeasureCmd.mode = netLoad.substring(1, 2);
        startMeasureCmd.time1 = netLoad.substring(2, 4);
        startMeasureCmd.time2 = netLoad.substring(4, 6);
        return startMeasureCmd;
    }

    /**
     * Analyzes a `MagnetCmd` object for a stop measure command.
     * @param cmd The `MagnetCmd` object to analyze.
     * @returns The same `MagnetCmd` object, unchanged.
     */
    public analysisStopMeasure(cmd: MagnetCmd): MagnetCmd {
        return cmd;
    }

    /**
     * Analyzes a `MagnetCmd` object for a startup report command and returns a `MagnetRunningTimeReportCmd` object.
     * @param cmd The `MagnetCmd` object to analyze.
     * @returns A `MagnetRunningTimeReportCmd` object representing the parsed command.
     */
    public analysisStartupReport(cmd: MagnetCmd): MagnetRunningTimeReportCmd {
        const startMeasureCmd = new MagnetRunningTimeReportCmd(cmd);
        const netLoad = cmd.netLoad;
        startMeasureCmd.time2 = netLoad.substring(2, 4);
        startMeasureCmd.time1 = netLoad.substring(4, 6);
        return startMeasureCmd;
    }

    public analysisHeartCheck(cmd: MagnetCmd): MagnetHeartCheckCmd {
        const heartCheck = new MagnetHeartCheckCmd(cmd);
        const netLoad = cmd.netLoad;
        heartCheck.modeStrength = netLoad.substring(0, 2);
        heartCheck.time1 = netLoad.substring(2, 4);
        heartCheck.time2 = netLoad.substring(4, 6);
        heartCheck.runningState = netLoad.substring(6, 8);
        return heartCheck;
    }
}
