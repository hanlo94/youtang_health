import {createApp} from "vue";
import "./app.less";
import router from "../src/router/index";
import {createPinia} from "pinia";
import StoreUtils from "@/utils/storeUtils";
import MineApi from "@/pagesMine/api/mine";

const App = createApp({
// @ts-ignore
    onShow(options) {
    },

    /** 
     * 主要是获取用户信息将用户信息缓存到localStorage中
    */
    onLaunch(options) {
        if (StoreUtils.readPatientId()) {
            MineApi.getPatientInfo().then((res) => {
                StoreUtils.savePatientHeight(res.data.height)
                StoreUtils.savePatientWeight(res.data.weight)
                StoreUtils.savePatientGender(res.data.gender)
                StoreUtils.savePatientLaborIntensity(res.data.labourIntensity)
                StoreUtils.savePatientBirthday(res.data.birth)
                StoreUtils.saveUserInfo(res.data)
                // {"msg":"查询成功","code":10000,"data":{"name":"肖世玉26","gender":1,
                //     "avatar":"","diabetesType":2,"height":174,
                //     "weight":75,"labourIntensity":1,"sugarAge":"",
                //     "sugarControlSituation":"","treatmentMethod":"","sleepSituation":"",
                //     "healthAction":"","complication":"","labels":"","mobile":"18701242109"},"status":true}

            })
        }
    },

    componentDidShow(options) {},

    onHide(options) {},

    componentDidHide(options) {}


    // 入口组件不需要实现 render 方法，即使实现了也会被 taro 所覆盖
});

App.use(router);
App.use(createPinia());

export default App;
