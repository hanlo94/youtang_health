/**
 * Description：
 * Created on 2023/7/20
 * Author :  郭
 */

export interface IHba1cChildItem {
    recordId:number;
    recordTime:string;
    remark:string;
    hba1c:number;
}

export interface IHba1cItem {
    recordDate:string;
    recordWeek:string;
    recordList:IHba1cChildItem[]
}