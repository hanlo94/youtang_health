export default definePageConfig({
    navigationBarTitleText: "糖化记录",
    usingComponents:{
        'ec-canvas':'../../component/ec-canvas/ec-canvas'
    }
});
