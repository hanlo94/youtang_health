<!--
Description：
Created on 2023/9/9
Author :  郭 -->
<template>
	<view class="view_root">
		<nut-tabs class="tab" v-model="active" color="#64A4F5" background="#ffffff" @click="changeTab">
			<nut-tab-pane title="曲线"></nut-tab-pane>
			<nut-tab-pane title="列表"></nut-tab-pane>
		</nut-tabs>
		<view class="view_charts" v-if="active === '0' ">
			<view class="view_bg">
				<view class="view_btn">
					<nut-button :class=" buttonIndex === 1? 'btn_true' : 'btn_false'  " type="info"
								@click="onClickFilter(1)">
						两周
					</nut-button>
					<nut-button :class=" buttonIndex === 2? 'btn_true' : 'btn_false'" type="info"
								@click="onClickFilter(2)">
						一个月
					</nut-button>
					<nut-button :class=" buttonIndex === 3? 'btn_true' : 'btn_false'" type="info"
								@click="onClickFilter(3)">
						三个月
					</nut-button>
				</view>
				<view class="charts" v-if="!isEmpty(recordChartList) ">
					<ec-canvas id="chart-dom-area" canvas-id="chart-area" :ec="ec"
							   force-use-old-canvas="true"></ec-canvas>
				</view>
				<view v-else>
					<nut-empty image="https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/common/nodata.png"
							   description="暂时还没有数据哦~"></nut-empty>
				</view>
			</view>

			<view class="view_bg " style="margin-top: 20px">
				<text>糖化数据</text>
				<view class="table">
					<nut-table :columns="columns" :data="recordTableList" bordered>
						<template #nodata>
							<div class="no-data"> 暂时还没有数据哦~</div>
						</template>
					</nut-table>
				</view>
			</view>


		</view>
		<scroll-view class="view_list" v-if="active ===  '1'" :scroll-y="true" @scrollToLower="scroll" flexed>
			<view v-if="!isEmpty(dataList)" class="view_item" v-for="(item, index) in dataList" :key="index">
				<view class="item_header">
					<text>{{ item.recordDate }}{{ item.recordWeek }}</text>
					<text></text>
				</view>
				<view class="item_bottom" v-for="(childItem,childIndex) in item.recordList" :key="childItem.recordId">
					<text>{{ childItem.recordTime.split(' ')[1] }}</text>
					<!--          低1  中 2  高3-->
					<tag-text :is-normal="formatHba1c(childItem.hba1c)" :sugarValue="childItem.hba1c "
							  :show-unity=" '%' "></tag-text>
				</view>
			</view>
			<view v-else class="view_no_data">
				<nut-empty image="https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/common/nodata.png"
						   description="暂时还没有数据哦~"></nut-empty>
			</view>
		</scroll-view>

	</view>
</template>
<script setup lang="ts">

import {reactive, ref} from "vue";
import TagText from "@/component/tag-text/tag-text.vue";
import {isEmpty} from "lodash";
import {IHba1cChildItem, IHba1cItem} from "@/pagesHba1c/ts/types";
import Hba1cApi from "@/pagesHba1c/api/Hba1c";
import * as echarts from "@/component/ec-canvas/echarts";
import {categoryHba1cChartOptions, categoryPressureChartOptions} from "@/utils/chartOption";
import {createRender} from "@/utils/pubUtils";
import Taro from "@tarojs/taro";
import StoreUtils from "@/utils/storeUtils";

definePageConfig({
	navigationBarTitleText: '糖化记录'
})
const active = ref('0')
const sum = ref([]);

const buttonIndex = ref(1)
/**
 * 默认页码
 */
const pageNum = ref(1);
const dataList = ref<Array<IHba1cItem>>([] as IHba1cItem[]);

const columns = [
	{
		title: '日期',
		key: 'recordTime',
		stylehead: 'font-size:10px;color:#666666; background:#EBF6FF;',
		stylecolumn: 'font-size:10px;color:#666666;',
		align: "center",
		render: (record) => createRender(record.dataId, record.recordTime, onTableItemClick)
	},
	{
		title: '糖化血红蛋白',
		key: 'hba1c',
		stylehead: 'font-size:10px;color:#666666; background:#EBF6FF;',
		stylecolumn: 'font-size:10px;color:red;',
		align: "center",
		render: (record) => createRender(record.dataId, record.hba1c, onTableItemClick)
	},
]

const recordTableList = ref<IHba1cChildItem[]>([] as IHba1cChildItem[])

const recordChartList = ref<IHba1cChildItem[]>([] as IHba1cChildItem[])

const chart = ref();

function initChart(canvas: any, width: any, height: any) {
	console.log("index.vue.initChart.",);
	// echarts.init初始化
	chart.value = echarts.init(canvas, null, {
		width,
		height
	})

	loadChart()
	return chart
}

const loadChart = () => {
	if (chart && chart.value && !isEmpty(recordChartList.value)) {
		// console.log("index.vue.loadChart.recordChartList=", JSON.stringify(recordChartList.value), '; recordTableList=', JSON.stringify(recordTableList.value));
		let list = recordChartList.value.reverse()
		// console.log("index.vue.loadChart.list=", JSON.stringify(list));
		const option = categoryHba1cChartOptions(list);
		// console.log('option', option)
		chart.value.setOption(option)
	}
}

const ec = reactive({
	onInit: initChart
})


/**
 * 切换曲线与列表标签
 */
const changeTab = (res) => {
	let {paneKey} = res
	if (paneKey == 0) {
		requestTimePeriodData()
	} else if (paneKey == 1) {
		requestRecordList()
	}
}

/**
 * 点击按钮 切换状态 请求接口
 * @param index
 */
const onClickFilter = (index) => {
	buttonIndex.value = index;
	requestTimePeriodData(true)
}

/**
 *  低1  中 2  高3
 * @param val
 */
const formatHba1c = (val: number) => {
	if (val > 6.5) {
		return 3;
	} else {
		return 2;
	}
}
/**
 * loadmore
 */
const scroll = () => {
	requestRecordList();
}

const requestRecordList = () => {
	Hba1cApi.getHba1cList(pageNum.value).then(res => {
		if (pageNum.value === 1) dataList.value = [];
		if (!isEmpty(res.data)) {
			dataList.value?.push(...res.data);
			pageNum.value++;
		}
	})
}

const requestTimePeriodData = (isLoadChart: boolean = false) => {
	Hba1cApi.getTimePeriodHba1c(buttonIndex.value).then(res => {
		recordTableList.value = []
		recordTableList.value.push(...res.data)
		// recordChartList.value=[]
		recordChartList.value = res.data
		if (isLoadChart) {
			loadChart()
		}
	})
}

requestTimePeriodData()

Taro.eventCenter.on('login', (item) => {
	requestTimePeriodData()
})

const onTableItemClick = (param) => {
	console.log("index.vue.onTableItemClick.", param);
}

</script>

<style lang="less">
.view_root {
	background: #efefef;
	position: relative;
	height: 100vh;

	.tab {
		position: fixed;
		width: 100%;
		z-index: 10;
		height: 100px;
		top: 0;
	}

	.view_list {
		height: calc(100vh - 100px);
		padding-top: 100px;

		.view_item {
			background: white;
			border-radius: 20px;
			display: flex;
			padding: 20px;
			flex-direction: column;
			margin: 20px 30px;

			.item_header {
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				align-items: center;
				padding-bottom: 10px;
				color: #666666;
				border-bottom: #efefef 1px solid;;
			}

			.item_bottom {
				display: flex;
				margin-top: 20px;
				flex-direction: row;
				justify-content: space-between;
				color: #333333;
			}

		}

	}

	.view_no_data {
		height: 100vh;
		padding-top: 150px;

		.nut-empty__box {
			width: 440px;
			height: 260px
		}
	}

	.view_charts {
		padding-top: 100px;
		height: 100vh;
		flex: 1;
		margin: 30px;

		.view_bg {
			display: flex;
			background: white;
			padding: 30px;
			border-radius: 15px;
			flex-direction: column;

			.view_btn {
				border: 10px;
				width: 100%;
				display: flex;
				justify-content: space-around;
				align-items: center;

				.btn_true {
					width: 160px;
					height: 80px;
					background: #0099ff;
					color: #ffffff;
					border: #0099ff solid 1px;
				}

				.btn_false {
					width: 160px;
					height: 80px;
					color: #0099ff;
					background: #ffffff;
					border: #0099ff solid 1px;
				}
			}

			.nut-empty__box {
				width: 330px;
				height: 195px
			}

			.charts {
				position: relative;
				height: 480px;
			}

			.table {
			}
		}


	}

}

</style>>

