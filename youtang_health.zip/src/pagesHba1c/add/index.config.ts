export default definePageConfig({
    navigationBarTitleText: "记糖化",
});
