import {PAGE_SIZE, postPatientRequest} from "@/api/api";
import {IHba1cChildItem, IHba1cItem} from "@/pagesHba1c/ts/types";

const Hba1cApi = {
	// region ********** 糖化 *********

	/**
	 * 添加或修改糖化记录
	 * @returns {Promise | Promise<unknown>}
	 * @param params
	 */
	addOrEditHba1c(params: {
		hba1c, recordTime, remark, recordId?
	}) {
		const data = {
			actId: 11030801,
			record: params
		}

		return postPatientRequest(data)
	},


	/**
	 * 根据时间段类型查询糖化记录
	 * @param type 1 两周 2 一月 3 三月
	 */
	getTimePeriodHba1c(type) {
		return postPatientRequest<IHba1cChildItem[]>({actId: 11030804, type})
	},

	/**
	 * 糖化记录列表
	 * @param page
	 * @param pageSize
	 * @returns {Promise | Promise<unknown>}
	 */
	getHba1cList(page, pageSize = PAGE_SIZE) {
		const data = {
			page,
			pageNum: page,
			pageSize,
			actId: 11030803,
		}
		return postPatientRequest<IHba1cItem[]>(data)
	},

	// endregion
}

export default Hba1cApi
