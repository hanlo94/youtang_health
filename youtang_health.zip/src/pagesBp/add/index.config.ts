export default definePageConfig({
    navigationBarTitleText: "记血压",
    usingComponents: {
        'wxscale': '@/component/wx-scale/wx-scale'
    }
});
