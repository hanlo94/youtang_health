<template>
  <view class="container_bmi">
    <view class="top">
      <view class="content_box">
        <HealthScale :loading="false" v-model:value="form.systolic" :min="0" :max="300" :inputType="'number'" ,
                     max-length="3" :int="true" title="收缩压/高压" unit="mmHg"/>
        <HealthScale :loading="state.showDiastolic" v-model:value="form.diastolic" :min="0" :max="300"
                     :inputType="'number'" , max-length="3" :int="true" title="舒张压/低压" unit="mmHg"/>
        <HealthTitle title="脉压差" :value="bp.value" :status="bp.status" :color="bp.color">
          <view style="padding-bottom:20px">
            脉压差:临床常用的血压检测项目之一，是指血收缩压（高压）减去舒张压（低压）的差值，正常情况下为30~60mmHg。
          </view>
        </HealthTitle>
      </view>
      <view class="content_box">
        <HealthScale :loading="state.showHeartRate" v-model:value="form.heartRate" :min="30" :max="200"
                     :inputType="'number'" , max-length="3" :int="true" title="心率" unit="次/分钟"/>
      </view>
      <view class="record_box">
        <view class="title">
          <view class="left">测量日期</view>
          <view class="right" @click.stop="state.showDataPicker = true">
            <text>{{ selectedDate }}</text>
            <image class="icon" src="@/assets/image/common/fold.png" mode="aspectFit"></image>
          </view>
        </view>
        <view class="line"></view>
        <view class="title">
          <view class="left">备注</view>
        </view>
        <textarea class="textarea" placeholder="今天有啥特殊情况，如心情不佳，劳累等等。"></textarea>
      </view>
    </view>
    <view class="bottom">
      <nut-button class="submit_btn" type="primary" size="large" @click="saveData">保存</nut-button>
    </view>
    <nut-popup position="bottom" v-model:visible="state.showDataPicker">
      <nut-date-picker
          v-model="form.recordTime"
          :min-date="new Date(2018, 0, 1)"
          :max-date="new Date()"
          @confirm="popupConfirm"
          type="datetime"
          :is-show-chinese="true"
          title="选择时间"
      >
      </nut-date-picker>
    </nut-popup>

    <point_dialog :show-point-dialog="showPointDialog" :rewards=rewardPoint @closeDialog="onClosePointDialog"/>
  </view>
</template>
<script lang="ts" setup>
import point_dialog from '@/component/point/index.vue'
import HealthScale from '@/component/healthScale/index.vue'
import HealthTitle from '@/component/healthTitle/index.vue'
import {computed, onMounted, reactive, ref} from "vue";
import {getBp} from "@/utils/sugarUtils";
import {formatDateToStr} from "@/utils/dateUtils";
import {showToast} from "@/utils/toastUtils";
import Taro from "@tarojs/taro";
import {useDateFormat} from "@vueuse/core/index";
import BloodPressureApi from "@/pagesBp/api/BloodPressure";
import {useMainPageStore} from "@/utils/storeUtils";

const showPointDialog = ref<boolean>(false)
const rewardPoint = ref<number>(1)

const form = ref({
  diastolic: 80,
  systolic: 120,
  heartRate: 80,
  pulsePressure: 0,
  recordTime: new Date(),
  remark: '',
  recordId: 0,
})

const selectedDate = computed(() => {
  const date = form.value.recordTime;
  return useDateFormat(form.value.recordTime, 'YYYY年M月D日 HH:mm').value;
})

// 脉压差
const bp = computed(() => {
  const obj = getBp(form.value.systolic, form.value.diastolic)
  form.value.pulsePressure = obj.value;
  return obj;
})


const show = ref(false)
setTimeout(() => {
  show.value = true
}, 1000)

const state = reactive({
  showDataPicker: false,
  showDiastolic: true,
  showHeartRate: true,
})

onMounted(() => {
  setTimeout(() => {
    state.showDiastolic = false
  }, 1100)
  setTimeout(() => {
    state.showHeartRate = false
  }, 2100)
})

const popupConfirm = (v) => {
  state.showDataPicker = false;
}

const mainPageStore = useMainPageStore()

const saveData = () => {
  const data = form.value;
  data.recordTime = formatDateToStr(form.value.recordTime)
  BloodPressureApi.addOrEditBloodPressure(data).then(res => {
    showToast('已保存')
    if (res.data) {
      rewardPoint.value = res.data
      showPointDialog.value = true
    } else {
      onFinal()
    }
    mainPageStore.refreshPage()
  })
}

const onClosePointDialog = () => {
  console.log('index.onClosePointDialog.showPointDialog=', showPointDialog)
  showPointDialog.value = false
  onFinal()
}

const onFinal = () => {
  // 跳转到 血压记录
  Taro.redirectTo({
    url: '/pagesBp/record/index'
  })
}


</script>
<style lang="less">
.container_bmi {
  width: 100%;
  height: 100vh;
  padding: 0 20.83px;
  box-sizing: border-box;

  display: flex;
  flex-direction: column;

  .top {

    flex: 1;
    overflow-y: auto;

    .content_box {
      display: flex;
      flex-direction: column;
      border-radius: 16.67px;
      overflow: hidden;
      margin-bottom: 27.78px;
      margin-top: 27.78px;
    }

    .record_box {
      width: 708.33px;
      height: 552.08px;
      border-radius: 16.67px;
      background: #FFFFFF;

      .title {
        height: 100px;
        display: flex;
        justify-content: space-between;
        align-items: center;

        padding: 0 21px;

        .left {
          font-size: 33.33px;
          color: #353535;
        }

        .right {
          font-size: 33.33px;
          color: #5F5F5F;
          display: flex;
          align-items: center;

          .icon {
            width: 30.7px;
            height: 30.7px;
          }
        }
      }

      .line {
        width: 666.67px;
        height: 1px;
        border-bottom: 1px solid rgba(187, 187, 187, 0.65);
        margin: 0 auto;
      }

      .textarea {
        width: 626.67px;
        height: 237px;
        border: 0.69px solid #BBBBBB;
        border-radius: 16.67px;
        margin: 0 auto;
        padding: 20px;
        font-size: 31.94px;
        line-height: 38.19px;
        color: #5F5F5F;
      }

    }
  }

  .bottom {
    height: 150px;

    display: flex;
    align-items: center;

    .submit_btn {
      width: 708.33px;
      height: 97px;
      border-radius: 16.67px;
      background: #64A4F5;
      font-size: 34.72px;
    }
  }

}


</style>
