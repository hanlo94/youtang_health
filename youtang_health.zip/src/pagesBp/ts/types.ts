/**
 * Description：
 * Created on 2023/7/20
 * Author :  郭
 */

export interface IBpChildItem {
    "recordId":number;
    "recordTime":string;
    "recordDate":string;
    "remark":string;
    /**
     * 舒张压
     */
    "diastolic":number;
    /**
     * 收缩压
     */
    "systolic":number;
    "heartRate":number;
    /**
     * 脉压差
     */
    "pulsePressure":number;
    "userFlag":string;
}


export interface IBpItem {
    recordDate:string;
    recordWeek:string;
    recordList:IBpChildItem[];
}
