export default definePageConfig({
    navigationBarTitleText: "血压记录",
    usingComponents:{
        'ec-canvas':'../../component/ec-canvas/ec-canvas'
    }
});
