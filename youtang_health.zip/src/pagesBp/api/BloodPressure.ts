import {PAGE_SIZE, postPatientRequest} from "@/api/api";
import {IBpChildItem, IBpItem} from "@/pagesBp/ts/types";

const BloodPressureApi={
	// region ********** 血压 *********

	/**
	 * 编辑血压
	 * @param systolic 收缩压
	 * @param diastolic 舒张压
	 * @param heartRate 心率
	 * @param pulsePressure  脉压差
	 * @param recordTime 记录时间 yyyy-MM-dd HH:mm
	 * @param remark  备注
	 * @param recordId
	 * @returns {Promise | Promise<unknown>}
	 */
	addOrEditBloodPressure(params: { systolic, diastolic, heartRate, pulsePressure, recordTime, remark, recordId? }) {
		const data = {
			record: params,
			actId: 11030701,
		}
		return postPatientRequest(data)
	},


	/**
	 * 根据时间段类型查询血压记录
	 * @param type 1 两周 2 一月 3 三月
	 */
	getTimePeriodBloodPressure(type) {
		const data = {
			type: type,
			actId: 11030704,
		}
		return postPatientRequest<IBpChildItem[]>(data)
	},

	/**
	 * 血压记录列表
	 * @param page
	 * @param pageSize
	 * @returns {Promise | Promise<unknown>}
	 */
	getBloodPressureList(page, pageSize = PAGE_SIZE) {
		const data = {
			page: page,
			pageNum: page,
			pageSize: pageSize,
			actId: 11030703,
		}
		return postPatientRequest<IBpItem[]>(data)
	},

	// endregion
}

export  default BloodPressureApi
