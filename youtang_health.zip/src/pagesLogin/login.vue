<template>
  <view class="container_login">
    <view class="top">
      <image src="https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/common/logo.png" class="icon" mode="widthFix"></image>
      <view class="name">优唐医生</view>
      <view>
        <button class="btn" v-if="agree" open-type="getPhoneNumber" @getphonenumber="getPhoneNumber">手机号快捷登录</button>
        <button class="btn" v-else @click.stop="showTip = true">手机号快捷登录</button>
      </view>
    </view>
    <view class="agreement">
      <view class="radio" @click.stop="agree = !agree">
        <image v-if="agree" class="active" src="@/assets/image/common/radio.png" mode="widthFix"></image>
        <view v-else class="not_active"></view>
      </view>
      <view class="text">
        已阅读并同意
        <span class="agreement_name" @click="openServiceItem">《优唐医生服务协议》</span>和
        <span class="agreement_name" @click='openPrivacy'>《优唐医生隐私条款》</span>
        。若您的手机号未注册，将为您直接注册。
      </view>
      <view v-show="showTip&&!agree" class="tips">请先同意我们的协议和隐私条款</view>
    </view>

  </view>
</template>
<script setup lang="ts">
import {onMounted, ref} from "vue";
import Taro from "@tarojs/taro";
import LoginApi from "@/api/login";
import StoreUtils, {useMainPageStore} from "@/utils/storeUtils";
import {PatientInfo, WxMaSessionInfo} from "@/api/types";
import PageNavigation from "@/utils/pageNavigation";

const hasUserInfo = ref()
const userInfo = ref()
const wxSession = ref<WxMaSessionInfo>()

const agree = ref(false)

onMounted(() => {
  autoLogin()
})

const openServiceItem=()=>{
	PageNavigation.openServiceItem()
}

const openPrivacy=()=>{
	PageNavigation.openPrivacy()
}

const showTip = ref(false)

const autoLogin = () => {
  Taro.login({
    success: (res) => {
      console.log("login.vue.success.", JSON.stringify(res));
      let response = LoginApi.code2Session(res.code);
      if (response) {
        response.then((res) => {
          console.log("login.vue.success..success", JSON.stringify(res));
          wxSession.value = res.data
          StoreUtils.saveSession(res.data.sessionKey)
          StoreUtils.saveOpenId(res.data.openid)
          StoreUtils.saveUnionId(res.data.unionid)
        }, (failure) => {
          console.log("login.vue.success..failure", failure)
        }).catch((error) => {
          console.log("login.vue.success..error", error);
        })
      }
    },
    fail: (res) => {
      console.log("login.vue.fail.", JSON.stringify(res));
    }
  })
}

const getUserProfile = (event) => {
  console.log("login.vue.getUserProfile.", JSON.stringify(event));
  Taro.getUserProfile({
    desc: '请求获取用户信息',
    success: (res) => {
      userInfo.value = res.userInfo
      // LoginApi.decryptUserInfo()
      // console.log("login.vue.getUserProfile.success.", JSON.stringify(res));
    },
    fail: (failure) => {
      console.log("login.vue.getUserProfile.fail.", JSON.stringify(failure));
    }
  })
}

const mainPageStore = useMainPageStore()

const getPhoneNumber = (event) => {
  console.log("login.vue.getPhoneNumber.", JSON.stringify(event));
  let {detail} = event
  let response = LoginApi.decryptPhoneNo(detail.encryptedData, detail.iv, wxSession.value?.openid, wxSession.value?.unionid);
  if (response) {
    response.then((res) => {
      console.log("login.vue.getPhoneNumber..success", JSON.stringify(res));
      StoreUtils.savePatientId(res.data.patientId)
      StoreUtils.savePatientHeight(res.data.height)
      StoreUtils.savePatientWeight(res.data.weight)
      StoreUtils.savePatientGender(res.data.gender)
      StoreUtils.savePatientLaborIntensity(res.data.labourIntensity)
      StoreUtils.savePatientBirthday(res.data.birth)
		mainPageStore.refreshPage()
      Taro.showToast({title: '登录成功'})
		Taro.eventCenter.trigger('login', {})
		Taro.eventCenter.trigger('loginonce', {})

		setTimeout(() => {
			Taro.navigateBack()
		}, 1000)
    }, (failure) => {
      console.log("login.vue.getPhoneNumber..failure", failure)
    }).catch((error) => {
      console.log("login.vue.getPhoneNumber..error", error);
    })
  }
}

</script>
<style lang="less">
.container_login {
  height: 100vh;
  background: white;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;

  .top {
    display: flex;
    flex-direction: column;
    align-items: center;

    .icon {
      width: 166.67px;
      height: 166.67px;
      margin-top: 30%;
    }

    .name {
      font-size: 33.33px;
      font-weight: 600;
      color: #353535;
      margin-top: 28px;
    }

    .btn {
      width: 708.33px;
      height: 97.22px;
      background: #64A4F5;

      display: flex;
      align-items: center;
      justify-content: center;

      font-size: 34.72px;
      color: #FFFFFF;

      margin-top: 83px;
    }
  }

  .agreement {
    width: 100%;
    display: flex;
    margin-bottom: 82px;
    position: relative;

    .radio {
      width: 68.5px;
      height: 70px;

      display: flex;
      justify-content: center;
      padding-top: 7px;

      .not_active {
        width: 27.78px;
        height: 27.78px;
        border-radius: 50%;
        border: 1px solid #64A4F5;
      }

      .active {
        width: 27.78px;
        height: 27.78px;
      }
    }

    .text {
      flex: 1;
      font-size: 29.17px;
      color: #5F5F5F;
      margin-right: 21px;
    }

    .agreement_name {
      color: #64A4F5;
      display: inline;
    }

    .tips{
      position: absolute;
      top:-50px;
      background: #64A4F5;
      padding: 5px 8px;
      border-radius: 10px;
      color:white;
      font-size: 24px;
      margin-left: 20px;
    }
    .tips:after{
      content: ' ';
      position: absolute;
      bottom:-20px;
      left:7px;
      border: 10px solid transparent;
      border-top: 10px solid #64A4F5;
    }
  }
}
</style>
