export default definePageConfig({
    navigationBarTitleText: "登录",
});
