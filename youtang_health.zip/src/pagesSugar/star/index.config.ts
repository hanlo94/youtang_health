export default definePageConfig({
    navigationBarTitleText: "控糖明星",
});
