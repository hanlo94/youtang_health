<template>
  <view class="container_sugar_star">
    <scroll-view class="scroll" :scrollY="true" @scrollToLower="scroll" flex>
      <view v-for="item in starList" class="item round" @click.stop="gotoDetailPage(item)">
        <image class="avatar" :src="item.thumb" mode="aspectFill"/>
        <view class="info">
          <view class="top">
            <view class="name">{{ item.name }}</view>
            <view class="join_at">加入日期：{{ item.joinTime }}</view>
          </view>
          <view class="bottom">{{ item.gender===1?'女':'男' }}｜{{ item.age }}岁｜{{ item.sickLength }}｜{{ item.diabetesType }}</view>
        </view>
      </view>
      <view v-show="state.finished" class="on_the_bottom">已经到底了</view>
    </scroll-view>
  </view>
</template>
<script lang="ts" setup>
import SugarApi from "@/api/modules/sugar";
import {reactive, ref} from "vue";
import {ISugarStarItem} from "@/api/types";
import Taro from "@tarojs/taro";
import PageNavigation from "@/utils/pageNavigation";

const state = reactive({
  page: 1,
  finished: false,
})
const starList = ref<ISugarStarItem[]>([] as ISugarStarItem[]);
const requestSugarStar = () => {
  if (state.page === 1) {
    starList.value = [];
    state.finished = false;
  }

  if (state.finished) {
    return;
  }

  let response = SugarApi.getSugarStarList(state.page);
  response.then((res) => {
    if (!res.recordList||res.recordList.length === 0) {
      state.finished = true;
      return;
    }
    starList.value.push(...res.recordList)
  }, (failure) => {
    console.log("index.js.requestSugarStar..failure", failure)
  }).catch((error) => {
    console.log("index.js.requestSugarStar..error", error);
  })
}

requestSugarStar()

const scroll = () => {
  state.page++;
  requestSugarStar();
}

const gotoDetailPage = (item) => {
	PageNavigation.navigationToWebView(item.url)
  // Taro.navigateTo({
  //   url: `/pages/webview/index?src=${encodeURIComponent(item.url)}&title=`
  // })
}
</script>
<style lang="less">
.container_sugar_star {
  height: 100vh;
  padding: 20.84px 27.78px;
  display: flex;
  flex-direction: column;

  .scroll{
    flex:1;
    overflow-y: auto;
  }

  .item {
    width: 100%;
    height: 186.11px;
    padding: 20.84px 27.78px;
    background: white;

    display: flex;
    align-items: center;

    margin-bottom: 27.78px;

    .avatar {
      width: 130.56px;
      height: 130.56px;
      border-radius: 100%;
      margin-right: 20.84px;
    }

    .info {
      flex: 1;
      display: flex;
      flex-direction: column;

      .top {

        display: flex;
        justify-content: space-between;
        align-items: center;

        .name {
          font-size: 32px;
          color: #353535;
        }

        .join_at {
          font-size: 29px;
          color: #353535;
        }
      }

      .bottom {
        font-size: 29px;
        color: #353535;
        margin-top: 36px;
      }
    }
  }
}
</style>
