<template>

  <view class="container_food">
    <view>
      <view ref="statusBarRef" class="view_status"></view>
      <view ref="titleRef" class="view_title">
        <view>
          <RectLeft ref="leftArrow" @click="onClickBack"></RectLeft>
        </view>

        <view class="view_date" @click="onClickChangeDate">
          <text class="tv_date">{{ selectedDateFormat }}</text>
        </view>
        <view></view>
      </view>
    </view>
    <view class="header_bg">
      <view class="view_header_bg">
        <view class="view_progress_item">
          <span>摄入</span>
          <span class="count">{{ result.calorie }}</span>
        </view>

        <view>
          <nut-circle-progress :progress="progress" radius="80" stroke-width="10px" path-color="#F8F8F8" color="#64A4F5">
            <view class="view_progress_item">
              <span v-if="getKcal() > 0">还可以吃</span>
              <span v-else>多吃了</span>
              <span class="count_plus">{{ Math.abs(getKcal()) }}</span>
              <span>千卡</span>
            </view>

          </nut-circle-progress>
        </view>
        <view class="view_progress_item">
          <span>预算</span>
          <span class="count">{{ result.calorieRecommend }}</span>
        </view>

      </view>
      <view ref="foodAnalyse" class="food_analyse" @click="onclickAnalysis()">饮食分析
        <IconFont name="rect-right" size="14" color='#6AA4FC'/>
      </view>
    </view>

    <scroll-view class="scroll_list" :scroll-y="true" v-if="dataList && dataList.length">
      <view>
        <view class="view_item" v-for="(item,index) in dataList" :key="index">
          <view class="item_header">
            <view class="header_title">
              <view class="title">{{ getFoodTypeByMealType(item.mealType) }}</view>
              <text v-if="item.calorieLow && item.calorieHigh">（建议：{{ item.calorieLow }} -{{
                  item.calorieHigh
                }}千卡）
              </text>
            </view>
            <text>{{ item.calorie }}千卡</text>
          </view>
          <view class="child_item" v-for="(childItem) in item.recordFoodRelList" :key="childItem.dataId"
                @click.stop="onChildItemClick(childItem)">
            <img :src="childItem.foodThumb"/>
            <view class="item_right">
              <view class="item_content">
                <text>{{ childItem.foodName }}</text>
                <text>{{ childItem.calorie }}千卡</text>
              </view>
              <view> {{ childItem.amount }}克</view>
            </view>
          </view>
        </view>
        <view class="view_button">
          <nut-button shape="square" @click="onClickCopy"> 从以前复制</nut-button>
          <nut-button shape="square" @click="gotoCaloriesPage"> 热量柱状图</nut-button>
        </view>
      </view>

    </scroll-view>
    <view v-else class="empty_view">
      <view class="view_no_data">
        <nut-empty image="https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/common/nodata.png"
                   description="你还没有添加饮食记录，赶快添加吧~"></nut-empty>
      </view>
      <view class="view_button">
        <nut-button shape="square" @click="onClickCopy"> 从以前复制</nut-button>
        <nut-button shape="square" @click="gotoCaloriesPage"> 热量柱状图</nut-button>
      </view>
    </view>


    <view class="view_bottom_btn">

      <view class="view_add">
        <view @click="onClickAdd(1)">
          <img :src="tab1"/>
          早餐
        </view>
        <view @click="onClickAdd(3)">
          <img :src="tab2"/>
          午餐
        </view>
        <view @click="onClickAdd(5)">
          <img :src="tab3"/>
          晚餐
        </view>
        <view @click="onClickAdd(0)">
          <img :src="tab4"/>
          加餐
        </view>
      </view>
    </view>
  </view>
  <nut-action-sheet v-model:visible="visible" :menu-items="menuItems" cancel-txt="取消" @choose="choose">
  </nut-action-sheet>
  <nut-popup pop-class="calendar_popup" position="top" v-model:visible="showTopDate" :style="{ height: '20%' }" round>
    <calendar v-model:selectedDate="selectedDate" @change="onCalendarChange" :status-date-list="statusDateList"></calendar>
  </nut-popup>
  <nut-popup position="bottom" v-model:visible="showBottom" :round="true">
    <view class="pop_root">
      <view class="pop_header">
        <view class="info">
          <img :src="addItem.foodThumb"/>
          <view class="item_content">
            <view class="content_header">
              <view class="title">{{ addItem.foodName }}</view>
              <img :src="itemDelIcon" style="width: 15px;height: 20px" @click.stop="onClickDeleteFood"/>
            </view>
            <view class="content_bom">{{ addItem.calorie }}kcal/{{ addItem.amount }}克</view>

          </view>
        </view>
        <view class="key_input">
          <text></text>
          <text class="tv_input"> {{ keyBoardValue }}</text>
          <text>克</text>
        </view>
      </view>
      <view class="pop_key_board">
        <view class="key_number">
          <nut-grid :column-num="3">
            <nut-grid-item
                :text="item.value"
                v-for="(item, index) in keyBoardList"
                :key="index"
                @click="onKeyBoardItemClick(item)"
            >
              <img v-if="item.id === 12" :src="keyBoardDown" style="width: 20px;height: 20px;margin-top: 15px"/>
            </nut-grid-item>
          </nut-grid>
        </view>
        <view class="key_controls">
          <view class="view_del" @click="onClickDeleteValue">
            <img :src="keyBoardDel" style="width: 20px;height: 20px"/></view>
          <view class="view_save" @click.stop="onClickKeyBoardSave">保存</view>
        </view>
      </view>
    </view>
  </nut-popup>
</template>

<script setup lang="ts">

import {computed, onMounted, ref, watch} from "vue";
import {IconFont, RectLeft} from "@nutui/icons-vue-taro";
import Taro from "@tarojs/taro";
import {IFoodHomeChildItem, IFoodHomeItem, IFoodHomeRecord} from "@/pagesFood/ts/types";
import {getFoodTypeByMealType} from "@/utils/foodUtils";
import {TaroElement} from "@tarojs/runtime";
import FoodApi from "@/api/modules/food";
import calendar from '@/component/calendar'
import {formatDate, showShortToast} from "@/utils/util";
import imgUrlFormat from "@/utils/imgUtils";
import PageNavigation from "@/utils/pageNavigation";
import StoreUtils from "@/utils/storeUtils";
import {IKeyBoardItem, keyBoardList} from "@/pagesFood/ts/optionsUtils";
import {isEmpty} from "lodash";
import {ICalendarDateStatus} from "@/component/calendar/types";

const tab1 = imgUrlFormat('sugar/food/breakfast_blue.png')
const tab2 = imgUrlFormat('sugar/food/lunch_blue.png')
const tab3 = imgUrlFormat('sugar/food/dinner_blue.png')
const tab4 = imgUrlFormat('sugar/food/addfood_blue.png')
const itemDelIcon = imgUrlFormat('sugar/food/item_del_icon.png')
const keyBoardDown = imgUrlFormat('sugar/food/keyboard_down.png')
const keyBoardDel = imgUrlFormat('sugar/food/keyboard_del.png')


/**
 * 操作的item
 */
const addItem = ref<IFoodHomeChildItem>({} as IFoodHomeChildItem);

const selectedDate = ref(formatDate(new Date()))

const selectedDateFormat = computed(() => {
  return `${selectedDate.value.slice(5, 7)}月${selectedDate.value.slice(8, 10)}日`
})

const visible = ref(false);
const showBottom = ref(false);
/**
 * 点击加餐
 */
const menuItems = [{name: '早加餐', id: 2,}, {name: '午加餐', id: 4,}, {name: '晚加餐', id: 6,}];

/**
 * 展示顶部弹窗
 */
const showTopDate = ref(false);

/**
 * 中间进度条
 */
const progress = ref(0);

/**
 * 首页数据
 */
const result = ref<IFoodHomeRecord>({} as IFoodHomeRecord);
/**
 * 首页列表
 */
const dataList = ref<Array<IFoodHomeItem>>([] as IFoodHomeItem[]);

/**
 * 键盘上的文字
 */
const keyBoardValue = ref("");


const titleRef = ref<TaroElement>(null);
const statusBarRef = ref<TaroElement>(null);
const leftArrow = ref<TaroElement>(null);
const foodAnalyse = ref<TaroElement>(null);

//日历状态数据
const statusDateList =ref<Array<ICalendarDateStatus>>([] as ICalendarDateStatus[]);

/**
 * 日历数据变化
 */
const onCalendarChange = (data) => {
	console.log("index.vue.onCalendarChange.",JSON.stringify(data));
	requestCalendarDietRecord(data.date)
}

/**
 * 点击键盘保存
 */
const onClickKeyBoardSave = () => {
  editFoodRecord(addItem.value.dataId, keyBoardValue.value)
  // addItem.value.inputg = Number(keyBoardValue.value);
  // selList.value.forEach((item, index) => {
  //   if (item.id === addItem.value.id) {
  //     selList.value.splice(index, 1)
  //   }
  // })
  // selList.value.push(addItem.value);
  // showBottom.value = false;
  // getTotalKcal();
}


/**
 * 点击键盘
 * @param item
 */
const onKeyBoardItemClick = (item: IKeyBoardItem) => {
  if (item.id === 12) {
    keyBoardValue.value = "";
    showBottom.value = false;
  } else {
    if (keyBoardValue.value.length <= 8) {
      keyBoardValue.value = keyBoardValue.value += item.value;
    }
  }
};
/**
 * 点击键盘上的删除
 */
const onClickDeleteValue = () => {
  if (!isEmpty(keyBoardValue.value)) {
    keyBoardValue.value = keyBoardValue.value.substring(
        0,
        keyBoardValue.value.length - 1
    );
  }
};

/**
 * 点击移除food
 */
const onClickDeleteFood = () => {
  deleteFoodRecord(addItem.value.dataId);
}

/**
 * 弹窗展示
 * @param item
 */
const onChildItemClick = (item: IFoodHomeChildItem) => {
  addItem.value = item
  keyBoardValue.value = '';
  showBottom.value = true;
}


/**
 * 切换日期
 */
const onClickChangeDate = () => {
  showTopDate.value = true;
}


onMounted(() => {
  statusBarRef.value.style.height = statusBarHeight + "px";
  titleRef.value.style.height = titleBarHeight + "px";
  // foodAnalyse.value.style.top = titleBarHeight + statusBarHeight + 10 + "px";
});

const {statusBarHeight, screenWidth, screenHeight, windowHeight} =
    Taro.getSystemInfoSync();
// 获取胶囊信息
const {width, height, left, top, right} =
    Taro.getMenuButtonBoundingClientRect();

// 计算标题栏高度
const titleBarHeight = height + (top - statusBarHeight) * 2;
// 计算导航栏高度
const appHeaderHeight = statusBarHeight + titleBarHeight;
//边距，两边的
const marginSides = screenWidth - right;
//标题宽度
const titelBarWidth = screenWidth - width - marginSides * 3;
//去掉导航栏，屏幕剩余的高度
const contentHeight = screenHeight - appHeaderHeight;

const onClickBack = () => {
  Taro.navigateBack({delta: -1});
};

const getKcal = () => {
  return result.value.calorieRecommend - result.value.calorie;
}
Taro.eventCenter.on('refresh', (item) => {
  requestDietRecord(selectedDate.value);
})

/**
 * 弹窗 选择
 */
const choose = (item) => {
  Taro.navigateTo({url: "/pagesFood/add/index?type=" + item.id + "&calorieRecommend=" + result.value.calorieRecommend})
}

//去饮食分析
const onclickAnalysis = () => {
	console.log("index.vue.onclickAnalysis.selectedDate=", selectedDate);
	if (isEmpty(dataList.value)) {
		showShortToast("您还没有添加饮食记录~")
	} else {
		Taro.navigateTo({url: '/pagesFood/analysis/index?date=' + selectedDate.value})
	}
}
//从以前复制
const onClickCopy = () => {
  Taro.navigateTo({url: '/pagesFood/history/index'})
}

/**
 * 1早餐 2 早加餐  3 午餐 4 午加餐 5 晚餐 6 晚加餐
 * @param type
 */
const onClickAdd = (type: number) => {
  if (type === 0) {//弹窗
    visible.value = true;
  } else {
    Taro.navigateTo({url: "/pagesFood/add/index?type=" + type + "&calorieRecommend=" + result.value.calorieRecommend + '&selectedDate=' + selectedDate.value})
  }

}


/**
 * 查询饮食首页数据
 * @param date
 *
 */
const requestDietRecord = (date = null) => {

  setTimeout(() => {
    showTopDate.value = false;
  }, 200)

  let response = FoodApi.getDietRecordByDate(date);
  if (response) {
    response.then((res) => {
      result.value = res.data;
      progress.value = result.value.calorie / result.value.calorieRecommend * 100;

      let r: { mealType: any, calorie: number, calorieHigh: number, calorieLow: number, recordFoodRelList: any }[] = [];
      res.data.recordFoodMealList.forEach(food => {
        const found = (r.find(item => item.mealType === food.mealType))
        if (found) {
          found.calorie += food.calorie;
          found.recordFoodRelList.push(...food.recordFoodRelList);
        } else {
          r.push({
            mealType: food.mealType,
            calorie: food.calorie,
            calorieHigh: food.calorieHigh || 0,
            calorieLow: food.calorieLow || 0,
            recordFoodRelList: food.recordFoodRelList
          })
        }
      })
      dataList.value = r;

    }, (failure) => {
      console.log("index.vue.requestDietRecord..failure", failure)
    }).catch((error) => {
      console.log("index.vue.requestDietRecord..error", error);
    })
  }

}

/**
 * 查询日历饮食数据
 * @param date
 */
const requestCalendarDietRecord = (date = null) => {
	console.log("index.vue.requestCalendarDietRecord.date=", date);
	let response = FoodApi.getCalendarDietRecordByDate(date);
	if (response) {
		response.then((res) => {
			console.log("index.vue.requestCalendarDietRecord..success", JSON.stringify(res));
			if (!res || !res.data) {
				return
			}
			let {FoodRecommend, recordFoodList} = res.data
			if (!FoodRecommend || isEmpty(recordFoodList)) {
				return;
			}
			statusDateList.value=[]
			// {"msg":"获取饮食成功","code":10000,"data":{
			// 	"FoodRecommend":{"dataId":18118,"isDel":0,"addTime":1698137067,"patientId":13550365,"calorieRecommend":1800,"calorieLow":1800,"calorieHigh":1900,
			// 		"breakfastCalorieLow":540,"breakfastCalorieHigh":570,"lunchCalorieLow":720,"lunchCalorieHigh":760,"supperCalorieLow":540,"supperCalorieHigh":570},
			// 	"recordFoodList":[{"recordDate":"2023-10-23","recordWeek":"星期一","calorie":406}]},"status":true}
			let {calorieLow, calorieHigh} = FoodRecommend
			console.log("index.vue.requestCalendarDietRecord.calorieLow=", calorieLow, '; calorieHigh=', calorieHigh);
			recordFoodList.map(item => {
				let state: number = 2
				if (item.calorie < calorieLow) {
					state = 1;
				} else if (item.calorie > calorieHigh) {
					state = 3;
				}
				return {
					date: item.recordDate,
					state,
					calorie: item.calorie
				}
			}).forEach(stateItem => {
				statusDateList.value.push(stateItem)
			})
			console.log("index.vue.requestCalendarDietRecord.statusDateList=",JSON.stringify(statusDateList.value));
		}, (failure) => {
			console.log("index.vue.requestCalendarDietRecord..failure", failure)
		}).catch((error) => {
			console.log("index.vue.requestCalendarDietRecord..error", error);
		})
	}
}

onMounted(() => {
	console.log("index.vue.onMounted.",);
  requestCalendarDietRecord();
  requestDietRecord(selectedDate.value)
})

Taro.eventCenter.on('login', (item) => {
	requestCalendarDietRecord();
	requestDietRecord(selectedDate.value)
})

watch(() => selectedDate.value, (value) => {
  requestDietRecord(value)
}, {deep: true})

/**
 * 编辑修改食物记录
 */
const editFoodRecord = (foodRecordId, foodAmount) => {
  FoodApi.editDietRecord(foodRecordId, foodAmount).then(res => {
    //编辑成功刷新当前页
    addItem.value = {} as IFoodHomeChildItem;
    requestDietRecord(selectedDate.value);
    showBottom.value = false;
  }, err => {

  });

}

/**
 * 删除食物记录
 */
const deleteFoodRecord = (foodRecordId) => {
  FoodApi.deleteFoodRecord(foodRecordId).then(res => {
    //删除成功刷新当前页
    addItem.value = {} as IFoodHomeChildItem;
    requestDietRecord(selectedDate.value);
    showBottom.value = false;
  }, err => {
    console.log("index.vue.deleteFoodRecord..failure", err)
  });

}

// 摄量柱状图页面
const gotoCaloriesPage = () => {
  // http://h5test.youtang120.com/youtang/histogram.html?patientId=12194298&calorieLineVal=2047
  PageNavigation.navigationToLandscapeWebView(result.value.calorieHistogramUrl + '?patientId=' + StoreUtils.readPatientId() + "&calorieLineVal=" + result.value.calorieRecommend)
  // Taro.navigateTo({url: '/pagesFood/calories/index'})
}

</script>


<style lang="less">
.container_food {
  height: 100vh;
  position: relative;

  .header_bg {
    position: relative;
  }

  .view_header_bg {
    background: white;
    display: flex;
    height: 400px;
    align-items: center;
    justify-content: space-around;
    border-radius: 10px;
    margin: 20px 15px;

    .view_progress_item {
      display: flex;
      flex-direction: column;
      align-items: center;

      .count {
        font-weight: bold;
        color: #6AA4FC;
        font-size: 36px;
        margin-top: 30px;
      }

      .count_plus {
        font-weight: bold;
        color: #6AA4FC;
        font-size: 50px;
        margin-top: 20px;
        margin-bottom: 20px;
      }
    }

  }

  .food_analyse {
    border: #64A4F5 solid 1px;
    color: #6AA4FC;
    font-size: 30px;
    background: #EBF6FF;
    padding: 10px 20px;
    display: flex;
    align-items: center;
    border-top-right-radius: 20px;
    border-bottom-left-radius: 20px;
    position: absolute;
    top: 0;
    right: 15px;
  }

  .view_bottom_btn {
    display: flex;
    position: fixed;
    bottom: 20px;
    width: 100%;
    flex-direction: column;


    .view_add {
      display: flex;
      margin-top: 50px;
      padding: 20px 0;
      background: white;
      align-items: center;

      view {
        color: #6AA4FC;
        display: flex;
        align-items: center;
        flex-direction: column;
        font-size: 30px;
        justify-content: center;
        flex: 1;

        img {
          margin-bottom: 15px;
          width: 30px;
          height: 30px;
        }
      }
    }
  }

  .scroll_list {
    height: calc(100vh - 500px);
    padding-bottom: 200px;
    overflow: scroll;

    .view_item {
      display: flex;
      background: #ffffff;
      border-radius: 10px;
      margin: 10px 15px;
      flex-direction: column;

      .item_header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 20px 15px;
        color: #5F5F5F;
        border-bottom: #efefef solid 1px;

        .header_title {
          display: flex;
          font-size: 20px;
          align-items: baseline;

          .title {
            font-size: 30px;
          }
        }
      }

      .child_item {
        display: flex;
        padding: 10px 20px;
        flex-direction: row;
        align-items: center;

        img {
          width: 120px;
          background: #efefef;
          border-radius: 15px;
          height: 120px;
        }

        .item_right {
          margin-left: 20px;
          display: flex;
          font-size: 28px;
          color: #333333;
          height: 120px;
          justify-content: space-between;
          flex-direction: column;
          flex: 1;

          .item_content {
            display: flex;

            flex-direction: row;
            justify-content: space-between;
            color: #333333;
          }
        }

      }


    }
  }

  .view_status {
    background: white;
  }

  .view_title {
    display: flex;
    width: 100%;
    justify-content: space-between;
    background: white;
    align-items: center;

    view {
      flex: 1;
    }

    .nut-icon-rect-left {
      margin-left: 5px;
    }

    .view_date {
      display: flex;
      align-items: center;
      justify-content: center;

      .tv_date {
        line-height: 30px;
        text-align: center;
        padding: 10px 30px;
        border-radius: 30px;
        border: #6aa4fc solid 1px;
      }
    }
  }


}

.calendar_popup {
  height: 860px !important;
  padding-top: 160px;
}

.empty_view {
  height: calc(100vh - 600px);

  .view_no_data {
    height: 500px;
    padding-top: 100px;

    .nut-empty__box {
      width: 440px;
      height: 260px
    }
  }
}


.view_button {
  display: flex;
  align-items: center;
  justify-content: space-around;

  .nut-button {
    border-radius: 8px;
    width: 275px;
    height: 97px;
    background: transparent;
  }
}

.pop_root {
  display: flex;
  flex-direction: column;
  width: 100%;
  margin-top: 20px;

  .pop_header {
    width: 750px;
    height: 250px;

    .info {
      display: flex;
      height: 160px;
      align-items: center;
      padding: 10px 20px;

      img {
        width: 120px;
        height: 120px;
        border-radius: 10px;
      }

      .item_content {
        display: flex;
        flex: 1;
        margin-left: 20px;
        height: 120px;
        flex-direction: column;
        justify-content: space-between;

        .content_header {
          color: #333333;
          display: flex;
          font-size: 35px;
          flex-direction: row;
          align-items: center;
          justify-content: space-between;

          .delete {
            border-radius: 30px;
            width: 30px;
            color: white;
            height: 30px;
            text-align: center;
            padding-bottom: 5px;
            line-height: 30px;
            background: #6aa4fc;
          }
        }

        .content_bom {
          color: #5d5d5d;
          font-size: 30px;
        }
      }
    }

    .key_input {
      display: flex;
      margin-top: 10px;
      align-items: center;
      padding: 0 20px;
      justify-content: space-between;

      .tv_input {
        width: 200px;
        text-align: center;
        height: 50px;
        color: #6aa4fc;
        border-bottom: #bbbbbb solid 1px;
      }
    }
  }

  .pop_key_board {
    display: flex;
    width: 750px;
    height: 568px;
    flex-direction: row;
    align-items: center;

    .key_number {
      width: 550px;

    }

    .key_controls {
      display: flex;
      width: 200px;
      height: 568px;
      flex-direction: column;
      justify-content: space-around;
      align-items: center;

      .view_del {
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        flex: 1;
      }

      .view_save {
        width: 100%;
        background: #6aa4fc;
        display: flex;
        color: white;
        align-items: center;
        justify-content: center;
        flex: 1;
      }
    }
  }

	.nut-grid-item__text {
		font-size: 44px;
	}
}
</style>
