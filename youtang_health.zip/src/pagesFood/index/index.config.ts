export default definePageConfig({
    navigationBarTitleText: "饮食首页",
    navigationStyle: "custom"
});
