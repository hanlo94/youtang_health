export default definePageConfig({
    navigationBarTitleText: "饮食记录",
});
