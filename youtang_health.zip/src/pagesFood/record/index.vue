<template>
  <view class="container_food">
    /pages/food/food
  </view>
</template>

<script setup lang="ts">

</script>



<style lang="less">
.container_food{}
</style>
