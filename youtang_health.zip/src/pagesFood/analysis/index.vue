<template>
  <view class="container_food_analysis">
    <view class="view_card" >
      <view class="view_title" @click="goMealRateInfo">三餐热量比例 <img :src="tipsIcon" alt=""/></view>
      <view class="chart">
        <ec-canvas id="chart-dom-area1" canvas-id="chart-area"  :ec="ec" force-use-old-canvas="true"></ec-canvas>
      </view>
      <view class="view_date">
        <view class="date_item">
          <view class="item_title">早餐+早加餐</view>
          <nut-progress :percentage="dietAnalysis.breakfastCalorieRate" :stroke-color="getStatus(dietAnalysis.breakfastCalorieResult).color" :show-text="false"
                        :stroke-width="state.strokeWith"/>
          <view class="item_desc">占比{{ dietAnalysis.breakfastCalorieRate }}%
            <text :class="getStatus(dietAnalysis.breakfastCalorieResult).class">
              {{ getStatus(dietAnalysis.breakfastCalorieResult).val }}
            </text>
          </view>
        </view>
        <view class="date_item">
          <view class="item_title">午餐+午加餐</view>
          <nut-progress :percentage="dietAnalysis.lunchCalorieRate" :stroke-color="getStatus(dietAnalysis.lunchCalorieResult).color" :show-text="false"
                        :stroke-width="state.strokeWith"/>
          <view class="item_desc">占比{{ dietAnalysis.lunchCalorieRate }}%
            <text :class="getStatus(dietAnalysis.lunchCalorieResult).class">
              {{ getStatus(dietAnalysis.lunchCalorieResult).val }}
            </text>
          </view>
        </view>
        <view class="date_item">
          <view class="item_title">晚餐+晚加餐</view>
          <nut-progress :percentage="dietAnalysis.supperCalorieRate" :stroke-color="getStatus(dietAnalysis.supperCalorieResult).color" :show-text="false"
                        :stroke-width="state.strokeWith"/>
          <view class="item_desc">占比{{ dietAnalysis.supperCalorieRate }}%
            <text :class="getStatus(dietAnalysis.supperCalorieResult).class">
              {{ getStatus(dietAnalysis.supperCalorieResult).val }}
            </text>
          </view>
        </view>
      </view>

    </view>
    <view class="view_card">
      <view class="view_title" @click="goNutritionInfo">三大营养功能比例 <img :src="tipsIcon" alt=""/></view>
      <view class="view_tips">注:脂肪的供能效率比较高，是碳水化合物和蛋白质的2.25倍。</view>

      <view class="chart">
        <ec-canvas id="chararea2" canvas-id="chararea2" :ec="ec2" force-use-old-canvas="true"></ec-canvas>
      </view>
      <view class="view_date">
        <view class="date_item">
          <view class="item_title">碳水化合物</view>
          <view class="item_title">{{ dietAnalysis.carbohydrate }}克</view>
          <nut-progress :percentage="dietAnalysis.carbohydrateRate" :stroke-color="getStatus(dietAnalysis.carbohydrateResult).color" :show-text="false"
                        :stroke-width="state.strokeWith"/>
          <view class="item_desc">占比{{ dietAnalysis.carbohydrateRate }}%
            <text :class="getStatus(dietAnalysis.carbohydrateResult).class">
              {{ getStatus(dietAnalysis.carbohydrateResult).val }}
            </text>
          </view>
        </view>
        <view class="date_item">
          <view class="item_title">蛋白质</view>
          <view class="item_title">{{ dietAnalysis.protein }}克</view>
          <nut-progress :percentage="dietAnalysis.proteinRate" :stroke-color="getStatus(dietAnalysis.proteinResult).color" :show-text="false"
                        :stroke-width="state.strokeWith"/>
          <view class="item_desc">占比{{ dietAnalysis.proteinRate }}%
            <text :class="getStatus(dietAnalysis.proteinResult).class">{{
                getStatus(dietAnalysis.proteinResult).val
              }}
            </text>
          </view>
        </view>
        <view class="date_item">
          <view class="item_title">脂肪</view>
          <view class="item_title">{{ dietAnalysis.fat }}克</view>
          <nut-progress :percentage="dietAnalysis.fatRate" :show-text="false" :stroke-width="state.strokeWith"
                        :stroke-color="getStatus(dietAnalysis.fatResult).color"/>
          <view class="item_desc">占比{{ dietAnalysis.fatRate }}%
            <text :class="getStatus(dietAnalysis.fatResult).class">{{ getStatus(dietAnalysis.fatResult).val }}</text>
          </view>
        </view>
      </view>

    </view>
  </view>
</template>

<script setup lang="ts">

import {onMounted, reactive, ref, watch} from "vue";
import FoodApi from "@/api/modules/food";
import * as echarts from "@/component/ec-canvas/echarts";
import {mealChartOptions, nutritionChartOptions} from "@/utils/chartOption";
import {getCurrentInstance} from "@tarojs/runtime";
import PageNavigation from "@/utils/pageNavigation";

const tipsIcon = require("../../assets/image/common/tip.png");

const {date} = (getCurrentInstance().router?.params)
console.log("index.vue.analysis date=.",JSON.stringify(date));

// #ED8E36
// #64A4F5
// #DD3542

const state = reactive({
  chart: null,
  chart2: null,
  chartInit: false,
  strokeWith: 3,
})
const chart = ref();
const chart2 = ref();

function initChart(canvas: any, width: any, height: any) {
  console.log('canvas',canvas,width,height)
  chart.value = echarts.init(canvas, null, {
    width,
    height
  })

  return chart
}

function initChart2(canvas: any, width: any, height: any) {
  console.log('canvas',canvas,width,height)
  chart2.value = echarts.init(canvas, null, {
    width,
    height
  })

  state.chartInit = true;
  return chart
}

const ec = ref({
  onInit: initChart
})

const ec2 = ref({
  onInit: initChart2
})

interface IDietAnalysis {
  breakfastCalorie: number;
  breakfastCalorieRate: number;
  breakfastCalorieResult: number;
  calorie: number;
  carbohydrate: string; // 碳水
  carbohydrateRate: number;
  carbohydrateResult: number;
  fat: string; //脂肪
  fatRate: number;
  fatResult: number;
  lunchCalorie: number;
  lunchCalorieRate: number;
  lunchCalorieResult: number;
  mealRateUrl: string;
  nutritionRateUrl: string;
  protein: string; // 蛋白质
  proteinRate: number;
  proteinResult: number;
  supperCalorie: number;
  supperCalorieRate: number;
  supperCalorieResult: number;
}

const dietAnalysis = ref<IDietAnalysis>({} as IDietAnalysis);
const getStatus = (status) => {
  if (status == '-1') {
    return {val: '偏低', class: 'tv_yellow',color:'#ED8E36'}
  } else if (status == '0') {
    return {val: '正常', class: 'tv_blue',color:'#64A4F5'}
  } else {
    return {val: '偏高', class: 'tv_red',color:'#DD3542'}
  }
}
/**
 * 饮食分析
 * {
 *  "msg": "查询成功",
 *  "code": 10000,
 *  "data": {
 "breakfastCalorieRate": 100,  // 饼图百分比
 *    "breakfastCalorie": 2634,
 "breakfastCalorieResult": 1,  // -1 偏低 0 正常 1 偏高

 "lunchCalorie": 0,
 "lunchCalorieRate": 0,
 "lunchCalorieResult": -1,

 "supperCalorieRate": 0,
 *    "supperCalorieResult": -1,
 "supperCalorie": 0,
 "mealRateUrl": "http://cms.youtang.tangyisheng.com.cn/events/ddoctor-userApp/MealP.html",

 三大营养素
 *    "proteinRate": 11, //饼图百分比
 "protein": "74.10",
 "proteinResult": 0

 "fat": "2.42",
 *    "fatResult": -1,
 *    "fatRate": 1,
 *
 *    "carbohydrate": "579.60",
 *    "carbohydrateResult": 1,
 *    "carbohydrateRate": 88,

 *    "calorie": 2634,
 *
 *    "nutritionRateUrl": "http://cms.youtang.tangyisheng.com.cn/events/ddoctor-userApp/NutritiveP.html",

 *  },
 *  "status": true
 * }
 * @param date
 */
const getDietAnalysis = () => {
  FoodApi.dietAnalysis(date).then((res) => {
    console.log("index.vue.dietAnalysis..success", JSON.stringify(res));
    dietAnalysis.value = res.data;

    setTimeout(()=>{
      const config = mealChartOptions(dietAnalysis.value.breakfastCalorieRate, dietAnalysis.value.lunchCalorieRate, dietAnalysis.value.supperCalorieRate);
      chart.value.setOption(config);
    },400)

    setTimeout(()=>{
      const config2 = nutritionChartOptions(dietAnalysis.value.carbohydrateRate, dietAnalysis.value.proteinRate, dietAnalysis.value.fatRate);
      chart2.value.setOption(config2);
    },800)



  }, (failure) => {
    console.log("index.vue.dietAnalysis..failure", failure)
  }).catch((error) => {
    console.log("index.vue.dietAnalysis..error", error);
  })

}

watch(() => state.chartInit, (value, oldValue, onCleanup) => {
  if (value !== oldValue) {
    getDietAnalysis();
  }
}, {deep: true})

const goNutritionInfo=()=>{
	console.log("index.vue.goNutritionInfo.",JSON.stringify(dietAnalysis.value));
	if (dietAnalysis.value) {
		PageNavigation.navigationToWebView(dietAnalysis.value.nutritionRateUrl)
	}
}

const goMealRateInfo=()=>{
	console.log("index.vue.goMealRateInfo.",JSON.stringify(dietAnalysis.value));
	if (dietAnalysis.value) {
		PageNavigation.navigationToWebView(dietAnalysis.value.mealRateUrl)
	}
}

</script>


<style lang="less">
.container_food_analysis {
  .view_card {
    background: white;
    border-radius: 15px;
    padding: 20px;
    margin: 20px;

    .view_title {
      display: flex;
      align-items: center;

      img {
        width: 30px;
        margin-left: 5px;
        height: 30px;
      }
    }

    .chart {
      height: 250px;
      width: 250px;
      margin: 20px auto;
      border-radius: 50%;
      background: #6AA4FC;
    }

    .view_date {
      display: flex;
      margin-top: 20px;
      align-items: center;
      justify-content: space-between;

      .date_item {
        display: flex;
        flex: 1;
        margin: 10px 10px;
        flex-direction: column;
        color: #5F5F5F;
        align-items: center;

        .item_title {
          font-size: 25px;
          color: #5F5F5F;
        }

        .item_desc {
          font-size: 23px;
        }

        .nut-progress {
          padding: 10px 5px;
        }
      }

    }

    .view_tips {
      background: #EBF6FF;
      border-radius: 10px;
      color: #5D5D5D;
      font-size: 22px;
      padding: 10px 15px;
      margin-top: 20px;
    }
  }

  .tv_red {
    color: #DD3542;
  }

  .tv_yellow {
    color: #ED8E36;
  }

  .tv_blue {
    color: #64A4F5;
  }
}
</style>
