export default definePageConfig({
    navigationBarTitleText: "饮食分析",
    usingComponents:{
        'ec-canvas':'@/component/ec-canvas/ec-canvas'
    }
});
