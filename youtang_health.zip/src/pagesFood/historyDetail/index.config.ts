export default definePageConfig({
	navigationBarTitleText: "记录详情",
});
