<template>
  <view class="container_food">
    <view class="item_title">
      <view class="title_left" @click="onClickAllSel">
        <img :src="imgCheckTrue" v-if="result.check"/>
        <img :src="imgCheckFalse" v-else/>
        <text>{{ result.recordDate }}</text>
      </view>
      <view class="title_right">
        <view class="point "></view>
        <text>{{ result.calorie }}千卡</text>
      </view>
    </view>
    <view style="padding-bottom: 100px">
      <view class="view_cell" v-for="(item ,index) in result.recordFoodMealList" :key="index">
        <view class="item_header">
          <view @click="onClickItem(item)">
            <img :src="imgCheckTrue" v-if="item.check"/>
            <img :src="imgCheckFalse" v-else/>
            <text>{{ getFoodTypeByMealType(item.mealType) }}
              <text class="tv_suggest" v-if="item.calorieLow && item.calorieHigh">
                （建议：{{ item.calorieLow }}-{{ item.calorieHigh }}千卡）
              </text>
            </text>
          </view>
          <view class="view_point">
            <view class="point "></view>
            <text>{{ item.calorie }}千卡</text>
          </view>
        </view>
        <view class="child_item" v-for="(childItem ,childIndex) in item.recordFoodRelList" :key="childItem.recordId"
              @click.stop="onItemChildClick(item,childItem)">
          <img class="checkbox" :src="imgCheckTrue" v-if="childItem.check"/>
          <img class="checkbox" :src="imgCheckFalse" v-else/>
          <img class="img_header" :src="childItem.foodThumb"/>
          <view class="child_right">
            <view class="content_top">
              <text>{{ childItem.foodName }}</text>
              <text>{{ childItem.calorie }}千卡</text>
            </view>
            <view>{{ childItem.amount }}克</view>
          </view>
        </view>
      </view>
    </view>

    <view class="view_bottom">
      <view class="bottom_l">
        <img :src="bottomKcalIcon"/>
        <view class="bottom_count">
          <text>已添加{{ selList.length }}项食物</text>
          <text class="tv_kcal">{{ totalSelKcal }}千卡</text>
        </view>
      </view>
      <view class="view_save" @click="onClickSave">复制到今天</view>
    </view>
  </view>
</template>

<script setup lang="ts">

import {onMounted, ref} from "vue";
import FoodApi from "@/api/modules/food";
import Taro from "@tarojs/taro";
import {IFoodHistoryChildItem, IFoodHistoryDetails, IFoodHistoryDetailsItem} from "@/pagesFood/ts/types";
import {getFoodTypeByMealType} from "@/utils/foodUtils";
import {showSuccessToast} from "@/utils/toastUtils";
import {formatDate} from "@/utils/util";
import imgUrlFormat from "@/utils/imgUtils";

const imgCheckTrue = imgUrlFormat('common/answer_true.png')
const imgCheckFalse = imgUrlFormat('common/answer_false.png')
const bottomKcalIcon = imgUrlFormat('sugar/food/diet.png')
/**
 * 存储数据合计
 */
const result = ref<IFoodHistoryDetails>({} as IFoodHistoryDetails);
// const dataList = ref<Array<IFoodHistoryChildItem>>([]);

/**
 * 选中的集合
 */
const selList = ref<Array<any>>([]);

/**
 * 选中的总卡路里数
 */
const totalSelKcal = ref(0);

/**
 * 查询日期
 */
const recordDate = ref();
const router = Taro.useRouter();
recordDate.value = router.params.date

Taro.setNavigationBarTitle({
  title: "记录详情" + recordDate.value
})


/**
 *复制到今天按钮
 * 调接口
 */
const onClickSave = () => {
  for (let i = 0; i < result.value.recordFoodMealList.length; i++) {
    let list = result.value.recordFoodMealList[i].recordFoodRelList.filter(item => item.check)
    if (list.length > 0) {
      FoodApi.requestSaveCopy(formatDate(new Date()), result.value.calorieRecommend, result.value.recordFoodMealList[i].mealType, list).then((res) => {
        showSuccessToast("保存成功")
        Taro.eventCenter.trigger('refresh', {})
        Taro.navigateBack({delta: -1})
      })
    }
  }
}

/**
 * 计算选中食物卡路里
 */
const getTotalKcal = () => {
  selList.value = []
  for (let i = 0; i < result.value.recordFoodMealList.length; i++) {
    for (let j = 0; j < result.value.recordFoodMealList[i].recordFoodRelList.length; j++) {
      if (result.value.recordFoodMealList[i].recordFoodRelList[j].check) {
        selList.value.push(result.value.recordFoodMealList[i].recordFoodRelList[j])
      }
    }
  }
  if (selList.value.length === 0) {
    totalSelKcal.value = 0
  } else {
    let totalKcal = 0;
    for (let i = 0; i < selList.value.length; i++) {
      totalKcal += selList.value[i].calorie
    }
    totalSelKcal.value = totalKcal.toFixed(2);
  }
}

onMounted(() => {
  getHistoryRecordDetailByDate(1)
})

/**
 * 最里层点击事件
 * @param item
 */
const onItemChildClick = (item: IFoodHistoryChildItem, childItem: IFoodHistoryDetailsItem) => {
  childItem.check = !childItem.check
  //如果所有子项都选中，则当前项选中
  item.check = item.recordFoodRelList.filter(item => item.check).length === item.recordFoodRelList.length;
  result.value.check = result.value.recordFoodMealList.filter(item => item.check).length === result.value.recordFoodMealList.length
  getTotalKcal()
}

/**
 * 点击午餐item
 * @param item
 */
const onClickItem = (item: IFoodHistoryChildItem) => {
  item.check = !item.check
  item.recordFoodRelList = item.recordFoodRelList.map(mapItem => {
    return {
      ...mapItem,
      check: item.check
    }
  })
  result.value.check = result.value.recordFoodMealList.filter(item => item.check).length === result.value.recordFoodMealList.length
  getTotalKcal()
}

/**
 * 点击全选
 */
const onClickAllSel = () => {
  //先改变外层状态，子层状态跟外层保持一致
  result.value.check = !result.value.check;
  result.value.recordFoodMealList = result.value.recordFoodMealList.map(item => {
    return {
      ...item,
      check: result.value.check,
      recordFoodRelList: item.recordFoodRelList.map(childItem => {
        return {
          ...childItem,
          check: result.value.check
        }
      })
    }
  })
  getTotalKcal()
}

/**
 * @param page
 */
const getHistoryRecordDetailByDate = (date) => {
  let response = FoodApi.getHistoryRecordDetailByDate(recordDate.value);
  if (response) {
    response.then((res) => {
      result.value = res.data;
      let r: { mealType: any, calorie: number, calorieHigh: number, calorieLow: number, recordFoodRelList: any }[] = [];
      res.data.recordFoodMealList.forEach(food => {
        const found = (r.find(item => item.mealType === food.mealType))
        if (found) {
          found.calorie += food.calorie;
          found.recordFoodRelList.push(...food.recordFoodRelList);
        } else {
          r.push({
            mealType: food.mealType,
            calorie: food.calorie,
            calorieHigh: food.calorieHigh || 0,
            calorieLow: food.calorieLow || 0,
            recordFoodRelList: food.recordFoodRelList
          })
        }
      })
      // dataList.value = r;
      result.value.recordFoodMealList =r;
      console.log(result.value)
      // 设置默认全选中
      onClickAllSel()
    }, (failure) => {
      console.log("index.vue.getHistoryRecordDetailByDate..failure", failure)
    }).catch((error) => {
      console.log("index.vue.getHistoryRecordDetailByDate..error", error);
    })
  }
}

</script>


<style lang="less">
.container_food {
  display: flex;
  position: relative;
  flex-direction: column;

  .item_title {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px 15px;
    margin: 20px 15px;
    border-radius: 20px;
    background: white;
    color: #5F5F5F;

    .title_left {
      display: flex;
      align-items: center;

      img {
        width: 30px;
        height: 30px;
        margin-right: 10px;
      }
    }

    .title_right {
      display: flex;
      align-items: center;
      justify-content: center;

      .point {
        width: 10px;
        height: 10px;
        border-radius: 5px;
        background: #ED8E36;
        margin-right: 10px;
      }
    }
  }

  .view_cell {
    display: flex;
    background: white;
    padding: 20px 0px;

    margin: 20px 15px;
    border-radius: 20px;
    flex-direction: column;

    .item_header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 20px 15px;
      color: #5F5F5F;
      border-bottom: #efefef solid 1px;

      img {
        width: 30px;
        height: 30px;
        margin-right: 10px;
      }

      .tv_suggest {
        font-size: 20px;
      }
    }

    .child_item {
      align-items: center;
      padding: 20px 15px;
      display: flex;

      .img_header {
        width: 150px;
        border-radius: 15px;
        background: #efefef;
        height: 150px;
      }

      .child_right {
        display: flex;
        flex: 1;
        justify-content: space-around;
        height: 150px;
        margin-left: 15px;
        flex-direction: column;

        .content_top {
          display: flex;
          align-items: center;
          justify-content: space-between;
        }
      }
    }
  }
}

.checkbox {
  width: 30px;
  height: 30px;
  margin-right: 10px;
}

.view_bottom {
  background: white;
  display: flex;
  height: 120px;
  padding: 5px 20px;
  position: fixed;
  bottom: 0;
  width: 100%;
  align-items: center;
  justify-content: space-between;

  .bottom_l {
    display: flex;
    align-items: center;

    img {
      width: 56px;
      height: 56px;
    }

    .bottom_count {
      display: flex;
      margin-left: 20px;
      font-size: 25px;
      flex-direction: column;
      align-items: flex-start;

      .tv_kcal {
        font-weight: bold;
        color: #6aa4fc;
        font-size: 40px;
      }
    }

  }

  .view_save {
    background: #6aa4fc;
    height: 80px;
    width: 250px;
    border-radius: 40px;
    line-height: 80px;
    text-align: center;
    color: white;
  }
}
</style>
