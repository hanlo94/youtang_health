export default definePageConfig({
    navigationBarTitleText: "记饮食",
    navigationStyle: "custom",

});
