<template>
  <view class="container_food">
    <view style="display: flex;flex-direction: column">
      <view ref="statusBarRef" class="view_status"></view>
      <view ref="titleRef" class="view_title">
        <view>
          <RectLeft ref="leftArrow" @click="onClickBack"></RectLeft>
        </view>
        <view class="view_date" @click="onClickTitleTime">
          <text class="tv_date">{{ titleText }}</text>
        </view>
        <view></view>
      </view>
    </view>
    <view class="view_search">
      <nut-searchbar v-model="keyWork" placeholder="输入食物"></nut-searchbar>
      <img :src="cameraIcon" @click="onClickImgAdd"/>
    </view>
    <view class="content">
      <view class="view_list_root" v-if="keyWork === null || keyWork.length === 0">
        <scroll-view class="list_left" :scroll-y="true">
          <view
              :class="
              leftCurrentIndex === index ? 'left_item_true' : 'left_item_false'
            "
              v-for="(item, index) in categoryList"
              :key="index"
              @click="onLeftClickItem(item, index)"
          >
            {{ item.categoryName }}
          </view>
        </scroll-view>
        <scroll-view :scroll-y="true" class="list_right" flexed @scrollToLower="onScrollRight">
          <view
              class="right_item"
              v-for="(item, index) in dataList"
			  @click="goFoodDetail(item)"
          >
            <img :src="item.thumb"/>
            <view class="item_content">
              <view class="content_header">
                <view class="title">{{ item.name }}</view>
                <view class="add" @click.stop="onClickAdd(item)">+</view>
              </view>
              <view class="content_bom"
              >{{ item.calorie }}kcal/{{ item.amount }}克
              </view>
            </view>
          </view>
        </scroll-view>
      </view>

      <scroll-view class="view_search_view" v-else flexed :scrollWidth="0" @scrollToLower="onScrollSearch"
                   :scroll-y="true">
        <view
            class="search_item"
            v-for="(item, index) in dataList"
        >
          <img :src="item.thumb"/>
          <view class="item_content">
            <view class="content_header">
              <view class="title">{{ item.name }}</view>
              <view class="add" @click.stop="onClickAdd(item)">+</view>
            </view>
            <view class="content_bom"
            >{{ item.calorie }}kcal/{{ item.amount }}克
            </view>
          </view>
        </view>
      </scroll-view>

    </view>
    <view class="view_bottom">
      <view class="bottom_l" @click="onClickShowSelDialog">
        <img :src="bottomKcalIcon" />
        <view class="bottom_count">
          <text>已添加{{ selList.length??0 }}项食物</text>
          <text class="tv_kcal">{{ totalSelKcal??0 }}千卡</text>
        </view>
      </view>
      <view class="view_save" @click="onClickSave">添加完成</view>
    </view>
    <nut-popup position="bottom" v-model:visible="showBottom" :round="true">
      <view class="pop_root">
        <view class="pop_header">
          <view class="info">
            <img :src="addItem.thumb"/>
            <view class="item_content">
              <view class="content_header">
                <view class="title">{{ addItem.name }}</view>
                <img :src="itemDelIcon" style="width: 15px;height: 20px" @click.stop="onClickDeleteFood"/>
              </view>
              <view class="content_bom">{{ addItem.calorie }}kcal/{{ addItem.amount }}克</view>

            </view>
          </view>
          <view class="key_input">
            <text></text>
            <text class="tv_input"> {{ keyBoardValue }}</text>
            <text>克</text>
          </view>
        </view>
        <view class="pop_key_board">
          <view class="key_number">
            <nut-grid :column-num="3">
              <nut-grid-item
                  :text="item.value"
                  v-for="(item, index) in keyBoardList"
                  :key="index"
                  @click="onKeyBoardItemClick(item)"
              >
                <img v-if="item.id === 12" :src="keyBoardDown" style="width: 20px;height: 20px;margin-top: 15px"/>
              </nut-grid-item>
            </nut-grid>
          </view>
          <view class="key_controls">
            <view class="view_del" @click="onClickDeleteValue">
              <img :src="keyBoardDel" style="width: 20px;height: 20px"/></view>
            <view class="view_save" @click.stop="onClickKeyBoardSave">保存</view>
          </view>
        </view>
      </view>
    </nut-popup>
    <nut-popup position="bottom" v-model:visible="showSelDialog" :round="true" :close-on-click-overlay="true">
      <view class="pop_list_root">
        <view class="pop_list_title">
          <text>已选食物</text>
          <span class="clear" @click.stop="onClickPopClearSel">清空全部</span>
        </view>
        <view class="pop_list">
          <view
              class="pop_item"
              v-for="(item, index) in selList"
              :key="item.id"
          >
            <img class="pop_item_header" :src="item.thumb"/>
            <view class="item_content">
              <view class="content_header">
                <view class="title">{{ item.name }}</view>
                <img :src="itemDelIcon" style="width: 15px;height: 20px" @click.stop="onClickDelItem(index)"/>
              </view>
              <view class="content_bom" v-if="item.type === 1">{{ item.calorie }}kcal</view>
              <view class="content_bom" v-else>{{ item.calorie }}kcal/{{ item.amount }}克</view>
            </view>
          </view>
        </view>
        <view class="pop_bottom">
          <view class="bottom_l">
            <img :src="bottomKcalIcon" @click="showSelDialog = false"/>
            <view class="bottom_count">
              <text>已添加{{ selList.length??0 }}项食物</text>
              <text class="tv_kcal">{{ totalSelKcal??0 }}千卡</text>
            </view>
          </view>
          <view class="view_save" @click="onClickSave">添加完成</view>
        </view>
      </view>
    </nut-popup>
    <nut-popup position="top" v-model:visible="showTimeTop" round>
      <nut-date-picker
          v-model="currentTopDate"
          title=""
          type="hour-minute"
          :is-show-chinese="true"
          :round="true"
          :show-toolbar="false"
          :min-date="new Date(2020, 0, 1)"
          :max-date="new Date(2025, 10, 1)"
          @change="onTimeChange"
      ></nut-date-picker>
      <view
          style="display: flex;align-items: center;justify-content: space-between;padding: 10px 20px;border-bottom-left-radius: 20px;border-bottom-right-radius: 20px">
        <view style="color: #666666" @click.stop="showTimeTop=false">取消</view>
        <view style="color: #6aa4fc" @click.stop="onTopTimeConfirm">确定</view>
      </view>
    </nut-popup>

    <point_dialog :show-point-dialog="showPointDialog" :rewards=rewardPoint @closeDialog="onClosePointDialog"/>
  </view>
</template>

<script setup lang="ts">
import point_dialog from '@/component/point/index.vue'
import {onMounted, ref, watch} from "vue";
import FoodApi from "@/api/modules/food";
import Taro from "@tarojs/taro";
import {IKeyBoardItem, keyBoardList} from "@/pagesFood/ts/optionsUtils";
import {isEmpty} from "lodash";
import {IFoodCategory, IFoodItem} from "@/pagesFood/ts/types";

import {formatDateTohm} from "@/utils/dateUtils";
import {showToast} from "@/utils/toastUtils";
import common from "@/api/modules/common";
import {RectLeft} from "@nutui/icons-vue-taro";
import {TaroElement} from "@tarojs/runtime";
import imgUrlFormat from "@/utils/imgUtils";
import {useMainPageStore} from "@/utils/storeUtils";
import {formatDate} from "@/utils/util";
import PageNavigation from "@/utils/pageNavigation";

const showPointDialog=ref<boolean>(false)
const rewardPoint=ref<string>()

const bottomKcalIcon = imgUrlFormat('sugar/food/diet.png')
const keyBoardDel = imgUrlFormat('sugar/food/keyboard_del.png')
const keyBoardDown = imgUrlFormat('sugar/food/keyboard_down.png')
const itemDelIcon = imgUrlFormat('sugar/food/item_del_icon.png')
const cameraIcon = imgUrlFormat('common/camera.png')

//键盘
const showBottom = ref(false);
//已选中列表弹窗
const showSelDialog = ref(false);

const showTimeTop = ref(false);
const currentTopDate = ref(new Date());

const scrollDate = ref(formatDateTohm(currentTopDate.value));

const formatCurrentTime = ref(formatDateTohm(currentTopDate.value));

const categoryList = ref<IFoodCategory[]>([]);
const dataList = ref<IFoodItem[]>([]);

const foodDetailUrl=ref<string>()

/**
 * 已经选择的食物
 */
const selList = ref<Array<IFoodItem>>([])

/**
 * 默认选中第0个
 */
const leftCurrentIndex = ref(0);
/**
 * 搜索
 */
const keyWork = ref('');

/**
 * 标题 本页面
 */
const titleText = ref('');


/**
 * 键盘上的文字
 */
const keyBoardValue = ref("");

/**
 * 操作的item
 */
const addItem = ref<IFoodItem>({} as IFoodItem);
/**
 * 选中的总卡路里数
 */
const totalSelKcal = ref('0');

/**
 * 默认page
 */
const pageNum = ref(1);
/**
 * 上个页面传入
 */
const calorieRecommend = ref(0);
const selectedDate = ref(formatDate(new Date()));

const router = Taro.useRouter();
//1早餐 2 早加餐  3 午餐 4 午加餐 5 晚餐 6 晚加餐
calorieRecommend.value = Number(router.params.calorieRecommend);
selectedDate.value = String(router.params.selectedDate);


const titleRef = ref<TaroElement>(null);
const statusBarRef = ref<TaroElement>(null);
const leftArrow = ref<TaroElement>(null);


const {statusBarHeight, screenWidth, screenHeight, windowHeight} =
    Taro.getSystemInfoSync();
// 获取胶囊信息
const {width, height, left, top, right} =
    Taro.getMenuButtonBoundingClientRect();

// 计算标题栏高度
const titleBarHeight = height + (top - statusBarHeight) * 2;
// 计算导航栏高度
const appHeaderHeight = statusBarHeight + titleBarHeight;
//边距，两边的
const marginSides = screenWidth - right;
//标题宽度
const titelBarWidth = screenWidth - width - marginSides * 3;
//去掉导航栏，屏幕剩余的高度
const contentHeight = screenHeight - appHeaderHeight;

//1早餐 2 早加餐  3 午餐 4 午加餐 5 晚餐 6 晚加餐
const setTitle = (time: string) => {
  console.log(time)
  if (Number(router.params.type) === 1) {
    titleText.value = '添加早餐' + time;
  } else if (Number(router.params.type) === 2) {
    titleText.value = '添加早加餐' + time;
  } else if (Number(router.params.type) === 3) {
    titleText.value = '添加午餐' + time;
  } else if (Number(router.params.type) === 4) {
    titleText.value = '添加午加餐' + time;
  } else if (Number(router.params.type) === 5) {
    titleText.value = '添加晚餐' + time;
  } else if (Number(router.params.type) === 6) {
    titleText.value = '添加晚加餐' + time;
  }
}
setTitle(formatDateTohm(new Date()));


/**
 *
 */
const onTimeChange = (val) => {
  console.log(val.selectedValue)
  scrollDate.value = val.selectedValue[0] + ":" + val.selectedValue[1];
}

/**
 * 点击顶部选择时间
 */
const onTopTimeConfirm = () => {
  console.log(currentTopDate.value);
  formatCurrentTime.value = scrollDate.value;
  setTitle(formatCurrentTime.value);
  showTimeTop.value = false;
}


/**
 * 切换时间
 */
const onClickTitleTime = () => {
  showTimeTop.value = true;
}


/**
 * 返回
 */
const onClickBack = () => {
  Taro.navigateBack({delta: -1})
}


// 监听一个事件，接受参数
Taro.eventCenter.on('phoneAddKcal', (arg) => {
  selList.value.push(arg);
  getTotalKcal();
})

/**
 * 点击搜索 相机icon  增加食物
 */
const onClickImgAdd = () => {
  Taro.chooseImage({
    count: 1,
    sizeType: ['original', 'compressed'],
    sourceType: ['album', 'camera'],
    success: (res) => {
      const tempFilePaths = res.tempFilePaths;
      const base64 = Taro.getFileSystemManager().readFileSync(tempFilePaths[0], "base64")
      common.uploadFile(base64).then(res => {
        console.log(res);
        Taro.navigateTo({
          url: "/pagesFood/phoneAdd/index?img=" + res.data
        })
      })
    }
  })
}

/**
 * 加载更多
 */
const onScrollSearch = () => {
  getFoodMaterialList(0, pageNum.value)
}
/**
 * 加载更多
 */
const onScrollRight = () => {
  getFoodMaterialList(categoryList.value[leftCurrentIndex.value].id, pageNum.value)
}


/**
 * 观测到选中变化 重新计算卡路里
 */
watch(() => keyWork.value, (newVal, oldVal) => {
  pageNum.value = 1
  if (!isEmpty(newVal)) {
    getFoodMaterialList(0, pageNum.value)
  } else {
    getFoodMaterialCategory()
  }

})

const mainPageStore = useMainPageStore()

/**
 * 完成添加
 */
const onClickSave = () => {
  let data = {
    calorieRecommend: calorieRecommend.value,
    date: selectedDate.value +" "+ formatCurrentTime.value,
    mealType: Number(router.params.type),
    foodList: selList.value.map(item => {
      return {
        ...item,
        foodId: item.id,
        amount: item.inputg,
      }
    })
  }

  FoodApi.addDietRecord(data).then(res => {
    showToast("保存成功");
    mainPageStore.refreshPage()
    Taro.eventCenter.trigger('refresh', {})
    if (res.data) {
      rewardPoint.value = res.data
      showPointDialog.value = true
    }else{
      onFinal()
    }
  })
}

const onClosePointDialog=()=>{
  console.log('index.onClosePointDialog.showPointDialog=', showPointDialog)
  showPointDialog.value=false
  onFinal()
}

const onFinal=()=>{
  Taro.navigateBack({delta: -1})
}

/**
 * 删除单个
 * @param index
 */
const onClickDelItem = (index: number) => {
  // console.log("index.vue.onClickDelItem.index=",index);
  if (selList.value.length == 1) {
    onClickPopClearSel()
  } else {
    selList.value.splice(index, 1)
    // selList.value = selList.value.slice(index, index+1)
    getTotalKcal();
  }
}

/**
 * 清空所有选中
 */
const onClickPopClearSel = () => {
  console.log('clear')
  selList.value = [];
  showSelDialog.value = false;
  getTotalKcal();
}

/**
 * 点击弹出选中的食物列表
 */
const onClickShowSelDialog = () => {
  if (selList.value.length !== 0) {
    showSelDialog.value = true;
  }
}


/**
 * 点击键盘保存
 */
const onClickKeyBoardSave = () => {
  addItem.value.inputg = Number(keyBoardValue.value);
  selList.value.forEach((item, index) => {
    if (item.id === addItem.value.id) {
      selList.value.splice(index, 1)
    }
  })
  selList.value.push(addItem.value);
  showBottom.value = false;
  getTotalKcal();
}


/**
 * 计算选中食物卡路里
 */
const getTotalKcal = () => {
  if (selList.value.length === 0) {
    totalSelKcal.value = '0'
  } else {
    let totalKcal = 0;
    for (let i = 0; i < selList.value.length; i++) {
      // console.log(selList.value[i]);
      if (selList.value[i].type === 1) {
        totalKcal += selList.value[i].calorie
      } else {
        totalKcal += (selList.value[i].calorie / selList.value[i].amount) * selList.value[i].inputg
      }
    }
    totalSelKcal.value = totalKcal.toFixed(2);
  }
}
/**
 * item 点击添加
 * @param item
 */
const onClickAdd = (item: IFoodItem) => {
  keyBoardValue.value = '';
  addItem.value = item;
  showBottom.value = true;
  console.log(addItem.value)
}

const goFoodDetail=(item: IFoodItem) => {
	console.log("index.vue.goFoodDetail.",JSON.stringify(item));
	if (foodDetailUrl.value) {
		PageNavigation.navigationToWebView(foodDetailUrl.value + item.id)
	}

}

/**
 * 点击移除food
 */
const onClickDeleteFood = () => {
  addItem.value = {} as IFoodItem;
  showBottom.value = false;
}

/**
 * 点击键盘
 * @param item
 */
const onKeyBoardItemClick = (item: IKeyBoardItem) => {
  if (item.id === 12) {
    keyBoardValue.value = "";
    showBottom.value = false;
  } else {
    if (keyBoardValue.value.length <= 8) {
      keyBoardValue.value = keyBoardValue.value += item.value;
    }
  }
};
/**
 * 点击键盘上的删除
 */
const onClickDeleteValue = () => {
  if (!isEmpty(keyBoardValue.value)) {
    keyBoardValue.value = keyBoardValue.value.substring(
        0,
        keyBoardValue.value.length - 1
    );
  }
};

onMounted(() => {
  statusBarRef.value.style.height = statusBarHeight + "px";
  titleRef.value.style.height = titleBarHeight + "px";
  getFoodMaterialCategory()
})
/**
 * 点击左侧筛选item
 * @param item
 */
const onLeftClickItem = (item, index) => {
  pageNum.value = 1
  getFoodMaterialList(item.id, 1)
  leftCurrentIndex.value = index;
}

/**
 * 查询食材分类，默认查询第一个分类下食材数据
 */
const getFoodMaterialCategory = () => {
  let response = FoodApi.getFoodMaterialCategory();
  if (response) {
    response.then((res) => {
      console.log("index.vue.getFoodMaterialCategory..success", JSON.stringify(res));
      categoryList.value = res.recordList;
      getFoodMaterialList(res.recordList[0].id, pageNum.value)
    }, (failure) => {
      console.log("index.vue.getFoodMaterialCategory..failure", failure)
    }).catch((error) => {
      console.log("index.vue.getFoodMaterialCategory..error", error);
    })
  }
}

/**
 * 根据食材分类分页查询食材列表
 * @param categoryId
 * @param page
 */
const getFoodMaterialList = (categoryId, page) => {
  FoodApi.getFoodMaterialList(categoryId, page, keyWork.value).then(res => {
	  if (!foodDetailUrl.value) {
		  foodDetailUrl.value = res.foodDetailUrl
	  }
    if (pageNum.value === 1) dataList.value = [];
    if (!isEmpty(res.data)) {
      dataList.value.push(...res.data.map(item => {
        return {
          ...item,
          inputg: 0,//默认0 用户自己输入的卡路里数
        }
      }));
      pageNum.value++;
    }
  });
}

</script>


<style lang="less">
.container_food {
  width: 100%;
  box-sizing: border-box;
  display: flex;
  height: 100vh;
  flex-direction: column;

  .content {
    flex: 1;
    padding: 20px;
  }

  .view_list_root {
    display: flex;
    flex: 1;
    height: calc(100vh - 450px);
    background: white;
    border-radius: 20px;
    overflow-y: auto;

    .list_left {
      width: 180px;
      margin: 20px;
      background: white;
      overflow-y: auto;

      .left_item_true {
        font-size: 30px;
        color: white;
        background: #6aa4fc;
        display: flex;
        align-items: center;
        justify-content: center;
        height: 70px;
      }

      .left_item_false {
        font-size: 30px;
        color: #5d5d5d;
        display: flex;
        align-items: center;
        justify-content: center;
        height: 70px;
      }
    }

    .list_right {
      width: 480px;
      height: calc(100vh - 260px);
      flex: 1;
      overflow-y: auto;

      .right_item {
        display: flex;
        padding: 10px 0;

        img {
          background: #666666;
          width: 120px;
          border-radius: 10px;
          height: 120px;
        }

        .item_content {
          display: flex;
          flex: 1;
          margin-left: 20px;
          flex-direction: column;
          justify-content: space-between;

          .content_header {
            color: #333333;
            display: flex;
            flex-direction: row;
            align-items: center;
            justify-content: space-between;
            font-size: 30px;

            .title {
              width: 300px;
            }

            .add {
              border-radius: 30px;
              width: 30px;
              margin-right: 20px;
              color: white;
              height: 30px;
              text-align: center;
              padding-bottom: 5px;
              line-height: 30px;
              background: #6aa4fc;
            }
          }

          .content_bom {
            color: #5d5d5d;
            font-size: 30px;
          }
        }
      }
    }
  }

  .view_bottom {
    background: white;
    display: flex;
    height: 120px;
    padding: 5px 20px;
    width: 100%;
    align-items: center;
    justify-content: space-between;

    .bottom_l {
      display: flex;
      align-items: center;

      img {
        width: 56px;
        height: 56px;
      }

      .bottom_count {
        display: flex;
        margin-left: 20px;
        font-size: 25px;
        flex-direction: column;
        align-items: flex-start;

        .tv_kcal {
          font-weight: bold;
          color: #6aa4fc;
          font-size: 40px;
        }
      }

    }

    .view_save {
      background: #6aa4fc;
      height: 80px;
      width: 250px;
      border-radius: 40px;
      line-height: 80px;
      text-align: center;
      color: white;
    }
  }
}


.pop_root {
  display: flex;
  flex-direction: column;
  width: 100%;
  margin-top: 20px;

  .pop_header {
    width: 750px;
    height: 250px;

    .info {
      display: flex;
      height: 160px;
      align-items: center;
      padding: 10px 20px;

      img {
        width: 120px;
        height: 120px;
        border-radius: 10px;
      }

      .item_content {
        display: flex;
        flex: 1;
        margin-left: 20px;
        height: 120px;
        flex-direction: column;
        justify-content: space-between;

        .content_header {
          color: #333333;
          display: flex;
          font-size: 35px;
          flex-direction: row;
          align-items: center;
          justify-content: space-between;

          .delete {
            border-radius: 30px;
            width: 30px;
            color: white;
            height: 30px;
            text-align: center;
            padding-bottom: 5px;
            line-height: 30px;
            background: #6aa4fc;
          }
        }

        .content_bom {
          color: #5d5d5d;
          font-size: 30px;
        }
      }
    }

    .key_input {
      display: flex;
      margin-top: 10px;
      align-items: center;
      padding: 0 20px;
      justify-content: space-between;

      .tv_input {
        width: 200px;
        text-align: center;
        height: 50px;
        color: #6aa4fc;
        border-bottom: #bbbbbb solid 1px;
      }
    }
  }

  .pop_key_board {
    display: flex;
    width: 750px;
    height: 568px;
    flex-direction: row;
    align-items: center;

    .key_number {
      width: 550px;

    }

    .key_controls {
      display: flex;
      width: 200px;
      height: 568px;
      flex-direction: column;
      justify-content: space-around;
      align-items: center;

      .view_del {
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        flex: 1;
      }

      .view_save {
        width: 100%;
        background: #6aa4fc;
        display: flex;
        color: white;
        align-items: center;
        justify-content: center;
        flex: 1;
      }
    }
  }
}

.nut-grid-item__text {
  font-size: 44px;
}

.pop_list_root {
  display: flex;
  padding: 20px;
  flex-direction: column;

  .pop_list_title {
    display: flex;
    justify-content: space-between;
    align-items: center;

    text {
      padding: 10px 0;
    }

    .clear {
      font-size: 25px;
      color: #5D5D5D;
    }

  }

  .pop_item {
    display: flex;
    padding: 10px 0;

    .pop_item_header {
      width: 120px;
      border-radius: 10px;
      background: #666666;
      height: 120px;
    }

    .item_content {
      display: flex;
      flex: 1;
      margin-left: 20px;
      flex-direction: column;
      justify-content: space-between;

      .content_header {
        color: #333333;
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: space-between;
        font-size: 30px;

        .title {
          width: 300px;
        }
      }

      .content_bom {
        color: #5d5d5d;
        font-size: 30px;
      }
    }
  }

  .pop_bottom {
    background: white;
    display: flex;
    height: 120px;
    padding: 5px 20px;
    width: 100%;
    align-items: center;
    justify-content: space-between;

    .bottom_l {
      display: flex;
      align-items: center;

      img {
        width: 56px;
        height: 56px;
      }

      .bottom_count {
        display: flex;
        margin-left: 20px;
        font-size: 25px;
        flex-direction: column;
        align-items: flex-start;

        .tv_kcal {
          font-weight: bold;
          color: #6aa4fc;
          font-size: 40px;
        }
      }

    }

    .view_save {
      background: #6aa4fc;
      height: 80px;
      width: 250px;
      border-radius: 40px;
      line-height: 80px;
      text-align: center;
      color: white;
    }
  }
}

.view_search_view {
  display: flex;
  height: calc(100vh - 260px);

  .search_item {
    display: flex;
    background: white;
    margin: 10px 20px;
    width: 100%;
    border-radius: 10px;
    padding: 20px;
    align-items: center;

    img {
      background: #666666;
      width: 120px;
      border-radius: 10px;
      height: 120px;
    }

    .item_content {
      display: flex;
      flex: 1;
      height: 120px;
      margin-left: 20px;
      flex-direction: column;
      justify-content: space-between;

      .content_header {
        color: #333333;
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: space-between;
        font-size: 30px;


        .add {
          border-radius: 30px;
          width: 30px;
          color: white;
          margin-right: 20px;
          height: 30px;
          text-align: center;
          padding-bottom: 5px;
          line-height: 30px;
          background: #6aa4fc;
        }
      }

      .content_bom {
        color: #5d5d5d;
        font-size: 30px;
      }
    }
  }
}

.view_search {
  display: flex;
  padding-right: 30px;

  background: white;
  align-items: center;

  .nut-searchbar {
    width: 640px;
  }

  img {
    width: 70px;
    height: 70px;
  }
}

.view_status {
  background: white;
}

.view_title {
  display: flex;
  width: 100%;
  justify-content: space-between;
  background: white;
  align-items: center;

  view {
    flex: 1;
  }

  .nut-icon-rect-left {
    margin-left: 5px;
  }

  .view_date {
    display: flex;
    align-items: center;
    justify-content: center;

  }
}

</style>
