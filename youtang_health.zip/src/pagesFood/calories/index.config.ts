export default definePageConfig({
    navigationBarTitleText: "热量柱状图",
    usingComponents:{
        'ec-canvas':'@/component/ec-canvas/ec-canvas'
    },
    pageOrientation: "landscape",
});
