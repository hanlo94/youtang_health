<template>
<!--  <ec-canvas id="chart-dom-area1" canvas-id="chart-area"  :ec="ec" force-use-old-canvas="true"></ec-canvas>-->
<view class="container_calories">
  <view class="tabs">
    <view v-for="item in tabs" :key="item.value" class="tab" :class="[item.value == state.active ? 'active' : '']" @click="state.active = item.value">
      {{item.name}}
    </view>
  </view>
  <view class="charts">
    <ec-canvas id="chart-dom-area1" canvas-id="chart-area"  :ec="ec" force-use-old-canvas="true"></ec-canvas>
  </view>
</view>
</template>

<script setup lang="ts">
import * as echarts from "@/component/ec-canvas/echarts";
import {reactive, ref} from "vue";

const tabs = [
  {
    name:'近7天',
    value:1,
  },
  {
    name:'近1个月',
    value:2,
  },
  {
    name:'近3个月',
    value:3,
  },
  {
    name:'近6个月',
    value:4,
  },
  {
    name:'近1年',
    value:5,
  },
]

const state = reactive({
  active: 1
})

const chart = ref();

function initChart(canvas: any, width: any, height: any) {
  console.log('canvas',canvas,width,height)
  chart.value = echarts.init(canvas, null, {
    width,
    height
  })

  return chart
}

const ec = ref({
  onInit: initChart
})
</script>


<style lang="less">
.container_calories{
  width: 750px;

  .tabs{
    display: flex;
    justify-content: center;
    align-items: center;
    margin-top: 15px;

    .tab{
      width: 120px;
      height: 35px;
      border: 1px solid #64A4F5;
      border-right: none;

      display: flex;
      align-items: center;
      justify-content: center;

      color: #64A4F5;
    }
    .tab:first-child{
      border-top-left-radius: 30px;
      border-bottom-left-radius: 30px;
    }
    .tab:last-child{
      border-right: 1px solid #64A4F5;
      border-top-right-radius: 30px;
      border-bottom-right-radius: 30px;
    }
    .active{
      background-color: #64A4F5;
      color: #fff;
    }
  }
}

</style>
