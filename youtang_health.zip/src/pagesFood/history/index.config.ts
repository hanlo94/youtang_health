export default definePageConfig({
	navigationBarTitleText: "从以前复制",
});
