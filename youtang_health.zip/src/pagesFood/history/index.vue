<template>
  <view class="container_food">
    <scroll-view class="view_list" :scrollY="true" @scrollToLower="scroll" flexed>
      <view class="view_item" v-for="(item ,index) in dataList" :key="index" @click="onItemClick(item)">

        <view class="item_header">
          <view class="item_left">
            <text>{{ item.recordDate }}{{ item.recordWeek }}</text>
            <view class="view_point">摄入{{ item.calorie }}千卡</view>
          </view>
          <IconFont name="rect-right" size="14" color='#666666'/>
        </view>
        <!--        <view style="padding: 10px 0" v-show="false">-->
        <!--          <view class="item_content">-->
        <!--            <text>早餐</text>-->
        <!--            <text>100千卡</text>-->
        <!--          </view>-->
        <!--          <view class="item_content">-->
        <!--            <text>早加餐</text>-->
        <!--            <text>100千卡</text>-->
        <!--          </view>-->
        <!--          <view class="item_content">-->
        <!--            <text>午餐</text>-->
        <!--            <text>100千卡</text>-->
        <!--          </view>-->
        <!--          <view class="item_content">-->
        <!--            <text>晚餐</text>-->
        <!--            <text>100千卡</text>-->
        <!--          </view>-->
        <!--        </view>-->

      </view>
    </scroll-view>
  </view>
</template>

<script setup lang="ts">

import {onMounted, ref} from "vue";
import FoodApi from "@/api/modules/food";
import Taro from "@tarojs/taro";
import {isEmpty} from "lodash";
import {IconFont} from "@nutui/icons-vue-taro";

interface IHistoryItem {
  recordDate: string,
  recordWeek: string,
  calorie: number,
}

const pageNum = ref(1);

/**
 * 数据合集
 */
const dataList = ref<Array<IHistoryItem>>([] as IHistoryItem[]);

onMounted(() => {
  getDietHistoryRecord()
})

/**
 * 加载更多
 */
const scroll = () => {

}

//点击item进入详情
const onItemClick = (item: IHistoryItem) => {
  Taro.navigateTo({url: '/pagesFood/historyDetail/index?date=' + item.recordDate})
}

/**
 * {
 *  "msg": "查询成功",
 *  "code": 10000,
 *  "data": [{
 *    "recordDate": "2023-09-15",
 *    "recordWeek": "周五",
 *    "calorie": 2634,
 *  }, {
 *    "recordDate": "2023-09-14",
 *    "recordWeek": "周四",
 *    "calorie": 766,
 *  }, {
 *    "recordDate": "2023-09-13",
 *    "recordWeek": "周三",
 *    "calorie": 383,
 *  }, {
 *    "recordDate": "2023-09-10",
 *    "recordWeek": "周日",
 *    "calorie": 766,
 *  }, {
 *    "recordDate": "2023-09-09",
 *    "recordWeek": "周六",
 *    "calorie": 766,
 *  }],
 *  "status": true
 * }
 * @param page
 */
const getDietHistoryRecord = () => {
  let response = FoodApi.getHistoryRecord(pageNum.value);
  if (response) {
    response.then((res) => {
      console.log("index.vue.getDietHistoryRecord..success", JSON.stringify(res));
      if (pageNum.value === 1) dataList.value = [];
      if (!isEmpty(res.data)) {
        dataList.value.push(...res.data);
        pageNum.value++;
      }
    }, (failure) => {
      console.log("index.vue.getDietHistoryRecord..failure", failure)
    }).catch((error) => {
      console.log("index.vue.getDietHistoryRecord..error", error);
    })
  }
}

</script>


<style lang="less">
.container_food {
  height: 100vh;

  .view_list {
    display: flex;
    height: 100vh;
    flex-direction: column;

    .view_item {
      display: flex;
      background: #ffffff;
      flex-direction: column;
      border-radius: 10px;
      margin: 10px 15px;

      .item_header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 20px 15px;
        color: #5F5F5F;
        border-bottom: #efefef solid 1px;

        //.view_point {
        //  display: flex;
        //  align-items: center;
        //  justify-content: center;
        //
        //  .point {
        //    width: 10px;
        //    height: 10px;
        //    border-radius: 5px;
        //    background: #ED8E36;
        //    margin-right: 10px;
        //  }
        //}

        .item_left {
          display: flex;
          color: #333333;
          flex-direction: column;

          .view_point {
            color: #666666;
            margin-top: 16px;
            font-size: 25px;
          }
        }

      }

      .item_content {
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        color: #333333;
        padding: 8px 15px;
      }
    }
  }
}
</style>
