<!--
Description：
Created on 2023/9/30
Author :  郭 -->
<template>
  <view class="view_img_root">
    <image class="img" :src="img" mode="aspectFill" />
    <view class="view_dia">
      <view class="input_item">
        <view>食物名称</view>
        <input placeholder="请输入" v-model="foodName"/>
      </view>
      <view class="input_item">
        <view>食物热量（千卡）</view>
        <input placeholder="请输入" type="number" v-model="foodKcal"/>
      </view>
      <view class="btn" @click="onClickAdd">确认添加</view>
    </view>
  </view>


</template>
<script setup lang="ts">

import {ref} from "vue";
import Taro from '@tarojs/taro'



const foodName = ref();
const foodKcal = ref();


definePageConfig({
  navigationBarTitleText: "拍照添加"
})
const img = ref('');
const router = Taro.useRouter();
img.value = String(router.params.img)


// amount: number;
// calorie: number;
// category: number;
// gi: number;
// id: number;
// name: string;
// nameAlias: string;
// thumb: string;//缩略图
// inputg: number;//用户自己输入克数
/**
 * 添加
 */
const onClickAdd = () => {
  Taro.eventCenter.trigger('phoneAddKcal', {
    type:1,
    thumb: img.value,
    name: foodName.value,
    calorie: foodKcal.value,
  })
  Taro.navigateBack({delta:-1})
}


</script>

<style lang="less">
.view_img_root {
  position: relative;

  .img {
    width: 100%;
    height: calc(100vh - 300px);
    object-fit: cover;
  }

  .view_dia {
    position: fixed;
    width: 100%;
    background: white;
    border-top-right-radius: 30px;
    border-top-left-radius: 30px;
    bottom: 20px;

    .input_item {
      display: flex;
      height: 100px;
      width: 100%;
      padding: 10px 20px;
      border-bottom: #efefef 1px solid;
      flex-direction: row;
      align-items: center;
      justify-content: space-between;

      view {
        width: 260px;
      }

      input {
        flex: 1;
        text-align: right;
      }
    }

  }

  .btn {
    background: #6aa4fc;
    border-radius: 15px;
    height: 80px;
    color: #efefef;
    width: 700px;
    margin: 10px auto;
    line-height: 80px;
    text-align: center;
  }

}
</style>
