/**
 * Description：
 * Created on 2023/7/20
 * Author :  郭
 */



export interface IFoodCategory {
    categoryCreateTime: string;
    categoryDesc: string;
    categoryName: string;
    categoryThumb: string;
    id: number;
}

export interface IFoodItem {
    amount: number;
    calorie: number;
    category: number;
    gi: number;
    id: number;
    name: string;
    nameAlias: string;
    thumb: string;//缩略图
    inputg: number;//用户自己输入克数
    type: number;//1用户输入
}


export interface IFoodHomeChildItem {
    dataId: number;
    isDel: number;
    recordId: number;
    foodCategory: number;
    foodId: number;
    date: string;
    foodName: string;
    amount: number;
    calorie: number;
    foodThumb: string;
    protein: number;
    fat: number;

}

export interface IFoodHomeItem {
    mealType: number;
    calorie: number;
    calorieLow: number;//有就显示
    calorieHigh: number;
    recordFoodRelList: IFoodHomeChildItem[];
}

export interface IFoodRecord {
    recordDate: string;
    calorie: number;
}

export interface IFoodRecordStatus extends IFoodRecord {
    status: number;
}

export interface IFoodHomeRecord extends IFoodRecord {
    calorieRecommend: number;
    calorieLow: number;
    calorieHigh: number;
    calorieHistogramUrl: string;
    fibre: number;
    totalLikes: number;
    recordFoodMealList: Array<IFoodHomeItem>;
}


/**
 *
 * 详情相关集合
 */
export interface IFoodHistoryDetailsItem {
    dataId: number;
    isDel: number;
    recordId: number;
    foodId: number;
    foodName: string;
    amount: number;
    calorie: number;
    date: string;
    foodThumb: string;
    check: boolean;
}

export interface IFoodHistoryChildItem {
    mealType: number;
    calorie: number;
    calorieLow: number;//建议低
    calorieHigh: number;//建议高
    recordFoodRelList: Array<IFoodHistoryDetailsItem>
    check: boolean;
}

export interface IFoodHistoryDetails {
    recordDate: string;
    calorieRecommend: number;
    calorieLow: number;
    calorieHigh: number;
    calorie: number;
    calorieHistogramUrl: string;
    fibre: number;
    score: number;
    totalLikes: number;
    recordFoodMealList: Array<IFoodHistoryChildItem>
    check: boolean;

}



