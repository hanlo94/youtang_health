// 定义智能设备相关常量
/**
 * 设备种类
 * @type {{BODYFAT: number, BLOODPRESSURE: number, SUGAR: number,MAGNET:number}}
 */
export const DeviceCategory = {
    UNKNOWN: 0,
    /**
     * 血压计
     */
    BLOODPRESSURE: 1,
    /**
     * 血糖仪
     */
    SUGAR: 2,
    /**
     * 体脂秤
     */
    BODYFAT: 3,
    /**
     * 复合磁
     */
    MAGNET: 4,
}

/**
 * 设备绑定状态
 * @type {{UNBIND: number, BIND: number}}
 */
export const DeviceBindState = {
    /**
     * 已绑定
     */
    BIND: 1,
    /**
     * 未绑定
     */
    UNBIND: 2,
}

export const DeviceAction = {
    UNKNOWN: 0,
    SCAN: 1,
    BLE: 2
}

/**
 * 设备品牌
 */
// export const DeviceBrand = [
//
// 	/**
// 	 * 未知
// 	 */
// 	{brand: 0, category: DeviceCategory.UNKNOWN, minLen: 6, maxLen: 20, action: DeviceAction.UNKNOWN},
//
// 	/**
// 	 * 小糖医/掌护科技
// 	 */
// 	{brand: 1, category: DeviceCategory.SUGAR, minLen: 6, maxLen: 20, action: DeviceAction.SCAN},
//
// 	/**
// 	 * 爱奥乐
// 	 */
// 	{brand: 2, category: DeviceCategory.UNKNOWN, minLen: 6, maxLen: 20, action: DeviceAction.SCAN},
//
// 	/**
// 	 * 微策
// 	 */
// 	{brand: 3, category: DeviceCategory.SUGAR, minLen: 6, maxLen: 20, action: DeviceAction.SCAN},
//
// 	/**
// 	 * 雅思
// 	 */
// 	{brand: 4, category: DeviceCategory.SUGAR, minLen: 6, maxLen: 20, action: DeviceAction.SCAN},
//
// 	/**
// 	 * 三诺GPRS
// 	 */
// 	{brand: 5, category: DeviceCategory.SUGAR, minLen: 6, maxLen: 20, action: DeviceAction.SCAN},
//
// 	/**
// 	 * 脉搏波
// 	 */
// 	{brand: 6, category: DeviceCategory.UNKNOWN, minLen: 6, maxLen: 20, action: DeviceAction.UNKNOWN},
//
// 	/**
// 	 * 三诺BLE-安稳
// 	 */
// 	{brand: 7, category: DeviceCategory.SUGAR, minLen: 6, maxLen: 20, action: DeviceAction.BLE},
//
// 	/**
// 	 * 瞬感
// 	 */
// 	{brand: 8, category: DeviceCategory.SUGAR, minLen: 6, maxLen: 20, action: DeviceAction.BLE},
//
// 	/**
// 	 * 三诺BLE-优智
// 	 */
// 	{brand: 9, category: DeviceCategory.SUGAR, minLen: 6, maxLen: 20, action: DeviceAction.BLE},
//
// 	/**
// 	 * 微策-舒可唯
// 	 */
// 	{brand: 10, category: DeviceCategory.SUGAR, minLen: 6, maxLen: 20, action: DeviceAction.SCAN},
//
// 	/**
// 	 * 体脂秤
// 	 */
// 	{brand: 11, category: DeviceCategory.SUGAR, minLen: 6, maxLen: 20, action: DeviceAction.BLE}
//
// ]

export class DeviceBrandProperties {
    /**
     * 设备品牌
     * {@link DeviceBrand}
     */
    brand;
    /**
     * 设备类型
     * {@link DeviceCategory}
     */
    category;
    /**
     * deviceSn 最小长度
     */
    minLen;
    /**
     * 最大长度
     */
    maxLen;

    /**
     * 点击动作 扫描二维码还是ble设备
     */
    action;

    /**
     * 绑定设备SN
     */
    deviceSn;

    /**
     * 页面路径
     */
    page;

    /**
     * 自动绑定
     */
    autoBind;

    constructor(brand, category, action, page = null, minLen = 6, maxLen = 18, autoBind = false) {
        this.brand = brand
        this.category = category
        this.action = action
        this.minLen = minLen
        this.maxLen = maxLen
        this.page = page
        this.autoBind = autoBind
    }

    setDeviceSnChecker(checker) {
        this.deviceSnChecker = deviceSn => checker(deviceSn)
        return this
    }

    deviceSnChecker = (deviceSn) => {
        if (deviceSn && deviceSn.length >= this.minLen && deviceSn.length <= this.maxLen) {
            return true;
        }
        return false
    }

}

export const DeviceBrand = {

    /**
     * 未知
     */
    UNKNOWN: new DeviceBrandProperties(0, DeviceCategory.UNKNOWN, DeviceAction.UNKNOWN),

    /**
     * 小糖医/掌护科技
     */
    XTY: new DeviceBrandProperties(1, DeviceCategory.SUGAR, DeviceAction.SCAN, '/pagesSugarAnalysis/sugarAnalysis', 15),

    /**
     * 爱奥乐
     */
    BIOLAND: new DeviceBrandProperties(2, DeviceCategory.UNKNOWN, DeviceAction.SCAN, '/pagesSugarAnalysis/sugarAnalysis', 9),

    /**
     * 微策
     */
    WEICE: new DeviceBrandProperties(3, DeviceCategory.SUGAR, DeviceAction.SCAN, '/pagesSugarAnalysis/sugarAnalysis', 10),

    /**
     * 雅思
     */
    YASI: new DeviceBrandProperties(4, DeviceCategory.SUGAR, DeviceAction.SCAN, '/pagesSugarAnalysis/sugarAnalysis', 12),

    /**
     * 三诺GPRS
     */
    SANNUO: new DeviceBrandProperties(5, DeviceCategory.SUGAR, DeviceAction.SCAN, '/pagesSugarAnalysis/sugarAnalysis', 5, 200),

    /**
     * 脉搏波
     */
    RBP: new DeviceBrandProperties(6, DeviceCategory.UNKNOWN, DeviceAction.UNKNOWN, null, null, null),

    /**
     * 三诺BLE-安稳
     */
    SANNUOBLE: new DeviceBrandProperties(7, DeviceCategory.SUGAR, DeviceAction.BLE, '/pagesSugarAnalysis/sugarAnalysis', 5, 200),

    /**
     * 瞬感
     */
    SHUNGANBLE: new DeviceBrandProperties(8, DeviceCategory.SUGAR, DeviceAction.BLE, null),

    /**
     * 三诺BLE-优智
     */
    SANNUOBLEYOUZHI: new DeviceBrandProperties(9, DeviceCategory.SUGAR, DeviceAction.BLE, null, 5, 200),

    /**
     * 微策-舒可唯
     */
    WEICE_SHUKEWEI: new DeviceBrandProperties(10, DeviceCategory.SUGAR, DeviceAction.SCAN, '/pagesSugarAnalysis/sugarAnalysis', 10),

    /**
     * 体脂秤
     */
    BODYFAT: new DeviceBrandProperties(11, DeviceCategory.BODYFAT, DeviceAction.BLE, '/pagesBodyFat/add/index', null, null),

    /**
     * 脉搏波血压计-GPRS
     */
    RBP_GPRS: new DeviceBrandProperties(12, DeviceCategory.BLOODPRESSURE, DeviceAction.SCAN, null).setDeviceSnChecker((imei) => {
        if (!imei) {
            return false;
        }
        if (imei.length === 28) {
            const s = imei.split(" ");
            if (s.length === 2) {
                return s[0].length === 13 && s[1].length === 14;
            }
        }
        return false;
    }),
    /**
     * 雅思BLE-GLM76
     */
    YASI_BLE: new DeviceBrandProperties(13, DeviceCategory.SUGAR, DeviceAction.BLE, '/pagesMine/yasiGlm/add/index', null, null, true),
    /**
     * 复合磁
     */
    MAGNET: new DeviceBrandProperties(14, DeviceCategory.MAGNET, DeviceAction.BLE, '/pagesComposite/index/index', null, null, true),

}

export function findDeviceBrand(brand) {
    let brands = Object.keys(DeviceBrand);
    if (!brand || brand >= brands.length) {
        return DeviceBrand.UNKNOWN
    } else {
        return DeviceBrand[brands[brand]]
    }
}



