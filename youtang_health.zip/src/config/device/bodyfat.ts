import imgUrlFormat from "@/utils/imgUtils";

export class ScaleMeasure {
    state: number;
    mainState: string;
    subState: string;
    icon?: string | null;
    retryBtnText?: string | null;
    iconAnimation: boolean = false;


    constructor(state: number, mainState: string, subState: string, icon?: string | null, iconAnimation?: boolean, retryBtnText?: string | null) {
        this.state = state;
        this.mainState = mainState;
        this.subState = subState;
        this.icon = icon ?? null;
        this.retryBtnText = retryBtnText;
        this.iconAnimation = iconAnimation ?? false;
    }


}


export const QnScaleMeasureState = {
    BLE_DISABLE: new ScaleMeasure(-1,
        "蓝牙未开启",
        "请先打开蓝牙才能进行绑定或测量哦~",
        imgUrlFormat('common/fail.png'), false, '打开蓝牙'),

    /**
     * SDK初始化 异常
     */
    SDK_ERROR: new ScaleMeasure(-2, "蓝牙初始化异常", "请联系客服进行咨询", imgUrlFormat('common/fail.png')),

    /**
     * SDK扫描异常
     */
    SCAN_ERROR: new ScaleMeasure(-3, "扫描异常", "请联系客服进行咨询", imgUrlFormat('common/fail.png')),

    /**
     * 未绑定状态
     */
    UNBIND: new ScaleMeasure(0, "体脂仪绑定", "记得脱袜光脚站立在体脂秤四个金属点上哦～"),

    /**
     * 绑定失败
     */
    BIND_FAILURE: new ScaleMeasure(
        1,
        "体脂仪绑定失败",
        "注意将手机蓝牙打开，并踩亮体脂仪进行设备绑定",
        imgUrlFormat('common/fail.png'),
        false,
        "重新绑定",
    ),

    /**
     * 未绑定-扫描中
     */
    UNBIND_SCANING: new ScaleMeasure(
        2,
        "体脂仪绑定",
        "请耐心等待扫描完成哦~",
        imgUrlFormat('common/load_mark.png'),
        true,
    ),

    /**
     * 未绑定-扫描超时
     */
    UNBIND_SCAN_TIMEOUT: new ScaleMeasure(
        2,
        "扫描超时",
        "注意将手机蓝牙打开，并踩亮体脂仪进行绑定",
        imgUrlFormat('common/fail.png'),
        false,
        "重新扫描",
    ),

    /**
     * 未绑定-扫描失败
     */
    UNBIND_SCAN_FAILURE: new ScaleMeasure(
        3,
        "体脂仪绑定",
        "扫描结束，请重新扫描",
        imgUrlFormat('common/fail.png'),
        true,
        "重新扫描",
    ),

    /**
     * 已绑定-待开始扫描
     */
    BIND_TO_SCAN: new ScaleMeasure(4, "体脂仪测量", "注意将手机蓝牙打开，并踩亮体脂仪进行测量"),

    /**
     * 已绑定-扫描中
     */
    BIND_SCANING: new ScaleMeasure(
        5,
        "体脂仪测量中",
        "请耐心等待扫描完成哦~",
        imgUrlFormat('common/load_mark.png'),
        true,
    ),

    /**
     * 已绑定-扫描超时
     */
    BIND_SCAN_TIMEOUT: new ScaleMeasure(
        6,
        "扫描超时",
        "注意将手机蓝牙打开，并踩亮体脂仪进行测量",
        imgUrlFormat('common/fail.png'),
        false,
        "重新扫描",
    ),

    /**
     * 已绑定-扫描失败
     */
    BIND_SCAN_FAILURE: new ScaleMeasure(
        6,
        "体脂仪测量",
        "注意将手机蓝牙打开，并踩亮体脂仪进行测量",
        imgUrlFormat('common/fail.png'),
        false,
        "重新扫描",
    ),

    /**
     * 已绑定-扫描成功-找到绑定的设备
     */
    BIND_SCAN_SUCCESS: new ScaleMeasure(
        7,
        "体脂仪测量",
        "扫描成功，即将开始测量，请不要移动",
        imgUrlFormat('common/load_mark.png'),
        true,
    ),

    /**
     * 已绑定-测量中
     */
    BIND_MEASURING: new ScaleMeasure(
        8,
        "正在测量",
        "赤脚上秤，保持身体静止，直至秤上显示不再变化",
        imgUrlFormat('common/load_mark.png'),
        true,
    ),

    /**
     * 测量失败
     */
    BIND_MEASURE_FAILURE: new ScaleMeasure(
        9,
        "测量失败",
        "测量失败，请重新进行体脂测量哦～",
        imgUrlFormat('common/fail.png'),
        false,
        "重新测量",
    ),

    /**
     * 测量成功
     */
    BIND_MEASURE_SUCCESS: new ScaleMeasure(
        10,
        "测量成功",
        "恭喜您体脂数据上传成功",
        imgUrlFormat('common/success.png'),
    ),

    BIND_MEASURE_FINISH: new ScaleMeasure(
        11,
        "测量结束",
        "本次体脂测量结束",
        imgUrlFormat('common/success.png'),
        false, "重新测量    ",
    ),

    /**
     * 心率测量中
     */
    HEART_RATE_MEASURING: new ScaleMeasure(
        12,
        "正在测量心率",
        "请耐心等待心率测量完成哦~",
        imgUrlFormat('common/load_mark.png'),
        true,
    ),

    /**
     * 体重测量中
     */
    WEIGHT_MEASURING: new ScaleMeasure(
        13,
        "正在测量体重",
        "请耐心等待体重测量完成哦~",
        imgUrlFormat('common/load_mark.png'),
        true,
    ),

    /**
     * 体脂测量中
     */
    BODY_FAT_MEASURING: new ScaleMeasure(
        14,
        "正在测量体脂",
        "请耐心等待体脂测量完成哦~",
        imgUrlFormat('common/load_mark.png'),
        true,
    ),

    /**
     * 断开连接
     */
    LOST_CONNECT: new ScaleMeasure(
        15,
        "连接已断开",
        "请先下秤，并重新测量",
        imgUrlFormat('common/fail.png'),
        false, "重新测量",
    )
}

/**
 * 监测项状态描述数组
 */
const BodyFatTipArrays = {
    WEIGHT_TIP_ARRAY: [
        "长期体重过轻会导致一系列问题，如脱发、厌食症等，身体机能会下降，需要加强营养，多吃高蛋白食物，摄入更多的热量以增加体重。",
        "体重偏低，身体消瘦，建议加强营养，平衡饮食，多吃高蛋白食物，摄入更多的热量以增加体重。",
        "恭喜您拥有理想的体重，保持合理健康的生活方式，适量参加运动，您就可以维持标准体重了。",
        "体重偏重，略显肥胖，建议一周进行3-5次有氧运动，减少主食（米饭、面条等）的摄入，增加高纤维粗粮比例。",
        "体重严重超标，建议低脂、低胆固醇、高纤维膳食，补充多种维生素，增加运动量进行体重控制。"
    ],
    // 体重与身体指标提示数组
    BMI_TIP_ARRAY: [
        "需要提升体能健康增重，适当多吃高热量、高蛋白、高脂肪饮食，多做力量运动如举重、俯卧撑、仰卧起坐等。",
        "男：BMI达标，如果腰围也属于标准腰围xxcm，就更理想了。标准腰围(cm)=身高(cm)x1/2-10<br />女：BMI达标，如果腰围也属于标准腰围xxcm，就更加理想了。标准腰围(cm)=身高(cm)x1/2-13",
        "BMI超标，建议选择比较健康的方法减重，如控制饮食、改变不良生活习惯和参加跑步、跳绳、打篮球、踢足球等消耗体能的运动。"
    ],

// 体脂率提示数组
    BODY_FAT_TIP_ARRAY: [
        "当身体摄取到优质营养，并且使小肠绒毛正常运作，就可以达到正常的脂肪比例。为了增重，食物最好以易消化、高蛋白、高热量为原则。",
        "目前您的体脂率处于标准范围，保持好的饮食方式和生活习惯是保持健康身材的最佳途径。",
        "要匀称不显胖，每日有氧运动要持续30分钟，体脂率才会开始燃烧，快走、慢跑、游泳、爬楼梯、骑自行车都是很好的选择。",
        "您的体内囤积了太多脂肪，必须检测血压、血糖、肝功能等情况，是否潜藏危害。赶快开始您的减肥大战，坚持饮食控制、运动及改变生活方式。"
    ],

// 体水分提示数组
    BODY_WATER_TIP_ARRAY: [
        "体水分率偏低，规律的饮食习惯和每天喝足8杯水可以维持正常的体水分水平，充足的水分可以促进代谢，带走废物和身体毒素。",
        "身体水分率处于标准值，适量饮水，适当运动，均衡饮食，保持身体水分的平衡。",
        "身体水分含量高，细胞活性高。充足的水分能帮助您更好地消化食物和吸收养分，并促进代谢，带走废物和毒素。"
    ],

// 骨骼肌率提示数组
    MUSCLE_RATE_TIP_ARRAY: [
        "您的骨胳肌比率低于理想范围，跟静态活动多、不运动有关，会导致基础代谢率降低，腰酸背痛，力量下降，外在表现是发胖，也容易诱发心血管疾病。",
        "您的骨胳肌比率处于标准范围。运动量过少或者节食会导致肌肉流失，请保持适当的运动量和合理的饮食。",
        "过高的骨胳肌比率可能会影响您的灵活性，平衡身体各项参数，您就能拥有健康标准的身材。"
    ],

// 基础代谢率提示数组
    BMR_TIP_ARRAY: [
        "达标：当前体重下基础代谢率标准值范围为（标准代谢-15%）～（标准代谢+15%）。您的标准基础代谢率为【%skcal】，处于达标状态。保持基础代谢率最有效的方式是每天都进行适量的运动。",
        "不达标：当前体重下基础代谢率标准值范围为（标准代谢-10%）～（标准代谢+15%）。您的标准基础代谢率为【%skcal】,目前处于未达标状态。持续轻量运动能够提高身体的基础代谢率，而节食基础代谢会大幅下降。"
    ],

// 体型提示数组
    BODY_SHAPE_TIP_ARRAY: [
        "",
        "您的体型属于隐形肥胖型，得多进行有氧运动，否则很容易成为真胖子了。",
        "您的体型属于运动不足型，需要运动起来了。",
        "您的体型属于偏瘦型，需要加强营养了。",
        "您的体型属于标准型，继续保持。",
        "您的体型属于偏瘦肌肉型，继续保持。",
        "您的体型属于肥胖型，控制饮食和加强有氧运动能够助您降低脂肪。",
        "您的体型属于偏胖型，控制饮食和加强有氧运动能够助您降低脂肪。",
        "您的体型属于标准肌肉型，继续保持。",
        "您的体型属于非常肌肉型，继续保持。"
    ],

// 蛋白质水准提示数组
    PROTEIN_TIP_ARRAY: [
        "蛋白质不足会引起基础代谢减少，也会引起肌肉的数量减少。坚持长期运动，适当提高肌肉比例，辅助于蛋白质的补充，可以提升蛋白质比例。",
        "您的蛋白质处于标准水平。",
        "蛋白质比例充足。"
    ],

// 肌肉量提示数组
    MUSCLE_MASS_TIP_ARRAY: [
        "您缺少足够的肌肉，需要加强运动，增加肌肉。",
        "您的肌肉比较发达，继续保持。",
        "您的肌肉比较发达，继续保持。"
    ],

// 健康得分提示数组
    HEALTH_SCORE_TIP_ARRAY: [
        "您的身体状况简直不能忍，接受现实还是改变自己,做出选择吧！！",
        "良好的体型是健康表现之一，您可能要变形了！",
        "您正在远离男神/女神的体质了，运动起来吧！",
        "您的体质已经接近男神/女神了，继续努力就能梦想成真！！",
        "神体质、好身材，您值得拥有。go go go！！",
        "您的身体状况已经超神，妥善保养就行了！！"
    ],

// 心率提示数组
    HEART_RATE_TIP_ARRAY: [
        "窦性心动过缓。可见于长期从事体力劳动和运动员；病理性见于甲状腺低下、颅内压增高、阻塞性黄胆、以及洋地黄、奎尼丁、或心得安类药物过量或中毒。",
        "健康成人的心率为60～100次/分，大多数为60～80次/分，女性稍快。",
        "窦性心动过速。常见于正常人运动、兴奋、激动、吸烟、饮酒和浓茶后；也可见于发热、休克、贫血、甲亢、心力衰竭及应用阿托品、肾上腺素、麻黄素等。"
    ],

// 皮下脂肪提示数组
    SUB_FAT_TIP_ARRAY: [
        "适度的皮下脂肪能够保护内脏和抵御寒冷，适度增加高蛋白、高热量的食物可以增加脂肪。",
        "您的皮下脂肪率处于标准范围。适当的运动强度和合理的饮食就能保持适度的皮下脂肪。",
        "皮下脂肪过多是外表肥胖的主要原因，除了有氧减脂以外，多进行增肌训练，肌肉的增加可以让您拥有更完美的体型。"
    ],

// 内脏脂肪等级提示数组
    VISCERAL_TIP_ARRAY: [
        "内脏脂肪指数标准，暂时没有太大风险。请继续保持健康的饮食和适当的运动！",
        "内脏脂肪指数标准，暂时没有太大风险。虽然处于标准范围，但内脏脂肪已经开始堆积，请积极运动，改变久坐不动、饮食不均衡等不良习惯。",
        "内脏脂肪指数偏高，持续保持均衡的饮食和适当的运动，以标准程度为目标，进行适当运动和限制卡路里。",
        "内脏脂肪指数危险，罹患心脏病、高血压、高血脂和2型糖尿病风险大，您迫切需要控制体重、积极运动和限制饮食。"
    ],

// 骨量提示数组
    BONE_MASS_TIP_ARRAY: [
        "您的骨量水平偏低。长期低钙饮食、缺乏运动、过度减肥等都可能引起骨量偏低，多吃含钙高的食物，多晒太阳，多运动及时补钙。",
        "您的骨量水平标准。骨量在短期内不会出现明显的变化，您只要保证健康的饮食和适当的锻炼，就可以维持稳定健康的骨量水平。",
        "您的骨量水平偏高。说明骨骼中包含的钙等无机盐的含量非常充分，但要注意防范肾结石、低血压的风险，尽可能避免高钙摄入。"
    ],
}

export enum QnScaleIndicator {
    TYPE_WEIGHT = 0,
    TYPE_BMI = 1,
    TYPE_BODY_FAT_RATE = 2,
    TYPE_BODY_WATER_RATE = 3,
    TYPE_MUSCLE_RATE = 4,
    TYPE_BMR = 5,
    TYPE_BODY_TYPE = 6,
    TYPE_PROTEIN = 7,
    TYPE_MUSCLE_MASS = 8,
    TYPE_METABOLIC_AGE = 9,
    TYPE_HEALTH_SCORE = 10,
    TYPE_HEALTH_RATE = 11,
    TYPE_SUB_FAT = 12,
    TYPE_VISFAT = 13,
    TYPE_LEAN_BODY_WEIGHT = 14,
    TYPE_BODY_FAT_WEIGHT = 300,
    TYPE_BONE_MASS = 15,
}

const State = {
    STATE_SERIOUS_LOW: "严重偏低",
    STATE_LOW: "偏低",
    STATE_NORMAL: "标准",
    STATE_SUFFICENT: "充足",
    STATE_HIGH: "偏高",
    STATE_SERIOUS_HIGH: "严重偏高",
} as const;

interface QnScaleIndicatorData {
    type: QnScaleIndicator;
    indicatorName: string;
    displayName: string;
    unit?: string;
    rangeTitleList?: string[];
    min?: number;
    max?: number;
    dataRange?: number[];
    style?: { color: string, label: string }[]
}

const QnScaleIndicatorData: QnScaleIndicatorData[] = [
    {
        type: QnScaleIndicator.TYPE_WEIGHT,
        indicatorName: "weight",
        displayName: "体重",
        unit: "kg",
        rangeTitleList: [
            State.STATE_SERIOUS_LOW,
            State.STATE_LOW,
            State.STATE_NORMAL,
            State.STATE_HIGH,
            State.STATE_SERIOUS_HIGH,
        ],
        min: 0,
        max: 100,
        dataRange: [0, 56.7, 69.3, 100],
        style: [{label: '偏低',color:'#FFA94F'}, {label: '标准',color:'#64A4F5'}, {label: '偏高',color:'#FF403D'}]
    },
    {
        type: QnScaleIndicator.TYPE_BMI,
        indicatorName: "bmi",
        displayName: "BMI",
        unit: "",
        rangeTitleList: [State.STATE_LOW, State.STATE_NORMAL, State.STATE_HIGH],
        min: 0,
        max: 50,
        dataRange: [0, 18.5, 25, 50],
		style: [{label: '偏低',color:'#FFA94F'}, {label: '标准',color:'#64A4F5'}, {label: '偏高',color:'#FF403D'}]
    },
    {
        type: QnScaleIndicator.TYPE_BODY_FAT_RATE,
        indicatorName: "bodyfat",
        displayName: "体脂率",
        unit: "%",
        rangeTitleList: [
            State.STATE_LOW,
            State.STATE_NORMAL,
            State.STATE_HIGH,
            State.STATE_SERIOUS_HIGH,
        ],
        min: 5,
        max: 70,
        dataRange: [5, 11, 21, 70],
		style: [{label: '偏低',color:'#FFA94F'}, {label: '标准',color:'#64A4F5'}, {label: '偏高',color:'#FF403D'}]

    },
    {
        type: QnScaleIndicator.TYPE_BODY_WATER_RATE,
        indicatorName: "water",
        displayName: "体水分",
        unit: "%",
        rangeTitleList: [State.STATE_LOW, State.STATE_NORMAL, State.STATE_SUFFICENT],
        dataRange: [0, 55.0, 65.0, 100],
		style: [{label: '偏低',color:'#FFA94F'}, {label: '标准',color:'#64A4F5'}, {label: '充足',color:'#64A4F5'}]

    },
    {
        type: QnScaleIndicator.TYPE_MUSCLE_RATE,
        indicatorName: "muscle",
        displayName: "骨骼肌率",
        unit: "%",
        rangeTitleList: [State.STATE_LOW, State.STATE_NORMAL, State.STATE_HIGH],
        max: 70,
        dataRange: [0, 49.0, 59.0, 70],
		style: [{label: '偏低',color:'#FFA94F'}, {label: '标准',color:'#64A4F5'}, {label: '偏高',color:'#FF403D'}]

    },
    {
        type: QnScaleIndicator.TYPE_BMR,
        indicatorName: "bmr",
        displayName: "基础代谢率",
        unit: "",
    },
    {
        type: QnScaleIndicator.TYPE_BODY_TYPE,
        indicatorName: "bodyShape",
        displayName: "体型",
        unit: "",
        rangeTitleList: [
            "无体型值",
            "隐形肥胖型",
            "运动不足型",
            "偏瘦型",
            "标准型",
            "偏瘦肌肉型",
            "肥胖型",
            "偏胖型",
            "标准肌肉型",
            "非常肌肉型",
        ],
    },
    {
        type: QnScaleIndicator.TYPE_PROTEIN,
        indicatorName: "protein",
        displayName: "蛋白质",
        unit: "",
        rangeTitleList: [State.STATE_LOW, State.STATE_NORMAL, State.STATE_SUFFICENT],
        dataRange: [0, 16.0, 18.0, 100],
		style: [{label: '偏低',color:'#FFA94F'}, {label: '标准',color:'#64A4F5'}, {label: '充足',color:'#64A4F5'}]
    },
    {
        type: QnScaleIndicator.TYPE_MUSCLE_MASS,
        indicatorName: "muscleMass",
        displayName: "肌肉量",
        unit: "",
        rangeTitleList: [State.STATE_LOW, State.STATE_NORMAL, State.STATE_SUFFICENT],
        dataRange: [0, 44.0, 52.4, 100],
		style: [{label: '偏低',color:'#FFA94F'}, {label: '标准',color:'#64A4F5'}, {label: '充足',color:'#64A4F5'}]

    },
    {
        type: QnScaleIndicator.TYPE_METABOLIC_AGE,
        indicatorName: "bodyAge",
        displayName: "身体年龄",
        unit: "",
        rangeTitleList: ["达标", "不达标"],
    },
    {
        type: QnScaleIndicator.TYPE_HEALTH_SCORE,
        indicatorName: "score",
        displayName: "得分",
        unit: "",
    },
    {
        type: QnScaleIndicator.TYPE_HEALTH_RATE,
        indicatorName: "heartRate",
        displayName: "心率",
        unit: "",
        rangeTitleList: [State.STATE_LOW, State.STATE_NORMAL, State.STATE_HIGH],
        min: 0,
        max: 200,
        dataRange: [0, 60.0, 100.0, 200],
		style: [{label: '偏低',color:'#FFA94F'}, {label: '标准',color:'#64A4F5'}, {label: '偏高',color:'#FF403D'}]

    },
    {
        type: QnScaleIndicator.TYPE_SUB_FAT,
        indicatorName: "subfat",
        displayName: "皮下脂肪",
        unit: "",
        rangeTitleList: [State.STATE_LOW, State.STATE_NORMAL, State.STATE_HIGH],
        dataRange: [0, 8.6, 16.7, 100],
		style: [{label: '偏低',color:'#FFA94F'}, {label: '标准',color:'#64A4F5'}, {label: '偏高',color:'#FF403D'}]

    },
    {
        type: QnScaleIndicator.TYPE_VISFAT,
        indicatorName: "visfat",
        displayName: "内脏脂肪等级",
        unit: "",
        rangeTitleList: [State.STATE_NORMAL, State.STATE_HIGH, State.STATE_SERIOUS_HIGH],
        min: 0,
        max: 20,
        dataRange: [0, 9.0, 14.0, 20],
		style: [{label: '标准',color:'#64A4F5'}, {label: '偏高',color:'#FF403D'}, {label: '严重偏高',color:'#FF403D'}]

    },
    {
        type: QnScaleIndicator.TYPE_LEAN_BODY_WEIGHT,
        indicatorName: "lbm",
        displayName: "去脂体重",
        unit: "kg",
    },
    // 非SDK原始指标，APP新建，用于页面展示时根据体脂率动态计算
    {
        type: QnScaleIndicator.TYPE_BODY_FAT_WEIGHT,
        indicatorName: "TYPE_BODY_FAT_WEIGHT",
        displayName: "脂肪重量",
        unit: "kg",
    },
    // 仅用于数据上传处理，页面展现并未使用
    {
        type: QnScaleIndicator.TYPE_BONE_MASS,
        indicatorName: "bone",
        displayName: "骨量",
        unit: "",
        rangeTitleList: [State.STATE_LOW, State.STATE_NORMAL, State.STATE_HIGH],
    },
];

// @ts-ignore
function valueOf(type: QnScaleIndicator): QnScaleIndicatorData | undefined {
    return QnScaleIndicatorData.find((v) => v.type === type);
}

// @ts-ignore
function toIntValue(type: QnScaleIndicator): boolean {
    return (
        type === QnScaleIndicator.TYPE_METABOLIC_AGE ||
        type === QnScaleIndicator.TYPE_BMR ||
        type === QnScaleIndicator.TYPE_HEALTH_SCORE
    );
}

export const BodyFatIndicator = {
    judge(value: number, list: number[]) {
        const min = list[0];
        const max = list[1];
        let type = 0;
        if (value < min) {
            type = 0;
        } else if (value <= max) {
            type = 1;
        } else {
            type = 2;
        }
        return type;
    },

    getTestItemIndicate(
        type: number,
        stateDescArray?: string[] | undefined
    ) {
        let result = {
            state: type,
            tip: ''
        }
        if (stateDescArray && stateDescArray.length > 0) {
            result.tip = stateDescArray[type]
        }
        return result;
    },

    isMaleV1(gender?: number): boolean {
        return gender == null || gender == 1 || gender == 0;
    },

    getWeightIndicate(gender: number, height: number, value: number) {
        const list = this.getFullWeightRange(gender, height);
        let type = 2;
        const target1 = list[0];
        const target2 = list[1];
        const target3 = list[2];
        const target4 = list[3];
        if (value <= target1) {
            type = 0;
        } else if (value > target1 && value < target2) {
            type = 1;
        } else if (value >= target2 && value <= target3) {
            type = 2;
        } else if (value > target3 && value <= target4) {
            type = 3;
        } else if (value > target4) {
            type = 4;
        }
        return this.getTestItemIndicate(type, BodyFatTipArrays.WEIGHT_TIP_ARRAY);
    },

    getWeightRange(gender: number, height: number): number[] {
        let sw;
        if (this.isMaleV1(gender)) {
            sw = (height - 80) * 0.7;
        } else {
            sw = (height * 1.37 - 110) * 0.45;
        }
        const rangeList: number[] = [];
        rangeList.push(0.9 * sw);
        rangeList.push(1.1 * sw);
        return rangeList;
    },

    getFullWeightRange(gender: number, height: number): number[] {
        let sw;
        if (this.isMaleV1(gender)) {
            sw = (height - 80) * 0.7;
        } else {
            sw = (height * 1.37 - 110) * 0.45;
        }
        const rangeList: number[] = [];
        rangeList.push(0.8 * sw);
        rangeList.push(0.9 * sw);
        rangeList.push(1.1 * sw);
        rangeList.push(1.2 * sw);
        return rangeList;
    },

    getBmiIndicate(value: number) {
        return this.getTestItemIndicate(this.judge(value, this.getBmiRange()), BodyFatTipArrays.BMI_TIP_ARRAY);
    },

    getBmiRange(): number[] {
        const rangeList: number[] = [];
        rangeList.push(18.5);
        rangeList.push(25);
        return rangeList;
    },

    getBodyFatIndicate(gender: number, value: number) {
        return this.getTestItemIndicate(this.judge(value, this.getBodyFatRateRange(gender)), BodyFatTipArrays.BODY_FAT_TIP_ARRAY);
    },

    getBodyFatRateRange(gender: number): number[] {
        const rangeList: number[] = [];
        if (this.isMaleV1(gender)) {
            rangeList.push(11);
            rangeList.push(21);
            rangeList.push(26);
        } else {
            rangeList.push(21);
            rangeList.push(31);
            rangeList.push(36);
        }
        return rangeList;
    },

    getMuscleRateIndicate(gender: number, value: number) {
        return this.getTestItemIndicate(this.judge(value, this.getMuscleRateRange(gender)), BodyFatTipArrays.MUSCLE_RATE_TIP_ARRAY);
    },

    getMuscleRateRange(gender: number): number[] {
        const rangeList: number[] = [];
        if (this.isMaleV1(gender)) {
            rangeList.push(49);
            rangeList.push(59);
        } else {
            rangeList.push(40);
            rangeList.push(50);
        }
        return rangeList;
    },

    getBodyWaterIndicate(gender: number, value: number) {
        return this.getTestItemIndicate(this.judge(value, this.getBodyWaterRange(gender)), BodyFatTipArrays.BODY_WATER_TIP_ARRAY);
    },

    getBodyWaterRange(gender: number): number[] {
        const rangeList: number[] = [];
        if (this.isMaleV1(gender)) {
            rangeList.push(55);
            rangeList.push(65);
        } else {
            rangeList.push(45);
            rangeList.push(60);
        }
        return rangeList;
    },

    getBodyShapeIndicate(value: number) {
        const index = Math.floor(value);
        return this.getTestItemIndicate(index, BodyFatTipArrays.BODY_SHAPE_TIP_ARRAY);
    },

    getProteinIndicate(gender: number, value: number) {
        return this.getTestItemIndicate(this.judge(value, this.getProteinRange(gender)), BodyFatTipArrays.PROTEIN_TIP_ARRAY);
    },

    getProteinRange(gender: number): number[] {
        const rangeList: number[] = [];
        if (this.isMaleV1(gender)) {
            rangeList.push(16);
            rangeList.push(18);
        } else {
            rangeList.push(14);
            rangeList.push(16);
        }
        return rangeList;
    },
    /**
     * 身体年龄
     */
    getBodyAgeIndicate(age: number, value: number) {
        return {
            state: value <= age ? 0 : 1,
            tip: "身体年龄不代表您的实际年龄，体年龄只用来评估当前身体状况。合理的饮食搭配，规律的运动锻炼，以及乐观积极的心态是保持身体年轻的秘诀~"
        }
    },

    getHeartRateIndicate(value: number) {
        return this.getTestItemIndicate(this.judge(value, this.getHeartRateRange()), BodyFatTipArrays.HEART_RATE_TIP_ARRAY);
    },

    getHeartRateRange(): number[] {
        const rangeList: number[] = [];
        rangeList.push(60);
        rangeList.push(100);
        return rangeList;
    },

    getMuscleMassIndicate(gender: number, height: number, value: number) {
        return this.getTestItemIndicate(this.judge(value, this.getMuscleMassRange(gender, height)), BodyFatTipArrays.MUSCLE_MASS_TIP_ARRAY);
    },

    getMuscleMassRange(gender: number, height: number): number[] {
        const list: number[] = [];
        if (this.isMaleV1(gender)) {
            if (height < 160) {
                list.push(38.5);
                list.push(46.5);
            } else if (height <= 170) {
                list.push(44);
                list.push(52.4);
            } else {
                list.push(49.4);
                list.push(59.4);
            }
        } else {
            if (height < 150) {
                list.push(29.1);
                list.push(34.7);
            } else if (height <= 160) {
                list.push(32.9);
                list.push(37.5);
            } else {
                list.push(36.5);
                list.push(42.5);
            }
        }
        return list;
    },

    /**
     * Bone Mass
     */
    getBoneMassIndicate(weight, gender, value) {
        return this.getTestItemIndicate(this.judge(value, this.getBoneMassRange(gender, weight)), BodyFatTipArrays.BONE_MASS_TIP_ARRAY);
    },

    getBoneMassRange(gender, weight) {
        const rangeList: number[] = [];
        if (this.isMaleV1(gender)) {
            if (weight <= 60) {
                rangeList.push(2.3);
                rangeList.push(3.1);
            } else if (weight < 75) {
                rangeList.push(2.7);
                rangeList.push(3.1);
            } else {
                rangeList.push(3.0);
                rangeList.push(3.4);
            }
        } else {
            if (weight <= 45) {
                rangeList.push(1.6);
                rangeList.push(2.0);
            } else if (weight > 45 && weight < 60) {
                rangeList.push(2.0);
                rangeList.push(2.4);
            } else {
                rangeList.push(2.3);
                rangeList.push(2.7);
            }
        }
        return rangeList;
    },

    /**
     * Visceral Fat
     */
    getVisFatIndicate(value) {
        let type = this.judge(value, this.getVisFatRange());
        let result = {
            state: type,
            tip: ''
        }
        const stateDescArray = BodyFatTipArrays.VISCERAL_TIP_ARRAY;
        if (value === 9) {
            result.tip = stateDescArray[1];
            type = 0;
        } else {
            if (type >= 1) {
                type += 1;
            }
            result.tip = stateDescArray[type];
        }
        result.state = type
        return result
    },

    getVisFatRange(): number[] {
        return [9, 14];
    },

    /**
     * Subcutaneous Fat
     */
    getSubFatIndicate(gender, value) {
        return this.getTestItemIndicate(this.judge(value, this.getSubFatRange(gender)), BodyFatTipArrays.SUB_FAT_TIP_ARRAY);
    },

    getSubFatRange(gender) {
        const list: number[] = [];
        if (this.isMaleV1(gender)) {
            list.push(8.6);
            list.push(16.7);
        } else {
            list.push(18.5);
            list.push(26.7);
        }
        return list;
    },

    /**
     * Lean Body Mass
     */
    getLbmIndicate() {
        return {
            state: 0
        }
    },

    getQnScaleIndicatorData(type: QnScaleIndicator) {
        return valueOf(type);
    }

}
