/**
 * 配置血糖时段、偏高偏低状态与时段和时间对应关系
 */
/**
 * 血糖时段
 * @type {[{value: string, key: number},{value: string, key: number},{value: string, key: number},{value: string, key: number},{value: string, key: number},null,null,null]}
 */

interface ITimeType {
	key: number,
	value: string,
	time: string
}

export const timeType: Array<ITimeType> = [
	{
		key: 7,
		value: '凌晨',
		time: '00:00'
	},
	{
		key: 0,
		value: '空腹',
		time: '05:00'
	}, {
		key: 1,
		value: '早餐后',
		time: '09:00'
	}, {
		key: 2,
		value: '午餐前',
		time: '11:00'
	}, {
		key: 3,
		value: '午餐后',
		time: '12:00'
	}, {
		key: 4,
		value: '晚餐前',
		time: '17:00'
	}, {
		key: 5,
		value: '晚餐后',
		time: '19:00'
	}, {
		key: 6,
		value: '睡前',
		time: '21:00'
	},
]
