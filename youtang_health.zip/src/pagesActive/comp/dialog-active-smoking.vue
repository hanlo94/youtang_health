<template>
  <view class="dialog_root">

    <view class="item" v-for="(item,index) in list" :key="item.id" @click="onItemClick(item,index)">
      <view class="option">
        <img :src=" item.check ? imgCheckTrue : imgCheckFalse"/>
        <text :class=" item.check ? 'blue' : 'gray' ">{{ index + 1 }}、{{ item.name }}</text>
      </view>
      <view class="input" v-if="index === 1">
        平均每天吸烟数（支）：
        <input type="number" placeholder="请输入" v-model="inputValue" maxlength="3"/>
      </view>
      <view class="input" v-if="index === 1">
        烟龄（年）：
        <input type="number" placeholder="请输入" v-model="inputValue2" maxlength="2"/>
      </view>
    </view>

    <view class="btn">
      <view class="btn_left" @click="onClickDialogClear">取消</view>
      <view class="btn_right" @click="onClickDialogSubmit">确认</view>
    </view>

  </view>

</template>
<script setup lang="ts">


import imgUrlFormat from "@/utils/imgUtils";
import {activeSmokeOptions} from "@/pagesActive/ts/lifeList";
import {ref} from "vue";
import {showToast} from "@/utils/toastUtils";
import {ISelectOption} from "@/pagesActive/ts/types";
import {IWordItem} from "@/api/types";

const imgCheckTrue = imgUrlFormat('sugar/icon_circle_blue_selected.png')
const imgCheckFalse = imgUrlFormat('sugar/icon_circle_gray_normal.png')

/**
 * 输入框
 */
const inputValue = ref<number | null>(null)
const inputValue2 = ref<number | null>(null)
const currentIndex = ref(-1)


type Props = {
  list: ISelectOption[];
  other: number | null;
  smokeYears: number | null;
}
const props = withDefaults(defineProps<Props>(), {
  list: () => [],
  other: null
})

inputValue.value = props.other === 0 ? null : props.other;
inputValue2.value = props.smokeYears === 0 ? null : props.smokeYears;


const emit = defineEmits(['onClickDialogSubmit', 'onClickDialogClear']);

/**
 * 提交
 */
const onClickDialogSubmit = () => {
  if (currentIndex.value === 1) {
    console.log(inputValue.value)
    if (!inputValue.value || inputValue.value < 1) {
      showToast('请输入吸烟数')
      return;
    }
    if (!inputValue2.value || inputValue2.value < 0) {
      showToast('请输入烟龄')
      return;
    }
  }
  emit('onClickDialogSubmit', {bean: activeSmokeOptions.value.filter(item => item.check)[0], input: inputValue.value,input2:inputValue2.value})
}

/**
 * 清除
 */
const onClickDialogClear = () => {
  emit('onClickDialogClear')
}


/**
 * 点击item
 */
const onItemClick = (item: ISelectOption, index: number) => {
  activeSmokeOptions.value.map(mapItem => mapItem.check = false)
  item.check = !item.check
  currentIndex.value = index
}

</script>

<style lang="less">
.dialog_root {
  display: flex;
  flex-direction: column;

  .item {
    display: flex;
    padding: 17px 22px;
    flex-direction: column;

    .option {
      display: flex;
      flex-direction: row;
      align-items: center;

      img {
        width: 30px;

        margin-right: 20px;
        height: 30px;
      }

      text {
        flex: 1;
      }

      .blue {
        color: #64A4F5;
      }

      .gray {
        color: #5F5F5F;
      }
    }

    .input {
      display: flex;
      padding-left: 50px;
      border-bottom: 1px solid #E5E5E5;
      padding-top: 30px;
      padding-bottom: 30px;
      color: #5F5F5F;
      flex-direction: row;
      justify-content: space-between;

      input {
        width: 150px;
      }
    }
  }

  .btn {
    display: flex;
    flex-direction: row;
    justify-content: space-around;
    background: white;
    padding: 50px 0px;
    align-items: center;

    .btn_left {
      border-radius: 17px;
      border: #64A4F5 solid 1px;
      width: 275px;
      height: 97px;
      color: #64A4F5;
      background: white;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .btn_right {
      border-radius: 17px;
      border: #64A4F5 solid 1px;
      width: 416px;
      height: 97px;
      color: white;
      background: #64A4F5;
      display: flex;
      justify-content: center;
      align-items: center;
    }
  }
}
</style>
