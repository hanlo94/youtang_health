<template>

  <view class="duration_root">

    <view class="tips">输入示例早中晚1：1：1</view>

    <view class="item">早<input v-model="breakfast" placeholder="请输入" maxlength="3"/></view>
    <view class="item">午<input v-model="lunch" placeholder="请输入" maxlength="3"/></view>
    <view class="item">晚<input v-model="dinner" placeholder="请输入" maxlength="3"/></view>


    <view class="btn">
      <view class="btn_left" @click="onClickDialogClear">取消</view>
      <view class="btn_right" @click="onClickDialogSubmit">确认</view>
    </view>

  </view>
</template>
<script setup lang="ts">

import {ref} from "vue";
import {showToast} from "@/utils/toastUtils";

const breakfast = ref('');
const lunch = ref('');
const dinner = ref('');

const emit = defineEmits(['onClickDialogSubmit', 'onClickDialogClear']);


const props = defineProps({
  content: {
    type: String,
    default: ''
  }
})

breakfast.value = props.content.split(':')[0];
lunch.value = props.content.split(':')[1];
dinner.value = props.content.split(':')[2];


const onClickDialogSubmit = () => {
  if (breakfast.value !== '' || lunch.value !== '' || dinner.value !== '') {
    emit('onClickDialogSubmit', {
      breakfast:  breakfast.value  || "0",
      lunch: lunch.value || "0",
      dinner: dinner.value || "0",
    })
  } else {
    showToast("请至少填写一项")
  }


}

/**
 *清除
 */
const onClickDialogClear = () => {
  emit('onClickDialogClear')
}


</script>

<style lang="less">
.duration_root {

  padding: 20px;

  .tips {
    background: #EBF6FF;
    margin: 22px 0;
    font-size: 29px;
    color: #64A4F5;
    padding: 18px 22px;
  }


  .item {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
    color: #5F5F5F;
    font-size: 33px;
    border-bottom: 1px solid #efefee;
    padding: 34px;

    input {
      width: 150px;
      text-align: right;
    }
  }

  .btn {
    display: flex;
    flex-direction: row;
    justify-content: space-around;
    background: white;
    padding: 50px 0px;
    align-items: center;

    .btn_left {
      border-radius: 17px;
      border: #64A4F5 solid 1px;
      width: 275px;
      height: 97px;
      color: #64A4F5;
      background: white;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .btn_right {
      border-radius: 17px;
      border: #64A4F5 solid 1px;
      width: 416px;
      height: 97px;
      color: white;
      background: #64A4F5;
      display: flex;
      justify-content: center;
      align-items: center;
    }
  }
}
</style>
