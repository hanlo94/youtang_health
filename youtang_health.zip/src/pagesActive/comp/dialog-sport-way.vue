<template>
  <view class="pop_root">
    <view class="item">
      <view class="header">
        <view class="title_icon"></view>
        锻炼1
      </view>

      <view class="content">
        <view class="content_item">锻炼方式 <input placeholder="请输入，如散步、游泳、跳舞" maxlength="20"/></view>
        <view class="content_item">锻炼频率（次/周） <input placeholder="请输入" maxlength="3"/></view>
        <view class="content_item">锻炼时长（分钟） <input placeholder="请输入" maxlength="3"/></view>
      </view>

    </view>
    <view class="item">
      <view class="header">
        <view class="title_icon"></view>
        锻炼2
      </view>

      <view class="content">
        <view class="content_item">锻炼方式 <input placeholder="请输入，如散步、游泳、跳舞" maxlength="20"/></view>
        <view class="content_item">锻炼频率（次/周） <input placeholder="请输入" maxlength="3"/></view>
        <view class="content_item">锻炼时长（分钟） <input placeholder="请输入" maxlength="3"/></view>
      </view>

    </view>

    <view class="btn">
      <view class="btn_left" @click="onClickDialogClear">取消</view>
      <view class="btn_right" @click="onClickDialogSubmit">确认</view>
    </view>
  </view>
</template>
<script setup lang="ts">

const emit = defineEmits(['onClickDialogSubmit', 'onClickDialogClear']);
const onClickDialogClear = () => {
  emit('onClickDialogClear')
}

const onClickDialogSubmit = () => {
  emit('onClickDialogClear', {})
}

</script>

<style lang="less">
.pop_root {
  display: flex;
  flex-direction: column;
  padding: 22px;

  .item {
    display: flex;


    flex-direction: column;

    .header {
      display: flex;
      color: #353535;
      padding: 22px 0;
      align-items: center;

      .title_icon {
        width: 20px;
        height: 20px;
        background-color: #6aa4fc;
        margin-right: 10px;
      }
    }

    .content {
      display: flex;
      border: 1px solid #efefee;
      border-radius: 16px;
      padding: 0 22px;
      flex-direction: column;

      .content_item {
        display: flex;
        padding: 30px 0;
        border-bottom: 1px solid #efefee;
        align-items: center;
        justify-content: space-between;

        input {
          text-align: right;
        }
      }
    }
  }

  .btn {
    display: flex;
    flex-direction: row;
    justify-content: space-around;
    background: white;
    padding: 50px 0px;
    align-items: center;

    .btn_left {
      border-radius: 17px;
      border: #64A4F5 solid 1px;
      width: 275px;
      height: 97px;
      color: #64A4F5;
      background: white;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .btn_right {
      border-radius: 17px;
      border: #64A4F5 solid 1px;
      width: 416px;
      height: 97px;
      color: white;
      background: #64A4F5;
      display: flex;
      justify-content: center;
      align-items: center;
    }
  }
}
</style>
