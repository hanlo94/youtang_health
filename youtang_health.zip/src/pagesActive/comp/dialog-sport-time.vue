<template>
  <view class="pop_root">
    <view class="list">
      <view :class=" item.check ? 'item_true' : 'item_false'  " v-for="(item,index) in list"
            :key="item.id" @click="onClickDialogItem(item,index)">{{index+1}}、{{ item.name }}
      </view>
    </view>


    <view class="btn">
      <view class="btn_left" @click="onClickDialogClear">取消</view>
      <view class="btn_right" @click="onClickDialogSubmit">确认</view>
    </view>
  </view>
</template>
<script setup lang="ts">

import {sportTimeOptions} from "@/pagesActive/ts/lifeList";
import {ISelectOption} from "@/pagesActive/ts/types";


type Props = {
  list:ISelectOption[];
}
const props = withDefaults(defineProps<Props>(), {
  list:()=>[],
})


const emit = defineEmits(['onClickDialogSubmit', 'onClickDialogClear']);


/**
 * 点击选中 取消选中
 * @param item
 * @param index
 */
const onClickDialogItem = (item: ISelectOption, index: number) => {
  item.check = !item.check
}


const onClickDialogClear = () => {
  sportTimeOptions.value.map(item => item.check = false)
  emit('onClickDialogClear')
}

const onClickDialogSubmit = () => {
  emit('onClickDialogSubmit', {list: sportTimeOptions.value.filter(item => item.check)})
}

</script>

<style lang="less">
.pop_root {
  display: flex;
  flex-direction: column;
  padding: 22px;

  .list {
    display: flex;
    flex-wrap: wrap;

    .item_true {
      padding: 10px 80px;
      border-radius: 40px;
      color: white;
      margin-left: 10px;
      margin-top: 30px;
      background: #6aa4fc;
      border: #6aa4fc solid 1px;
    }

    .item_false {
      border: #BBBBBB solid 1px;
      padding: 10px 80px;
      border-radius: 40px;
      color: #5F5F5F;
      margin-left: 10px;
      margin-top: 30px;
      background: white;
    }
  }

  .btn {
    display: flex;
    flex-direction: row;
    justify-content: space-around;
    background: white;
    padding: 50px 0px;
    align-items: center;

    .btn_left {
      border-radius: 17px;
      border: #64A4F5 solid 1px;
      width: 275px;
      height: 97px;
      color: #64A4F5;
      background: white;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .btn_right {
      border-radius: 17px;
      border: #64A4F5 solid 1px;
      width: 416px;
      height: 97px;
      color: white;
      background: #64A4F5;
      display: flex;
      justify-content: center;
      align-items: center;
    }
  }
}
</style>
