<template>
  <view class="food_root">

    <view class="tips">{{tips}}</view>
    <view class="item" v-for="(item,index) in list" :key="item.id" @click="onItemClick(item,index)">
      <view class="option">
        <img :src=" item.check ? imgCheckTrue : imgCheckFalse"/>
        <text :class=" item.check ? 'blue' : 'gray' ">{{index+1}}、{{ item.name }}</text>
      </view>
    </view>

    <view class="btn">
      <view class="btn_left" @click="onClickDialogClear">取消</view>
      <view class="btn_right" @click="onClickDialogSubmit">确认</view>
    </view>


  </view>

</template>
<script setup lang="ts">

import imgUrlFormat from "@/utils/imgUtils";
import {ISelectOption} from "@/pagesActive/ts/types";


const imgCheckTrue = imgUrlFormat('sugar/icon_circle_blue_selected.png')
const imgCheckFalse = imgUrlFormat('sugar/icon_circle_gray_normal.png')
interface Props {
  list: Array<any>;
  tips:string;
}

/**
 * 需要显示的list
 * 需要展示的 “其他” 内容
 */
const props = withDefaults(defineProps<Props>(), {
  list: () => [],
  tips:''
});


const emit = defineEmits(['onClickDialogSubmit', 'onClickDialogClear']);

/**
 * 提交
 */
const onClickDialogSubmit = () => {
  emit('onClickDialogSubmit', {bean: props.list.filter(item => item.check)[0]})
}

/**
 * 清除
 */
const onClickDialogClear = () => {
  emit('onClickDialogClear')
}



/**
 * 选中
 * @param item
 * @param index
 */
const onItemClick = (item:ISelectOption,index:number) => {
  props.list.map(mapItem => mapItem.check = false)
  item.check = !item.check
}


</script>

<style  lang="less">
.food_root{
  display: flex;

  flex-direction: column;
  .tips{
    background: #EBF6FF;
    margin: 22px;
    font-size: 29px;
    color: #64A4F5;
    padding: 18px 22px;
  }

  .item {
    display: flex;
    padding: 17px 22px;
    flex-direction: column;

    .option {
      display: flex;
      flex-direction: row;
      align-items: center;

      img {
        width: 30px;

        margin-right: 20px;
        height: 30px;
      }

      text {
        flex: 1;
      }

      .blue {
        color: #64A4F5;
      }

      .gray {
        color: #5F5F5F;
      }
    }

    .input {
      display: flex;
      padding-left: 50px;
      border-bottom: 1px solid #E5E5E5;
      padding-top: 30px;
      padding-bottom: 30px;
      color: #5F5F5F;
      flex-direction: row;
      justify-content: space-between;

      input {
        width: 150px;
      }
    }
  }

  .btn {
    display: flex;
    flex-direction: row;
    justify-content: space-around;
    background: white;
    padding: 50px 0px;
    align-items: center;

    .btn_left {
      border-radius: 17px;
      border: #64A4F5 solid 1px;
      width: 275px;
      height: 97px;
      color: #64A4F5;
      background: white;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .btn_right {
      border-radius: 17px;
      border: #64A4F5 solid 1px;
      width: 416px;
      height: 97px;
      color: white;
      background: #64A4F5;
      display: flex;
      justify-content: center;
      align-items: center;
    }
  }
}
</style>