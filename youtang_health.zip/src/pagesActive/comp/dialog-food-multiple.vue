<template>
  <view class="food_root">

    <view class="tips">{{ tips }}</view>
    <view class="list">
      <view :class=" item.check ? 'item_true' : 'item_false'  " v-for="(item,index) in list"
            :key="item.id" @click="onClickDialogItem(item,index)">{{index+1}}、{{ item.name }}
      </view>
    </view>

    <view v-if="showOther" class="input">其他：<input placeholder="请输入" v-model="content" /></view>


    <view class="btn">
      <view class="btn_left" @click="onClickDialogClear">取消</view>
      <view class="btn_right" @click="onClickDialogSubmit">确认</view>
    </view>

  </view>

</template>
<script setup lang="ts">

import {ISelectOption} from "@/pagesActive/ts/types";
import {ref, watch} from "vue";

const content = ref<string|null>();

interface Props {
  list: ISelectOption[];
  tips: string|null;
  other: string|null;
  showOther: boolean;
}

/**
 * 需要显示的list
 * 需要展示的 “其他” 内容
 */
const props = withDefaults(defineProps<Props>(), {
  list: () => [],
  tips: null,
  other: null,
  showOther: false,
});

content.value = props.other


const emit = defineEmits(['onClickDialogSubmit', 'onClickDialogClear']);

/**
 * 提交
 */
const onClickDialogSubmit = () => {
  emit('onClickDialogSubmit', {list: props.list.filter(item => item.check), input: content.value})
}

/**
 * 清除
 */
const onClickDialogClear = () => {
  emit('onClickDialogClear')
}


/**
 * 点击选中 取消选中
 * @param item
 * @param index
 */
const onClickDialogItem = (item: ISelectOption, index: number) => {
  item.check = !item.check
}


</script>

<style lang="less">
.food_root {
  display: flex;

  padding-left: 22px;
  padding-right: 22px;
  flex-direction: column;

  .tips {
    background: #EBF6FF;
    margin: 22px 0;
    font-size: 29px;
    color: #64A4F5;
    padding: 18px 22px;
  }

  .list {
    display: flex;
    flex-wrap: wrap;

    .item_true {
      padding: 10px 80px;
      border-radius: 40px;
      color: white;
      margin-left: 10px;
      margin-top: 30px;
      background: #6aa4fc;
      border: #6aa4fc solid 1px;
    }

    .item_false {
      border: #BBBBBB solid 1px;
      padding: 10px 80px;
      border-radius: 40px;
      color: #5F5F5F;
      margin-left: 10px;
      margin-top: 30px;
      background: white;
    }
  }

  .input {
    display: flex;
    flex-direction: row;
    margin-top: 30px;
    align-items: center;


  }

  .btn {
    display: flex;
    flex-direction: row;
    justify-content: space-around;
    background: white;
    padding: 50px 0px;
    align-items: center;

    .btn_left {
      border-radius: 17px;
      border: #64A4F5 solid 1px;
      width: 275px;
      height: 97px;
      color: #64A4F5;
      background: white;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .btn_right {
      border-radius: 17px;
      border: #64A4F5 solid 1px;
      width: 416px;
      height: 97px;
      color: white;
      background: #64A4F5;
      display: flex;
      justify-content: center;
      align-items: center;
    }
  }
}
</style>
