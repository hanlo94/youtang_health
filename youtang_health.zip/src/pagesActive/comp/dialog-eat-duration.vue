<template>

  <view class="duration_root">

    <view class="item">早餐（分钟）<input v-model="breakfast" placeholder="请输入" type="number" maxlength="3"/></view>
    <view class="item">午餐（分钟）<input v-model="lunch" placeholder="请输入" type="number" maxlength="3"/></view>
    <view class="item">晚餐（分钟）<input v-model="dinner" placeholder="请输入" type="number" maxlength="3"/></view>


    <view class="btn">
      <view class="btn_left" @click="onClickDialogClear">取消</view>
      <view class="btn_right" @click="onClickDialogSubmit">确认</view>
    </view>

  </view>
</template>
<script setup lang="ts">

import {ref} from "vue";
import {showToast} from "@/utils/toastUtils";

const breakfast = ref<number | null>();
const lunch = ref<number | null>();
const dinner = ref<number | null>();

type Props = {
  breakfast:number|null;
  lunch:number|null;
  dinner:number|null;
}
const props = withDefaults(defineProps<Props>(), {
  breakfast:null,
  lunch:null,
  dinner:null,
})

breakfast.value = props.breakfast === 0 ? null : props.breakfast;
lunch.value = props.lunch === 0 ? null : props.lunch;
dinner.value = props.dinner === 0 ? null : props.dinner;


const emit = defineEmits(['onClickDialogSubmit', 'onClickDialogClear']);

const onClickDialogSubmit = () => {

  if (breakfast.value === 0 || lunch.value === 0 || dinner.value === 0 || lunch.value === null || breakfast.value === null || dinner.value === null) {
    showToast("请填写完整信息")
    return;
  }

  emit('onClickDialogSubmit', {
    breakfast: breakfast.value,
    lunch: lunch.value,
    dinner: dinner.value,
  })
}

/**
 *清除
 */
const onClickDialogClear = () => {
  emit('onClickDialogClear')
}


</script>

<style lang="less">
.duration_root {

  padding: 20px;

  .item {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
    color: #5F5F5F;
    font-size: 33px;
    border-bottom: 1px solid #efefee;
    padding: 34px;

    input {
      width: 150px;
      text-align: right;
    }
  }

  .btn {
    display: flex;
    flex-direction: row;
    justify-content: space-around;
    background: white;
    padding: 50px 0px;
    align-items: center;

    .btn_left {
      border-radius: 17px;
      border: #64A4F5 solid 1px;
      width: 275px;
      height: 97px;
      color: #64A4F5;
      background: white;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .btn_right {
      border-radius: 17px;
      border: #64A4F5 solid 1px;
      width: 416px;
      height: 97px;
      color: white;
      background: #64A4F5;
      display: flex;
      justify-content: center;
      align-items: center;
    }
  }
}
</style>
