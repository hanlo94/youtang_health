<template>
  <view class="card_view">
    <view :class=" type === 1 ?'card_scroll' :'card_scroll_type0'  ">
      <view class="card_bg">
        <view class="view_item_name">
          <text>真实姓名</text>
          <view class="arrow">
            <input placeholder="请输入" v-model="baseInfo.patientName" maxlength="10"/>
            <RectRight></RectRight>
          </view>

        </view>
        <view class="view_item_gender">
          <text>性别</text>
          <view class="warp">
            <view :class=" item.value === baseInfo.gender ? 'check_true' :'check_false' "
                  v-for="(item ,index ) in genderList"
                  :key="item.value" @click="onChooseItem(item,'gender')">{{ item.label }}
            </view>
          </view>
        </view>
        <view class="view_item_column" v-if="baseInfo.gender === 2">
          <text>您是否处于备孕期、妊娠期或哺乳期？</text>
          <view class="column_sel">
            <view :class=" item.value === baseInfo.pregnancy ? 'check_true' :'check_false' "
                  v-for="(item ,index ) in yes1OrNo2List"
                  :key="item.value" @click="onChooseItem(item,'pregnancy')">{{ item.label }}
            </view>
          </view>
        </view>
        <view class="view_item_name">
          <text>民族</text>
          <view class="arrow">
            <input placeholder="请输入" v-model="baseInfo.ethnicity" maxlength="20"/>
            <RectRight></RectRight>
          </view>
        </view>
        <view class="view_item_name">
          <text>籍贯</text>
          <view class="arrow">
            <input placeholder="请输入" v-model="baseInfo.nativePlace"/>
            <RectRight></RectRight>
          </view>
        </view>
        <view class="view_item_birthday" @click="showBirthdayPop = true">
          <text>出生日期</text>
          <view class="arrow">
            <text>{{ baseInfo.birthDate || '请选择' }}</text>
            <RectRight></RectRight>
          </view>
        </view>
        <view class="view_item_gender">
          <text>出生日期类型</text>
          <view class="warp">
            <view :class=" item.value === baseInfo.sunCalendar ? 'check_true' :'check_false' "
                  v-for="(item ,index ) in birthdayTypeList"
                  :key="item.value" @click="onChooseItem(item,'sunCalendar')">{{ item.label }}
            </view>
          </view>
        </view>
        <view class="view_item_name">
          <text>身份证号</text>
          <view class="arrow">
            <input placeholder="请输入" v-model="baseInfo.idNumber" maxlength="18"/>
            <RectRight></RectRight>
          </view>
        </view>
        <view class="view_item_name">
          <text>本人联系方式1</text>
          <view class="arrow">
            <input placeholder="请输入" v-model="baseInfo.contactInfo1" maxlength="11"/>
            <RectRight></RectRight>
          </view>
        </view>
        <view class="view_item_name">
          <text>本人联系方式2</text>
          <view class="arrow">
            <input placeholder="请输入" v-model="baseInfo.contactInfo2" maxlength="11"/>
            <RectRight></RectRight>
          </view>
        </view>
        <view class="view_item_name">
          <text>家庭住址</text>
          <view class="arrow">
            <input placeholder="请输入" v-model="baseInfo.addressStreet" maxlength="20"/>
            <RectRight></RectRight>
          </view>
        </view>
        <view class="view_item_birthday" @click="showMarriedPop = true">
          <text>婚姻状况</text>
          <view class="arrow">
            <text>{{ baseInfo.maritalStatusStr || '请选择' }}</text>
            <RectRight></RectRight>
          </view>
        </view>
        <view class="view_item_birthday" @click="showDwellPop = true">
          <text>居住情况</text>
          <view class="arrow">
            <text>{{ baseInfo.livingSituationStr || '请选择' }}</text>
            <RectRight></RectRight>
          </view>
        </view>
        <view class="view_item_birthday" @click="showEduPop = true">
          <text>文化程度</text>
          <view class="arrow">
            <text>{{ baseInfo.educationLevelStr || '请选择' }}</text>
            <RectRight></RectRight>
          </view>
        </view>

        <view class="view_item_gender">
          <text>目前任职状态</text>
          <view class="warp">
            <view :class=" item.value === baseInfo.employmentStatus ? 'check_true' :'check_false' "
                  v-for="(item ,index ) in jobList"
                  :key="item.value" @click="onChooseItem(item,'employmentStatus')">{{ item.label }}
            </view>
          </view>
        </view>

        <view class="view_item_column">
          <text>（原）工作单位及工作岗位</text>
          <input placeholder="请输入" v-model="baseInfo.workUnitJobPosition" maxlength="20"/>
        </view>


        <view class="view_item_birthday" @click="showSalaryPop = true">
          <text>过去一年，您的月均可支配收入？</text>
          <view class="arrow">
            <text >{{ baseInfo.monthlyIncomeStr || '请选择' }}</text>
            <RectRight></RectRight>
          </view>
        </view>

      </view>
      <view style="padding: 10px">第一紧急联系人：</view>
      <view class="card_bg mt20">
        <view class="view_item_name">
          <text>紧急联系人姓名</text>
          <view class="arrow">
            <input placeholder="请输入" v-model="baseInfo.emergencyContact1" maxlength="10"/>
            <RectRight></RectRight>
          </view>
        </view>
        <view class="view_item_name">
          <text>与本人关系</text>
          <view class="arrow">
            <input placeholder="请输入" v-model="baseInfo.relation1" maxlength="20"/>
            <RectRight></RectRight>
          </view>
        </view>
        <view class="view_item_name">
          <text>联系电话</text>
          <view class="arrow">
            <input placeholder="请输入" v-model="baseInfo.emergencyPhone1" maxlength="11"/>
            <RectRight></RectRight>
          </view>
        </view>
      </view>
      <view style="padding: 10px">第二紧急联系人：</view>
      <view class="card_bg mt20">
        <view class="view_item_name">
          <text>紧急联系人姓名</text>
          <view class="arrow">
            <input placeholder="请输入" v-model="baseInfo.emergencyContact2" maxlength="10"/>
            <RectRight></RectRight>
          </view>
        </view>
        <view class="view_item_name">
          <text>与本人关系</text>
          <view class="arrow">
            <input placeholder="请输入" v-model="baseInfo.relation2" maxlength="20"/>
            <RectRight></RectRight>
          </view>
        </view>
        <view class="view_item_name">
          <text>联系电话</text>
          <view class="arrow">
            <input placeholder="请输入" v-model="baseInfo.emergencyPhone2" maxlength="11"/>
            <RectRight></RectRight>
          </view>
        </view>
      </view>
    </view>


    <view class="btn" v-if="type === 1">
      <view class="btn_left" @click="onClickSubmit(2)">存为草稿</view>
      <view class="btn_right" @click="onClickSubmit(3)">提交</view>
    </view>
  </view>


  <nut-action-sheet v-model:visible="showMarriedPop" :menu-items="marryOptions" @choose="chooseMarry" color="#6aa4fc"
                    :choose-tag-value="baseInfo.maritalStatusStr" cancel-txt="取消" title="请选择婚姻状况"/>

  <nut-action-sheet v-model:visible="showDwellPop" :menu-items="dwellOptions" @choose="chooseDwell" color="#6aa4fc"
                    :choose-tag-value="baseInfo.livingSituationStr" cancel-txt="取消" title="请选择居住情况"/>

  <nut-action-sheet v-model:visible="showEduPop" :menu-items="eduOptions" @choose="chooseEdu" color="#6aa4fc"
                    :choose-tag-value="baseInfo.educationLevelStr" cancel-txt="取消" title="请选择文化程度"/>

  <nut-action-sheet v-model:visible="showSalaryPop" :menu-items="salaryOptions" @choose="chooseSalary" color="#6aa4fc"
                    :choose-tag-value="baseInfo.monthlyIncomeStr" cancel-txt="取消" title="请选择收入"/>


  <nut-popup v-model:visible="showBirthdayPop" position="bottom" round>
    <nut-date-picker
        v-model="val"
        :min-date="min"
        :max-date="max"
        :three-dimensional="false"
        @confirm="onPopConfirm"
        @cancel="showBirthdayPop = false"
        :is-show-chinese="true"
    ></nut-date-picker>
  </nut-popup>
</template>


<script setup lang="ts">
import {ref} from "vue";
import {birthdayTypeList, genderList, ILabelItem, jobList} from "@/pagesMine/ts/dataUtils";
import {RectRight} from "@nutui/icons-vue-taro";
import {dwellOptions, eduOptions, marryOptions, salaryOptions, yes1OrNo2List} from "@/pagesActive/ts/dataOptions";
import activeApi from "@/api/modules/active";
import {IBasicInfo, ISelectOption} from "@/pagesActive/ts/types";
import {showToast} from "@/utils/toastUtils";
import Taro from "@tarojs/taro";
import {isEmpty} from "lodash";

const min = new Date(1920, 0, 1)
const max = new Date()
const val = ref(new Date())

const baseInfo = ref({} as IBasicInfo)

const showBirthdayPop = ref(false)
//婚姻状况
const showMarriedPop = ref(false)
//居住情况
const showDwellPop = ref(false)
//文化程度
const showEduPop = ref(false)
//工资收入
const showSalaryPop = ref(false)

const dataId = Number(Taro.getCurrentInstance().router?.params?.dataId)
//1未完成,2暂存,3已完成,4待更新
const status = Number(Taro.getCurrentInstance().router?.params?.status)

/**
 * 1点击加号进入。默认0。1展示按钮，0不展示。
 */
const type = Number(Taro.getCurrentInstance().router?.params?.type || 0)


definePageConfig({
  navigationBarTitleText: "基础信息",
})

const value = ref('1');

const onPopConfirm = ({selectedValue}) => {
  console.log(selectedValue)
  baseInfo.value.birthDate = selectedValue[0] + '-' + selectedValue[1] + '-' + selectedValue[2]
  showBirthdayPop.value = false
}
/**
 * 信息回显 请求详情
 */
const requestBasicInfo = () => {
  if (status === 1) return;
  activeApi.requestBasicInfo(dataId).then(res => {
    baseInfo.value = res.data || {} as IBasicInfo;
    baseInfo.value.maritalStatusStr = marryOptions.find(item => item.id === res.data.maritalStatus)?.name || ''
    baseInfo.value.livingSituationStr = dwellOptions.find(item => item.id === res.data.livingSituation)?.name || ''
    baseInfo.value.educationLevelStr = eduOptions.find(item => item.id === res.data.educationLevel)?.name || ''
    baseInfo.value.monthlyIncomeStr = salaryOptions.find(item => item.id === res.data.monthlyIncome)?.name || ''

  }, err => {
    showToast(err)
  })

}
requestBasicInfo()


const checkInfo = () => {
  if (isEmpty(baseInfo.value.patientName)) {
    showToast('请输入真实姓名');
    return false;
  }
  if (baseInfo.value.gender !== 1 && baseInfo.value.gender !== 2) {
    showToast('请选择性别');
    return false;
  }
  if (baseInfo.value.gender === 1 && (baseInfo.value.pregnancy !== 1 && baseInfo.value.pregnancy !== 0)) {
    showToast('请选择是否备孕、妊娠、哺乳');
    return false;
  }
  if (isEmpty(baseInfo.value.birthDate)) {
    showToast('请选择出生日期');
    return false;
  }
  if (baseInfo.value.sunCalendar !== 1 && baseInfo.value.sunCalendar !== 0) {
    showToast('请选择出生日期类型');
    return false;
  }
  if (isEmpty(baseInfo.value.nativePlace)) {
    showToast('请输入籍贯');
    return false;
  }
  if (isEmpty(baseInfo.value.ethnicity)) {
    showToast('请输入民族');
    return false;
  }
  if (isEmpty(baseInfo.value.idNumber)) {
    showToast('请输入身份证号');
    return false;
  }
  if (isEmpty(baseInfo.value.contactInfo1)) {
    showToast('请输入本人联系方式1');
    return false;
  }
  if (isEmpty(baseInfo.value.contactInfo2)) {
    showToast('请输入本人联系方式2');
    return false;
  }
  if (isEmpty(baseInfo.value.addressStreet)) {
    showToast('请输入家庭住址');
    return false;
  }
  if (isEmpty(baseInfo.value.maritalStatusStr)) {
    showToast('请选择婚姻状况');
    return false;
  }
  if (isEmpty(baseInfo.value.livingSituationStr)) {
    showToast('请选择居住情况');
    return false;
  }
  if (isEmpty(baseInfo.value.educationLevelStr)) {
    showToast('请选择文化程度');
    return false;
  }
  if (baseInfo.value.employmentStatus !== 1 && baseInfo.value.employmentStatus !== 2) {
    showToast('请选择任职状态');
    return false;
  }
  if (isEmpty(baseInfo.value.workUnitJobPosition)) {
    showToast('请输入原工作单位及工作岗位');
    return false;
  }
  return true;
}

/**
 * 提价数据 新增
 */
const onClickSubmit = (dataStatus: number) => {



  if (dataStatus === 2) {//未完成状态 调创建  其他为编辑
    activeApi.requestBasicInfoCreate({...baseInfo.value, dataStatus, profileId: dataId}).then(res => {
      showToast("保存草稿成功")
      Taro.navigateBack({delta: -1})
    }, err => {
      showToast(err)
    })
  } else {
    if (isEmpty(baseInfo.value.contactInfo1) && isEmpty(baseInfo.value.contactInfo2)) {
      showToast('请输入本人联系方式');
      return ;
    }
    if (!isEmpty(baseInfo.value.contactInfo1) && baseInfo.value.contactInfo1.length !== 11) {
      showToast('请输入正确的本人联系方式1');
      return ;
    }
    if (!isEmpty(baseInfo.value.contactInfo2) && baseInfo.value.contactInfo2.length !== 11) {
      showToast('请输入正确的本人联系方式2');
      return ;
    }
    activeApi.requestBasicInfoEdit({...baseInfo.value, dataStatus, profileId: dataId}).then(res => {
      showToast("保存成功")
      Taro.navigateBack({delta: -1})
    }, err => {
      showToast(err)
    })
  }

}


const chooseMarry = (item: ISelectOption, index: number) => {
  console.log(item)
  baseInfo.value.maritalStatusStr = item.name;
  baseInfo.value.maritalStatus = item.id;
}
const chooseDwell = (item: ISelectOption, index: number) => {
  baseInfo.value.livingSituationStr = item.name;
  baseInfo.value.livingSituation = item.id;
}
const chooseEdu = (item: ISelectOption, index: number) => {
  baseInfo.value.educationLevelStr = item.name
  baseInfo.value.educationLevel = item.id
}
const chooseSalary = (item: ISelectOption, index: number) => {
  baseInfo.value.monthlyIncomeStr = item.name
  baseInfo.value.monthlyIncome = item.id
}

/**
 * 继续作答
 */
const onClickAnswer = () => {

}

/**
 * 点击选择基础信息
 * @param item 数据项
 * @param field 字段名称
 */
const onChooseItem = (item: ILabelItem, field: string) => {
  baseInfo.value[field] = item.value;
  baseInfo.value[`${field}` + 'Value'] = item.label;
}
</script>

<style lang="less">
.card_view {
  height: 100vh;
  background: #efefef;
}

.mt20 {
  margin-top: 20px;
}

.card_scroll {
  overflow-y: auto;
  height: calc(100% - 150px);
}

.card_scroll_type0 {
  overflow-y: auto;
  height: 100%;
}


.card_bg {
  background: white;
  border-radius: 15px;
  padding: 0 15px;
  margin: 12px 18px;

  .view_item_name {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 30px 0;
    border-bottom: #efefef solid 1px;

    .arrow {
      display: flex;
      flex-direction: row;
      justify-content: center;
      align-items: center;

      text {
        color: #5F5F5F;
      }

      input {
        text-align: right;
        color: #5F5F5F;
      }
    }


  }

  .view_item_gender {
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: #efefef solid 1px;
    padding: 30px 0;

    .warp {
      display: flex;
      justify-content: center;
      align-items: center;
    }
  }

  .view_item_birthday {
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: #efefef solid 1px;
    padding: 30px 0;

    .arrow {
      display: flex;
      flex-direction: row;
      width: 300px;
      justify-content: flex-end;
      align-items: center;

      text {
        color: #5F5F5F;
        //white-space: nowrap;
        //overflow: hidden;
        //text-overflow: ellipsis;
      }

      input {
        text-align: right;
        margin-right: 22px;
        color: #5F5F5F;
        border-bottom: none;
      }

    }
  }

  .view_item_type {
    display: flex;
    padding: 30px 0;
    flex-direction: column;
    border-bottom: #efefef solid 1px;

    .warp {
      display: flex;
      margin-top: 20px;
      flex-wrap: wrap;
    }
  }

  .view_item_column {
    display: flex;
    flex-direction: column;
    padding: 30px 0;
    border-bottom: #efefef solid 1px;

    input {
      margin-top: 10px;
      color: #5F5F5F;
    }
  }
}

.check_true {
  width: 200px;
  height: 60px;
  border-radius: 30px;
  background: #6aa4fc;
  color: white;
  margin: 5px 5px;
  line-height: 60px;
  border: #6aa4fc solid 1px;
  text-align: center;
}

.check_false {
  width: 200px;
  height: 60px;
  border-radius: 30px;
  border: #6aa4fc solid 1px;
  background: white;
  color: #6aa4fc;
  margin: 5px 5px;
  line-height: 60px;
  text-align: center;
}

.column_sel {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  margin-top: 20px;
}

.btn {
  display: flex;
  flex-direction: row;
  justify-content: space-around;
  background: white;
  padding: 20px 0px;
  align-items: center;

  .btn_left {
    border-radius: 17px;
    border: #64A4F5 solid 1px;
    width: 275px;
    height: 97px;
    color: #64A4F5;
    background: white;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .btn_right {
    border-radius: 17px;
    border: #64A4F5 solid 1px;
    width: 416px;
    height: 97px;
    color: white;
    background: #64A4F5;
    display: flex;
    justify-content: center;
    align-items: center;
  }
}
</style>
