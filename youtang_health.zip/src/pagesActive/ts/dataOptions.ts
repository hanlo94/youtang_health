import {ISelectOption} from "@/pagesActive/ts/types";
/**
 *Description：各种各样的options
 *Created on 2024/5/2
 *Author :  郭
 */

/**
 * 婚姻状况：①未婚   ②已婚   ③同居   ④丧偶   ⑤离婚
 */
export const marryOptions = [
    {name: '未婚', id: 1,},
    {name: '已婚', id: 2,},
    {name: '同居', id: 3,},
    {name: '丧偶', id: 4,},
    {name: '离婚', id: 5,}
]

/**
 * 居住情况：①独居   ②夫妻同住   ③与儿女合住   ④养老院居住   ⑤其他
 */
export const dwellOptions = [
    {name: '独居', id: 1,},
    {name: '夫妻同住', id: 2,},
    {name: '与儿女合住', id: 3,},
    {name: '养老院居住', id: 4,},
    {name: '其他', id: 5,},
]
/**
 * 文化程度
 */
export const eduOptions = [
    {name: '未上学', id: 1,},
    {name: '小学', id: 2,},
    {name: '初中', id: 3,},
    {name: '高中、中专', id: 4,},
    {name: '大专、本科', id: 5,},
    {name: '研究生及以上', id: 6,},
]

/**
 * 工资程度
 * ①≤2000元  ②2001~4000元  ③4001~6000元  ④6001~8000元  ⑤8001~10000元  ⑥≥10000元
 */
export const salaryOptions = [
    {name: '≤2000元', id: 1,},
    {name: '2001~4000元', id: 2,},
    {name: '4001~6000元', id: 3,},
    {name: '6001~8000元', id: 4,},
    {name: '8001~10000元', id: 5,},
    {name: '≥10000元', id: 6,},
]

/**
 * 经口服用、静脉注射、肌肉注射、外用
 */
export const toolWayOptions:ISelectOption[] = [
    {name: '口服', id: 1, check: false},
    {name: '外用', id: 2, check: false},
    {name: '其他', id: 3, check: false},
]

/**
 * 经口服用、静脉注射、肌肉注射、外用
 */
export const medicineWayOptions:ISelectOption[] = [
    {name: '经口服用', id: 1, check: false},
    {name: '静脉注射', id: 2, check: false},
    {name: '肌肉注射', id: 3, check: false},
    {name: '外用', id: 3, check: false},
]


/**
 *单次剂量
 * 粒、片、克、毫克、mg/dL、ml、IU
 */
export const medicineDoseOptions:ISelectOption[] = [
    {name: '粒', id: 1, check: false},
    {name: '片', id: 2, check: false},
    {name: '克', id: 3, check: false},
    {name: '毫克', id: 4, check: false},
    {name: 'mg/dL', id: 5, check: false},
    {name: 'ml', id: 6, check: false},
    {name: 'IU', id: 7, check: false},
    {name: '袋', id: 8, check: false},
]

export const yes1OrNo2List = [
    {
        label:"是",
        value:1
    },
    {
        label:"否",
        value:2
    }
]

