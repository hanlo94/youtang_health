/**
 *Description：
 *Created on 2024/5/2
 *Author :  郭
 */
import {ref} from "vue";
import { ISelectOption } from "./types";




/**
 * 循环系统疾病
 */
export const circulationIllnessList = ref<ISelectOption[]>([
    {name: '高血压', id: 1, check: false},
    {name: '脑卒中（脑梗/腔梗/出血性）', id: 2, check: false},
    {name: '心肌缺血', id: 3, check: false},
    {name: '冠心病', id: 4, check: false},
    {name: '动脉粥样硬化', id: 5, check: false},
    {name: '肺心病', id: 6, check: false},
    {name: '人工心脏起搏', id: 7, check: false},
    {name: '静脉曲张', id: 8, check: false},
])
/**
 * 循环系统症状
 * □头痛　　　　□头晕　　　　□心慌　　　　□胸闷
 * □活动气促　  □下肢水肿　　□心前区疼痛　□心律不齐
 * □早搏　　　　□房颤　　　　□心悸　　　　□四肢冰凉
 */
export const circulationSymptomList = ref<ISelectOption[]>([
    {name: '头痛', id: 1, check: false},
    {name: '头晕', id: 2, check: false},
    {name: '心慌', id: 3, check: false},
    {name: '胸闷', id: 4, check: false},
    {name: '活动气促', id: 5, check: false},
    {name: '下肢水肿', id: 6, check: false},
    {name: '心前区疼痛', id: 7, check: false},
    {name: '心律不齐', id: 8, check: false},
    {name: '早搏', id: 9, check: false},
    {name: '房颤', id: 10, check: false},
    {name: '心悸', id: 11, check: false},
    {name: '四肢冰凉', id: 12, check: false},
])

/**
 * 呼吸系统疾病
 * □老慢支   □肺气肿   □肺癌   □呼吸暂停综合症   □咽炎
 * □肺结核   □慢阻肺   □哮喘   □支气管扩张       □肺纤维化
 */
export const breatheIllnessList = ref<ISelectOption[]>([
    {name: '老慢支', id: 1, check: false},
    {name: '肺气肿', id: 2, check: false},
    {name: '肺癌', id: 3, check: false},
    {name: '呼吸暂停综合症', id: 4, check: false},
    {name: '咽炎', id: 5, check: false},
    {name: '肺结核', id: 6, check: false},
    {name: '慢阻肺', id: 7, check: false},
    {name: '哮喘', id: 8, check: false},
    {name: '支气管扩张', id: 9, check: false},
    {name: '肺纤维化', id: 10, check: false},
])

/**
 * 呼吸系统症状
 * □咳嗽  □咳痰  □咯血  □呼吸困难  □气喘  □气短  □嘴唇紫绀
 */
export const breatheSymptomList = ref<ISelectOption[]>([
    {name: '咳嗽', id: 1, check: false},
    {name: '咳痰', id: 2, check: false},
    {name: '咯血', id: 3, check: false},
    {name: '呼吸困难', id: 4, check: false},
    {name: '气喘', id: 5, check: false},
    {name: '气短', id: 6, check: false},
    {name: '嘴唇紫绀', id: 7, check: false},
])


/**
 * 免疫系统疾病
 * □类风湿性关节炎   □风心病    □凝血功能下降  □白细胞减少症
 * □系统性红斑狼疮   □带状疱疹  □湿疹          □过敏性哮喘
 */
export const immuneIllnessList = ref<ISelectOption[]>([
    {name: '类风湿性关节炎', id: 1, check: false},
    {name: '风心病', id: 2, check: false},
    {name: '凝血功能下降', id: 3, check: false},
    {name: '白细胞减少症', id: 4, check: false},
    {name: '系统性红斑狼疮', id: 5, check: false},
    {name: '带状疱疹', id: 6, check: false},
    {name: '湿疹', id: 7, check: false},
    {name: '过敏性哮喘', id: 8, check: false},
])

/**
 * 免疫系统症状
 * □易感冒   □畏寒怕冷   □淋巴结肿大   □精神状态差   □皮肤瘙痒
 */
export const immuneSymptomList = ref<ISelectOption[]>([
    {name: '易感冒', id: 1, check: false},
    {name: '畏寒怕冷', id: 2, check: false},
    {name: '淋巴结肿大', id: 3, check: false},
    {name: '精神状态差', id: 4, check: false},
    {name: '皮肤瘙痒', id: 5, check: false},
])


/**
 * 神经系统疾病
 * □神经性头痛     □帕金森氏综合症    □神经性皮炎    □脑萎缩
 * □阿尔茨海默综合症   □神经衰弱      □美尼尔氏综合症
 */
export const nerveIllnessList = ref<ISelectOption[]>([
    {name: '神经性头痛', id: 1, check: false},
    {name: '帕金森氏综合症', id: 2, check: false},
    {name: '神经性皮炎', id: 3, check: false},
    {name: '脑萎缩', id: 4, check: false},
    {name: '阿尔茨海默综合症', id: 5, check: false},
    {name: '神经衰弱', id: 6, check: false},
    {name: '美尼尔氏综合症', id: 7, check: false},
])

/**
 * 神经系统症状
 * □记忆力减退     □反应迟缓     □全身无力    □肢体震颤
 * □感官功能障碍   □平衡功能障碍
 */
export const nerveSymptomList = ref<ISelectOption[]>([
    {name: '记忆力减退', id: 1, check: false},
    {name: '反应迟缓', id: 2, check: false},
    {name: '全身无力', id: 3, check: false},
    {name: '肢体震颤', id: 4, check: false},
    {name: '感官功能障碍', id: 5, check: false},
    {name: '平衡功能障碍', id: 6, check: false},
])


/**
 * 运动系统疾病
 * □既往骨折史   □骨质疏松   □坐骨神经痛   □关节炎   □肩周炎
 * □关节腔积液   □骨质增生   □股骨头坏死   □腰椎病   □颈椎病
 */
export const sportIllnessList = ref<ISelectOption[]>([
    {name: '既往骨折史', id: 1, check: false},
    {name: '骨质疏松', id: 2, check: false},
    {name: '坐骨神经痛', id: 3, check: false},
    {name: '关节炎', id: 4, check: false},
    {name: '肩周炎', id: 5, check: false},
    {name: '关节腔积液', id: 6, check: false},
    {name: '骨质增生', id: 7, check: false},
    {name: '股骨头坏死', id: 8, check: false},
    {name: '腰椎病', id: 9, check: false},
    {name: '颈椎病', id: 10, check: false},
])

/**
 * 运动系统症状
 * □关节疼痛     □关节红肿     □关节变形     □肌肉痛     □骨刺
 * □肌肉萎缩     □颈椎疼痛     □脊柱变形
 */
export const sportSymptomList = ref<ISelectOption[]>([
    {name: '关节疼痛', id: 1, check: false},
    {name: '关节红肿', id: 2, check: false},
    {name: '关节变形', id: 3, check: false},
    {name: '肌肉痛', id: 4, check: false},
    {name: '骨刺', id: 5, check: false},
    {name: '肌肉萎缩', id: 6, check: false},
    {name: '颈椎疼痛', id: 7, check: false},
    {name: '脊柱变形', id: 8, check: false},
])


/**
 * 消化系统疾病
 * □慢性肝炎   □脂肪肝  □肝囊肿  □药物性肝病    □肝癌  □胆结石
 * □慢性胃炎   □胃溃疡  □胃癌    □肠易激综合征  □肠癌  □胰腺炎
 */
export const digestionIllnessList = ref<ISelectOption[]>([
    {name: '慢性肝炎', id: 1, check: false},
    {name: '脂肪肝', id: 2, check: false},
    {name: '肝囊肿', id: 3, check: false},
    {name: '药物性肝病', id: 4, check: false},
    {name: '肝癌', id: 5, check: false},
    {name: '胆结石', id: 6, check: false},
    {name: '慢性胃炎', id: 7, check: false},
    {name: '胃溃疡', id: 8, check: false},
    {name: '胃癌', id: 9, check: false},
    {name: '肠易激综合征病', id: 10, check: false},
    {name: '肠癌', id: 11, check: false},
    {name: '胰腺炎', id: 12, check: false},
])

/**
 * 消化系统症状
 * □食欲减退      □反酸      □恶心      □呕吐      □腹胀
 * □吸收障碍      □腹痛      □腹泻      □便血      □便秘
 */
export const digestionSymptomList = ref<ISelectOption[]>([
    {name: '食欲减退', id: 1, check: false},
    {name: '反酸', id: 2, check: false},
    {name: '恶心', id: 3, check: false},
    {name: '呕吐', id: 4, check: false},
    {name: '腹胀', id: 5, check: false},
    {name: '吸收障碍', id: 6, check: false},
    {name: '腹痛', id: 7, check: false},
    {name: '腹泻', id: 8, check: false},
    {name: '便血', id: 9, check: false},
    {name: '便秘', id: 10, check: false},
])


/**
 * 内分泌系统疾病
 * □糖尿病（Ⅰ型/Ⅱ型）   □血脂异常   □痛风/高尿酸血症   □贫血
 * □甲状腺结节   □甲状腺肿瘤   □甲亢   □甲减
 */
export const endocrineIllnessList = ref<ISelectOption[]>([
    {name: '糖尿病（Ⅰ型/Ⅱ型）', id: 1, check: false},
    {name: '血脂异常', id: 2, check: false},
    {name: '痛风/高尿酸血症', id: 3, check: false},
    {name: '贫血', id: 4, check: false},
    {name: '甲状腺结节', id: 5, check: false},
    {name: '甲状腺肿瘤', id: 6, check: false},
    {name: '甲亢', id: 7, check: false},
    {name: '甲减', id: 8, check: false},
])

/**
 * 内分泌系统症状
 * □体重增加   □体重减轻   □饥饿感   □面色苍白   □面色潮红
 */
export const endocrineSymptomList = ref<ISelectOption[]>([
    {name: '体重增加', id: 1, check: false},
    {name: '体重减轻', id: 2, check: false},
    {name: '饥饿感', id: 3, check: false},
    {name: '面色苍白', id: 4, check: false},
    {name: '面色潮红', id: 5, check: false},
])

/**
 * 泌尿系统疾病
 * □肾炎   □肾结石   □肾囊肿   □泌尿生殖感染   □输尿管结石
 * □其他：                、                、
 * 男：□前列腺疾病史（前列腺炎/前列腺肥大）      □前列腺癌
 * 女：□良性乳腺疾病史   □乳腺癌   □子宫肌瘤   □卵巢囊肿
 */
export const urinaryIllnessManList = ref<ISelectOption[]>([
    {name: '肾炎', id: 1, check: false},
    {name: '肾结石', id: 2, check: false},
    {name: '肾囊肿', id: 3, check: false},
    {name: '泌尿生殖感染', id: 4, check: false},
    {name: '输尿管结石', id: 5, check: false},
    {name: '前列腺疾病史（前列腺炎/前列腺肥大）', id: 6, check: false},
    {name: '前列腺癌', id: 7, check: false},
])
/**
 * 泌尿系统疾病
 * □肾炎   □肾结石   □肾囊肿   □泌尿生殖感染   □输尿管结石
 * □其他：                、                、
 * 男：□前列腺疾病史（前列腺炎/前列腺肥大）      □前列腺癌
 * 女：□良性乳腺疾病史   □乳腺癌   □子宫肌瘤   □卵巢囊肿
 */
export const urinaryIllnessWomanList = ref<ISelectOption[]>([
    {name: '肾炎', id: 1, check: false},
    {name: '肾结石', id: 2, check: false},
    {name: '肾囊肿', id: 3, check: false},
    {name: '泌尿生殖感染', id: 4, check: false},
    {name: '输尿管结石', id: 5, check: false},
    {name: '良性乳腺疾病史', id: 6, check: false},
    {name: '乳腺癌', id: 7, check: false},
    {name: '子宫肌瘤', id: 8, check: false},
    {name: '卵巢囊肿', id: 9, check: false},
])

/**
 * 泌尿系统症状
 * □尿频     □尿急     □尿痛     □夜尿频多
 */
export const urinarySymptomList = ref<ISelectOption[]>([
    {name: '尿频', id: 1, check: false},
    {name: '尿急', id: 2, check: false},
    {name: '尿痛', id: 3, check: false},
    {name: '夜尿频多', id: 4, check: false},
])


/**
 * 感官系统疾病
 * □耳聋/耳鸣   □视网膜脱落   □白内障   □青光眼   □黄斑变性
 */
export const senseIllnessList = ref<ISelectOption[]>([
    {name: '耳聋/耳鸣', id: 1, check: false},
    {name: '视网膜脱落', id: 2, check: false},
    {name: '白内障', id: 3, check: false},
    {name: '青光眼', id: 4, check: false},
    {name: '黄斑变性', id: 5, check: false},
])

/**
 * 感官系统症状
 * □听力下降   □视力下降   □味觉退化   □嗅觉退化   □感觉迟缓
 */
export const senseSymptomList = ref<ISelectOption[]>([
    {name: '听力下降', id: 1, check: false},
    {name: '视力下降', id: 2, check: false},
    {name: '味觉退化', id: 3, check: false},
    {name: '嗅觉退化', id: 4, check: false},
    {name: '感觉迟缓', id: 5, check: false},
])


/**
 * 过敏
 *
 * □青霉素   □头孢菌素类   □喹诺酮类药物   □磺胺类药物  □替硝唑  □甲硝唑
 * □链霉素   □异种血清     □化妆品   □染发剂   □花粉   □柳絮    □化纤用品
 * □牛奶     □乳糖不耐受   □鸡蛋     □麸质     □螃蟹   □虾
 */
export const allergyList = ref<ISelectOption[]>([
    {name: '青霉素', id: 1, check: false},
    {name: '头孢菌素类', id: 2, check: false},
    {name: '喹诺酮类药物', id: 3, check: false},
    {name: '磺胺类药物', id: 4, check: false},
    {name: '替硝唑', id: 5, check: false},
    {name: '甲硝唑', id: 6, check: false},
    {name: '链霉素', id: 7, check: false},
    {name: '异种血清', id: 8, check: false},
    {name: '化妆品', id: 9, check: false},
    {name: '染发剂', id: 10, check: false},
    {name: '花粉', id: 11, check: false},
    {name: '柳絮', id: 12, check: false},
    {name: '化纤用品', id: 13, check: false},
    {name: '牛奶', id: 14, check: false},
    {name: '乳糖不耐受', id: 15, check: false},
    {name: '鸡蛋', id: 16, check: false},
    {name: '麸质', id: 17, check: false},
    {name: '螃蟹', id: 18, check: false},
    {name: '虾', id: 19, check: false},
])


/**
 * 家族病史
 * □糖尿病   □高血压   □脑卒中   □冠心病/心肌梗死   □痛风/高尿酸血症   □血脂异常
 */
export const familyMedicalHistoryList = ref<ISelectOption[]>([
    {name: '糖尿病', id: 1, check: false},
    {name: '高血压', id: 2, check: false},
    {name: '脑卒中', id: 3, check: false},
    {name: '冠心病/心肌梗死', id: 4, check: false},
    {name: '痛风/高尿酸血症', id: 5, check: false},
    {name: '血脂异常', id: 6, check: false},
])