import {ref} from "vue";
import {ISelectOption} from "@/pagesActive/ts/types";


/**
 * 早餐选项
 * ①基本不吃（如选择此项，请跳至问题3作答）   ②在外就餐（包括点外卖）   ③自己烹饪
 */
export const breakfastOptions = ref<ISelectOption[]>([
    {name: '基本不吃', id: 1, check: false},
    {name: '在外就餐（包括点外卖）', id: 2, check: false},
    {name: '自己烹饪', id: 3, check: false},
])

/**
 * 早餐选项
 * ①谷薯类  ②蔬菜、水果类  ③动物性食物（禽畜肉、水产、蛋类） ④奶及奶制品类
 * ⑤大豆类  ⑥坚果类
 */
export const breakfastCategoryOptions = ref<ISelectOption[]>([
    {name: '谷薯类', id: 1, check: false},
    {name: '蔬菜、水果类', id: 2, check: false},
    {name: '动物性食物（禽畜肉、水产、蛋类）', id: 3, check: false},
    {name: '奶及奶制品类', id: 4, check: false},
    {name: '大豆类', id: 5, check: false},
    {name: '坚果类', id: 6, check: false},
])
/**
 * 午餐选项
 * ①谷薯类  ②蔬菜、水果类  ③动物性食物（禽畜肉、水产、蛋类） ④奶及奶制品类
 * ⑤大豆类  ⑥坚果类
 */
export const lunchCategoryOptions = ref<ISelectOption[]>([
    {name: '谷薯类', id: 1, check: false},
    {name: '蔬菜、水果类', id: 2, check: false},
    {name: '动物性食物（禽畜肉、水产、蛋类）', id: 3, check: false},
    {name: '奶及奶制品类', id: 4, check: false},
    {name: '大豆类', id: 5, check: false},
    {name: '坚果类', id: 6, check: false},
])

/**
 * 晚餐选项
 * ①谷薯类  ②蔬菜、水果类  ③动物性食物（禽畜肉、水产、蛋类） ④奶及奶制品类
 * ⑤大豆类  ⑥坚果类
 */
export const dinnerCategoryOptions = ref<ISelectOption[]>([
    {name: '谷薯类', id: 1, check: false},
    {name: '蔬菜、水果类', id: 2, check: false},
    {name: '动物性食物（禽畜肉、水产、蛋类）', id: 3, check: false},
    {name: '奶及奶制品类', id: 4, check: false},
    {name: '大豆类', id: 5, check: false},
    {name: '坚果类', id: 6, check: false},
])

/**
 * 加餐选项
 * ①谷薯类  ②蔬菜、水果类  ③动物性食物（禽畜肉、水产、蛋类） ④奶及奶制品类
 * ⑤大豆类  ⑥坚果类
 */
export const addCategoryOptions = ref<ISelectOption[]>([
    {name: '谷薯类', id: 1, check: false},
    {name: '蔬菜、水果类', id: 2, check: false},
    {name: '动物性食物（禽畜肉、水产、蛋类）', id: 3, check: false},
    {name: '奶及奶制品类', id: 4, check: false},
    {name: '大豆类', id: 5, check: false},
    {name: '坚果类', id: 6, check: false},
])

/**
 * 早餐选项
 * ①否（指平均频率＜1次/周，如选择此项，请跳至第7题作答）
 * ②是，通常于     点     分晚餐后加餐，平均一周晚餐后加餐     次。
 */
export const extraMealOptions = ref<ISelectOption[]>([
    {name: '否（指平均频率＜1次/周）', id: 1, check: false},
    {name: '是', id: 2, check: false},
])

/**
 * 是否按时列表
 * ①按时（7天/周） ②基本按时（4~6天/周） ③有时按时（1~3天/周） ④很难按时（＜1天/周）
 */
export const eatOnTimeOptions = ref<ISelectOption[]>([
    {name: '按时（7天/周）', id: 1, check: false},
    {name: '基本按时（4~6天/周）', id: 2, check: false},
    {name: '有时按时（1~3天/周）', id: 3, check: false},
    {name: '很难按时（＜1天/周）', id: 4, check: false},
])
/**
 * 经常食用如下食品
 * ①油炸食品   ②熏烧烤食品   ③腌腊食品   ④酱卤食品   ⑤火腿肠   ⑥方便米面制品
 * ⑦饼干   ⑧膨化食品   ⑨果脯/蜜饯    ⑩辣条   ⑪含糖或碳酸饮料
 */
export const eatTypesOptions = ref<ISelectOption[]>([
    {name: '油炸食品', id: 1, check: false},
    {name: '熏烧烤食品', id: 2, check: false},
    {name: '腌腊食品', id: 3, check: false},
    {name: '酱卤食品', id: 4, check: false},
    {name: '火腿肠', id: 5, check: false},
    {name: '方便米面制品', id: 6, check: false},
    {name: '饼干', id: 7, check: false},
    {name: '膨化食品', id: 8, check: false},
    {name: '果脯/蜜饯', id: 9, check: false},
    {name: '辣条', id: 10, check: false},
    {name: '含糖或碳酸饮料', id: 11, check: false},
])

/**
 * 经常烹饪如下食品
 * ①煎炸  ②烧煮  ③炖煨  ④爆炒  ⑤熏烧烤  ⑥蒸汆  ⑦腌腊  ⑧酱卤
 */
export const cookingTypesOptions = ref<ISelectOption[]>([
    {name: '煎炸', id: 1, check: false},
    {name: '烧煮', id: 2, check: false},
    {name: '炖煨', id: 3, check: false},
    {name: '爆炒', id: 4, check: false},
    {name: '熏烧烤', id: 5, check: false},
    {name: '蒸汆', id: 6, check: false},
    {name: '腌腊', id: 7, check: false},
    {name: '酱卤', id: 8, check: false},
])



/**
 * 一周在外就餐次数
 * ①少于1次   ②1~6次  ③7~13次  ④14~21次  ⑤＞21次
 */
export const outEatCountsOptions = ref<ISelectOption[]>([
    {name: '少于1次', id: 1, check: false},
    {name: '1~6次', id: 2, check: false},
    {name: '7~13次', id: 3, check: false},
    {name: '14~21次', id: 4, check: false},
    {name: '＞21次', id: 5, check: false},
])