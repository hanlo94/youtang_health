import {IDiseaseListItem, ISelectOption} from "@/pagesActive/ts/types";
import {
    breatheIllnessList,
    breatheSymptomList,
    circulationIllnessList,
    circulationSymptomList,
    digestionIllnessList,
    digestionSymptomList,
    endocrineIllnessList,
    endocrineSymptomList,
    immuneIllnessList,
    immuneSymptomList,
    nerveIllnessList,
    nerveSymptomList,
    senseIllnessList, senseSymptomList,
    sportIllnessList,
    sportSymptomList,
    urinaryIllnessManList, urinaryIllnessWomanList, urinarySymptomList
} from "@/pagesActive/ts/diseaseList";
import {isEmpty} from "lodash";


/**
 * Description：疾病相关所有数据集合
 * Created on 2024/5/12
 * Author :  郭
 */

//1循环系统,2呼吸系统,3免疫系统,4神经系统,5运动系统,6消化系统,7内分泌系统,8泌生殖系统,9感官系线
export const getSystemName = (item: IDiseaseListItem) => {
    if (item.systemType === 1) return '循环系统'
    if (item.systemType === 2) return '呼吸系统'
    if (item.systemType === 3) return '免疫系统'
    if (item.systemType === 4) return '神经系统'
    if (item.systemType === 5) return '运动系统'
    if (item.systemType === 6) return '消化系统'
    if (item.systemType === 7) return '内分泌系统'
    if (item.systemType === 8) return '泌生殖系统'
    if (item.systemType === 9) return '感官系统'
}
/**
 * 不同的item配置不同的选项 疾病
 * 1循环系统,2呼吸系统,3免疫系统,4神经系统,5运动系统,6消化系统,7内分泌系统,8泌生殖系统,9感官系线
 */
export const formatDiseaseIllnessOptions = (systemType: number, gender: number) => {
    if (systemType === 1) return circulationIllnessList;
    if (systemType === 2) return breatheIllnessList;
    if (systemType === 3) return immuneIllnessList;
    if (systemType === 4) return nerveIllnessList;
    if (systemType === 5) return sportIllnessList;
    if (systemType === 6) return digestionIllnessList;
    if (systemType === 7) return endocrineIllnessList;
    if (systemType === 8) return gender === 2 ? urinaryIllnessWomanList : urinaryIllnessManList;
    if (systemType === 9) return senseIllnessList;
}
/**
 * 不同的item配置不同的选项 症状
 * 1循环系统,2呼吸系统,3免疫系统,4神经系统,5运动系统,6消化系统,7内分泌系统,8泌生殖系统,9感官系线
 */
export const formatDiseaseSymptomOptions = (systemType: number) => {
    if (systemType === 1) return circulationSymptomList;
    if (systemType === 2) return breatheSymptomList;
    if (systemType === 3) return immuneSymptomList;
    if (systemType === 4) return nerveSymptomList;
    if (systemType === 5) return sportSymptomList;
    if (systemType === 6) return digestionSymptomList;
    if (systemType === 7) return endocrineSymptomList;
    if (systemType === 8) return urinarySymptomList;
    if (systemType === 9) return senseSymptomList;
}

/**
 * 处理多选
 */
export const formatMultipleOptions = (str: string, options: ISelectOption[]) => {
    return str?.split(',').map(mapItem => options.find(item => item.id === Number(mapItem))?.name).join(',')
}


/**
 *   拼接其他
 */
export const formatOptionsAndWay = (str1: string, str2: ISelectOption[], str3: string) => {
    let data = formatMultipleOptions(str1, str2)
    if (!isEmpty(data) && !isEmpty(str3)) {
        return data + ',' + str3;
    } else if (isEmpty(data)) {
        return str3
    } else if (isEmpty(str3)) {
        return data;
    } else {
        return ''
    }
}
/**
 * 拼接时间 00：00：00
 * @param data
 */
export const formatShouShuDate = (data: string) => {
    if (isEmpty(data)) return data
    if (data.includes(" 00:00:00")) {
        return data.substring(0, 10)
    } else {
        return data
    }
}
/**
 * 如果包含描述 那么不显示
 * @param str
 */
export const filterOptionsDesc = (str: string) => {
    if (isEmpty(str)) return str

    // let start = str.indexOf("（")
    // let end = str.indexOf("）")
    //
    // let startStr = str.substring(0, start);
    // let endStr = str.substring(end, str.length)
    //
    // return startStr + endStr;

    // if (str.includes("（")) {
    //     return str.split('（')[0]
    // } else {
    //     return str
    // }
    console.log('utils.filterOptionsDesc.str=', str)
    str = str.replace(/\([^()]*\)/g, "");
    console.log('utils.filterOptionsDesc.after ', str)
    str = str.replace(/\（[^（）]*\）/g, "");
    console.log('utils.filterOptionsDesc.finally ', str)
    return str.replace(/\（([^（）]+)\）/g, '');
}
