/**
 *Description：
 *Created on 2024/5/3
 *Author :  郭
 */
import {ref} from "vue";
import {ISelectOption} from "@/pagesActive/ts/types";


/**
 * 主动吸烟
 */
export const activeSmokeOptions = ref<ISelectOption[]>([
    {name: '从不吸烟', id: 1, check: false},
    {name: '现在吸烟（指最近三个月平均每天吸烟≥1支）', id: 2, check: false},
    {name: '已经戒烟（指最近三个月不吸烟，但以前曾平均每天吸烟≥1支）', id: 3, check: false},
])

/**
 * 被动吸烟
 */
export const activePassiveOptions = ref<ISelectOption[]>([
    {name: '基本没有（指每天被动吸烟时长＜15分钟）', id: 1, check: false},
    {name: '是的', id: 2, check: false},
    {name: '既往是，但现在基本没有（指近三个月没有被动吸烟，但以前曾平均每天被动吸烟≥15分钟）', id: 3, check: false},
])


/**
 * 是否和酒
 */
export const drinkWineOptions = ref<ISelectOption[]>([
    {name: '从不喝酒', id: 1, check: false},
    {name: '现在饮酒（指最近三个月平均每周饮酒≥1次，且每次饮酒≥100 mL）', id: 2, check: false},
    {name: '已经戒酒（指最近三个月不喝酒，但以前曾平均每周饮酒≥1次）', id: 3, check: false},
])

/**
 * 酒类型
 * ①白酒   ②红酒   ③啤酒   ④米酒
 */
export const typeWineOptions = ref<ISelectOption[]>([
    {name: '白酒', id: 1, check: false},
    {name: '红酒', id: 2, check: false},
    {name: '啤酒', id: 3, check: false},
    {name: '米酒', id: 4, check: false},
])

/**
 * 是否运动
 */
export const sportOptions = ref<ISelectOption[]>([
    {name: '否', id: 1, check: false},
    {name: '是（指平均每周进行3次以上、每次30分钟以上的运动或平均每周进行总时长75分钟以上的运动）', id: 2, check: false},
])

/**
 * 锻炼时间
 */
export const sportTimeOptions =ref<ISelectOption[]>([
    {name: '早上（早餐前）', id: 1, check: false},
    {name: '上午（早中餐之间）', id: 2, check: false},
    {name: '下午（中晚餐之间）', id: 3, check: false},
    {name: '晚上（晚餐后）', id: 4, check: false},
])
