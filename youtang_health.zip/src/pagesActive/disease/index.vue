<!--
Description：
Created on 2024/3/28
Author :  郭 -->
<template>
  <view class="card_view">
    <view :class=" type === 1 ?'card_scroll' :'card_scroll_type0'  ">
      <view class="question">1.您是否患有下列疾病或者症状？（多选。若无，可以不用填写）</view>
      <view class="card_bg" v-for="(item,index) in dataList" :key="index">
        <view class="tag">{{ getSystemName(item) }}</view>
        <view class="view_item_birthday" @click="item.showDiseasePop = true">
          <text>疾病</text>
          <view class="arrow">
            <text> {{ formatOptionsAndWay(item.diseases, item.diseaseOptions, item.diseaseOther) || '请选择' }}</text>
            <RectRight></RectRight>
          </view>
        </view>
        <view class="view_item_birthday" @click="item.showSymptomPop = true">
          <text>症状</text>
          <view class="arrow">
            <text> {{ formatOptionsAndWay(item.symptoms, item.symptomOptions, item.symptomsOther) || '请选择' }}</text>
            <RectRight></RectRight>
          </view>
        </view>


        <nut-action-sheet v-model:visible="item.showDiseasePop" title="选择疾病（可多选）">
          <dialog-multiple-comp
              :input-value="item.diseaseOther" :list="item.diseaseOptions" :show-other="true"
              @on-click-dialog-submit="(e)=>onClickDiseaseSubmit(e,item)"
              @on-click-dialog-clear="item.showDiseasePop = false">
          </dialog-multiple-comp>
        </nut-action-sheet>
        <nut-action-sheet v-model:visible="item.showSymptomPop" title="选择症状（可多选）">
          <dialog-multiple-comp
              :input-value="item.symptomsOther" :list="item.symptomOptions"
              :show-other="true"
              @on-click-dialog-submit="(e)=>onClickSymptomSubmit(e,item)"
              @on-click-dialog-clear="item.showSymptomPop = false">
          </dialog-multiple-comp>
        </nut-action-sheet>

      </view>

      <view class="question">2.过敏史（多选。若无，可以不用填写）</view>
      <view class="card_bg">
        <view class="view_item_birthday" @click="showAllergyPop = true">
          <text>过敏史</text>
          <view class="arrow">
            <text> {{ formatOptionsAndWay(result.allergen, allergyList, result.allergenOther) || '请选择' }}</text>
            <RectRight></RectRight>
          </view>
        </view>
      </view>
      <view class="question">3.既往手术史（若无，可以不用填写）</view>
      <view class="card_list">
        <view class="list_item" v-for="(item,index) in shoushuList" :key="index">
          <view class="title">
            <view>({{ index + 1 }})既往手术史</view>
            <view class="delete" v-if=" type==1 " @click="onDeleteShouShu(index)">删除</view>
          </view>
          <view class="card_bg">
            <view class="view_item_name">
              <text>手术名称</text>
              <view class="arrow">
                <input placeholder="请输入" v-model="item.surgeryName " maxlength="20"/>
                <RectRight></RectRight>
              </view>
            </view>
            <view class="view_item_birthday" @click="item.showPop = true">
              <text>手术时间</text>
              <view class="arrow">
                <text  :class="placeholderClass(item.surgeryDate)">{{ formatShouShuDate(item.surgeryDate) || '请选择' }}</text>
                <RectRight></RectRight>
              </view>
            </view>
          </view>
          <nut-popup v-model:visible="item.showPop" position="bottom" round>
            <nut-date-picker
                v-model="val"
                :min-date="min"
                :max-date="max"
                :three-dimensional="false"
                @confirm="(e)=>onPopShouShuConfirm(e,item)"
                :is-show-chinese="true"
            ></nut-date-picker>
          </nut-popup>
        </view>
      </view>
      <view class="card_bg  do-horizon-container-center add" v-if=" type==1 "  @click="onClickAddShouShu">
        <view>增加既往手术史</view>
      </view>

      <view class="question">4.既往外伤史（若无，可以不用填写）</view>
      <view class="card_list">
        <view class="list_item" v-for="(item,index) in waishangList" :key="index">
          <view class="title">
            <view>({{ index + 1 }})既往外伤史</view>
            <view class="delete"  v-if=" type==1 " @click="onDeleteWaiShang(index)">删除</view>
          </view>
          <view class="card_bg">
            <view class="view_item_name">
              <text>名称</text>
              <view class="arrow">
                <input placeholder="请输入" v-model="item.injuryName" maxlength="20"/>
                <RectRight></RectRight>
              </view>
            </view>
            <view class="view_item_birthday" @click="item.showPop = true">
              <text>受伤时间</text>
              <view class="arrow">
                <text>{{ formatShouShuDate(item.injuryDate) || '请选择' }}</text>
                <RectRight></RectRight>
              </view>
            </view>
<!--            <view class="add" v-if="index === waishangList.length -1" @click="onClickAddWaiShang">-->
<!--              <view class="icon">+</view>-->
<!--              <view>增加既往外伤史</view>-->
<!--            </view>-->

            <nut-popup v-model:visible="item.showPop" position="bottom" round>
              <nut-date-picker
                  v-model="val"
                  :min-date="min"
                  :max-date="max"
                  :three-dimensional="false"
                  @cancel="item.showPop=false"
                  @confirm="(e)=>onPopWaiShangConfirm(e,item)"
                  :is-show-chinese="true"
              ></nut-date-picker>
            </nut-popup>
          </view>
        </view>

        <view class="card_bg  do-horizon-container-center add" v-if=" type==1 " @click="onClickAddWaiShang">
          <view>增加既往外伤史</view>
        </view>
      </view>

      <view class="question">5.您的亲属是否正患有或曾患有下列疾病？（多选。若无，可以不用填写）</view>
      <view class="card_bg">
        <view class="view_item_birthday" @click="showFamilyMedicalHistoryPop = true">
          <text>疾病家族史</text>
          <view class="arrow">
            <text  >{{ formatMultipleOptions(result.diseaseName, familyMedicalHistoryList) || '请选择' }}</text>
            <RectRight></RectRight>
          </view>
        </view>
      </view>
    </view>
    <view class="btn" v-if="type === 1">
      <view class="btn_left" @click="onClickSubmit(2)">存为草稿</view>
      <view class="btn_right" @click="onClickSubmit(3)">提交</view>
    </view>
  </view>


  <nut-action-sheet v-model:visible="showAllergyPop" title="选择过敏史（可多选）">
    <dialog-multiple-comp
        :input-value="result.allergenOther" :list="allergyList"
        @on-click-dialog-submit="onAllergySubmit"
        @on-click-dialog-clear="showAllergyPop = false">
    </dialog-multiple-comp>
  </nut-action-sheet>

  <nut-action-sheet v-model:visible="showFamilyMedicalHistoryPop" title="选择家族史（可多选）">
    <dialog-multiple-comp
        :list="familyMedicalHistoryList"
        @on-click-dialog-submit="onFamilyMedicalHistorySubmit"
        @on-click-dialog-clear="showFamilyMedicalHistoryPop = false">
    </dialog-multiple-comp>
  </nut-action-sheet>


</template>
<script setup lang="ts">


import {RectRight} from "@nutui/icons-vue-taro";
import {ref} from "vue";
import {allergyList, familyMedicalHistoryList} from "@/pagesActive/ts/diseaseList";
import DialogMultipleComp from "@/pagesActive/comp/dialog-multiple-comp.vue";
import activeApi from "@/api/modules/active";
import Taro from "@tarojs/taro";
import {IDiseaseDetails, IDiseaseListItem, ISelectOption} from "@/pagesActive/ts/types";
import {
  formatDiseaseIllnessOptions,
  formatDiseaseSymptomOptions, formatMultipleOptions,
  formatOptionsAndWay, formatShouShuDate,
  getSystemName
} from "@/pagesActive/ts/utils";
import {showToast} from "@/utils/toastUtils";
import {isEmpty, isUndefined} from "lodash";

const min = new Date(1970, 0, 1)
const max = new Date()
const val = ref(new Date())

definePageConfig({
  navigationBarTitleText: "疾病信息",
})

const dataId = Number(Taro.getCurrentInstance().router?.params?.dataId)
//1未完成,2暂存,3已完成,4待更新
const status = Number(Taro.getCurrentInstance().router?.params?.status)
/**
 * 1点击加号进入。默认0。1展示按钮，0不展示。
 */
const type = Number(Taro.getCurrentInstance().router?.params?.type || 0)


//过敏
const showAllergyPop = ref(false)

//家族遗传病
const showFamilyMedicalHistoryPop = ref(false)

//各种系统
const dataList = ref<IDiseaseListItem[]>([]);
//手术
const shoushuList = ref<IDiseaseListItem[]>([]);
//外伤
const waishangList = ref<IDiseaseListItem[]>([]);


const result = ref<IDiseaseDetails>({} as IDiseaseDetails)

const placeholderClass = (text) => {
  console.log('index.placeholderClass.',JSON.stringify(text))
  return text ? 'text-dark' : 'text-placeholder'
}
/**
 * 提交数据
 * @param dataStatus
 */
const onClickSubmit = (dataStatus: number) => {
  result.value.tysExtHealthDisList = dataList.value.map(item =>{
    return{
      ...item,
      diseaseOptions: null, symptomOptions: null,
    }
  });
  result.value.tysExtHealthDisSurgeryHistList = shoushuList.value
      .filter(item => !isEmpty(item.surgeryName) && !isUndefined(item.surgeryName) && !isEmpty(item.surgeryDate) && !isUndefined(item.surgeryDate))
      .map(mapItem => {
        return {
          ...mapItem,
          diseaseOptions: null, symptomOptions: null,
        }
      })
  result.value.tysExtHealthDisInjuryHistList = waishangList.value
      .filter(item => !isEmpty(item.injuryName) && !isUndefined(item.injuryName) && !isEmpty(item.injuryDate) && !isUndefined(item.injuryDate))
      .map(mapItem => {
        return {
          ...mapItem,
          diseaseOptions: null, symptomOptions: null,
        }
      })

  if (dataStatus === 2) {
    activeApi.requestDiseaseCreate({...result.value, dataStatus, profileId: dataId}).then(res => {
          showToast("保存草稿成功")
          Taro.navigateBack({delta: -1})
        }, err => {
          showToast(err)
        }
    )
  } else {
    activeApi.requestDiseaseEdit({...result.value, dataStatus, profileId: dataId}).then(res => {
          showToast("保存成功")
          Taro.navigateBack({delta: -1})
        }, err => {
          showToast(err)
        }
    )
  }
}


/**
 * 回调手术时间
 * @param selectedValue
 * @param item
 */
const onPopShouShuConfirm = ({selectedValue}, item: IDiseaseListItem) => {
  item.surgeryDate = selectedValue[0] + '-' + selectedValue[1] + '-' + selectedValue[2]
  item.showPop = false
}
/**
 * 回调外伤时间
 * @param selectedValue
 * @param item
 */
const onPopWaiShangConfirm = ({selectedValue}, item: IDiseaseListItem) => {
  item.injuryDate = selectedValue[0] + '-' + selectedValue[1] + '-' + selectedValue[2]
  item.showPop = false
}

/**
 * 请求详情
 */
const requestDetails = () => {
  if (status === 1) {
    shoushuList.value.push({surgeryName: null, surgeryDate: null} as IDiseaseListItem);
    waishangList.value.push({injuryName: null, injuryDate: null} as IDiseaseListItem);
  }
  activeApi.requestDiseaseDetails(dataId).then(res => {
    result.value = res.data || {} as IDiseaseDetails;

    dataList.value = res.data.tysExtHealthDisList.map(mapItem => {
      return {
        ...mapItem,
        diseaseOptions: formatDiseaseIllnessOptions(mapItem.systemType, result.value.gender),
        symptomOptions: formatDiseaseSymptomOptions(mapItem.systemType),
        showDiseasePop: false,
        showSymptomPop: false,

      }
    });

    //默认增加一条空数据
    shoushuList.value = res.data.tysExtHealthDisSurgeryHistList.map(item => {
      return {
        ...item,
        showPop: false,
      }
    }) || [];
    if (type === 1 && shoushuList.value.length == 0) {
      shoushuList.value.push({surgeryName: null, surgeryDate: null} as IDiseaseListItem);
    }
    waishangList.value = res.data.tysExtHealthDisInjuryHistList.map(item => {
      return {
        ...item, showPop: false
      }
    }) || [];
    if (type === 1 && waishangList.value.length == 0) {
      waishangList.value.push({injuryName: null, injuryDate: null} as IDiseaseListItem);
    }
  })
}

requestDetails()
/**
 * 返回的json过敏
 * @param obj
 * @param type
 */
const onAllergySubmit = (obj: any) => {
  console.log(obj)
  result.value.allergen = obj.list.map(mapItem => mapItem.id).join(',')
  result.value.allergenOther = obj.inputValue;
  showAllergyPop.value = false
}
/**
 * 返回的json遗传病史
 * @param obj
 * @param type
 */
const onFamilyMedicalHistorySubmit = (obj: any) => {
  console.log(obj)
  result.value.diseaseName = obj.list.map(mapItem => mapItem.id).join(',')
  showFamilyMedicalHistoryPop.value = false
}

/**
 * 返回的json 疾病
 * @param obj
 * @param type
 */
const onClickDiseaseSubmit = (obj: any, item: IDiseaseListItem) => {
  console.log(obj)
  item.diseases = obj.list.map(mapItem => mapItem.id)?.join(',');
  item.diseaseOther = obj.inputValue;
  item.showDiseasePop = false
}
/**
 * 返回的json 症状
 * @param obj
 * @param type
 */
const onClickSymptomSubmit = (obj: any, item: IDiseaseListItem) => {
  console.log(obj)
  item.symptoms = obj.list.map(mapItem => mapItem.id)?.join(',');
  item.symptomsOther = obj.inputValue;
  item.showSymptomPop = false
}


const onDeleteWaiShang = (pos: number) => {
  Taro.showModal({
    title: '提示',
    content: '确定删除吗？',
    success: function (res) {
      if (res.confirm) {
        console.log(pos)
        waishangList.value = waishangList.value.filter((item, index) => index != pos)
        console.log('index.onDeleteWaiShang.', waishangList.value)
      } else if (res.cancel) {
      }
    }
  })
}

const onClickAddWaiShang = () => {
  waishangList.value.push({injuryName: null, injuryDate: null} as IDiseaseListItem);
}
const onClickAddShouShu = () => {
  shoushuList.value.push({surgeryName: null, surgeryDate: null} as IDiseaseListItem);
}
/**
 * 删除
 * @param pos
 */
const onDeleteShouShu = (pos: number) => {
  Taro.showModal({
    title: '提示',
    content: '确定删除吗？',
    success: function (res) {
      if (res.confirm) {
        shoushuList.value = shoushuList.value.filter((item, index) => index != pos)
      } else if (res.cancel) {
      }
    }
  })
}

</script>

<style lang="less">
@import "../dossier.less";

.card_view {
  height: 100vh;
  background: #efefef;

  .card_scroll {
    overflow-y: auto;
    height: calc(100% - 150px);
  }
  .card_scroll_type0 {
    overflow-y: auto;
    height: 100%;
  }


  .question {
    color: #333333;
    font-size: 33px;
    font-weight: 400;
    margin: 34px 20px 0 20px;
  }

  .card_bg {
    background: white;
    border-radius: 16px;
    margin: 15px 20px;

    .tag {
      background: #6aa4fc;
      max-width: 150px;
      padding: 3px 10px;
      font-size: 25px;
      border-top-left-radius: 16px;
      border-bottom-right-radius: 8px;
      color: white;
    }

    .tag170 {
      background: #6aa4fc;
      width: 170px;
      font-size: 25px;
      border-top-left-radius: 16px;
      border-bottom-right-radius: 8px;
      color: white;
    }

    .view_item_name {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 30px 20px;
      border-bottom: #efefef solid 1px;

    }

    .view_item_birthday {
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-bottom: #efefef solid 1px;
      padding: 30px 20px;


    }

    .arrow {
      display: flex;
      flex-direction: row;
      width: 450px;
      justify-content: flex-end;
      align-items: center;

      text {
        color: #5F5F5F;
        //white-space: nowrap;
        //overflow: hidden;
        //text-overflow: ellipsis;
      }

      input {
        text-align: right;
        color: #5F5F5F;
        border-bottom: none;
      }

    }

  }



  .card_list {
    .title {
      display: flex;
      margin: 20px;
      justify-content: space-between;
      align-items: center;

      .delete {
        color: #6aa4fc;
      }
    }
  }

}

.btn {
  display: flex;
  flex-direction: row;
  justify-content: space-around;
  background: white;
  padding: 20px 0px;
  align-items: center;

  .btn_left {
    border-radius: 17px;
    border: #64A4F5 solid 1px;
    width: 275px;
    height: 97px;
    color: #64A4F5;
    background: white;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .btn_right {
    border-radius: 17px;
    border: #64A4F5 solid 1px;
    width: 416px;
    height: 97px;
    color: white;
    background: #64A4F5;
    display: flex;
    justify-content: center;
    align-items: center;
  }
}


</style>
