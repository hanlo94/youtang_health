<template>
  <view class="card_list">
    <scroll-view class="view_list" :scrollY="true" @scrollToLower="scroll" flexed v-if="dataList && dataList.length">
      <view class="card_item" v-for="(item, index) in dataList" :key="index" @click="onClickItem(index,item.dataId)">
        <view class="item_header">
          <text>{{ formatDate2YmdWeek(item.updateTime) }}</text>
          <text>{{ formatDateTohm(new Date(item.updateTime)) }}</text>
        </view>
        <view class="content">您的
          <text class="blue">健康档案信息</text>
          已更新，档案报告已生成，快来查看吧!
        </view>
      </view>
    </scroll-view>
    <view v-else class="view_no_data">
      <nut-empty image="https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/common/nodata.png"
                 description="暂时还没有数据哦~"></nut-empty>
    </view>
  </view>

</template>
<script setup lang="ts">
import Taro from "@tarojs/taro";
import activeApi from "@/api/modules/active";
import {ref} from "vue";
import {isEmpty} from "lodash";
import {formatDate2YmdWeek, formatDateTohm} from "@/utils/dateUtils";
import {IIndexMsg} from "@/pagesActive/ts/types";

definePageConfig({
  navigationBarTitleText: "健康档案",
})

const pageNum = ref(1);
//最终的数据
const dataList = ref<IIndexMsg[]>([])
/**
 * 1点击加号进入。默认0
 */
const type = Number(Taro.getCurrentInstance().router?.params?.type || 0)


const scroll = () => {

  requestIndexMsgList()
}


/**
 * 请求列表
 */
const requestIndexMsgList = () => {
  let data = {
    qstatus: 3,   //问卷状态(1未开始、2进行中、3已完成)
    page: pageNum.value,  //当前页
    pageSize: 10, //每页显示10条
    isDel: 0  //未被删除数据
  }
  activeApi.requestActiveMsgList(data).then(res => {
    if (pageNum.value === 1) dataList.value = [];
    if (!isEmpty(res.data)) {
      dataList.value.push(...res.data);
      pageNum.value++;
    }
  })
}

requestIndexMsgList()


/**
 * 开始作答
 */
const onClickItem = (index: number,profileId:number) => {
  //跳转完善信息页面
  Taro.navigateTo({
    url: '/pagesActive/add/index?type=' + type+'&profileId='+profileId
  })
}
</script>

<style lang="less">
.card_list {
  display: flex;
  flex-direction: column;
  height: 100vh;
  background: #efefee;

  .view_list {
    display: flex;
    height: 100vh;
    flex-direction: column;
  }

  .card_item {
    display: flex;
    background: white;
    border-radius: 16px;
    padding: 28px 22px;
    margin: 14px 22px;
    flex-direction: column;

    .item_header {
      display: flex;
      flex-direction: row;
      justify-content: space-between;
      border-bottom: #efefee solid 1px;
      padding-bottom: 20px;
      color: #5F5F5F;
      align-items: center;
    }

    .content {
      padding-top: 30px;
      color: #353535;
      padding-bottom: 10px;
    }

    .blue {
      color: #6aa4fc;
    }
  }
  .view_no_data {
    height: 100vh;
    padding-top: 150px;

    .nut-empty__box {
      width: 440px;
      height: 260px
    }
  }
}

</style>
