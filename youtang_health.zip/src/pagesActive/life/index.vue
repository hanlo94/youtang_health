<template>
  <view class="card_view">
    <view :class=" type === 1 ?'card_scroll' :'card_scroll_type0'  ">
      <view class="question">1.吸烟史（最近三个月）</view>
      <view class="card_bg">
        <view class="card_item" @click="showActiveSmoke = true">
          <text>您是否主动吸烟？</text>
          <view class="arrow">
            <text>{{
                filterOptionsDesc(activeSmokeOptions.find(item => item.id === result.smokingStatus)?.name) || '请选择'
              }}
            </text>
            <RectRight></RectRight>
          </view>
        </view>
        <view class="card_item" @click="showPassiveSmoke = true">
          <text>您是否被动吸烟？</text>
          <view class="arrow">
            <text>{{
                filterOptionsDesc(activePassiveOptions.find(item => item.id === result.passiveSmokingStatus)?.name) || '请选择'
              }}
            </text>
            <RectRight></RectRight>
          </view>
        </view>
      </view>
      <view class="question">2.饮酒史（最近三个月）</view>
      <view class="card_bg">
        <view class="card_item" @click="showDrinkWine= true">
          <text>您是否饮酒</text>
          <view class="arrow">
            <text>{{
                filterOptionsDesc(drinkWineOptions.find(item => item.id === result.drinkingStatus)?.name) || '请选择'
              }}
            </text>
            <RectRight></RectRight>
          </view>
        </view>
        <view class="card_item" @click="showTypeWine= true">
          <text>您主要喝什么酒？（可多选）</text>
          <view class="arrow">
            <text>{{ getWineType() || '请选择' }}</text>
            <RectRight></RectRight>
          </view>
        </view>
      </view>
      <view class="question">3.运动史（最近三个月）</view>
      <view class="card_bg pb">
        <view class="card_item" @click="showSport = true">
          <text>您是否有锻炼习惯？</text>
          <view class="arrow">
            <text>{{
                filterOptionsDesc(sportOptions.find(item => item.id === result.exerciseHabit)?.name) || '请选择'
              }}
            </text>
            <RectRight></RectRight>
          </view>
        </view>
        <view class="card_item" @click="showSportTime = true">
          <text>您锻炼时间段一般为？（可多选）</text>
          <view class="arrow">
            <text>{{ filterOptionsDesc(getSportTime()) || '请选择' }}</text>
            <RectRight></RectRight>
          </view>
        </view>

        <view class="sport_item" v-for="(item,index) in dataList" :key="index">
          <view class="header">
            <view class="title_icon"></view>
            <view class="title">
              <view>({{ index + 1 }})锻炼方式、频率、时长</view>
              <view class="delete" v-if=" type==1 " @click="onClickDelete(item,index)">删除</view>
            </view>
          </view>
          <view class="content">
            <view class="content_item">锻炼方式
              <input placeholder="请输入，如散步、游泳、跳舞" v-model="item.exerciseMode" maxlength="10"/></view>
            <view class="content_item">锻炼频率（次/周）
              <input placeholder="请输入" v-model="item.exerciseFreq" type="number" maxlength="3"/>
            </view>
            <view class="content_item">锻炼时长（分钟）
              <input placeholder="请输入" v-model="item.exerciseDuration" maxlength="3" type="number"/></view>

          </view>
        </view>
        <view class="card_bg do-horizon-container-center add" v-if=" type==1 " @click="onClickAddItem">
          <view>增加锻炼方式、频率、时长</view>
        </view>
      </view>
    </view>


    <view class="btn" v-if="type===1">
      <view class="btn_left" @click="onClickSubmit(2)">存为草稿</view>
      <view class="btn_right" @click="onClickSubmit(3)">提交</view>
    </view>
  </view>


  <nut-action-sheet v-model:visible="showActiveSmoke" title="最近三个月，您是否主动吸烟？">
    <dialog-active-smoking
        @on-click-dialog-submit="onActiveSmokeSubmit"
        :list="activeSmokeOptions"
        :other="result.dailyCigarettes"
        :smoke-years="result.smokingYears"
        @on-click-dialog-clear=" showActiveSmoke = false">
    </dialog-active-smoking>
  </nut-action-sheet>


  <nut-action-sheet v-model:visible="showPassiveSmoke" title="最近三个月，您是否被动吸烟？">
    <dialog-passive-smoking
        @on-click-dialog-submit="onPassiveSmokeSubmit"
        :list="activePassiveOptions"
        :other="result.passiveSmokeHours"
        @on-click-dialog-clear=" showPassiveSmoke = false">

    </dialog-passive-smoking>
  </nut-action-sheet>

  <nut-action-sheet v-model:visible="showDrinkWine" title="最近三个月，您是否饮酒？">
    <dialog-drink-wine @on-click-dialog-submit="onDrinkWineSubmit"
                       :list="drinkWineOptions"
                       :drink-count="result.weeklyDrinkingTimes"
                       :drink-ml="result.mlPerDrink"
                       :drink-year="result.drinkingYears"
                       @on-click-dialog-clear=" showDrinkWine = false"></dialog-drink-wine>
  </nut-action-sheet>


  <nut-action-sheet v-model:visible="showTypeWine" title="最近三个月，您主要喝什么酒？（可多选）">
    <dialog-multiple-comp
        :input-value="result.otherAlcohol"
        :list="typeWineOptions"
        :show-other="true"
        @on-click-dialog-submit="onTypeWineSubmit"
        @on-click-dialog-clear="showTypeWine = false">
    </dialog-multiple-comp>
  </nut-action-sheet>

  <nut-action-sheet v-model:visible="showSport" title="最近三个月，您是否有锻炼习惯？">
    <dialog-sport
        :list="sportOptions"
        :other="result.exerciseYears"
        @on-click-dialog-submit="onSportSubmit"
        @on-click-dialog-clear=" showSport = false"></dialog-sport>
  </nut-action-sheet>


  <nut-action-sheet v-model:visible="showSportTime" title="最近三个月，您锻炼时间段一般为？">
    <dialog-sport-time @on-click-dialog-clear="showSportTime = false" :list="sportTimeOptions"
                       @on-click-dialog-submit="onSportTimeSubmit"></dialog-sport-time>
  </nut-action-sheet>


</template>
<script setup lang="ts">
import {ref} from "vue";
import {RectRight} from "@nutui/icons-vue-taro";
import DialogActiveSmoking from "@/pagesActive/comp/dialog-active-smoking.vue";
import DialogPassiveSmoking from "@/pagesActive/comp/dialog-passive-smoking.vue";
import DialogDrinkWine from "@/pagesActive/comp/dialog-drink-wine.vue";
import DialogMultipleComp from "@/pagesActive/comp/dialog-multiple-comp.vue";
import {
  activePassiveOptions,
  activeSmokeOptions,
  drinkWineOptions,
  sportOptions,
  sportTimeOptions,
  typeWineOptions
} from "@/pagesActive/ts/lifeList";
import DialogSport from "@/pagesActive/comp/dialog-sport.vue";
import DialogSportTime from "@/pagesActive/comp/dialog-sport-time.vue";
import Taro from "@tarojs/taro";
import activeApi from "@/api/modules/active";
import {ILifeDetails, ILifeDetailsItem} from "@/pagesActive/ts/types";
import {isEmpty, isUndefined} from "lodash";
import {showToast} from "@/utils/toastUtils";
import {filterOptionsDesc} from "@/pagesActive/ts/utils";

const dataId = Number(Taro.getCurrentInstance().router?.params?.dataId)
//1未完成,2暂存,3已完成,4待更新
const status = Number(Taro.getCurrentInstance().router?.params?.status)

/**
 * 1点击加号进入。默认0。1展示按钮，0不展示。
 */
const type = Number(Taro.getCurrentInstance().router?.params?.type || 0)

const showActiveSmoke = ref(false)
const showPassiveSmoke = ref(false)
const showDrinkWine = ref(false)
const showTypeWine = ref(false)
const showSport = ref(false)
const showSportTime = ref(false)


definePageConfig({
  navigationBarTitleText: "生活方式",
})


const result = ref<ILifeDetails>({} as ILifeDetails)
/**
 * 处理锻炼 列表
 */
const dataList = ref<ILifeDetailsItem[]>([])

/**
 * 处理锻炼时间多选
 */
const getSportTime = () => {
  return result.value.exerciseTimeSlots?.split(',').map(mapItem => sportTimeOptions.value.find(item => item.id === Number(mapItem))?.name).join(',')
}

/**
 * 回显酒类型
 */
const getWineType = () => {
  if (!isEmpty(result.value.otherAlcohol) && !isUndefined(result.value.otherAlcohol)) {
    let str = result.value.preferredAlcohol?.split(',').map(mapItem => typeWineOptions.value.find(item => item.id === Number(mapItem))?.name).join(',');
    if (!isEmpty(str)) {
      return str + ',' + result.value.otherAlcohol
    } else {
      return result.value.otherAlcohol
    }
  } else {
    return result.value.preferredAlcohol?.split(',').map(mapItem => typeWineOptions.value.find(item => item.id === Number(mapItem))?.name).join(',')
  }

}

/**
 * 点击删除
 * @param item
 * @param pos
 */
const onClickDelete = (item: ILifeDetailsItem, pos: number) => {
  Taro.showModal({
    title: '提示',
    content: '确定删除吗？',
    success: function (res) {
      if (res.confirm) {
        dataList.value = dataList.value.filter((item, index) => index != pos)
      } else if (res.cancel) {
      }
    }
  })
}


const onClickAddItem = () => {
  dataList.value.push({} as ILifeDetailsItem)
}


/**
 * 继续作答
 */
const onClickSubmit = (dataStatus: number) => {
  result.value.exercises = dataList.value.filter(item => {
    console.log('log=str===', item.exerciseDuration, item.exerciseFreq, item.exerciseMode)
    console.log('log====', item.exerciseDuration !== 0, item.exerciseFreq !== 0, !isEmpty(item.exerciseMode))
    return item.exerciseDuration !== 0 && !isUndefined(item.exerciseDuration) && item.exerciseFreq !== 0 && !isUndefined(item.exerciseFreq) && !isEmpty(item.exerciseMode) && !isUndefined(item.exerciseMode)
  })

  if (dataStatus === 2) {
    activeApi.requestLifeCreate({...result.value, dataStatus, profileId: dataId}).then(res => {
      showToast("保存草稿成功")
      Taro.navigateBack({delta: -1})
    }, err => {
      showToast(err)
    })
  } else {
    activeApi.requestLifeEdit({...result.value, dataStatus, profileId: dataId}).then(res => {
      showToast("保存成功")
      Taro.navigateBack({delta: -1})
    }, err => {
      showToast(err)
    })
  }


}


/**
 * 请求详情
 */
const requestLifeDetails = () => {
  if (dataId === 0) {
    dataList.value.push({} as ILifeDetailsItem);
    return;
  }
  activeApi.requestLifeDetails(dataId).then(res => {
    result.value = res.data || {} as ILifeDetails
    dataList.value = result.value.exercises || []
    if (type === 1 && dataList.value.length == 0) {
      dataList.value.push({} as ILifeDetailsItem);
    }

    //处理主动吸烟
    activeSmokeOptions.value.map(item => {
      return {
        ...item,
        check: item.id === result.value.smokingStatus
      }
    });
    //处理被动吸烟
    activePassiveOptions.value.map(item => {
      return {
        ...item,
        check: item.id === result.value.passiveSmokingStatus
      }
    });
    //处理饮酒
    drinkWineOptions.value.map(item => {
      return {
        ...item,
        check: item.id === result.value.drinkingStatus
      }
    });
    //酒类型
    typeWineOptions.value.map(mapItem => {
      return {
        ...mapItem,
        name: result.value.preferredAlcohol?.split(',')?.filter(item => Number(item) === mapItem.id)
      }
    })

    //锻炼习惯
    sportOptions.value.map(mapItem => {
      return {
        ...mapItem,
        check: mapItem.id === result.value.exerciseHabit
      }
    })

    //锻炼时间
    sportTimeOptions.value.map(mapItem => {
      return {
        ...mapItem,
        name: result.value.exerciseTimeSlots?.split(',')?.filter(item => Number(item) === mapItem.id)
      }
    })

  })
}

requestLifeDetails()

/**
 * 锻炼时间
 */
const onSportTimeSubmit = (obj: any) => {
  console.log(obj)
  result.value.exerciseTimeSlots = obj.list?.map(item => item.id).join(",")
  showSportTime.value = false
}


/**
 * 是否运动
 * @param obj
 */
const onSportSubmit = (obj: any) => {
  console.log(obj)
  result.value.exerciseHabit = obj.bean.id;
  result.value.exerciseYears = Number(obj.input);
  showSport.value = false
}


/**
 * 酒类型
 */
const onTypeWineSubmit = (obj: any) => {
  console.log(obj)
  result.value.preferredAlcohol = obj.list?.map(item => item.id).join(",")
  result.value.otherAlcohol = obj.inputValue;
  showTypeWine.value = false
}

/**
 * 是否饮酒
 * @param obj
 */
const onDrinkWineSubmit = (obj: any) => {
  console.log(obj)
  result.value.drinkingStatus = obj.bean.id;
  result.value.drinkingYears = Number(obj.input.drinkYear);
  result.value.mlPerDrink = Number(obj.input.drinkMl);
  result.value.weeklyDrinkingTimes = Number(obj.input.drinkCount);
  showDrinkWine.value = false
}

/**
 * 显示数据 主动抽烟
 */
const onActiveSmokeSubmit = (obj: any) => {
  console.log(obj)
  result.value.smokingStatus = obj.bean.id;
  result.value.dailyCigarettes = Number(obj.input);
  showActiveSmoke.value = false
}
/**
 * 显示数据被动抽烟
 */
const onPassiveSmokeSubmit = (obj: any) => {
  console.log(obj)
  result.value.passiveSmokingStatus = obj.bean.id;
  result.value.passiveSmokeHours = Number(obj.input);
  showPassiveSmoke.value = false
}


</script>

<style lang="less">
@import "../dossier.less";

.card_view {
  height: 100vh;
  background: #efefef;

  .card_scroll {
    overflow-y: auto;
    height: calc(100% - 150px);

  }

  .card_scroll_type0 {
    overflow-y: auto;
    height: 100%;
  }

  .question {
    color: #333333;
    font-size: 33px;
    font-weight: 400;
    margin: 34px 20px 0 20px;
  }

  .card_bg {
    border-radius: 16px;
    background: white;
    display: flex;
    flex-direction: column;
    padding: 0 20px;
    margin: 20px 22px;

    .card_item {
      display: flex;
      align-items: center;
      padding: 30px 0;
      justify-content: space-between;
      border-bottom: #efefef solid 1px;


      .arrow {
        display: flex;
        flex-direction: row;
        width: 500px;
        justify-content: flex-end;
        align-items: center;

        text {
          color: #5F5F5F;
          //white-space: nowrap;
          //overflow: hidden;
          //text-overflow: ellipsis;
        }

      }

    }

    .sport_item {
      display: flex;


      flex-direction: column;

      .header {
        display: flex;
        color: #353535;
        padding: 22px 0;
        align-items: center;

        .title_icon {
          width: 20px;
          height: 20px;
          background-color: #6aa4fc;
          margin-right: 10px;
        }

        .title {
          display: flex;
          margin: 20px;
          flex: 1;
          justify-content: space-between;
          align-items: center;

          .delete {
            color: #6aa4fc;
          }
        }
      }

      .content {
        display: flex;
        border: 1px solid #efefee;
        border-radius: 16px;
        padding: 0 22px;
        flex-direction: column;

        .content_item {
          display: flex;
          padding: 30px 0;
          border-bottom: 1px solid #efefee;
          align-items: center;
          justify-content: space-between;

          input {
            text-align: right;
          }
        }
      }

      .add {
        display: flex;
        color: #6aa4fc;
        flex-direction: row;
        padding: 20px;
        align-items: center;
        justify-content: center;

        .icon {
          width: 30px;
          height: 30px;
          color: white;
          margin-right: 10px;
          display: flex;
          justify-content: center;
          align-items: center;
          background: #6aa4fc;
          border-radius: 15px;

        }
      }
    }

  }
}

.pb {
  padding-bottom: 10px;
}

.btn {
  display: flex;
  flex-direction: row;
  justify-content: space-around;
  background: white;
  padding: 20px 0px;
  align-items: center;

  .btn_left {
    border-radius: 17px;
    border: #64A4F5 solid 1px;
    width: 275px;
    height: 97px;
    color: #64A4F5;
    background: white;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .btn_right {
    border-radius: 17px;
    border: #64A4F5 solid 1px;
    width: 416px;
    height: 97px;
    color: white;
    background: #64A4F5;
    display: flex;
    justify-content: center;
    align-items: center;
  }


}
</style>
