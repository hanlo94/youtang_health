<template>
  <view class="card_view">
    <view :class=" type === 1 ?'card_scroll' :'card_scroll_type0'  ">
      <view class="question">
        1.最近三个月，您是否使用过健康产品及健康工具，如保健食品、功能营养品以及健康工具等。（若近三个月未使用过，可以不用填写）
      </view>
      <view class="card_list">
        <view class="list_item" v-for="(item,index) in dataList" :key="index">
          <view class="title">
            <view>({{ index + 1 }})产品或工具名称</view>
            <view class="delete" v-if=" type==1 " @click="onClickDelete(item,index)">删除</view>
          </view>
          <view class="card_bg">
            <view class="view_item_name">
              <text>产品或工具名称</text>
              <view class="arrow">
                <input placeholder="请输入" v-model="item.productName" maxlength="20"/>
                <RectRight></RectRight>
              </view>
            </view>
            <view class="view_item_birthday">
              <text>单次剂量</text>
              <view class="arrow">
                <input placeholder="请输入" v-model="item.dosage" maxlength="3" type="number"/>
                <RectRight></RectRight>
              </view>
            </view>
            <view class="view_item_birthday" @click="item.showDose = true">
              <text>单次剂量单位</text>
              <view class="arrow">
                <text>{{ item.dosageStr || '请选择' }}</text>
                <RectRight></RectRight>
              </view>
            </view>
            <view class="view_item_birthday" @click="item.showToolWay = true">
              <text>途径</text>
              <view class="arrow">
                <text>{{ item.administrationRouteStr || '请选择' }}</text>
                <RectRight></RectRight>
              </view>
            </view>
            <view class="view_item_name" @click="item.showFrequencyCount = true">
              <text>每日使用时间频次和数量</text>
              <view class="arrow">
                <text>{{ item.usageScheduleStr || '请输入' }}</text>
                <RectRight></RectRight>
              </view>
            </view>
            <view class="view_item_name">
              <text>使用年限（年）</text>
              <view class="arrow">
                <input placeholder="请输入" v-model="item.usageDuration" maxlength="3"/>
                <RectRight></RectRight>
              </view>
            </view>
          </view>
          <view class="card_bg do-horizon-container-center add"  v-if=" type==1 " @click="onClickAddItem">
            <view>增加健康产品及工具使用信息</view>
          </view>
          <nut-action-sheet title="请选择途径" v-model:visible="item.showToolWay" :menu-items="item.options"
                            @choose="(optionItem) => choose(optionItem,index)"
                            cancel-txt="取消" color="#6aa4fc"
                            :choose-tag-value="item.administrationRouteStr"/>

          <nut-action-sheet title="请选择单次剂量" v-model:visible="item.showDose" :menu-items="item.doseOptions"
                            @choose="(optionItem) => chooseDose(optionItem,index)"
                            cancel-txt="取消" color="#6aa4fc"
                            :choose-tag-value="item.dosageStr"/>


          <nut-action-sheet v-model:visible="item.showFrequencyCount" title="每日使用时间点及频率">
            <dialog-frequency-count @on-click-dialog-clear="item.showFrequencyCount = false"
                                    :content="item.usageSchedule"
                                    @on-click-dialog-submit="(obj)=>onClickFrequencyCountSubmit(obj,item)"></dialog-frequency-count>
          </nut-action-sheet>
        </view>

      </view>
      <view class="card_remark">
        <view>备注</view>
        <textarea placeholder="请输入相关内容，建议不超过100个字" rows="5" v-model="result.remark"
                  maxlength="100"></textarea>
      </view>
    </view>
    <view class="btn" v-if="type === 1">
      <view class="btn_left" @click="onClickSubmit(2)">存为草稿</view>
      <view class="btn_right" @click="onClickSubmit(3)">提交</view>
    </view>
  </view>


</template>
<script setup lang="ts">
import {RectRight} from "@nutui/icons-vue-taro";
import {ref} from "vue";
import {medicineDoseOptions, toolWayOptions} from "@/pagesActive/ts/dataOptions";
import {ISelectOption, IToolDetails, IToolItem} from "@/pagesActive/ts/types";
import DialogFrequencyCount from "@/pagesActive/comp/dialog-frequency-count.vue";
import Taro from "@tarojs/taro";
import activeApi from "@/api/modules/active";
import {showToast} from "@/utils/toastUtils";
import {isEmpty, isUndefined} from "lodash";

definePageConfig({
  navigationBarTitleText: "健康产品工具信息",
})

const dataId = Number(Taro.getCurrentInstance().router?.params?.dataId)
//1未完成,2暂存,3已完成,4待更新
const status = Number(Taro.getCurrentInstance().router?.params?.status)

/**
 * 1点击加号进入。默认0。1展示按钮，0不展示。
 */
const type = Number(Taro.getCurrentInstance().router?.params?.type || 0)

const dataList = ref<IToolItem[]>([])
const result = ref<IToolDetails>({} as IToolDetails)


/**
 * 点击删除
 * @param item
 * @param pos
 */
const onClickDelete = (item: IToolItem, pos: number) => {
  Taro.showModal({
    title: '提示',
    content: '确定删除吗？',
    success: function (res) {
      if (res.confirm) {
        dataList.value = dataList.value.filter((item, index) => index != pos)
      } else if (res.cancel) {
      }
    }
  })
}

const formatSchedule = (usageSchedule: string) => {
  let str = ''
  let data = ''
  let list = usageSchedule.split(':')
  if (list[0] !== '0') {
    str = str.concat('早')
    data = data.concat(list[0])
  }
  if (list[1] !== '0') {
    str = str.concat(':中')
    data = data.concat(":" + list[1])
  }
  if (list[2] !== '0') {
    str = str.concat(':晚')
    data = data.concat(":" + list[2])
  }
  return str + data;
}

/**
 * 请求详情
 */
const requestDetails = () => {
  if (dataId === 0) {
    dataList.value.push({
      options: toolWayOptions,
      doseOptions: medicineDoseOptions,
      showToolWay: false,
      showDose: false,
      showFrequencyCount: false
    } as IToolItem);
    return;
  }
  activeApi.requestToolDetails(dataId, 1).then((res) => {
    result.value = res.data || {} as IToolDetails;
    dataList.value = res.data?.tysExtHealthDrugToolsItems?.map(mapItem => {
      return {
        ...mapItem,
        options: toolWayOptions,
        doseOptions: medicineDoseOptions,
        showToolWay: false,
        showDose: false,
        dosage: mapItem.dosage,
        showFrequencyCount: false,
        administrationRouteStr: toolWayOptions.find(item => item.id === mapItem.administrationRoute)?.name,
        dosageStr: medicineDoseOptions.find(item => item.id == mapItem.dosageUnit)?.name,
        usageScheduleStr: formatSchedule(mapItem.usageSchedule)
      }
    }) || [];
    if (type===1 && dataList.value.length==0) {
      dataList.value.push({
        options: toolWayOptions,
        doseOptions: medicineDoseOptions,
        showToolWay: false,
        showDose: false,
        showFrequencyCount: false
      } as IToolItem);
    }
  })
}
requestDetails()


const onClickFrequencyCountSubmit = (obj: any, item: IToolItem) => {
  console.log(obj)

  let str = '';
  let data = '';
  let usageSchedule = obj.breakfast + ":" + obj.lunch + ":" + obj.dinner;

  if (obj.breakfast !== 0 && obj.breakfast !== '0') {
    str = str.concat('早')
    data = data.concat(obj.breakfast)
  }
  if (obj.lunch !== 0 && obj.lunch !== '0') {
    str = str.concat(':中')
    data = data.concat(":" + obj.lunch)
  }
  if (obj.dinner !== 0 && obj.dinner !== '0') {
    str = str.concat(':晚')
    data = data.concat(":" + obj.dinner)
  }
  console.log("=======", usageSchedule, str, data)
  item.usageSchedule = usageSchedule
  item.usageScheduleStr = str + data
  item.showFrequencyCount = false;
}

const choose = (optionItem: ISelectOption, index: number) => {
  dataList.value[index].administrationRouteStr = optionItem.name
}
const chooseDose = (optionItem: ISelectOption, index: number) => {
  dataList.value[index].dosageStr = optionItem.name
  dataList.value[index].dosageUnit = optionItem.id
}

const isBlank = (value: string | any) => {
  return !isEmpty(value) && !isUndefined(value)
}

/**
 * 提交数据 新增
 */
const onClickSubmit = (dataStatus: number) => {
  console.log('====', dataList.value)
  result.value.tysExtHealthDrugToolsItems = dataList.value
      // .filter(fliterItem => {
      //   console.log('productName===', !isEmpty(fliterItem.productName), !isUndefined(fliterItem.productName))
      //   console.log('dosage===', !isEmpty(fliterItem.dosageUnit), !isUndefined(fliterItem.dosageUnit))
      //   console.log('administrationRouteStr===', !isEmpty(fliterItem.administrationRouteStr), !isUndefined(fliterItem.administrationRouteStr))
      //   console.log('usageSchedule===', !isEmpty(fliterItem.usageSchedule), !isUndefined(fliterItem.usageSchedule))
      //   console.log('usageDuration===', !isEmpty(fliterItem.usageDuration), !isUndefined(fliterItem.usageDuration))
      //   return ((!isEmpty(fliterItem.productName) && !isUndefined(fliterItem.productName))
      //       && (fliterItem.dosageUnit !== 0 && !isUndefined(fliterItem.dosageUnit))
      //       && (!isEmpty(fliterItem.administrationRouteStr) && !isUndefined(fliterItem.administrationRouteStr))
      //       && (!isEmpty(fliterItem.usageSchedule) && !isUndefined(fliterItem.usageSchedule))
      //       && (fliterItem.usageDuration !== 0 && !isUndefined(fliterItem.usageDuration))
      //   )
      // })
      .filter(filterItem => {
        // console.log('productName===', !isEmpty(filterItem.productName), !isUndefined(filterItem.productName))
        // console.log('dosage===', !isEmpty(filterItem.dosage), !isUndefined(filterItem.dosage))
        // console.log('dosageUnit===', filterItem.dosageUnit !== 0, !isUndefined(filterItem.dosageUnit))
        // console.log('administrationRouteStr===', !isEmpty(filterItem.administrationRouteStr), !isUndefined(filterItem.administrationRouteStr))
        // console.log('usageSchedule===', !isEmpty(filterItem.usageSchedule), !isUndefined(filterItem.usageSchedule))
        // console.log('usageDuration===', filterItem.usageDuration !== 0, !isUndefined(filterItem.usageDuration))

        return (isBlank(filterItem.productName) ||
            isBlank(filterItem.dosage) ||
            (filterItem.dosageUnit !== 0 && !isUndefined(filterItem.dosageUnit)) ||
            isBlank(filterItem.administrationRouteStr) ||
            isBlank(filterItem.usageSchedule) ||
            (filterItem.usageDuration !== 0 && !isUndefined(filterItem.usageDuration))
        )
      })
      .map(mapItem => {
        return {
          ...mapItem,
          administrationRoute: toolWayOptions.find(item => item.name === mapItem.administrationRouteStr)?.id
        }
      })

  if (dataStatus === 2) {
    activeApi.requestToolCreate({...result.value, dataStatus, profileId: dataId, conditionType: 1}).then(res => {
      showToast("保存草稿成功")
      Taro.navigateBack({delta: -1})
    }, err => {
      showToast(err)
    })
  } else {
    activeApi.requestToolEdit({...result.value, dataStatus, profileId: dataId, conditionType: 1}).then(res => {
      showToast("保存成功")
      Taro.navigateBack({delta: -1})
    }, err => {
      showToast(err)
    })
  }


}

const onClickAddItem = () => {
  dataList.value.push({
    options: toolWayOptions,
    doseOptions: medicineDoseOptions,
    showToolWay: false,
    showDose: false,
    showFrequencyCount: false
  } as IToolItem);
}
</script>

<style lang="less">
@import "../dossier.less";

.card_view {
  height: 100vh;
  background: #efefef;

  .card_scroll {
    overflow-y: auto;
    height: calc(100% - 150px);

  }

  .card_scroll_type0 {
    overflow-y: auto;
    height: 100%;
  }

  .question {
    color: #333333;
    font-size: 33px;
    font-weight: 400;
    margin: 34px 20px 0 20px;
  }

  .card_bg {
    background: white;
    border-radius: 16px;
    margin: 15px 20px;

    .tag {
      background: #6aa4fc;
      width: 120px;
      font-size: 25px;
      border-top-left-radius: 16px;
      border-bottom-right-radius: 8px;
      color: white;
    }

    .tag170 {
      background: #6aa4fc;
      width: 170px;
      font-size: 25px;
      border-top-left-radius: 16px;
      border-bottom-right-radius: 8px;
      color: white;
    }

    .view_item_name {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 30px 20px;
      border-bottom: #efefef solid 1px;


      .arrow {
        display: flex;
        flex-direction: row;
        width: 250px;
        justify-content: flex-end;
        align-items: center;

        text {
          color: #5F5F5F;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }

        input {
          text-align: right;
          width: 150px;
          color: #5F5F5F;
        }
      }


    }

    .view_item_birthday {
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-bottom: #efefef solid 1px;
      padding: 30px 20px;

      .arrow {
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: center;

        text {
          color: #5F5F5F;
        }

        input {
          color: #5F5F5F;
          text-align: right;
        }
      }
    }

    .add {
      display: flex;
      color: #6aa4fc;
      flex-direction: row;
      padding: 20px;
      align-items: center;
      justify-content: center;

      .icon {
        width: 30px;
        height: 30px;
        color: white;
        margin-right: 10px;
        display: flex;
        justify-content: center;
        align-items: center;
        background: #6aa4fc;
        border-radius: 15px;

      }
    }
  }

  .card_list {

    .title {
      display: flex;
      margin: 20px;
      justify-content: space-between;
      align-items: center;

      .delete {
        color: #6aa4fc;
      }
    }
  }

  .card_remark {
    display: flex;
    flex-direction: column;
    background: white;
    padding: 34px 22px;
    border-radius: 16px;
    margin: 15px 20px;

    textarea {
      width: 650px;
      padding: 20px 0;
    }
  }
}

.btn {
  display: flex;
  flex-direction: row;
  justify-content: space-around;
  background: white;
  padding: 20px 0px;
  align-items: center;

  .btn_left {
    border-radius: 17px;
    border: #64A4F5 solid 1px;
    width: 275px;
    height: 97px;
    color: #64A4F5;
    background: white;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .btn_right {
    border-radius: 17px;
    border: #64A4F5 solid 1px;
    width: 416px;
    height: 97px;
    color: white;
    background: #64A4F5;
    display: flex;
    justify-content: center;
    align-items: center;
  }
}
</style>
