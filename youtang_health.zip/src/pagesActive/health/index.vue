<template>
  <view class="card_view">
    <view class="card_scroll">
      <view class="question">1.我当前最关注的健康问题</view>
      <view class="card_remark">
        <textarea placeholder="请输入相关内容，建议不超过100个字" rows="5" ></textarea>
      </view>
      <view class="question">2.我最期望的健康目标</view>
      <view class="card_remark">
        <textarea placeholder="请输入相关内容，建议不超过100个字" rows="5" ></textarea>
      </view>
    </view>
    <view class="btn">
      <view class="btn_left">存为草稿</view>
      <view class="btn_right" @click="onClickSubmit">提交</view>
    </view>
  </view>
</template>
<script setup lang="ts">
import {ref} from "vue";

definePageConfig({
  navigationBarTitleText: "关注的问题",
})
const shoushuList = ref([1, 2, 3])
const showBirthdayPop = ref(false)

/**
 * 提交数据
 */
const onClickSubmit = () => {

}

const onClickAddItem = () => {
  shoushuList.value.push(shoushuList.value.length + 1)
}
</script>

<style  lang="less">
.card_view {
  height: 100vh;
  background: #efefef;

  .card_scroll {
    overflow-y: auto;
    height: calc(100% - 150px);
    .question {
      color: #333333;
      font-size: 33px;
      font-weight: 400;
      margin: 34px 20px 0 20px;
    }
    .card_remark{
      display: flex;
      flex-direction: column;
      background: white;
      padding: 34px 22px;
      border-radius: 16px;
      margin: 15px 20px;
      textarea{
        padding: 20px 0;
      }
    }
  }
}

.btn {
  display: flex;
  flex-direction: row;
  justify-content: space-around;
  background: white;
  padding: 20px 0px;
  align-items: center;

  .btn_left {
    border-radius: 17px;
    border: #64A4F5 solid 1px;
    width: 275px;
    height: 97px;
    color: #64A4F5;
    background: white;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .btn_right {
    border-radius: 17px;
    border: #64A4F5 solid 1px;
    width: 416px;
    height: 97px;
    color: white;
    background: #64A4F5;
    display: flex;
    justify-content: center;
    align-items: center;
  }
}
</style>