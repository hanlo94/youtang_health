<template>
  <view class="view_vip_index">
    <view class="card_bg">
      <view>
        本问卷评估单包含
        <text>基本信息、疾病信息、健康产品工具信息、用药信息、生活习惯、膳食调查六大模块。</text>
        可以点击下列模块进行问卷信息填写和查看。模块信息完成后，请点击“提交”哦～
      </view>

    </view>
    <view class="item" v-for="(item ,index) in result.modules" :key="index" @click="onClickItem(item,index)">
      <view class="item_title">
        <text class="title">{{ item.name }}</text>
        <!--        (1未完成,2暂存,3已完成,4待更新-->
        <text class="status gray" v-if="item.status === 1 || item.status === 2 "> {{ getStatusStr(item.status) }}</text>
        <text class="status blue" v-else> {{ getStatusStr(item.status) }}</text>


      </view>
      <view class="item_date">{{ item.text }}</view>
    </view>

    <view class="btn" @click="onClickSubmit" v-if="type===1">全部提交</view>

    <point_dialog :show-point-dialog="showPointDialog" :rewards=rewardPoint @closeDialog="onClosePointDialog"/>
  </view>

</template>

<script setup lang="ts">
import point_dialog from '@/component/point/index.vue'
import Taro, {useDidShow} from "@tarojs/taro";
import {IActive, IActiveListItem} from "@/pagesActive/ts/types";
import {ref} from "vue";
import activeApi from "@/api/modules/active";
import {showToast} from "@/utils/toastUtils";
import StoreUtils from "@/utils/storeUtils";

const showPointDialog=ref<boolean>(false)
const rewardPoint=ref<number>(1)

/**
 * 1点击加号进入。默认0。1展示按钮，0不展示。
 */
const type = Number(Taro.getCurrentInstance().router?.params?.type || 0)
let profileId = Number(Taro.getCurrentInstance().router?.params?.profileId || 0)

definePageConfig({
  navigationBarTitleText: "健康档案",
})

/**
 * 最终的接口结果
 */
const result = ref<IActive>({} as IActive)

// (1未完成,2暂存,3已完成,4待更新
const getStatusStr = (status: number) => {
  if (status === 1) {
    return "未填写"
  } else if (status === 2) {
    return "未提交"
  } else if (status === 3) {
    return "已提交"
  } else if (status === 4) {
    return '待更新'
  } else {
    return ''
  }
}

/**
 * 更新
 */
const onClickSubmit = () => {
  if (result.value && result.value.dataId) {
    //六个模块都要是已提交或者待更新的状态 允许提交
    if (result.value.modules?.filter(item => item.status === 3 || item.status === 4).length === 6) {
      activeApi.requestActiveListSubmit(result.value.dataId).then(res => {
        showToast('提交成功');
        if (res.data) {
          rewardPoint.value = res.data
          showPointDialog.value = true
        }else{
          onFinal()
        }
      })
    } else {
      showToast('请完善全部问卷')
    }
  } else {
    showToast('数据异常，请稍后重试')
  }
}

/**
 * 获取列表
 */
const requestList = () => {
  activeApi.requestActiveList(profileId).then(res => {
    result.value = res.data
    if (!profileId){
      profileId=res.data.dataId
    }
  })
}

useDidShow(() => {
  requestList()
})


/**
 * 开始作答
 */
const onClickItem = (item: IActiveListItem, index: number) => {
  if (index === 0) {
    //跳转完善信息页面
    Taro.navigateTo({
      url: '/pagesActive/basicinfo/index?dataId=' + result.value.dataId + '&status=' + item.status + '&type=' + type
    })
  } else if (index === 1) {
    Taro.navigateTo({
      url: '/pagesActive/disease/index?dataId=' + result.value.dataId + '&status=' + item.status + '&type=' + type
    })
  } else if (index === 2) {
    Taro.navigateTo({
      url: '/pagesActive/tool/index?dataId=' + result.value.dataId + '&status=' + item.status + '&type=' + type
    })
  } else if (index === 3) {
    Taro.navigateTo({
      url: '/pagesActive/medicine/index?dataId=' + result.value.dataId + '&status=' + item.status + '&type=' + type
    })
  } else if (index === 4) {
    Taro.navigateTo({
      url: '/pagesActive/life/index?dataId=' + result.value.dataId + '&status=' + item.status + '&type=' + type
    })
  } else if (index === 5) {
    Taro.navigateTo({
      url: '/pagesActive/food/index?dataId=' + result.value.dataId + '&status=' + item.status + '&type=' + type
    })
  }
}

const onClosePointDialog=()=>{
  console.log('index.onClosePointDialog.showPointDialog=', showPointDialog)
  showPointDialog.value=false
  onFinal()
}

const onFinal=()=>{
  Taro.navigateBack({delta: -1})
}
</script>

<style lang="less">
.view_vip_index {
  display: flex;
  flex-direction: column;

  .card_bg {
    margin: 40px 20px;
    padding: 30px 20px;
    color: #5F5F5F;
    font-size: 33px;
    background: white;
    border-radius: 16px;

    text {
      color: #64A4F5;
    }
  }

  .item {
    margin: 14px 22px;
    padding: 35px 22px;
    background: white;
    border-radius: 16px;

    .item_title {
      color: #353535;
      display: flex;
      align-items: center;
      font-weight: 600;
      font-size: 33px;

      .status {
        width: 95px;
        height: 35px;
        color: white;
        margin-left: 10px;
        font-size: 25px;
        border-radius: 6px;
        display: flex;
        justify-content: center;
        align-items: center;

      }

      .blue {
        background: #64A4F5
      }

      .gray {
        background: #BBBBBB
      }
    }

    .item_date {
      color: #5F5F5F;
      font-size: 30px;
      margin-top: 28px;
    }

  }

  .btn {
    width: 710px;
    height: 100px;
    background: #64A4F5;
    font-size: 30px;
    color: white;
    border-radius: 16px;
    margin: 50px auto;
    display: flex;
    justify-content: center;
    align-items: center;
  }

}
</style>
