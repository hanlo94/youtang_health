<template>
  <view class="card_view">
    <view :class=" type === 1 ?'card_scroll' :'card_scroll_type0'  ">
      <view class="question">1.膳食调查（最近三个月）</view>
      <view class="card_bg">
        <view class="card_item" @click="showBreakfast = true">
          <text>早餐通常怎么安排？</text>
          <view class="arrow">
            <text>{{ breakfastOptions.find(item => item.id === result.breakfastArrangement)?.name || '请选择' }}</text>
            <RectRight></RectRight>
          </view>
        </view>
        <view class="card_item" @click="showBreakfastCategory = true">
          <text>吃早餐时常如何搭配？（可多选）</text>
          <view class="arrow">
            <text>{{ formatMultipleOptions(result.breakfastCombination, breakfastCategoryOptions) || '请选择' }}</text>
            <RectRight></RectRight>
          </view>
        </view>
        <view class="card_item" @click="showLunchCategory = true">
          <text>吃午餐时常如何搭配？（可多选）</text>
          <view class="arrow">
            <text>{{ formatMultipleOptions(result.lunchCombination, lunchCategoryOptions) || '请选择' }}</text>
            <RectRight></RectRight>
          </view>
        </view>
        <view class="card_item" @click="showDinnerCategory = true">
          <text>吃晚餐时常如何搭配？（可多选）</text>
          <view class="arrow">
            <text>{{ formatMultipleOptions(result.dinnerCombination, dinnerCategoryOptions) || '请选择' }}</text>
            <RectRight></RectRight>
          </view>
        </view>
        <view class="card_item" @click="showExtraMeal = true">
          <text>是否时常晚餐后加餐？</text>
          <view class="arrow">
            <text>{{ filterOptionsDesc(extraMealOptions.find(item => item.id === result.postDinnerSnack)?.name) || '请选择' }}</text>
            <RectRight></RectRight>
          </view>
        </view>
        <view class="card_item" @click="showAddCategory = true">
          <text>晚餐后加餐如何搭配？（可多选）</text>
          <view class="arrow">
            <text>{{ formatMultipleOptions(result.postDinnerSnackCombination, addCategoryOptions) || '请选择' }}</text>
            <RectRight></RectRight>
          </view>
        </view>
        <view class="card_item" @click="showEatOnTime = true">
          <text>一日三餐能够按时吗？</text>
          <view class="arrow">
            <text>{{ filterOptionsDesc(eatOnTimeOptions.find(item => item.id === result.mealTimingAdherence)?.name) || '请选择' }}</text>
            <RectRight></RectRight>
          </view>
        </view>
        <view class="card_item" @click="showEatDuration = true">
          <text>您的用餐时长平均为？</text>
          <view class="arrow">
            <text>{{
                filterOptionsDesc(formatEatDuration(result.mealDurationMorning, result.mealDurationNoon, result.mealDurationEvening)) || '请选择'
              }}
            </text>
            <RectRight></RectRight>
          </view>
        </view>
        <view class="card_item" @click="showEatType = true">
          <text>时常食用哪种食品？（可多选）</text>
          <view class="arrow">
            <text>{{ filterOptionsDesc(formatMultipleOptions(result.frequentFoodConsumption, eatTypesOptions)) || '请选择' }}</text>
            <RectRight></RectRight>
          </view>
        </view>
        <view class="card_item" @click="showCookingType = true">
          <text>时常采用哪种烹饪？（可多选）</text>
          <view class="arrow">
            <text>{{ filterOptionsDesc(formatCookingWay()) || '请选择' }}</text>
            <RectRight></RectRight>
          </view>
        </view>
        <view class="card_item" @click="showOutEatCounts = true">
          <text>平均一周在外就餐次数？</text>
          <view class="arrow">
            <text>{{ filterOptionsDesc(outEatCountsOptions.find(item => item.id === result.outEatingFrequency)?.name) || '请选择' }}</text>
            <RectRight></RectRight>
          </view>
        </view>
        <view class="card_item">
          <text>平均每日总饮水量约为（mL）?</text>
          <view class="arrow">
            <input placeholder="请输入" v-model="result.averageDailyWaterIntake" type="number" maxlength="4"/>
          </view>
        </view>

      </view>

    </view>


    <view class="btn" v-if="type === 1">
      <view class="btn_left" @click="onClickSubmit(2)">存为草稿</view>
      <view class="btn_right" @click="onClickSubmit(3)">提交</view>
    </view>
  </view>


  <nut-action-sheet v-model:visible="showBreakfast" title="最近三个月，您的早餐时常怎么安排？">
    <dialog-food-single tips="时常指平均频率≥4次/周" :list="breakfastOptions"
                        @on-click-dialog-clear="showBreakfast =false"
                        @on-click-dialog-submit="onClickBreakfastSubmit"></dialog-food-single>
  </nut-action-sheet>

  <nut-action-sheet v-model:visible="showBreakfastCategory" title="最近三个月，您吃早餐时常如何搭配？（可多选）">
    <dialog-food-multiple tips="时常指平均频率≥4次/周" :list="breakfastCategoryOptions"
                          @on-click-dialog-clear="showBreakfastCategory =false"
                          @on-click-dialog-submit="onClickBreakfastCategorySubmit"></dialog-food-multiple>
  </nut-action-sheet>


  <nut-action-sheet v-model:visible="showLunchCategory" title="最近三个月，您吃午餐时常如何搭配？（可多选）">
    <dialog-food-multiple tips="时常指平均频率≥4次/周" :list="lunchCategoryOptions"
                          @on-click-dialog-clear="showLunchCategory =false"
                          @on-click-dialog-submit="onClickLunchCategorySubmit"></dialog-food-multiple>
  </nut-action-sheet>

  <nut-action-sheet v-model:visible="showDinnerCategory" title="最近三个月，您吃晚餐时常如何搭配？（可多选）">
    <dialog-food-multiple tips="时常指平均频率≥4次/周" :list="dinnerCategoryOptions"
                          @on-click-dialog-clear="showDinnerCategory =false"
                          @on-click-dialog-submit="onClickDinnerCategorySubmit"></dialog-food-multiple>
  </nut-action-sheet>


  <nut-action-sheet v-model:visible="showExtraMeal" title="最近三个月，您是否时常晚餐后加餐？">
    <dialog-food-extrameal @on-click-dialog-clear="showExtraMeal =false"
                           :list="extraMealOptions"
                           :content-count="result.postDinnerSnackFrequency"
                           :content-time="result.postDinnerSnackTime"
                           @on-click-dialog-submit="onClickExtraMealSubmit"></dialog-food-extrameal>
  </nut-action-sheet>

  <nut-action-sheet v-model:visible="showAddCategory" title="最近三个月，您吃晚餐后加餐时常如何搭配？（可多选）">
    <dialog-food-multiple tips="时常指平均频率≥4次/周" :list="addCategoryOptions"
                          @on-click-dialog-clear="showAddCategory =false"
                          @on-click-dialog-submit="onClickAddCategorySubmit"></dialog-food-multiple>
  </nut-action-sheet>


  <nut-action-sheet v-model:visible="showEatOnTime" title="最近三个月，您一日三餐能够按时吗？">
    <dialog-food-single tips="按时指早餐6:30~8:30，午餐11:30~13:30，晚餐18:00~20:00" :list="eatOnTimeOptions"
                        @on-click-dialog-clear="showEatOnTime =false"
                        @on-click-dialog-submit="onClickEatOnTimeSubmit"></dialog-food-single>
  </nut-action-sheet>

  <nut-action-sheet v-model:visible="showEatDuration" title="最近三个月，您的用餐时长平均为？">
    <dialog-eat-duration @on-click-dialog-clear="showEatDuration = false"
                         :breakfast="result.mealDurationMorning"
                         :lunch="result.mealDurationNoon"
                         :dinner="result.mealDurationEvening"
                         @on-click-dialog-submit="onClickEatDurationSubmit"></dialog-eat-duration>
  </nut-action-sheet>

  <nut-action-sheet v-model:visible="showEatType" title="最近三个月，时常食用哪种食品？（可多选）">
    <dialog-food-multiple tips="时常指平均频率≥4次/周" :list="eatTypesOptions"
                          @on-click-dialog-clear="showEatType =false"
                          @on-click-dialog-submit="onClickEatTypeSubmit"></dialog-food-multiple>
  </nut-action-sheet>


  <nut-action-sheet v-model:visible="showCookingType" title="最近三个月，您时常采用哪种烹饪？（可多选）">
    <dialog-food-multiple tips="时常指平均频率≥4次/周" :list="cookingTypesOptions"
                          @on-click-dialog-clear="showCookingType =false" :show-other="true"
                          :other="result.cookingMethodsOther"
                          @on-click-dialog-submit="onClickCookingTypeSubmit"></dialog-food-multiple>
  </nut-action-sheet>


  <nut-action-sheet v-model:visible="showOutEatCounts" title="最近三个月，您平均一周在外就餐次数？">
    <dialog-food-single tips="每餐算一次" :list="outEatCountsOptions"
                        @on-click-dialog-clear="showOutEatCounts =false"
                        @on-click-dialog-submit="onClickOutEatCountsSubmit"></dialog-food-single>
  </nut-action-sheet>

</template>
<script setup lang="ts">
import {ref} from "vue";
import {RectRight} from "@nutui/icons-vue-taro";
import DialogFoodSingle from "@/pagesActive/comp/dialog-food-single.vue";
import {
  addCategoryOptions,
  breakfastCategoryOptions,
  breakfastOptions,
  cookingTypesOptions, dinnerCategoryOptions,
  eatOnTimeOptions,
  eatTypesOptions, extraMealOptions, lunchCategoryOptions, outEatCountsOptions
} from "@/pagesActive/ts/foodList";
import DialogFoodMultiple from "@/pagesActive/comp/dialog-food-multiple.vue";
import DialogFoodExtrameal from "@/pagesActive/comp/dialog-food-extrameal.vue";
import DialogEatDuration from "@/pagesActive/comp/dialog-eat-duration.vue";
import Taro from "@tarojs/taro";
import activeApi from "@/api/modules/active";
import {IFoodDetails, ISelectOption} from "@/pagesActive/ts/types";
import {isEmpty, isUndefined} from "lodash";
import {showToast} from "@/utils/toastUtils";
import {filterOptionsDesc, formatMultipleOptions} from "@/pagesActive/ts/utils";


const showBreakfast = ref(false)
const showBreakfastCategory = ref(false)
const showLunchCategory = ref(false)
const showDinnerCategory = ref(false)
const showAddCategory = ref(false)
const showExtraMeal = ref(false)
const showEatOnTime = ref(false)
const showEatDuration = ref(false)
const showEatType = ref(false)
const showCookingType = ref(false)
const showOutEatCounts = ref(false)


const value = ref(null)

const dataId = Number(Taro.getCurrentInstance().router?.params?.dataId)
//1未完成,2暂存,3已完成,4待更新
const status = Number(Taro.getCurrentInstance().router?.params?.status)
/**
 * 1点击加号进入。默认0。1展示按钮，0不展示。
 */
const type = Number(Taro.getCurrentInstance().router?.params?.type || 0)
/**
 * 结果
 */
const result = ref<IFoodDetails>({} as IFoodDetails)

definePageConfig({
  navigationBarTitleText: "膳食调查",

})
/**
 * 提交数据
 * @param dataStatus
 */
const onClickSubmit = (dataStatus: number) => {
  if (dataStatus === 2) {
    activeApi.requestFoodCreate({...result.value, dataStatus, profileId: dataId}).then(res => {
          showToast("保存草稿成功")
          Taro.navigateBack({delta: -1})
        }, err => {
          showToast(err)
        }
    )
  } else {
    activeApi.requestFoodEdit({...result.value, dataStatus, profileId: dataId}).then(res => {
          showToast("保存成功")
          Taro.navigateBack({delta: -1})
        }, err => {
          showToast(err)
        }
    )
  }


}

/**
 * 烹饪方式  拼接其他
 */
const formatCookingWay = () => {
  let data = formatMultipleOptions(result.value.cookingMethods, cookingTypesOptions.value)
  let other = result.value.cookingMethodsOther;
  if (!isEmpty(data) && !isEmpty(other)) {
    return data + ',' + other;
  } else if (isEmpty(data)) {
    return other
  } else if (isEmpty(other)) {
    return data;
  } else {
    return ''
  }
}

/**
 * 用餐时长
 * @param b 早餐
 * @param l 午餐
 * @param d 晚餐
 */
const formatEatDuration = (b: number, l: number, d: number): string => {
  let data = ''
  if (!isUndefined(b) && b != 0) {
    data = data.concat('早：' + b)
  }
  if (!isUndefined(l) && l != 0) {
    data = data.concat('中：' + l)
  }
  if (!isUndefined(d) && d != 0) {
    data = data.concat('晚：' + d)
  }
  return data
}


/**
 * 请求详情回显
 */
const requestDetails = () => {
  activeApi.requestFoodDetails(dataId).then(res => {
    result.value = res.data || {} as IFoodDetails;

    breakfastOptions.value.map(item => {
      return {
        ...item,
        check: result.value.breakfastArrangement === item.id
      }
    })

    ///早餐类型
    breakfastCategoryOptions.value.map(mapItem => {
      return {
        ...mapItem,
        check: result.value.breakfastCombination.split(',')?.filter(item => Number(item) === mapItem.id)
      }
    })
    //午餐类型
    lunchCategoryOptions.value.map(mapItem => {
      return {
        ...mapItem,
        check: result.value.lunchCombination.split(',')?.filter(item => Number(item) === mapItem.id)
      }
    })
    //晚餐类型
    dinnerCategoryOptions.value.map(mapItem => {
      return {
        ...mapItem,
        check: result.value.dinnerCombination.split(',')?.filter(item => Number(item) === mapItem.id)
      }
    })
    //是否加餐
    extraMealOptions.value.map(mapItem => {
      return {
        ...mapItem,
        check: result.value.postDinnerSnack === mapItem.id
      }
    })

    //晚餐类型
    addCategoryOptions.value.map(mapItem => {
      return {
        ...mapItem,
        check: result.value.postDinnerSnackCombination.split(',')?.filter(item => Number(item) === mapItem.id)
      }
    })
    //一日三餐按时
    eatOnTimeOptions.value.map(mapItem => {
      return {
        ...mapItem,
        check: result.value.mealTimingAdherence === mapItem.id
      }
    })
    //经常食用什么食物
    eatTypesOptions.value.map(mapItem => {
      return {
        ...mapItem,
        check: result.value.frequentFoodConsumption.split(',')?.filter(item => Number(item) === mapItem.id)
      }
    })
    //经常采用那种烹饪方式
    cookingTypesOptions.value.map(mapItem => {
      return {
        ...mapItem,
        check: result.value.cookingMethods.split(',')?.filter(item => Number(item) === mapItem.id)
      }
    })
    //在外就餐次数
    outEatCountsOptions.value.map(mapItem => {
      return {
        ...mapItem,
        check: result.value.outEatingFrequency === mapItem.id
      }
    })
    //处理水
    result.value.averageDailyWaterIntake = result.value.averageDailyWaterIntake === 0 ? null : result.value.averageDailyWaterIntake;
  })
}
requestDetails()


/**
 * 加餐
 * @param obj
 */
const onClickAddCategorySubmit = (obj: any) => {
  console.log(obj)
  result.value.postDinnerSnackCombination = obj.list.map(mapItem => mapItem.id).join(',')

  showAddCategory.value = false
}

/**
 * 晚餐
 * @param obj
 */
const onClickDinnerCategorySubmit = (obj: any) => {
  console.log(obj)
  result.value.dinnerCombination = obj.list.map(mapItem => mapItem.id).join(',')
  showDinnerCategory.value = false
}


/**
 * 午餐
 * @param obj
 */
const onClickLunchCategorySubmit = (obj: any) => {
  console.log(obj)
  result.value.lunchCombination = obj.list.map(mapItem => mapItem.id).join(',')
  showLunchCategory.value = false
}

/**
 * 在外就餐次数
 * @param obj
 */
const onClickOutEatCountsSubmit = (obj: any) => {
  console.log(obj)
  result.value.outEatingFrequency = obj.bean.id
  showOutEatCounts.value = false
}


/**
 * 经常烹饪
 * @param obj
 */
const onClickCookingTypeSubmit = (obj: any) => {
  console.log(obj)
  result.value.cookingMethods = obj.list.map(mapItem => mapItem.id).join(',')
  result.value.cookingMethodsOther = obj.input
  showCookingType.value = false
}


/**
 * 时常食用哪种食品
 * @param obj
 */
const onClickEatTypeSubmit = (obj: any) => {
  console.log(obj)
  result.value.frequentFoodConsumption = obj.list.map(mapItem => mapItem.id).join(',')
  showEatType.value = false
}


/**
 * 展示用餐时长
 * @param obj
 */
const onClickEatDurationSubmit = (obj: any) => {
  console.log(obj)
  result.value.mealDurationMorning = obj.breakfast;
  result.value.mealDurationNoon = obj.lunch;
  result.value.mealDurationEvening = obj.dinner;
  showEatDuration.value = false
}


/**
 * 展示是否按时用餐
 * @param obj
 */
const onClickEatOnTimeSubmit = (obj: any) => {
  console.log(obj)
  result.value.mealTimingAdherence = obj.bean.id
  showEatOnTime.value = false
}

/**
 * 点击晚餐后加餐
 * @param obj
 */
const onClickExtraMealSubmit = (obj: any) => {
  console.log(obj)
  result.value.postDinnerSnack = obj.bean.id;
  result.value.postDinnerSnackTime = obj.input.contentTime;
  result.value.postDinnerSnackFrequency = obj.input.contentCount;
  showExtraMeal.value = false
}

/**
 * 点击早餐分类
 * @param obj
 */
const onClickBreakfastCategorySubmit = (obj: any) => {
  console.log(obj)
  result.value.breakfastCombination = obj.list.map(mapItem => mapItem.id).join(',')
  showBreakfastCategory.value = false
}

/**
 * 点击选择早餐
 * @param obj
 */
const onClickBreakfastSubmit = (obj: any) => {
  console.log(obj)
  result.value.breakfastArrangement = obj.bean.id;
  showBreakfast.value = false
}


/**
 * 继续作答
 */
const onClickAnswer = () => {

}


</script>

<style lang="less">
.card_view {
  height: 100vh;
  background: #efefef;

  .card_scroll {
    overflow-y: auto;
    height: calc(100% - 150px);
  }
  .card_scroll_type0 {
    overflow-y: auto;
    height: 100%;
  }

  .question {
    color: #333333;
    font-size: 33px;
    font-weight: 400;
    margin: 34px 20px 0 20px;
  }

  .card_bg {
    border-radius: 16px;
    background: white;
    display: flex;
    flex-direction: column;
    padding: 0 20px;
    margin: 20px 22px;

    .card_item {
      display: flex;
      align-items: center;
      padding: 30px 0;
      justify-content: space-between;
      border-bottom: #efefef solid 1px;


      .arrow {
        display: flex;
        flex-direction: row;
        width: 500px;
        justify-content: flex-end;
        align-items: center;

        text {
          color: #5F5F5F;
          //white-space: nowrap;
          //overflow: hidden;
          //text-overflow: ellipsis;
        }

        input {
          text-align: right;
          margin-right: 22px;
          color: #5F5F5F;
          width: 150px;
          border-bottom: none;
        }

      }

    }


  }

}

.btn {
  display: flex;
  flex-direction: row;
  justify-content: space-around;
  background: white;
  padding: 20px 0px;
  align-items: center;

  .btn_left {
    border-radius: 17px;
    border: #64A4F5 solid 1px;
    width: 275px;
    height: 97px;
    color: #64A4F5;
    background: white;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .btn_right {
    border-radius: 17px;
    border: #64A4F5 solid 1px;
    width: 416px;
    height: 97px;
    color: white;
    background: #64A4F5;
    display: flex;
    justify-content: center;
    align-items: center;
  }
}
</style>
