/**
 * Description：
 * Created on 2023/7/20
 * Author :  郭
 */

export interface ILabelItem{
    label:string;
    value:number;
}

/**
 * 性别
 */
export const genderList = [
    {
        label:"男",
        value:1
    },
    {
        label:"女",
        value:2
    }
]

/**
 * 出生日期类型
 */
export const birthdayTypeList = [
    {
        label:"阳历",
        value:1
    },
    {
        label:"阴历",
        value:2
    }
]

/**
 * 任职状态
 */
export const jobList = [
    {
        label:"在职",
        value:1
    },
    {
        label:"离退休",
        value:2
    }
]

export const yesOrNoList = [
    {
        label:"是",
        value:1
    },
    {
        label:"否",
        value:0
    }
]

/**
 * 糖尿病类型
 */
export const sugarList = [
    {
        label:"无",
        value:0
    },{
        label:"1型",
        value:1
    },
    {
        label:"2型",
        value:2
    },
    {
        label:"妊娠型",
        value:3
    },
    {
        label:"其他型",
        value:4
    },
    {
        label:"糖前期",
        value:5
    }
]


/**
 * 劳动强度类型
 */
export const labourList = [
    {
        label:"轻体力劳动",
        value:1
    },
    {
        label:"中体力劳动",
        value:2
    },
    {
        label:"重体力劳动",
        value:3
    },
    {
        label:"卧床休息",
        value:4
    },
]

export const smokingFrequencyList = [
    {
        label:"1支/天",
        value:1
    },
    {
        label:"1-3支/天",
        value:2
    },
    {
        label:">3支/天",
        value:3
    }
]

export const drinkFrequencyList = [
    {
        label:"1次/周",
        value:1
    },
    {
        label:"1-3次/周",
        value:2
    },
    {
        label:">3次/周",
        value:3
    }
]

export const drinkAmountList = [
    {
        label:"<2两/次",
        value:1
    },
    {
        label:"每次2两以上",
        value:2
    }
]

export const sportFrequencyList = [
    {
        label:"1次/周",
        value:1
    },
    {
        label:"1-3次/周",
        value:2
    },
    {
        label:">3次/周",
        value:3
    }
]

export const sportTimeList = [
    {
        label:"不足30分钟/次",
        value:1
    },
    {
        label:"30分钟以上/次",
        value:2
    },
]
