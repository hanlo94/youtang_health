<template>
  <view class="container_device">
    <scroll-view class="page-scroll-view" scroll-y type="list" enhanced="{{true}}" show-scrollbar="{{false}}">
      <view>
        <block v-for='(item,index) in deviceList' :key='index'>
          <comp_category v-if="item.layoutType===1" :categoryName='item.categoryName' :index='index'></comp_category>
          <comp_item class="item" v-else :item='item' :index='index'></comp_item>
        </block>
      </view>
    </scroll-view>
  </view>

</template>
<script setup lang="ts">
import comp_category from './comp/category.vue';
import comp_item from './comp/item.vue';
import {ref} from "vue";
import SugarApi from "@/api/modules/sugar";
import {IDeviceItem} from "@/api/types";
import Taro from "@tarojs/taro";
import StoreUtils from "@/utils/storeUtils";

const deviceList = ref<IDeviceItem[]>([] as IDeviceItem[]);

const getDeviceList=()=>{
	SugarApi.getDeviceList().then((res) => {
		deviceList.value = res.data;
	},(failure)=>{
		console.log("device.vue.getDeviceList.failure=", failure);
	})
}

getDeviceList()

Taro.eventCenter.on('login', (item) => {
	getDeviceList()
})
Taro.eventCenter.on('bind', (item) => {
	getDeviceList()
})

</script>
<style lang="less">
.container_device {
  padding: 35px 20.83px;

  .image {
    width: 127px;
    height: 127px;
  }

  .item {
    margin-top: 35px;
    margin-bottom: 35px;
  }
}

</style>
