export default definePageConfig({
    navigationBarTitleText: "智能设备",
});
