<template>
  <view class="comp_category">
    <text>{{ categoryName }}</text>
  </view>
</template>
<script setup lang="ts">
type Props = {
  categoryName: string
}
const props = withDefaults(defineProps<Props>(), {})
</script>

<style lang="less">
.comp_category{
  height: 36px;
  display: flex;
  align-items: center;

  font-size: 33.33px;
  font-weight: 600;
  color: #353535;
}
</style>
