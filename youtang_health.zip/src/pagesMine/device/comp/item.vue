<template>
  <view class="box_device_item" @click="onItemClick">

    <view class="left">
      <image class="image" :src="item.imgUrl" mode="aspectFill"/>
    </view>
    <view class="right">
      <view class="device_name">{{ item.deviceName }}</view>
      <view class="device_desc">{{ item.deviceDesc }}</view>
      <view class="action_container">
        <view class="unbind_box" v-if="item.bindState==1" @click.stop="onItemUnBind">
          解除绑定
        </view>
        <view class="unbind_box" v-if="item.jumpUrl && item.jumpUrl != ''" @click.stop="onDeviceGuide">
          使用指南
        </view>
      </view>

    </view>

    <view class="status" v-if="item.bindState !== 3" :class="[item.bindState == 1 ? 'status_bind' : 'status_unbind']">
      {{ item.bindState == 1 ? "已绑定" : "未绑定" }}
    </view>
  </view>
</template>
<script setup lang="ts">
import {IDeviceItem} from "@/api/types";
import SugarApi from "@/api/modules/sugar";
import {
  DeviceAction,
  DeviceBindState,
  DeviceBrand,
  DeviceBrandProperties,
  findDeviceBrand
} from "@/config/device/deviceConfig";
import {showShortToast} from "@/utils/util";
import Taro from "@tarojs/taro";
import PageNavigation from "@/utils/pageNavigation";

type Props = {
  item: IDeviceItem
}
const props = withDefaults(defineProps<Props>(), {})

const onItemUnBind = () => {
  console.log("item.vue.onItemUnBind.",);
  let device = props.item
  let response = SugarApi.unBindDevice(device.deviceBrand, device.categoryId);
  if (response) {
    response.then((res) => {
      console.log("item.vue.onItemUnBind..success", JSON.stringify(res));
      showShortToast('解绑成功')
      device.bindState = DeviceBindState.UNBIND
    }, (failure) => {
      console.log("item.vue.onItemUnBind..failure", failure)
      showShortToast('解绑失败')
    }).catch((error) => {
      console.log("item.vue.onItemUnBind..error", error);
      showShortToast('解绑异常')
    })
  }
}

const onDeviceGuide = () => {
  console.log('item.onDeviceGuide.')
  let device = props.item
  console.log('item.onDeviceGuide.device=', JSON.stringify(device))
  PageNavigation.navigationToWebView(device.jumpUrl, device.deviceName)
}

// 扫描设备二维码
const startScanCode = (deviceSnChecker, success, failure) => {
  let that = this
  Taro.scanCode({
    success(res) {
      console.log("device.js.success.", JSON.stringify(res), '; res.result=', res.result, ' deviceSnChecker: ', deviceSnChecker, '; typeof deviceSnChecker=', typeof deviceSnChecker);
      if (deviceSnChecker && typeof deviceSnChecker == 'function' && deviceSnChecker(res.result)) {
        success && success(res.result)
      } else {
        showShortToast('请扫描正确的设备标识码')
      }
    },
    fail(res) {
      failure && failure(res)
    }
  })
}

// 扫描失败
const scanFailure = (failure: string) => {
  console.log('device.scanFailure ', failure)
  if (failure && failure.indexOf('cancel') != -1) {
    showShortToast("取消扫描")
  } else {
    showShortToast("扫描失败")
  }
}

const onItemClick = (res) => {
  let device = props.item
  console.log("device.js.onItemClick.", JSON.stringify(res), ' type of DeviceBrand', typeof DeviceBrand, '; device=', JSON.stringify(device));
  let isBind = device.bindState && device.bindState == DeviceBindState.BIND

  let deviceProperties = findDeviceBrand(device.deviceBrand);
  deviceProperties.minLen = device.deviceSnMinLength || deviceProperties.minLen
  deviceProperties.maxLen = device.deviceSnMaxLength || deviceProperties.maxLen
  deviceProperties.page = device.xcxPage || deviceProperties.page
  // getApp().globalData.console.log.console.log('onItemClick index', index, ' ; deviceBrand=', JSON.stringify(deviceBrand), '; device ; ', JSON.stringify(device))
  console.log('onItemClick index', ' ; deviceBrand=', JSON.stringify(deviceProperties), ' ; deviceBrand.action = ', deviceProperties.action, '; typeof deviceBrand is ', typeof deviceProperties, ' ; bodyfat=', JSON.stringify(DeviceBrand.BODYFAT), ' ; typeof DeviceBrand.BODYFAT is ', typeof DeviceBrand.BODYFAT, '; device ; ', JSON.stringify(device))

  if (deviceProperties == DeviceBrand.RBP) {
    // 脉搏波
    console.log('device.onItemClick 点击脉搏波设备')
  } else if (deviceProperties.action == DeviceAction.UNKNOWN) {
    showShortToast('暂不支持该设备')
  } else if (deviceProperties.action == DeviceAction.SCAN) {
    console.log('device.onItemClick 点击扫描设备 isBind', isBind, '; page =', deviceProperties.page)
    handleGprsDevice(isBind, device.deviceBrand, device.categoryId, deviceProperties, (res) => {
      device.bindState = DeviceBindState.BIND
    })
  } else if (deviceProperties.action == DeviceAction.BLE) {
    console.log('device.onItemClick 点击蓝牙设备 isBind', isBind, '; page =', deviceProperties.page)
    handleBleDevice(isBind, deviceProperties)
  } else {
    showShortToast('暂不支持该设备')
  }
}

/**
 * 处理GPRS设备点击事件
 */
const handleGprsDevice = (isBind: boolean | number, deviceBrand, deviceCategory, deviceProperties: DeviceBrandProperties, bindSuccess) => {
// 开启扫描
  if (isBind) {
    // 已绑定进入测量界面
    deviceProperties.page && Taro.navigateTo({
      url: deviceProperties.page
    })
  } else {
    // 未绑定开启扫描  判定扫描结果 绑定设备
    const deviceSnChecker = deviceProperties.deviceSnChecker
    startScanCode(deviceSnChecker, (deviceSn) => bindDevice(deviceSn, deviceBrand, deviceCategory, bindSuccess), (failure) => scanFailure(failure))
  }
}

const handleBleDevice = (isBind: boolean | number, deviceProperties: DeviceBrandProperties,) => {
  if (isBind || deviceProperties.autoBind) {
    // 已绑定  或 自动绑定直接进入测量界面
    deviceProperties.page && Taro.navigateTo({
      url: deviceProperties.page + '?isBind=' + isBind,
    })
  } else {
    // 未绑定进入
    // 蓝牙BLE
    if (deviceProperties == DeviceBrand.BODYFAT) {
      // 体脂秤
      Taro.navigateTo({
        url: deviceProperties.page + '?isBind=' + isBind,
        events: (event) => {
          console.log('device.events, ', JSON.stringify(event))
        },
      })
    } else {
      showShortToast('暂不支持该设备')
    }
  }
}

const bindDevice = (deviceSn, deviceBrand, categoryId, success) => {
  SugarApi.bindDevice(deviceSn, deviceBrand, categoryId).then((res) => {
    console.log("item.vue.bindDevice..success", JSON.stringify(res));
    success && typeof success == 'function' && success(res)
  }, (failure) => {
    showShortToast(failure)
  })
}
</script>

<style lang="less">
.box_device_item {
  width: 100%;
  background-color: white;
  border-radius: 16.67px;
  padding: 27.78px 20.83px;

  display: flex;
  flex-direction: row;
  justify-content: space-between;

  position: relative;

  .left {
    display: flex;
    justify-content: center;
    align-items: center;

    .image {
      width: 188.9px;
      height: 204.17px;
    }
  }

  .right {
    flex: 1;
    padding-left: 24.3px;

    display: flex;
    flex-direction: column;
    justify-content: space-between;
    //align-items: center;

    .device_name {
      font-size: 34px;
      font-weight: 600;
      color: #353535;
    }

    .action_container {

      display: flex;
      flex-direction: row;
      justify-content: flex-end;
      text-align: center;
      gap:10px;

      .unbind_box {
        font-size: 26px;
        color: #4aa4fc;
        height: 50px;
        width: 130px;
        text-align: center;
        display: flex;
        justify-content: center;
        border-radius: 35px;
        border: 1px solid #4aa4fc;
        align-items: center;
      }
    }

    .device_desc {
      font-size: 26px;
      color: #5F5F5F;
    }
  }

  .status {
    position: absolute;
    top: 0;
    left: 0;

    width: 95.83px;
    height: 35.42px;
    border-top-left-radius: 16.67px;

    font-size: 23px;
    color: white;

    display: flex;
    justify-content: center;
    align-items: center;
  }

  .status_bind {
    background: #64A4F5;
  }

  .status_unbind {
    background: #BBBBBB;
  }
}
</style>
