import {ScaleMeasure} from "@/config/device/bodyfat";
import imgUrlFormat from "@/utils/imgUtils";

/**
 * 雅思血糖仪 UUID配置
 * @type {{IEEE_11073_CERT_DATA_UUID: string, GLUCOSE_MEAS_UUID: string, MANUFACTURER_NAME_UUID: string, HARDWARE_REV_UUID: string, SOFTWARE_REV_UUID: string, BLE_OUT_RET_GLU_UUID: string, PNP_ID_UUID: string, SERV_GLUCOSE_UUID: string, BLE_IN_CMD_GLU_UUID: string, SERV_DEVINFO_UUID: string, SYSTEM_ID_UUID: string, MODEL_NUMBER_UUID: string, SERIAL_NUMBER_UUID: string, FIRMWARE_REV_UUID: string, SERV_GLUCOSE_UUID_PREFIX: string}}
 */
export const DeviceUUID = {

    // 血糖服务UUID
    /**
     * 血糖仪
     */
    SERV_GLUCOSE_UUID: "00001808-0000-1000-8000-00805f9b34fb",
    SERV_GLUCOSE_UUID_UPPER: "00001808-0000-1000-8000-00805F9B34FB",
    SERV_GLUCOSE_UUID_PREFIX: "1808",

    /**
     * 设备信息
     */
    SERV_DEVINFO_UUID: "0000180a-0000-1000-8000-00805f9b34fb",
    SERV_DEVINFO_UUID_UPPER: "0000180A-0000-1000-8000-00805F9B34FB",

    // 血糖服务特性UUID
    /**
     * Glucose Measurement
     */
    GLUCOSE_MEAS_UUID: "2A18",
    /**
     * BLE CMD
     */
    BLE_IN_CMD_GLU_UUID: "00002A6C-0000-1000-8000-00805F9B34FB",
    BLE_IN_CMD_GLU_UUID_PREFIX: "2A6C",
    /**
     * UART RET
     */
    BLE_OUT_RET_GLU_UUID: "00002A6D-0000-1000-8000-00805F9B34FB",
    BLE_OUT_RET_GLU_UUID_PREFIX: "2A6D",

    // 设备信息服务特性UUID
    SYSTEM_ID_UUID: "2A23",
    MODEL_NUMBER_UUID: "2A24",
    SERIAL_NUMBER_UUID: "2A25",
    FIRMWARE_REV_UUID: "2A26",
    HARDWARE_REV_UUID: "2A27",
    SOFTWARE_REV_UUID: "2A28",
    MANUFACTURER_NAME_UUID: "2A29",
    IEEE_11073_CERT_DATA_UUID: "2A2A",
    PNP_ID_UUID: "2A50"
};

// 定义UART命令常量
const UartCmd = {
    /**
     * 命令前缀
     */
    UART_PREFIX: "02" as const,
    /**
     * 读Eeprom[ADDR]地址的数据，ADDR=0—2047
     */
    UART_READ_EEPROM_DATA: "05A5" as const,
    /**
     * 写EEPROM数据，ADDR= 0-2047, Data=要写入的数据
     */
    UART_WRITE_EEPROM_DATA: "06B5" as const,
    /**
     * 读血糖仪已保存多少Record
     */
    UART_READ_TOTAL_RCD_NO: "0206AA5503AE00AE" as const,
    /**
     * 读当前血糖仪RTC(实时时钟)
     */
    UART_READ_RTC: "0206AA5503A100A1" as const,
    /**
     * 读取年份偏移
     */
    UART_READ_YEAR_OFFSET: "0208AA5505A5002A00CF" as const,
    /**
     * 修改血糖仪RTC，CHK为0xB1之后(包括0xA5)的字节的累加和。其他为要设置的时间。年为百年取余,即2016为16
     */
    UART_MODIFY_RTC: "09B1" as const,
    /**
     * 读取血糖记录，0<index<=recordno，1表示最新的测试结果
     */
    UART_Read_RCD: "05AF00" as const,
} as const;

// 定义UART响应常量
const UartResponse = {
    // 读取修改时间反馈前缀
    RESPONSE_RTC_PREFIX: "0208A2" as const,
    // 读取指定索引记录
    RESPONSE_RECORD_PREFIX: "02095F" as const,
    // 读取血糖记录条数反馈前缀
    RESPONSE_RECORD_NO_PREFIX: "0204BE" as const,
    // 年份偏移反馈前缀
    RESPONSE_YEAR_OFFSET_PREFIX: "02055B002A" as const,
} as const;


// 绑定、测量过程状态
export const BleScanMeasureState = {
    LOCATION_CLOSE: new ScaleMeasure(-6,
        "未开启定位",
        "请先打开系统定位才能更快地找到设备哦~",
        imgUrlFormat('common/fail.png'), false, '连接仪器'),

    BLE_CLOSE: new ScaleMeasure(-5,
        "蓝牙已关闭",
        "请先打开蓝牙才能进行绑定或测量哦~",
        imgUrlFormat('common/fail.png'), false, '打开蓝牙'),

    BLE_AUTHORIZE: new ScaleMeasure(-4,
        "蓝牙未授权",
        "请先打开小程序设置，允许蓝牙授权",
        imgUrlFormat('common/fail.png'), false, '打开设置'),
    BLE_DISABLE: new ScaleMeasure(-1,
        "蓝牙未开启",
        "请先打开手机蓝牙才能进行绑定或测量哦~",
        imgUrlFormat('common/fail.png'), false, '打开蓝牙'),

    /**
     * SDK初始化 异常
     */
    SDK_ERROR: new ScaleMeasure(-2, "蓝牙初始化异常", "请联系客服进行咨询", imgUrlFormat('common/fail.png')),

    /**
     * SDK扫描异常
     */
    SCAN_ERROR: new ScaleMeasure(-3, "扫描异常", "请联系客服进行咨询", imgUrlFormat('common/fail.png')),

    /**
     * 未绑定状态
     */
    UNBIND: new ScaleMeasure(0, "血糖仪绑定", "为数据上传成功，请持续开启蓝牙。请勿关闭。"),

    /**
     * 绑定失败
     */
    BIND_FAILURE: new ScaleMeasure(
        1,
        "血糖仪绑定失败",
        "注意将手机蓝牙打开，并打开血糖仪进行设备绑定",
        imgUrlFormat('common/fail.png'),
        false,
        "重新绑定",
    ),

    /**
     * 未绑定-扫描中
     */
    UNBIND_SCANING: new ScaleMeasure(
        2,
        "血糖仪绑定",
        "请耐心等待扫描完成哦~",
        imgUrlFormat('common/load_mark.png'),
        true,
    ),

    /**
     * 未绑定-扫描超时
     */
    UNBIND_SCAN_TIMEOUT: new ScaleMeasure(
        3,
        "扫描超时",
        "注意将手机蓝牙打开，并打开血糖仪进行绑定",
        imgUrlFormat('common/fail.png'),
        false,
        "重新扫描",
    ),

    /**
     * 未绑定-扫描失败
     */
    UNBIND_SCAN_FAILURE: new ScaleMeasure(
        4,
        "血糖仪绑定",
        "扫描结束，请重新扫描",
        imgUrlFormat('common/fail.png'),
        true,
        "重新扫描",
    ),

    /**
     * 已绑定-待开始扫描
     */
    BIND_TO_SCAN: new ScaleMeasure(5, "血糖仪测量", "为数据上传成功，请持续开启蓝牙。请勿关闭。"),

    /**
     * 已绑定-扫描中
     */
    BIND_SCANING: new ScaleMeasure(
        6,
        "正在扫描设备",
        "请耐心等待扫描完成哦~",
        imgUrlFormat('common/load_mark.png'),
        true,
    ),

    /**
     * 已绑定-扫描超时
     */
    BIND_SCAN_TIMEOUT: new ScaleMeasure(
        7,
        "扫描超时",
        "注意将手机蓝牙打开，并打开血糖仪进行测量",
        imgUrlFormat('common/fail.png'),
        false,
        "重新扫描",
    ),

    /**
     * 已绑定-扫描失败
     */
    BIND_SCAN_FAILURE: new ScaleMeasure(
        8,
        "扫描失败",
        "注意将手机蓝牙打开，并打开血糖仪进行测量",
        imgUrlFormat('common/fail.png'),
        false,
        "重新扫描",
    ),

    SCAN_EMPTY: new ScaleMeasure(
        9,
        "扫描结束",
        "注意将手机蓝牙打开，并打开血糖仪进行测量",
        null,
        false,
        "重新扫描"
    ),

    CONNECTING: new ScaleMeasure(
        10,
        "连接设备",
        "正在连接中，请稍候",
        imgUrlFormat('common/success.png')
    ),

    CONNECT_SUCCESS: new ScaleMeasure(
        12,
        "连接成功",
        "请开始进行测量",
        imgUrlFormat('common/success.png')
    ),
    CONNECT_FAILURE: new ScaleMeasure(
        11,
        "连接失败",
        "注意将手机蓝牙打开，并打开血糖仪进行连接",
        imgUrlFormat('common/fail.png'), false,
        "重新连接"
    ),

    /**
     * 已绑定-扫描成功-找到绑定的设备
     */
    BIND_SCAN_SUCCESS: new ScaleMeasure(
        13,
        "血糖仪测量",
        "扫描成功，即将开始连接，请准备进行测量",
        imgUrlFormat('common/success.png'),
        true,
    ),

    /**
     * 已绑定-测量中
     */
    BIND_MEASURING: new ScaleMeasure(
        14,
        "正在测量",
        "请滴入血样，开始测量",
        imgUrlFormat('common/load_mark.png'),
        true,
    ),

    /**
     * 测量失败
     */
    BIND_MEASURE_FAILURE: new ScaleMeasure(
        15,
        "测量失败",
        "测量失败，请重新进行血糖测量哦～",
        imgUrlFormat('common/fail.png'),
    ),

    /**
     * 测量成功
     */
    BIND_MEASURE_SUCCESS: new ScaleMeasure(
        16,
        "测量成功",
        "恭喜您血糖数据上传成功",
        imgUrlFormat('common/success.png'),
    ),

    BIND_MEASURE_FINISH: new ScaleMeasure(
        17,
        "测量结束",
        "本次血糖测量结束",
        imgUrlFormat('common/success.png')
    ),
    /**
     * 断开连接
     */
    LOST_CONNECT: new ScaleMeasure(
        18,
        "连接已断开",
        "为数据上传成功，请持续开启蓝牙。请勿关闭。",
        imgUrlFormat('common/fail.png'),
        false, "重新连接",
    ),
    SERVICE_NOT_EXIST: new ScaleMeasure(
        19,
        "测量异常",
        "请联系客服进行咨询",
    ),
    SERVICE_NOT_FOUND: new ScaleMeasure(
        20,
        "测量失败",
        "请联系客服进行咨询",
    ),
    UPLOAD_FAILURE: new ScaleMeasure(
        21,
        "上传失败",
        "请稍等几秒钟重新上传",
        "重新上传"
    ),
    MEASURE_TIMEOUT: new ScaleMeasure(
        22,
        "测量超时",
        "请稍等几秒钟重新上传",
        "重新上传"
    ),

}


