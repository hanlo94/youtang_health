export default definePageConfig({
    navigationBarTitleText: "雅思血糖仪",
});
