<template>

  <view class="container_body_yasi">
    <view class="card_bg">
      <view class="card">
        <view class="top_tips">
          <image class="icon" :src="measureState.icon" mode="widthFix"></image>
          <view>{{ measureState.mainState }}</view>
        </view>
        <view class="sub_tips">{{ measureState.subState }}</view>

        <view class="tips">
          注意事项：
          <ul>
            <li>1.注意将手机蓝牙打开，并打开血糖仪进行测量</li>
          </ul>
        </view>

        <!--    背景    -->
        <view class="round_box">
          <view class="round">
            <view class="round1">
              <view class="round2">
                <view class="round3">
                  <image class="device_img" mode="heightFix"
                         :src="imgUrlFormat('sugar/glucometer_pic.png')" alt=""/>
                </view>
              </view>
            </view>
          </view>
        </view>
      </view>
    </view>
    <!--  按钮  -->
    <view v-if="scaleMeasureState?.retryBtnText" class="retry" @click.stop="onRetryBtnClick">
      <nut-button type="info" class="btn">{{ scaleMeasureState?.retryBtnText }}</nut-button>
    </view>
  </view>
</template>
<script lang="ts" setup>
import Taro from "@tarojs/taro";
import {onMounted, ref, computed, onUnmounted, onBeforeMount} from "vue";
import {ScaleMeasure} from "@/config/device/bodyfat";
import {BleScanMeasureState, DeviceUUID} from "@/pagesMine/yasiGlm/config/YasiGluConstants";
import {useMainPageStore} from "@/utils/storeUtils";
import SugarApi from "@/api/modules/sugar";
import imgUrlFormat from "@/utils/imgUtils";
import {showToast, showToastLong} from "@/utils/toastUtils";
import {getCurrentInstance} from "@tarojs/runtime";
import {formatCurrentIndex, formatTime} from "@/utils/util";
import {IBleGluUploadData} from "@/api/types";

const scaleMeasureState = ref<ScaleMeasure>()
const bindState = ref<boolean>(false)

// 是否已连接
const connected = ref<boolean>(false)
const connecting = ref<boolean>(false)
const scanning = ref<boolean>(false)

const connectedDevice = ref()
const measureState = computed(() => {
  const res = {
    state: scaleMeasureState.value?.state,
    icon: scaleMeasureState.value?.icon,
    mainState: scaleMeasureState.value?.mainState,
    subState: scaleMeasureState.value?.subState,
    retryBtn: scaleMeasureState.value?.retryBtnText
  }
  return res;
})

const upload = ref<IBleGluUploadData>()

const timer = ref<number>(0)

const logger = () => {
  const realTimeLogger = Taro.getRealtimeLogManager && Taro.getRealtimeLogManager()
  const wxLogger =
      Taro.getLogManager &&
      Taro.getLogManager({
        level: 0,
      });
  const log = (...params) => {
    console.log(...params);
    realTimeLogger && realTimeLogger.info(...params)
    wxLogger && wxLogger.log(...params);
  };
  return {
    log,
  };
};

// region 页面生命周期

onBeforeMount(() => {
  console.log('index.onBeforeMount.')
  let {isBind} = getCurrentInstance().router?.params
  bindState.value = isBind
})

onMounted(() => {
  console.log('index.onMounted.')
  updateState(BleScanMeasureState.BIND_TO_SCAN)
  checkBlePermission()
})

onUnmounted(() => {
  console.log('index.onUnmounted.')
  stopBle()
})

// endregion

// region 蓝牙权限与蓝牙适配器状态操作

/**
 * 检验蓝牙授权状态
 */
const checkBlePermission = (silent: boolean = false) => {
  console.log('index.checkBlePermission.silent=', silent)
  Taro.getSetting({
    success(res) {
      logger().log("index.vue.checkBlePermission.getSetting.success.res.authSetting=", res.authSetting);
      if (!res.authSetting['scope.bluetooth']) {
        Taro.authorize({
          scope: 'scope.bluetooth',
          success: (res) => {
            // showShortToast('蓝牙授权成功')
            logger().log("checkBlePermission.authorize.success.", JSON.stringify(res));
            openBluetoothAdapter()
          },
          fail: (res) => {
            // showShortToast('蓝牙授权失败')
            logger().log('蓝牙授权失败', JSON.stringify(res))
            if (!silent) {
              showBleAuthorizeModal()
            }
            onBleAuthorize()
          }
        })
      } else {
        // checkBleAdapterState()
        openBluetoothAdapter()
      }
    },
    fail(res) {
      console.log('index.checkBlePermission.fail.', JSON.stringify(res))
      if (!silent) {
        showBleAuthorizeModal()
      }
      onBleAuthorize()
    }
  })
}

/**
 * 校验蓝牙适配器状态
 */
const checkBleAdapterState = () => {
  Taro.getBluetoothAdapterState({
    success: (res) => {
      console.log("index.vue.checkBleAdapterState.success.", JSON.stringify(res));
      // startScan()
    },
    fail: (failure) => {
      console.log("index.vue.checkBleAdapterState.fail.", JSON.stringify(failure));
      // openBluetoothAdapter()
    }
  })
}

/**
 * 打开蓝牙适配器
 */
const openBluetoothAdapter = () => {
  const systemSetting = Taro.getSystemSetting()
  const bleEnabled = systemSetting.bluetoothEnabled;
  const locationEnabled = systemSetting.locationEnabled;
  Taro.openBluetoothAdapter({
    success: (res) => {
      logger().log("index.vue.openBluetoothAdapter.success.", JSON.stringify(res));
      if (locationEnabled) {
        startScan()
        updateState(bindState.value ? BleScanMeasureState.BIND_TO_SCAN : BleScanMeasureState.UNBIND)
      } else {
        updateState(BleScanMeasureState.LOCATION_CLOSE)
        showBleDisableModal(BleScanMeasureState.LOCATION_CLOSE.subState)
      }
    },
    fail: (res) => {
      logger().log("index.vue.openBluetoothAdapter.fail.", JSON.stringify(res), '; JSON.stringify(res).indexOf(\'openBluetoothAdapter:fail already opened = ', JSON.stringify(res).indexOf('openBluetoothAdapter:fail already opened'));
      if (JSON.stringify(res).indexOf('openBluetoothAdapter:fail already opened') != -1) {
        console.log('index.openBluetoothAdapter,already opened.start scan')
        if (locationEnabled) {
          startScan()
          updateState(bindState.value ? BleScanMeasureState.BIND_TO_SCAN : BleScanMeasureState.UNBIND)
        } else {
          updateState(BleScanMeasureState.LOCATION_CLOSE)
          showBleDisableModal(BleScanMeasureState.LOCATION_CLOSE.subState)
        }
      } else {
        console.log('index.openBluetoothAdapter,failed')
        let str
        if (!bleEnabled && !locationEnabled) {
          str = '手机蓝牙、定位未打开，请先打开手机蓝牙、定位权限'
        } else if (!bleEnabled) {
          str = BleScanMeasureState.BLE_DISABLE.subState
        } else {
          str = BleScanMeasureState.LOCATION_CLOSE.subState
        }
        showBleDisableModal(str)
        onBleDisable()
      }
    },
    complete: () => {
      onBleAdapterState()
    }
  })
}


const closeBluetoothAdapter = () => {
  Taro.closeBluetoothAdapter({
    success: (res) => {
      logger().log("index.vue.closeConnect.success.", JSON.stringify(res));
    },
    fail: (res) => {
      logger().log("index.vue.closeConnect.fail.", JSON.stringify(res));
    }
  })
}

const onBleAdapterState = () => {
  Taro.onBluetoothAdapterStateChange(res => {
    if (res.available) {
      // 蓝牙适配器可用
      logger().log("onBluetoothAdapterStateChange 蓝牙适配器可用, scaleMeasureState.value?.state=", scaleMeasureState.value?.state);
      if (scaleMeasureState.value?.state == BleScanMeasureState.BLE_DISABLE.state) {
        const systemSetting = Taro.getSystemSetting()
        if (systemSetting.locationEnabled) {
          updateState(bindState.value ? BleScanMeasureState.BIND_TO_SCAN : BleScanMeasureState.UNBIND)
          restart()
        } else {
          updateState(BleScanMeasureState.LOCATION_CLOSE)
          showToastLong("位置信息未开启，请先打开")
        }
      }
    } else {
      // 蓝牙适配器不可用
      logger().log("onBluetoothAdapterStateChange 蓝牙适配器不可用");
      stopBle(false)
      onBleDisable()
    }
  })
}

//
const onBleDisable = () => {
  updateState(BleScanMeasureState.BLE_DISABLE)
}

const onBleAuthorize = () => {
  updateState(BleScanMeasureState.BLE_AUTHORIZE)
}

// endregion

// region  扫描与连接

const startScan = () => {
  console.log('index.startScan.')
  Taro.startBluetoothDevicesDiscovery({
    allowDuplicatesKey: false,
    services: [
      DeviceUUID.SERV_GLUCOSE_UUID,
      DeviceUUID.SERV_GLUCOSE_UUID_UPPER,
      DeviceUUID.SERV_DEVINFO_UUID,
      DeviceUUID.SERV_DEVINFO_UUID_UPPER
    ],
    complete: (res) => {
      // 扫描结束
      logger().log("startScan 开启扫描结束 ", JSON.stringify(res));
    },
    success: (res) => {
      console.log('index.startScan.success.', JSON.stringify(res))
      scanning.value = true
      onBluetoothDeviceFound(res)
      updateState(bindState.value ? BleScanMeasureState.BIND_SCANING : BleScanMeasureState.UNBIND_SCANING)
      timer.value = startTimer(timeOut);
      showToastLong("开始扫描仪器")
      console.log('index.success. startTimer in startScan ', timer.value, '; time is ', Date.now())
    },
    fail: (res) => {
      logger().log("index.vue.startScan.fail.", JSON.stringify(res), '; res.errMsg=', res.errMsg, ';res.errMsg.indexOf(\'already discovering devices\') != -1=', (res.errMsg.indexOf('already discovering devices') != -1));
      if (res.errMsg && res.errMsg.indexOf('already discovering devices') != -1) {
        // 已开启扫描
        console.log('index.startScan.fail.already stop then start ')
      } else {
        updateState(bindState.value ? BleScanMeasureState.BIND_SCAN_FAILURE : BleScanMeasureState.UNBIND_SCAN_FAILURE)
        logger().log('index.start scan fail. update state', scaleMeasureState.value?.mainState)
      }
    }
  })
}

const stopScan = (callback: ActionCallback | null = null) => {
  console.log('index.stopScan.scanning.value=', scanning.value)
  if (scanning.value) {
    console.log('index.stopScan.scanning.value=', scanning.value)
    Taro.stopBluetoothDevicesDiscovery({
      success: (res) => {
        logger().log("index.vue.stopScan.success.", JSON.stringify(res));
        scanning.value = false
        callback && callback()
      },
      fail: (res) => {
        logger().log("index.vue.stopScan.fail.", JSON.stringify(res));
      },
      complete: (res) => {
        console.log('index.complete.stopBluetoothDevicesDiscovery', JSON.stringify(res))
      }
    })
  } else {
    callback && callback()
  }
}

/**
 * 扫描发现设备监听
 * @param res
 */
const onBluetoothDeviceFound = (res) => {
  console.log('index.onBluetoothDeviceFound.', JSON.stringify(res))
  Taro.onBluetoothDeviceFound((res) => {
    res.devices.forEach(device => {
      if (!device.name && !device.localName) {
        console.log('index.onBluetoothDeviceFound 过滤设备名称为空')
        return
      }
      if (device.name.indexOf("未知") != -1) {
        console.log('index.onBluetoothDeviceFound 过滤 设备名称异常')
        return;
      }
      if (!device.advertisServiceUUIDs || device.advertisServiceUUIDs.length === 0) {
        console.log('index.onBluetoothDeviceFound 过滤开放服务为空 deviceId=', device.deviceId)
        return
      }
      //     "00001808-0000-1000-8000-00805f9b34fb",
      //     "0000180a-0000-1000-8000-00805f9b34fb"
      if (device.advertisServiceUUIDs.indexOf(DeviceUUID.SERV_GLUCOSE_UUID) != -1 || device.advertisServiceUUIDs.indexOf(DeviceUUID.SERV_GLUCOSE_UUID_UPPER) != -1) {
        console.log('index.onBluetoothDeviceFound index of 发现匹配服务', device.advertisServiceUUIDs)
      } else {
        console.log('index.onBluetoothDeviceFound index of 未找到匹配服务', device.advertisServiceUUIDs)
        return;
      }
      console.log('onBluetoothDeviceFound device=', JSON.stringify(device), '; connectedDevice.value=', connectedDevice.value)
      if (!connectedDevice.value) {
        connectedDevice.value = device
        showToast('扫描成功，找到匹配设备')
        updateState(BleScanMeasureState.BIND_SCAN_SUCCESS)
      }
      stopScan()
      startConnect()
      // const foundDevices = this.data.devices
      // const idx = inArray(foundDevices, 'deviceId', device.deviceId)
      // const data = {}
      // if (idx === -1) {
      //   data[`devices[${foundDevices.length}]`] = device
      // } else {
      //   data[`devices[${idx}]`] = device
      // }

    })
  })
}

const startConnect = () => {
  if (connected.value) {
    // 已连接
    logger().log("startConnect 已连接 不重复连接")
    return
  }
  if (!connecting.value) {
    connecting.value = true
  } else {
    // 连接中
    logger().log("startConnect 连接中不重复连接")
    return
  }
  updateState(BleScanMeasureState.CONNECTING)
  console.log('index.startConnect.device.value=', connectedDevice.value)
  let {deviceId} = connectedDevice.value
  Taro.createBLEConnection({
    deviceId,
    success: function (res) {
      console.log('index.createBLEConnection.success.', JSON.stringify(res))
      onConnectionStateChange()
    },
    fail: function (res) {
      console.log('index.startConnect.createBLEConnection.fail.', JSON.stringify(res))
      updateState(BleScanMeasureState.CONNECT_FAILURE)
    }
  })

}

const onConnectFailure = () => {
  logger().log("onConnectFailure.")
  connected.value = false
  connecting.value = false
  updateState(BleScanMeasureState.LOST_CONNECT)
}

const onConnectSuccess = () => {
  console.log('index.onConnectSuccess.')
  connected.value = true
  updateState(BleScanMeasureState.CONNECT_SUCCESS)
  startMeasure()
}

const onConnectionStateChange = () => {
  console.log('index.onConnectionStateChange.')
  Taro.onBLEConnectionStateChange((res) => {
    console.log('onConnectionStateChange', `device ${res.deviceId} state has changed, connected: ${res.connected}`)
    if (res.connected) {
      onConnectSuccess()
    } else {
      onConnectFailure()
    }
  })
}

const offBLEConnectionStateChange = () => {
  Taro.offBLEConnectionStateChange((res) => {
    console.log('onConnectionStateChange', `device ${res.deviceId} state has changed, connected: ${res.connected}`)
  })
}

const startMeasure = () => {
  console.log('index.startMeasure.')
  let {deviceId} = connectedDevice.value
  Taro.getBLEDeviceServices({
    deviceId,
    success: (res) => {
      console.log('index.getBLEDeviceServices.success.', JSON.stringify(res))
      // 查找特定服务 ，找到继续查找特征值，找不到直接反馈失败
      let bleService;
      if (res.services && res.services.length > 0) {
        bleService = res.services.find(service =>
            service.uuid.indexOf(DeviceUUID.SERV_GLUCOSE_UUID_PREFIX) != -1
        );
      }
      if (bleService) {
        updateState(BleScanMeasureState.BIND_MEASURING)
        showToastLong("开始测量")
        getBleCharacteristics(deviceId, bleService.uuid)
      } else {
        updateState(BleScanMeasureState.SERVICE_NOT_FOUND)
      }

    },
    fail: (res) => {
      logger().log('index.getBLEDeviceServices.fail.', JSON.stringify(res))
      updateState(BleScanMeasureState.SERVICE_NOT_EXIST)
    }
  })
}

const getBleCharacteristics = (deviceId: string, serviceId: string) => {
  Taro.getBLEDeviceCharacteristics({
    deviceId,
    serviceId,
    success: (res) => {
      console.log('index.getBLEDeviceCharacteristics.success.', JSON.stringify(res))
      let characteristic
      if (res.characteristics && res.characteristics.length > 0) {
        characteristic = res.characteristics.find(characteristic =>
            characteristic.uuid.toUpperCase().indexOf(DeviceUUID.GLUCOSE_MEAS_UUID) != -1
        );
      }
      if (characteristic) {
        // 找到特征值
        console.log('index.getBLEDeviceCharacteristics.success. 找到特征值', JSON.stringify(characteristic))
        // 开始读特征值
        notifyCharacteristicValueChange(deviceId, serviceId, characteristic.uuid)
      } else {
        updateState(BleScanMeasureState.SERVICE_NOT_FOUND)
      }
    },
    fail: (res) => {
      logger().log('index.getBLEDeviceCharacteristics.fail.', JSON.stringify(res))
      updateState(BleScanMeasureState.SERVICE_NOT_EXIST)
    }
  })
}

const notifyCharacteristicValueChange = (deviceId: string, serviceId: string, uuid: string) => {
  Taro.notifyBLECharacteristicValueChange({
    state: true,
    deviceId,
    serviceId,
    characteristicId: uuid,
    success: (res) => {
      logger().log('index.notifyBLECharacteristicValueChange.success.', JSON.stringify(res))
      onCharacteristicValueChange()
    },
    fail: (res) => {
      logger().log('index.notifyBLECharacteristicValueChange.fail.', JSON.stringify(res))
    }
  })
}

const onCharacteristicValueChange = () => {
  logger().log("onCharacteristicValueChange.")
  Taro.onBLECharacteristicValueChange((res) => {
    let hexString = ab2hex(res.value);
    logger().log(`onBLECharacteristicValueChange.characteristic ${res.characteristicId} has changed, now is ${res.value}`, '; parseValue=', hexString)
    // 470000e707011e0408240000f08a11
    analysisData(hexString)
  })
}

const offCharacteristicValueChange = () => {
  logger().log("offCharacteristicValueChange.")
  Taro.offBLECharacteristicValueChange((res) => {
    logger().log('index.onBLECharacteristicValueChange', JSON.stringify(res))
  })
}


const disConnect = () => {
  logger().log("disConnect.", connectedDevice.value)
  const {deviceId} = connectedDevice.value
  offBLEConnectionStateChange()
  Taro.closeBLEConnection({
    deviceId,
    success: (res) => {
      logger().log('index.closeBLEConnection.success.', JSON.stringify(res))
      connected.value = false
      connecting.value = false
      connectedDevice.value = null
    },
    fail: (res) => {
      logger().log('index.closeBLEConnection.fail.', JSON.stringify(res))
    }
  })
}


/**
 * 停止蓝牙活动
 * 1、
 * 2、关闭连接
 * 3、停止扫描
 * 4、关闭蓝牙适配器
 */
const stopBle = function (closeBleAdapter: boolean = true) {
  if (connected.value) {
    offCharacteristicValueChange()
    disConnect()
  }
  clearTimer()
  stopScan()
  if (closeBleAdapter) {
    closeBluetoothAdapter()
  }
}

/**
 * 刷新蓝牙
 */
const restart = () => {
  console.log('index.restart.')
  if (connected.value) {
    offCharacteristicValueChange()
    disConnect()
  }
  stopScan(() => {
    startScan()
  })
}

// endregion

// region 计时器
/**
 * 扫描计时器
 * @param callback
 * @param timeout 默认10s超时
 */
const startTimer = (callback: ActionCallback | null = null, timeout: number = 10000) => {
  console.log('index.startTimer.current time is ', Date.now())
  return setInterval(() => {
    callback && callback()
  }, timeout)
}

const timeOut: ActionCallback = () => {
  console.log('index.timeOut.', scaleMeasureState.value, '; current time is ', Date.now())
  if (!connectedDevice.value) {
    updateState(BleScanMeasureState.BIND_SCAN_TIMEOUT)
    showToastLong("扫描失败，请重新点击连接仪器")
    stopScan()
  }
  clearTimer()
}

interface ActionCallback {
  (): void
}

const clearTimer = () => {
  if (timer.value) {
    clearInterval(timer.value)
    timer.value = 0
  }
}


// endregion

// region 页面逻辑操作

const mainPageStore = useMainPageStore()

// ArrayBuffer转16进度字符串示例
function ab2hex(buffer) {
  const hexArr = Array.prototype.map.call(
      new Uint8Array(buffer),
      function (bit) {
        return ('00' + bit.toString(16)).slice(-2)
      }
  )
  return hexArr.join('');
}


const analysisData = (hexString) => {
  logger().log("analysisData.", '构造前', JSON.stringify(hexString));
  const sugarValue = parseSugarValue(hexString.substring(hexString.length - 6, hexString.length - 2));
  // 获取当前时间
  let date = new Date();
  const recordTime = formatTime(date)
  // 根据当前时间获取默认时段
  let timeIndex = formatCurrentIndex(date.getHours())
  // 方法返回值与实际定义的时段不一致，凌晨实际为7，其余项需要减去1  肖 2024-01-30 10:26:50
  if (timeIndex == 0) {
    timeIndex = 7;
  } else {
    timeIndex -= 1
  }
  let {deviceId} = connectedDevice.value
  logger().log("index.vue.analysisData.deviceId=", deviceId);

  upload.value= {
    recordValue: sugarValue,
    recordTime,
    timeType: timeIndex,
    deviceSn: deviceId
  }
  uploadData()
}

function parseSugarValue(valueHexStr: string): number {
  const n: number = parseInt(valueHexStr.charAt(1) + valueHexStr.charAt(0), 16);
  const m: number = parseInt(valueHexStr.substring(2), 16);
  logger().log(`parseSugarValue: valueStr=${valueHexStr};n=${n}; m =${m}`);
  return m * Math.pow(10, n - 16);
}

const uploadData = () => {
  console.log('index.uploadData.', JSON.stringify(upload.value))
  let response = SugarApi.uploadYasiBleRecord(upload.value!!);
  if (response) {
    response.then((res) => {
      logger().log("index.vue.uploadData..success", JSON.stringify(res));
      showToastLong('测量成功')
      updateState(BleScanMeasureState.BIND_MEASURE_SUCCESS)
      mainPageStore.refreshPage()
      stopBle()
      Taro.redirectTo({
        url: '/pagesSugarAnalysis/sugarAnalysis'
      })
    }, (failure) => {
      logger().log("index.vue.uploadData..failure", failure)
      updateState(BleScanMeasureState.BIND_MEASURE_FAILURE)
    }).catch((error) => {
      console.log("index.vue.uploadData..error", error);
    })
  }
}

// endregion

// region 页面更新、响应页面事件
const onRetryBtnClick = () => {
  console.log('index.onRetryBtnClick.scaleMeasureState.value=', scaleMeasureState.value)
  switch (scaleMeasureState.value?.state) {
    case BleScanMeasureState.BIND_TO_SCAN.state:
    case BleScanMeasureState.UNBIND.state:
      if (!scanning.value) {
        updateState(BleScanMeasureState.BIND_TO_SCAN)
        checkBlePermission()
      } else {
        restart()
      }
      break;
    case BleScanMeasureState.LOCATION_CLOSE.state:
      const systemSetting = Taro.getSystemSetting()
      const locationEnabled = systemSetting.locationEnabled;
      if (locationEnabled) {
        checkBlePermission()
      } else {
        showBleDisableModal(BleScanMeasureState.LOCATION_CLOSE.subState)
      }
      break;
    case BleScanMeasureState.BIND_SCAN_FAILURE.state:
    case BleScanMeasureState.BIND_SCAN_TIMEOUT.state:
    case BleScanMeasureState.UNBIND_SCAN_TIMEOUT.state:
    case BleScanMeasureState.UNBIND_SCAN_FAILURE.state:
    case BleScanMeasureState.LOST_CONNECT.state:
    case BleScanMeasureState.CONNECT_FAILURE.state:
    case BleScanMeasureState.BIND_MEASURE_SUCCESS.state:
      updateState(bindState.value ? BleScanMeasureState.BIND_TO_SCAN : BleScanMeasureState.UNBIND)
      // restart()
      checkBlePermission()
      break;
    case BleScanMeasureState.BIND_MEASURE_FAILURE.state:
      uploadData()
      break;
    case BleScanMeasureState.BLE_DISABLE.state:
      // let systemInfo = Taro.getSystemInfoSync();
      // if (systemInfo.platform === 'ios') {
      //   Taro.showModal({
      //     title: '提示',
      //     content: '请先打开手机蓝牙开关？',
      //     showCancel: false,
      //
      //   })
      // } else {
      //   Taro.openSystemBluetoothSetting(
      //       {
      //         success: (res) => {
      //           console.log("index.vue.updateState..success", res);
      //           checkBleAdapterState()
      //           onBleAdapterState()
      //         },
      //         fail: (res) => {
      //           console.log("index.vue.updateState..fail", res);
      //         }
      //       }
      //   );
      // }
      showBleDisableModal();
      // checkBlePermission();
      break;
    case BleScanMeasureState.BLE_AUTHORIZE.state:
      logger().log('index.onRetryBtnClick.BLE_AUTHORIZE')
      Taro.openSystemBluetoothSetting({
        success: (res) => {
          console.log('index.onRetryBtnClick.BLE_AUTHORIZE.success.res=', JSON.stringify(res))
        }
      })
      break;
    case BleScanMeasureState.UNBIND_SCANING.state:
    case BleScanMeasureState.BIND_SCANING.state:
      showToastLong("正在扫描仪器，请稍候")
      break;
    default:
      console.log('index.onRetryBtnClick.default')
      break;
  }
}


const showBleDisableModal = (str: string | null = null) => {
  Taro.showModal({
    content: str || '手机蓝牙未开启，请先打开手机蓝牙',
    showCancel: false,
    confirmText: '知道了'
  })
}

const showBleAuthorizeModal = () => {
  Taro.showModal({
    content: BleScanMeasureState.BLE_AUTHORIZE.subState,
    showCancel: false,
    confirmText: '知道了',
    success: (res) => {
      Taro.openSystemBluetoothSetting({
        success: (res) => {
          console.log('index.showBleAuthorizeModal.BLE_AUTHORIZE.success.res=', JSON.stringify(res))
        }
      })
      // Taro.openSetting({
      //   success: (res) => {
      //     console.log('index.showBleAuthorizeModal.BLE_AUTHORIZE.success.res=', JSON.stringify(res))
      //   }
      // })
    }
  })
}

const updateState = (state) => {
  console.log("index.vue.updateState.", JSON.stringify(state));
  scaleMeasureState.value = state
}

const showPageBleState = () => {
  console.log('index.showPageBleState. state =', scaleMeasureState.value)
  // // if (scaleMeasureState.value?.retryBtnText) {
  // btButton.value = scaleMeasureState.value?.retryBtnText!!
  // // }
  // if (!btButton.value || btButton.value == '重新扫描') {
  //   btButton.value = "连接仪器"
  // }
  switch (scaleMeasureState.value?.state) {

    case BleScanMeasureState.BLE_AUTHORIZE.state:

      break;
    case BleScanMeasureState.LOCATION_CLOSE.state:

      break;
    case BleScanMeasureState.BLE_DISABLE.state:

      break;
    case BleScanMeasureState.BIND_TO_SCAN.state:
    case BleScanMeasureState.UNBIND.state:

      break;
    case BleScanMeasureState.BIND_SCANING.state:
    case BleScanMeasureState.UNBIND_SCANING.state:
      // 开启扫描成功

      break;
    case BleScanMeasureState.BIND_SCAN_FAILURE.state:
    case BleScanMeasureState.UNBIND_SCAN_FAILURE.state:
      // // 开启扫描失败
      // btIcon.value = imgUrlFormat('sugar/bluetooth_false.png');
      // btContent.value = "请扫描仪器蓝牙"
      // break;
    case BleScanMeasureState.BIND_SCAN_TIMEOUT.state:
      // btIcon.value = imgUrlFormat('sugar/bluetooth_false.png');
      // btContent.value = "连接仪器失败，请重新扫描仪器蓝牙"
      break;
    case BleScanMeasureState.SERVICE_NOT_EXIST.state:
    case BleScanMeasureState.SERVICE_NOT_FOUND.state:
      // 设备服务异常
      // btIcon.value = imgUrlFormat('sugar/bluetooth_false.png');
      // btContent.value = "设备异常，请联系客服"
      showToastLong("设备异常")
      break
    case BleScanMeasureState.CONNECT_FAILURE.state:
      showToastLong("雅斯GLM-76L血糖仪连接失败");
    case BleScanMeasureState.LOST_CONNECT.state:
      // btIcon.value = imgUrlFormat('sugar/bluetooth_true.png');
      // btTitle.value = "设备未连接"
      // btContent.value = "为数据上传成功，请持续开启蓝牙。请勿关闭。"
      break
    case BleScanMeasureState.BIND_MEASURING.state:
      // 开始测量
      showToastLong("请开始测量");
      // btContent.value = BleScanMeasureState.BIND_MEASURING.subState
      break
    case BleScanMeasureState.BIND_SCAN_SUCCESS.state:
      // 开始测量
      showToastLong("发现设备，开始扫描");
      break
    case BleScanMeasureState.CONNECT_SUCCESS.state:
      // 连接成功
      // btIcon.value = imgUrlFormat('sugar/bluetooth_true.png');
      // btTitle.value = "雅斯76L血糖仪设备已连接"
      // btContent.value = BleScanMeasureState.CONNECT_SUCCESS.subState
      // btButton.value = "查看数据"
      showToastLong("雅斯GLM-76L血糖仪连接成功");
      break;
    default:
      // btContent.value = "为数据上传成功，请持续开启蓝牙。请勿关闭。"
      break;
  }
}

// endregion


</script>
<style lang="less">
.icon {
  width: 44px;
  height: 44px;
}

.container_body_yasi {
  padding: 27.78px 20.84px;
  border-radius: 16.67px;

  .card_bg {
    background: white;
    z-index: -2;
    position: relative;
    min-height: 1150px;
    border-radius: 16.67px;

    .card {
      padding: 0 20.84px;

      .top_tips {
        font-size: 39.17px;
        font-weight: 600;

        display: flex;
        justify-content: center;
        align-items: center;
        padding-top: 120px;

        .icon {
          width: 27.78px;
          height: 27.78px;
          margin-right: 15px;
        }
      }

      .sub_tips {
        font-size: 33.17px;
        font-weight: 600;
        text-align: center;
        margin-top: 10px;
      }

      .tips {
        font-size: 30px;
        color: #5F5F5F;
        margin-top: 540px;
      }

      .bt_list {
        margin-top: 69px;

        .item {
          .bt_card {
            height: 106.25px;
            display: flex;
            justify-content: space-between;
            align-items: center;

            .left {
              .device_name {
                font-size: 33px;
                color: #353535;
              }

              .device_mac {
                font-size: 31.94px;
                color: #5F5F5F;
                margin-top: 28px;
              }
            }

            .right {
              .link_btn {
                width: 148.61px;
                height: 62.5px;
                border-radius: 51.39px;
                border-color: #64A4F5;

                font-size: 33.33px;
                color: #64A4F5;
                line-height: 30.28px;
              }
            }
          }

          .block {
            height: 35px;
            border-bottom: 1px solid #BBBBBB65;
            margin-bottom: 27.78px;
          }
        }
      }
    }


  }

  .btn {
    width: 666.67px;
    height: 97.22px;
    border-radius: 16.67px;
    background: #64A4F5;
    color: white;
    border: none;
    bottom: 50px;
    left: 41px;
    position: fixed;
  }

  .round_box {
    position: absolute;
    z-index: -1;
    top: 104px;
    left: 10px;

    display: flex;
    align-items: center;
    justify-content: center;

    .round {
      width: 694px;
      height: 694px;
      border-radius: 50%;
      border: 1px solid #64A4F550;
      display: flex;
      align-items: center;
      justify-content: center;

      .round1 {
        width: 555.56px;
        height: 555.56px;
        border-radius: 50%;
        border: 1px solid #64A4F550;
        display: flex;
        align-items: center;
        justify-content: center;

        .round2 {
          width: 416.67px;
          height: 416.67px;
          border-radius: 50%;
          border: 1px solid #64A4F550;
          display: flex;
          align-items: center;
          justify-content: center;

          .round3 {
            width: 277.78px;
            height: 277.78px;
            border-radius: 50%;
            border: 1px solid #64A4F550;
            display: flex;
            align-items: center;
            justify-content: center;
          }
        }
      }
    }
  }

  .device_img {
    width: 176.39px;
    height: 176.39px;
  }
}
</style>
