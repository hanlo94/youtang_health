<!--
Description：积分明细
Created on 2024-07-26
Author :  萧 -->
<template>
  <view class="points_history_root">
    <view class=" point_header ">
      <view class="header-content">
        <view class="horizontal patient">
<!--          <nut-avatar size="large" shape="round">-->
            <img class="img_header" :src="pointBalance.avatar"/>
<!--          </nut-avatar>-->
          <view class="vertical point-balance-root">
            <text class="name">{{ pointBalance.name }}</text>
            <view class="point-balance">
              <text class="points-header-value">{{ pointBalance.point }}</text>
              <text class="points-header-unit">积分</text>
            </view>
          </view>
        </view>

        <view class="point-rule" @click.stop="goPointRule">
          <text class="point-rule-text">规则</text>
        </view>

        <view class="point-header-bottom"/>

        <image class="image-icon" :src="imgUrlFormat('point/integralpic1.png')" mode="widthFix"/>
      </view>
    </view>

    <view class="round point-overdue " :class="pointBalance.overdueClass">
      <view class="circle-container"/>
      <view class="point-overdue-text">您有
        <text>{{ pointBalance.overduePoint }}</text>
        积分将于{{ pointBalance.overdueDate }}过期
      </view>
    </view>

    <view class="point_history round vertical">
      <nut-tabs class="tab" v-model="active" background="#ffffff" :animated-time="0"  title-gutter="10"
                color="#4aa4fc" @click="changeTab">
        <nut-tab-pane pane-key="1" title="积分收入" color="#4aa4fc"></nut-tab-pane>
        <nut-tab-pane pane-key="2" title="积分支出" color="#4aa4fc"></nut-tab-pane>
      </nut-tabs>
      <view class="history_list ">
        <scroll-view class="right" :scrollY="true" @scrollToLower="scroll" flexed>
          <view v-if="!isEmpty(dataList)" v-for="(item, index) in dataList" :key="index">
            <view class="vertical-container " style="margin-top: 30rpx">
              <view class="horizon-container">
                <view class="vertical-container">
                  <text class="task_name">{{ item.remark }}</text>
                  <text class="task_desc">{{ item.recordTime }}</text>
                </view>
                <view class="horizontal vertical-center" style="margin-right: 20rpx">
                  <image class="task_value_icon" :src="imgUrlFormat('point/integral2.png')" mode="scaleToFit"></image>
                  <text class="task_value">{{ item.changeValue }}</text>
                </view>
              </view>
              <view class="divider"></view>
            </view>
          </view>
          <view class="no_data vertical-center" v-else>
            <view class="vertical ">
              <image class="no-data-image" :src="imgUrlFormat('point/nodata.png')" mode="scaleToFit"></image>
              <text class="no-data-text"> {{ active == 1 ? "暂无积分收入记录" : "暂无积分支出记录" }}</text>
              <view @click.stop="onNoDataClick" v-if="active == 1" style="margin-top: 40rpx;justify-content: center;display: flex;">
                <text class="no-data-operation"> {{ active == 2 ? "快去兑换好礼" : "快去做任务赚积分" }}</text>
              </view>
            </view>
          </view>
          <!--          <view v-show="state.finished" class="on_the_bottom">已经到底了</view>-->
        </scroll-view>
      </view>
      <!--        </scroll-view>-->
    </view>

  </view>
</template>

<script setup lang="ts">
import {computed, onMounted, reactive, ref} from "vue";
import Taro from "@tarojs/taro";
import {isEmpty} from "lodash";
import PointApi, {PointBalance, PointHistoryRecord} from "@/pagesMine/api/points";
import imgUrlFormat from "@/utils/imgUtils";
import PageNavigation from "@/utils/pageNavigation";
import {showShortToast} from "@/utils/util";

const pointBalance = ref<PointBalance>({
  avatar:"https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/common/logo.png"
})

const active = ref(1)

const income = reactive({
  pointType: 1,
  page: 1,
  finished: false,
  pageSize: 20,
  list: [] as PointHistoryRecord[]
})

const outcome = reactive({
  pointType: 2,
  page: 1,
  finished: false,
  pageSize: 20,
  list: [] as PointHistoryRecord[]
})

// const incomeList = [
// {
//   imageUrl: image_url,
//   title: '邀请好友，送积分',
//   valueIconUrl: image_url,
//   value: '+2',
//   recordTime: '2024-07-29 15:47:27'
// },
// {
//   imageUrl: image_url,
//   title: '邀请好友，送积分',
//   valueIconUrl: image_url,
//   value: '+2',
//   recordTime: '2024-07-29 15:47:27'
// },
// ]

// const outcomeList = [
//   {
//     imageUrl: image_url,
//     title: '邀请好友，扣积分',
//     valueIconUrl: image_url,
//     value: '-2',
//     recordTime: '2024-07-29 15:47:27'
//   },
//   {
//     imageUrl: image_url,
//     title: '邀请好友，扣积分',
//     valueIconUrl: image_url,
//     value: '-2',
//     recordTime: '2024-07-29 15:47:27'
//   },
// ]

const dataList = computed(() => {
  return active.value == 0 ? income.list : outcome.list;
});

onMounted(() => {
  getBalance()
  getPointsHistory(income.pointType)
})

const getBalance = () => {
  PointApi.getBalance().then(res => {
    console.log("index.vue..points.index.res=", JSON.stringify(res));
    if (!res.data.overduePoint){
      res.data.overdueClass='hide-overdue'
    }
    if (!res.data.avatar || res.data.avatar.trim().length == 0) {
      res.data.avatar = pointBalance.value.avatar
    }
    pointBalance.value = res.data
  }).catch(err => {
    console.log('index.getBalance. err = ', JSON.stringify(err))
  })
}

const getPointsHistory = (pointType) => {
  const page = pointType == income.pointType ? income.page : outcome.page
  PointApi.getPointHistoryList(page, pointType).then(res => {
    console.log('index.getPointsHistory. page=', page, '; active=', active.value, '; response=', JSON.stringify(res))
    if (res && res.data && res.data.list && res.data.list.length > 0) {
      incomeOrOutCome(() => {
        if (page == 1) {
          income.list.length = 0
        }
        income.list.push(...res.data.list)
        income.page += 1
      }, () => {
        if (page == 1) {
          outcome.list.length = 0
        }
        outcome.list.push(...res.data.list)
        outcome.page += 1
      })
    } else {
      // 无数据
      incomeOrOutCome(() => {
        if (page == 1) {
          income.list.length = 0
        } else {
          income.finished = true
          showShortToast('没有更多了')
        }
      }, () => {
        if (page == 1) {
          outcome.list.length = 0
        } else {
          outcome.finished = true
          showShortToast('没有更多了')
        }
      })
    }
  }).catch(err => {
    console.log('index.getPointsHistory.error =', err)
  })
}

const scroll = () => {
  incomeOrOutCome(() => {
    if (income.finished) {
      showShortToast('没有更多了')
    } else {
      income.page++
      getPointsHistory(income.pointType)
    }
  }, () => {
    if (outcome.finished) {
      showShortToast('没有更多了')
    } else {
      outcome.page++
      getPointsHistory(outcome.pointType)
    }
  })
}

const changeTab = (res) => {
  let {paneKey} = res
  console.log('index.changeTab.paneKey=', paneKey, '; active=', active)
  if (paneKey == 1) {
    income.page = 1
    income.finished = false
  } else if (paneKey == 2) {
    outcome.page = 1
    outcome.finished = false
  }
  getPointsHistory(paneKey)
}

const incomeOrOutCome = (incomeMethod, outComeMethod) => {
  if (active.value == 0) {
    incomeMethod && incomeMethod()
  } else {
    outComeMethod && outComeMethod()
  }
}

const goPointRule = () => {
  PageNavigation.openPointRule()
}

const onNoDataClick = () => {
  console.log('index.onNoDataClick.active=', active)
  if (active.value == 2) {
    goDeduction()
  } else {
    Taro.navigateBack({
      delta: 1
    })
  }
}

const goDeduction = () => {
  // 打开小程序
  console.log('index.goDeduction.')
  Taro.navigateToMiniProgram({
    appId: 'wx0f46682f8af98432',
    path: '"/pages/integral/goods/list"',
    success(res) {
      // 打开成功
      console.log("mall.js.success.", JSON.stringify(res));
    },
    fail(res) {
      console.log("mall.js.fail.", JSON.stringify(res));
    }
  })
};

</script>

<style lang="less">
.points_history_root {
  height: 100vh;

  .point_header {
    background: #4aa4fc;
    width: 100%;
    height: 248rpx;

    .header-content {
      position: relative;
      width: 100%;

      .patient {
        position: absolute;
        align-items: start;
        top: 42rpx;
        left: 20rpx;

        .img_header {
          border: #6aa4fc solid 1px;
          width: 120px;
          border-radius: 50%;
          height: 120px;
        }

        .point-balance-root {
          margin-left: 12rpx;

          .name {
            font-size: 30rpx;
            color: white;
          }

          .point-balance {
            display: flex;
            align-items: flex-end;
            flex-direction: row;

            .points-header-value {
              color: #FFFFFF;
              font-size: 80rpx;
              font-weight: bold;
            }

            .points-header-unit {
              color: white;
              margin-bottom: 24px;
              margin-left: 10rpx;
              font-size: 24rpx;
            }

          }
        }
      }

      .point-rule {
        position: absolute;
        right: 0;
        top: 20rpx;
        border-radius: 20rpx 0 0 20rpx;
        padding-right: 20rpx;
        border: 1px solid white;
        border-right-width: 0;
        align-items: center;
        padding-left: 24rpx;

        .point-rule-text {
          color: white;
          font-size: 24rpx;
        }
      }

      .point-header-bottom {
        border-radius: 24rpx 24rpx 0 0;
        background: #f2f2f2;
        width: 100%;
        height: 30rpx;
        top: 222rpx;
        position: absolute;
        left: 0;
        z-index: 1;
      }

      //.point-image {
      //  position: absolute;
      //  top: 74rpx;
      //  right: 50rpx;
      //  z-index: 2;

      .image-icon {
        position: absolute;
        top: 74rpx;
        right: 50rpx;
        z-index: 2;
        width: 180rpx;
        height: 180rpx;
      }

      //}
    }
  }

  .hide-overdue {
    display: none  !important;
  }

  .point-overdue {
    background: white;
    display: flex;
    align-items: center;
    padding: 10px 20px;
    margin: 20px 20px 0;



    .circle-container {
      position: relative;
      width: 20px; /* 圆的直径 */
      height: 20px;
      border: 2px solid #4aa4fc; /* 空心圆的边框 */
      border-radius: 50%;
      overflow: hidden; /* 防止伪元素超出容器边界 */
    }

    .circle-container::before {
      content: '';
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      width: 8px; /* 内层圆的直径 */
      height: 8px;
      background-color: #4aa4fc; /* 实心圆的颜色 */
      border-radius: 50%;
    }

    .point-overdue-text {
      display: flex;
      flex-direction: row;
      margin-left: 16rpx;

      text {
        color: #4aa4fc;
      }
    }


  }


  .point_history {
    margin: 20rpx;
    background-color: white;
    padding: 20px;
    height: 100vh;

    .tab {
      width: 100%;
      height: 90px;
    }

    .history_list {
      height: 90vh;
    }

    .no_data {
      display: flex;
      justify-content: center;
      align-items: center;
      margin-top: 50%;

      .no-data-image {
        width: 309rpx;
        height: 220rpx;
      }

      .no-data-text {
        color: #555;
        margin-top: 20rpx;
        font-size: 24rpx;
        text-align: center;
      }

      .vertical-center {
        align-items: center;
        height: calc(100vh - 100px);
        padding-top: 10rpx;
        padding-bottom: 10rpx;
      }

      .child {
        display: inline-block;
        vertical-align: center;
      }

      .no-data-operation {
        color: #4aa4fc;
        font-size: 30rpx;
        text-align: center;
        border-radius: 58rpx;
        border: 1px solid #4aa4fc;
        padding-left: 24rpx;
        padding-right: 24rpx;
        box-sizing: border-box;
      }
    }

    .vertical-center {
      align-items: center;
    }

    .task_value {
      color: #ff770f;
      margin-left: 10rpx;
      font-size: 32rpx;
      font-weight: bold;
    }

    .task_desc {
      color: #555;
      margin-top: 16rpx;
      font-size: 24rpx;
    }

    .divider {
      margin-top: 30rpx;
      width: 100%;
      height: 1px;
      background-color: #f2f2f2;
    }

    .task_value_icon {
      width: 40rpx;
      height: 40rpx;
    }

    .task_name {
      color: #333;
      font-size: 32rpx;
      text-align: start;
      font-weight: bold;
    }

  }

}
</style>
