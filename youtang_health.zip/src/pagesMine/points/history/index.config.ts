export default definePageConfig({
    navigationBarTitleText: "积分明细",
    titleBarColor: "#4aa4fc",
    navigationBarBackgroundColor: "#4aa4fc",
    navigationBarTextStyle: "white",
    enableShareAppMessage:true,
    enableShareTimeline:true,
});