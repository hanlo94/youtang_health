export default definePageConfig({
    navigationBarTitleText: "积分乐园",
    titleBarColor: "#4aa4fc",
    navigationBarBackgroundColor: "#4aa4fc",
    navigationBarTextStyle: "white",
    enableShareAppMessage:true,
    enableShareTimeline:true,
});