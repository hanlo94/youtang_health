<!--
Description：积分乐园
Created on 2024-07-26
Author :  萧 -->
<template>
  <view class="points_root">
    <scroll-view :scroll-y="true" flexed>
      <view class=" point_header ">
        <view class="header-content">
          <view class="horizontal patient">
            <!--            <nut-avatar size="large" >-->
            <img class="img_header" :src="pointBalance.avatar"/>
            <!--            </nut-avatar>-->
            <view class="vertical point-balance-root">
              <text class="name">{{ pointBalance.name }}</text>
              <view class="point-balance">
                <text class="points-header-value">{{ pointBalance.point }}</text>
                <view @click.stop="goPointHistory">
                  <text class="points-header-detail">积分明细</text>
                </view>
              </view>
            </view>
          </view>

          <view class="point-rule" @click.stop="goPointRule">
            <text class="point-rule-text">规则</text>
          </view>

          <view class="point-header-bottom"/>

          <image class="image-icon" :src="imgUrlFormat('point/integralpic1.png')" mode="widthFix"/>
        </view>
      </view>

      <view class="round points-exchange horizon-container" v-if="showGoods"  >
        <view class=" horizontal points-exchange-root " @click.stop="goExchange">
          <image class="points-exchange-image" :src="imgUrlFormat('point/point1.png')" mode="widthFix"/>
          <view class="vertical-container points-exchange-text">
            <text class="points-exchange-title">积分兑好礼</text>
            <text class="points-exchange-desc">惊喜好礼等你来拿</text>
          </view>
        </view>

        <view class="points-exchange-divider"/>

        <view class=" horizontal points-exchange-root " @click.stop="goMall">
          <image class="points-exchange-image" :src="imgUrlFormat('point/point2.png')" mode="widthFix"/>
          <view class="vertical-container points-exchange-text">
            <text class="points-exchange-title">超值购好物</text>
            <text class="points-exchange-desc">畅享购物新乐趣</text>
          </view>
        </view>
      </view>

      <view class="point_signin round vertical">
        <text class="point-item-title">每日签到</text>
        <!--        <view>-->
        <rich-text style="margin-top: 10px" :nodes="signInState.prompt"></rich-text>
        <!--          <text class="marquee-text">{{ signInState.prompt }}</text>-->
        <!--        </view>-->
        <!--        <view class="horizontal marquee-parent">-->
        <!--          <view class="marquee-container">-->
        <!--            <text class="marquee-text">已经连续签到0天，再连续签到7天，额外奖励10分</text>-->
        <!--          </view>-->
        <!--        </view>-->
        <view class="horizon-container signin-container">

          <view v-for="(item, index) in signInState.list" :key="index"
                class="signin-item vertical " @click.stop="signIn(item)">
            <view class="signin-item-bg vertical" :class="item.signinClass">
              <image class="signin-img" :src="item.icon" mode="widthFix"/>
              <text :class="item.signinValueClass">+{{ item.addValue }}</text>
            </view>
            <text :class="item.signInTextClass">{{ item.signInText }}</text>
          </view>
        </view>
      </view>

      <view class="point-task round vertical">
        <text class="point-item-title" style="width: 100%">做任务赚积分</text>
        <view v-for="(item, index) in visibleItems" :key="index" class="horizontal vertical-center" style="width: 100%">
          <image class="task_img" :src="item.ruleImage" mode="aspectFill"></image>
          <view class="vertical-container task-value-content">
            <view class="horizon-container vertical-center">
              <view class="vertical-container" style="flex: 3">
                <view class="horizontal vertical-center">
                  <text class="task_name">{{ item.ruleName }}</text>
                  <view class="horizontal vertical-center" style="margin-left: 10rpx">
                    <image class="task_value_icon" :src="imgUrlFormat('point/integral2.png')" mode="scaleToFit"></image>
                    <text class="task_value">{{ item.ruleAddValue }}</text>
                  </view>
                </view>
                <text class="task_desc">{{ item.ruleDescription }}</text>
              </view>
              <view @click.stop="onTaskItemClick(item)" style="flex: 1" v-if="item.ruleOperation">
                <text :class="item.ruleOperationClass">{{ item.ruleOperation }}</text>
              </view>
            </view>
            <!-- 添加间隔线 -->
            <view class="divider"></view>
          </view>
        </view>
        <view class="more" @click.stop="changeFoldState">
          <text> {{ isFold ? "更多任务" : "收起来" }}</text>
          <img style="width: 30rpx ;height:30rpx; margin-left: 10rpx"
               :src="imgUrlFormat(isFold?'point/fold1.png':'point/fold2.png')"/>
        </view>

      </view>

      <view class="point-shop-banner round" v-if="showGoods" @click.stop="goDeduction">
        <image class="cover" :src="imgUrlFormat('point/integralpic2.png')" mode="scaleToFit"></image>
      </view>

      <view class="point-shop round vertical " v-if="showGoods" id="point-shop">
        <view class="horizon-container">
          <text class="point-item-title">积分兑换好礼</text>
          <view @click.stop="goDeduction()" class="horizontal">
            <text class="shop-mall">查看更多</text>
            <image style="margin-left: 10rpx; width: 30rpx; height: 30rpx" src="@/assets/image/common/fold.png"></image>
          </view>
        </view>
        <nut-grid :column="2" :gutter="3" :border="false" :direction="'horizontal'" :column-num="2">
          <nut-grid-item v-for="(item, index) in pointGoods" :key="index" class="override-grid-item"
                         @click.stop="goPointsGoodsInfo(item)">
            <view class="vertical">
              <view class="round">
                <image class="goods_image" :src="item.goodsImage" mode="scaleToFit"></image>
              </view>
              <text class="goods_name margin-top">{{ item.goodsName }}</text>
              <view class="horizontal margin-top">
                <text class="goods_points" v-if="item.goodsDiscountPrice">{{
                    item.goodsPoint
                  }}积分+{{ item.goodsDiscountPrice }}元
                </text>
                <text class="goods_points" v-else>{{ item.goodsPoint }}积分</text>
              </view>
              <view class="horizon-container">
                <text class="goods_price line margin-top"> {{ item.goodsPrice ? item.goodsPrice + '元' : '' }}</text>
                <view class="points_exchange_container">
                  <text class="points_exchange">兑换</text>
                </view>
              </view>
            </view>
          </nut-grid-item>
          <!--          <nut-grid-item class="override-grid-item">-->
          <!--            <view class="vertical">-->
          <!--              <view class="round">-->
          <!--                <image class="goods_image" :src="image_url" mode="scaleToFit"></image>-->
          <!--              </view>-->
          <!--              <text class="goods_name margin-top">礼品名称礼品名称</text>-->
          <!--              <view class="horizontal margin-top">-->
          <!--                <text class="goods_points">1000</text>-->
          <!--                <text class="goods_price">积分+20元</text>-->
          <!--              </view>-->
          <!--              <text class="goods_price line margin-top">39元</text>-->
          <!--            </view>-->
          <!--          </nut-grid-item>-->
          <!--          <nut-grid-item class="override-grid-item">-->
          <!--            <view class="vertical">-->
          <!--              <view class="round">-->
          <!--                <image class="goods_image" :src="image_url" mode="scaleToFit"></image>-->
          <!--              </view>-->
          <!--              <text class="goods_name margin-top">礼品名称礼品名称</text>-->
          <!--              <view class="horizontal margin-top">-->
          <!--                <text class="goods_points">1000</text>-->
          <!--                <text class="goods_price">积分+20元</text>-->
          <!--              </view>-->
          <!--              <text class="goods_price line margin-top">39元</text>-->
          <!--            </view>-->
          <!--          </nut-grid-item>-->
          <!--          <nut-grid-item class="override-grid-item">-->
          <!--            <view class="vertical">-->
          <!--              <view class="round">-->
          <!--                <image class="goods_image" :src="image_url" mode="scaleToFit"></image>-->
          <!--              </view>-->
          <!--              <text class="goods_name margin-top">礼品名称礼品名称</text>-->
          <!--              <view class="horizontal margin-top">-->
          <!--                <text class="goods_points">1000</text>-->
          <!--                <text class="goods_price">积分+20元</text>-->
          <!--              </view>-->
          <!--              <text class="goods_price line margin-top">39元</text>-->
          <!--            </view>-->
          <!--          </nut-grid-item>-->
          <!--          <nut-grid-item class="override-grid-item">-->
          <!--            <view class="vertical">-->
          <!--              <view class="round">-->
          <!--                <image class="goods_image" :src="image_url" mode="scaleToFit"></image>-->
          <!--              </view>-->
          <!--              <text class="goods_name margin-top">礼品名称礼品名称</text>-->
          <!--              <view class="horizontal margin-top">-->
          <!--                <text class="goods_points">1000</text>-->
          <!--                <text class="goods_price">积分+20元</text>-->
          <!--              </view>-->
          <!--              <text class="goods_price line margin-top">39元</text>-->
          <!--            </view>-->
          <!--          </nut-grid-item>-->
        </nut-grid>


      </view>

    </scroll-view>

    <nut-popup v-model:visible="showSignInDialog"
               position="center" :style="{ height: '45%' }"
               style="background: transparent">
      <view class="signin-dialog">
        <view class="dialog-pop">
          <img class=bg :src="imgUrlFormat('point/pop1.png')"/>
          <view class="dialog_content">
            <view class="content vertical">
              <view class="horizontal" style="justify-content: center">
                奖励您
                <text style="color:#4aa4fc;font-size: 36rpx ">{{ rewardPoint }}</text>
                个积分
              </view>
              <view>连续签到送额外积分～</view>
            </view>
            <view class="btn" @click="onCloseSignInDialog">开心收下</view>
          </view>
        </view>
        <img class="close" :src="imgUrlFormat('point/close.png')" @click.stop="onCloseSignInDialog"/>
      </view>
    </nut-popup>
  </view>
</template>

<script setup lang="ts">
import {computed, onMounted, ref} from "vue";
import StoreUtils from "@/utils/storeUtils";
import Taro from "@tarojs/taro";
import PointApi, {
  CycleSignInState,
  PointBalance,
  PointGoods,
  PointRuleConstants,
  PointTask,
  PointTimeConstants
} from "@/pagesMine/api/points";
import imgUrlFormat from "@/utils/imgUtils";
import PageNavigation from "@/utils/pageNavigation";



const showGoods = ref(false);

const showSignInDialog = ref(false);
const rewardPoint = ref<number>(0)

const pointGoods = ref<Array<any>>([] as PointGoods[])

const pointBalance = ref<PointBalance>({
  avatar: "https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/common/logo.png"
})

const signInState = ref<CycleSignInState>({bonusValue: 0, difference: 0, signInDays: 0})

const tasks = ref<PointTask[]>([] as PointTask[]);

const isFold = ref(true);

const visibleItems = computed(() => {
  return isFold.value ? tasks.value.slice(0, 5) : tasks.value;
});

onMounted(() => {
  getPointInfo()
  getPointGoods()
})

const getPointInfo = () => {
  getBalance()
  getTasks(5)
  if (StoreUtils.readPatientId()) {
    getSignInCycleList()
  }
}

const signIn = (item) => {
  //
  console.log("index.vue..signIn.item=", JSON.stringify(item));
  let that = this;
  if (item.today) {
    PointApi.signIn().then(res => {
      console.log("index.vue..signIn.res=", JSON.stringify(res));
      if (res && res.data) {
        handleSignInState(res.data)
        rewardPoint.value = res.data.point

        showSignInDialog.value = true
        getBalance()
      }
    }).catch(err => {
      console.log('index.signIn. err = ', JSON.stringify(err))

    })
  }
}

const getTasks = (count) => {
  PointApi.getTasks().then(res => {
    console.log("index.vue..getTasks.res=", JSON.stringify(res));
    if (res.data && res.data.length > 0) {
      res.data.forEach(task => {
        let totalCount
        if (task.ruleTimeLimit != null && PointTimeConstants.UNLIMITED != task.ruleTimeLimit) {
          if (PointTimeConstants.LIMIT_ONCE == task.ruleTimeLimit) {
            totalCount = 1;
          } else if (PointTimeConstants.DAILY_LIMIT == task.ruleTimeLimit) {
            totalCount = task.ruleDayTimes;
          } else if (PointTimeConstants.MONTHLY_LIMIT == task.ruleTimeLimit) {
            totalCount = task.ruleMonthTimes;
          }
          if (totalCount > 0) {
            task.ruleDescription += "(" + task.finishCount + "/" + totalCount + ")"
          }
          if (totalCount && task.finishCount == totalCount) {
            task.ruleOperationClass = 'task_operation_finish'
            task.ruleOperation = '已完成'
          } else {
            task.ruleOperationClass = 'task_operation'
          }
        } else {
          task.ruleOperationClass = 'task_operation'
        }
      })
    }
    tasks.value = res.data
  }).catch(err => {
    console.log('index.getTasks. err = ', JSON.stringify(err))
  })
}

const getSignInCycleList = () => {
  PointApi.getSignInCycleList().then(res => {
    console.log("index.vue..getSignInCycleList.res=", JSON.stringify(res));
    handleSignInState(res.data)
  }).catch(err => {
    console.log('index.getSignInCycleList. err = ', JSON.stringify(err))
  })
}

const handleSignInState = (data) => {
  data.list && data.list.forEach(item => {
    item.signInTextClass = 'signin-bg'
    if (item.signed) {
      item.icon = imgUrlFormat('point/finish.png')
      item.signinClass = 'signin-bg-signed'
      item.signinValueClass = 'signin-value'
      item.signInText = "已签"
    } else {
      item.icon = imgUrlFormat('point/integral2.png')
      item.signinClass = 'signin-bg-unsign'
      item.signinValueClass = 'unsignin-value'
      if (item.today) {
        item.signInTextClass = 'unsign-bg'
        item.signInText = "签到"
      } else {
        item.signInText = "第" + item.signInDay + "天"
      }
    }
    if (item.bonusValue) {
      item.addValue += item.bonusValue
    }

  })
  if (!data.prompt && data.promptStr) {
    if (data.promptStr.length == 4) {
      data.prompt = data.promptStr[0] + data.signInDays + data.promptStr[1] + data.difference + data.promptStr[2] + data.bonusValue + data.promptStr[3]
    } else {
      data.prompt = data.promptStr[0] + data.signInDays + data.promptStr[1] + data.difference + data.promptStr[2]
    }
  }
  // if (data.promptStr && data.promptStr.length >= 4) {
  //   data.prompt = data.promptStr[0] + data.signInDays + data.promptStr[1]
  //       + data.difference + data.promptStr[2] + data.bonusValue + data.promptStr[3]
  // }
  signInState.value = data
}

const getBalance = () => {
  PointApi.getBalance().then(res => {
    console.log("index.vue..points.index.res=", JSON.stringify(res));
    if (!res.data.avatar || res.data.avatar.trim().length == 0) {
      res.data.avatar = pointBalance.value.avatar
    }
    pointBalance.value = res.data
  }).catch(err => {
    console.log('index.getBalance. err = ', JSON.stringify(err))
  })
}

const getPointGoods = () => {
  PointApi.getPointGoods().then(res => {
    console.log("index.vue..points.index.res=", JSON.stringify(res));
    if (res && res.data && res.data.length > 0) {
      showGoods.value = true
      pointGoods.value.push(...res.data)
    }
  }).catch(err => {
    console.log('index.getPointGoods. err = ', JSON.stringify(err))
  })
}

Taro.eventCenter.on('login', (item) => {
  console.log("mine.vue..login.",);
  getPointInfo()
})

Taro.eventCenter.once('loginonce', (item) => {
  console.log("mine.vue..loginonce.",);
  getPointInfo()
})

const goExchange = () => {
  Taro.pageScrollTo({
    duration: 200,
    selector: "#point-shop",
    offsetTop: 20,
  })
};

const goDeduction = () => {
  // 打开小程序
  console.log('index.goDeduction.')
  Taro.navigateToMiniProgram({
    appId: 'wx0f46682f8af98432',
    path: '/pages/integral/goods/list',
    success(res) {
      // 打开成功
      console.log("mall.js.success.", JSON.stringify(res));
    },
    fail(res) {
      console.log("mall.js.fail.", JSON.stringify(res));
    }
  })
};

const goMall = () => {
  // 打开小程序
  console.log('index.goMall.')
  Taro.navigateToMiniProgram({
    appId: 'wx0f46682f8af98432',
    success(res) {
      // 打开成功
      console.log("mall.js.success.", JSON.stringify(res));
    },
    fail(res) {
      console.log("mall.js.fail.", JSON.stringify(res));
    }
  })
};

const goPointHistory = () => {
  Taro.navigateTo({
    url: '/pagesMine/points/history/index'
  })
}

const goPointRule = () => {
  PageNavigation.openPointRule()
}


const onTaskItemClick = (item) => {
  console.log('index.onTaskItemClick.item=', item)
  if (item) {
    if (item.ruleOperation == '已完成') {
      // 已完成 点击不做处理
    } else {
      if (item.rulePointsOperationType == PointRuleConstants.ACADEMY_READ) {
        Taro.switchTab({url: item.mpPagePath})
      } else if (item.rulePointsOperationType == PointRuleConstants.SHOPPING) {
        goMall()
      } else if (item.rulePointsOperationType == PointRuleConstants.MARKET_SHARING) {

      } else if (item.mpPagePath) {
        Taro.navigateTo({
          url: item.mpPagePath
        })
      }
    }
  }
}

const changeFoldState = () => {
  console.log('index.changeFoldState.before isFOld = ', isFold)
  isFold.value = !isFold.value
  console.log('index.changeFoldState.after isFOld = ', isFold)
  if (tasks && tasks.value && tasks.value.length > 0) {

  } else {
    getTasks(0)
  }
  // if (isFold.value) {
  //   getTasks(5)
  // } else {
  //   getTasks(0)
  // }
}

const goPointsGoodsInfo = (item) => {
  console.log('index.goPointsGoodsInfo.', JSON.stringify(item))
  Taro.navigateToMiniProgram({
    appId: 'wx0f46682f8af98432',
    path: item.goodsPagePath,
    success(res) {
      // 打开成功
      console.log("mall.js.success.", JSON.stringify(res));
    },
    fail(res) {
      console.log("mall.js.fail.", JSON.stringify(res));
    }
  })
}

const onCloseSignInDialog = () => {
  showSignInDialog.value = false
}

</script>

<style lang="less">
.points_root {
  height: 100vh;

  .point-item-title {
    font-size: 36rpx;
    color: #333;
    font-weight: 600;
  }

  .point_header {
    background: #4aa4fc;
    width: 100%;
    height: 248rpx;

    .header-content {
      position: relative;
      width: 100%;

      .patient {
        position: absolute;
        align-items: start;
        top: 42rpx;
        left: 20rpx;

        .img_header {
          border: #6aa4fc solid 1px;
          width: 120px;
          border-radius: 50%;
          height: 120px;
        }

        .point-balance-root {
          margin-left: 12rpx;

          .name {
            font-size: 30rpx;
            color: white;
          }

          .point-balance {
            display: flex;
            align-items: flex-end;
            text-align: center;
            flex-direction: row;

            .points-header-value {
              color: #FFFFFF;
              font-size: 80rpx;
              font-weight: bold;
            }

            .points-header-detail {
              color: white;
              font-size: 24px;
              position: absolute;
              top: 67%;
              width: 100rpx;
              padding-right: 1.5em;
              margin-left: 10rpx;
            }

            .points-header-detail::after {
              content: ''; /* 必须有内容才能显示伪元素 */
              position: absolute;
              right: 0;
              top: 50%;
              transform: translateY(-50%); /* 垂直居中 */
              width: 1em;
              height: 1em;
              background-image: url('https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/point/fold.png');
              background-repeat: no-repeat;
              background-position: center center;
              background-size: cover; /* 使图片填充整个区域 */
            }
          }
        }
      }

      .point-rule {
        position: absolute;
        right: 0;
        top: 20rpx;
        border-radius: 20rpx 0 0 20rpx;
        padding-right: 20rpx;
        border: 1px solid white;
        border-right-width: 0;
        align-items: center;
        padding-left: 24rpx;

        .point-rule-text {
          color: white;
          font-size: 24rpx;
        }
      }

      .point-header-bottom {
        border-radius: 24rpx 24rpx 0 0;
        background: #f2f2f2;
        width: 100%;
        height: 30rpx;
        top: 222rpx;
        position: absolute;
        left: 0;
        z-index: 1;
      }

      //.point-image {
      //  position: absolute;
      //  top: 74rpx;
      //  right: 50rpx;
      //  z-index: 2;

      .image-icon {
        position: absolute;
        top: 74rpx;
        right: 50rpx;
        z-index: 2;
        width: 180rpx;
        height: 180rpx;
      }

      //}
    }
  }

  .points-exchange {
    margin: 20rpx;
    background-color: white;
    padding: 30rpx 40rpx;

    .points-exchange-root {
      justify-content: center;
      align-items: center;

      .points-exchange-image {
        width: 64rpx;
        height: 64rpx;
      }

      .points-exchange-text {
        margin-left: 10rpx;

        .points-exchange-title {
          color: #333;
          font-size: 34rpx;
        }

        .points-exchange-desc {
          color: #999;
          font-size: 24rpx;
        }
      }

    }

    .points-exchange-divider {
      width: 1rpx;
      height: 90rpx;
      align-self: center;
      align-items: center;
      background: #e4e4e4;
    }

  }

  .point_signin {
    margin: 20rpx;
    background-color: white;
    padding: 20px;

    .divider {
      width: 30rpx;
      height: 1px;
      background-color: #666;
    }

    .marquee-parent {
      display: flex;
      align-items: center;
      margin-top: 10rpx;

      .marquee-container {
        height: 40rpx; /* 设置容器高度 */
        overflow: hidden; /* 隐藏溢出内容 */
        white-space: nowrap; /* 强制文本在一行内显示 */
      }

      .marquee-text {
        display: inline-block;
        animation: marquee 10s linear infinite; /* 动画名称、持续时间、速度曲线、是否无限循环 */
      }

      @keyframes marquee {
        from {
          transform: translateX(100%); /* 开始时在右侧 */
        }
        to {
          transform: translateX(-100%); /* 结束时在左侧 */
        }
      }
    }

    .signin-container {
      //flex-wrap: wrap;
      margin-right: -10px;
      margin-top: 20rpx;

      .signin-item {
        margin-right: 10px;
        flex: 1;
        align-items: center;

        .signin-item-bg {
          align-items: center;
          box-sizing: border-box;
          padding-top: 10rpx;
          width: 100%;
          padding-bottom: 10rpx;
          border-radius: 10rpx;
        }

        .signin-bg-signed {
          background: #ebf6ff;
        }

        .signin-bg-unsign {
          background: #f8f8f8;
        }


        .signin-img {
          width: 50rpx;
          height: 50rpx;
        }

        .unsignin-value {
          font-weight: 600;
          font-size: 28rpx;
          color: #ff770f;
        }

        .signin-value {
          font-weight: 600;
          font-size: 28rpx;
          color: #4aa4fc;
        }

        .signin-bg {
          color: #333;
          width: 100%;
          text-align: center;
          font-size: 24rpx;
          margin-top: 10rpx;
        }

        .unsign-bg {
          border-radius: 20rpx;
          background: #4aa4fc;
          margin-top: 10rpx;
          width: 100%;
          text-align: center;
          font-size: 24rpx;
          color: white;
        }

      }

    }

  }

  .point-task {
    margin: 20rpx;
    background-color: white;
    padding: 20px;

    .vertical-center {
      align-items: center;
    }

    .task_img {
      width: 80rpx;
      height: 80rpx;
    }

    .task-value-content {
      margin-left: 8rpx;
      width: 88%;
      margin-top: 30rpx;

      .task_value_icon {
        width: 40rpx;
        height: 40rpx;
      }

      .task_name {
        color: #333;
        font-size: 32rpx;
        text-align: center;
      }

      .task_value {
        color: #ff770f;
        margin-left: 10rpx;
        font-size: 32rpx;
        font-weight: bold;
      }

      .task_desc {
        color: #555;
        margin-top: 16rpx;
        font-size: 24rpx;
      }

      .task_operation {
        color: #4aa4fc;
        font-size: 30rpx;
        border-radius: 20rpx;
        border: 1px solid #4aa4fc;
        padding-left: 24rpx;
        padding-right: 24rpx;
        box-sizing: border-box;
      }

      .task_operation_finish {
        background: #f9f9f9;
        color: #999;
        font-size: 30rpx;
        border-radius: 20rpx;
        border: 1px solid #f9f9f9;
        padding-left: 24rpx;
        padding-right: 24rpx;
        box-sizing: border-box;
      }

      .divider {
        margin-top: 30rpx;
        width: 100%;
        height: 1px;
        background-color: #f2f2f2;
      }
    }

    .more {
      margin-top: 10rpx;
      display: flex;
      justify-content: center;
      align-items: center;
    }
  }

  .point-shop-banner {
    margin: 0 20rpx 20rpx 20rpx;

    .cover {
      width: 100%;
      height: 178rpx;
      border-radius: 26rpx;
    }
  }

  .point-shop {
    margin: 0 20rpx 20rpx 20rpx;
    background-color: white;
    padding: 20px;

    .shop-mall {
      color: #555555;
      font-size: 28rpx;
    }

    .override-grid-item {
      --nut-grid-item-content-padding: 0;
      --nut-grid-item-content-bg-color: rgba(0, 0, 0, 0);
      margin-top: 24rpx;
      margin-bottom: 24rpx;
    }

    .goods_name {
      color: #333;
      font-size: 30rpx;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
      line-height: 1.5;
      height: 3em;
      text-overflow: ellipsis;
      max-height: 3em;
    }

    .goods_image {
      width: 310rpx;
      height: 310rpx;
      border-radius: 16rpx;
    }

    .goods_points {
      color: #FF403D;
      font-size: 28rpx;
    }

    .points_exchange_container {
      justify-content: center;
      align-items: center;
      display: flex;
      border-radius: 50rpx;
      border: 1px solid #4aa4fc;
      padding-left: 24rpx;
      padding-right: 24rpx;
      box-sizing: border-box;
    }

    .points_exchange {
      color: #4aa4fc;
      font-size: 28rpx;
      text-align: center;
    }

    .margin-top {
      margin-top: 20rpx;
    }

    .goods_price {
      color: #666;
      font-size: 24rpx;
    }

    .line {
      color: #333;
      text-decoration: line-through;
    }


  }


  .signin-dialog {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;

    .dialog-pop {
      display: flex;
      position: relative;
      box-sizing: border-box;
      align-items: center;
      justify-content: center;

      .bg {
        width: 566px;
        height: 553px;
      }

      .dialog_content {
        position: absolute;
        display: flex;
        top: 240px;
        width: 70vw;
        flex-direction: column;
        align-items: center;

        .content {
          font-size: 32rpx;
          height: 94rpx;
          margin: 40px 20px 10px 20px;
          color: #5D5D5D;
        }

        .btn {
          width: 502px;
          margin: 20px;
          height: 90px;
          text-align: center;
          line-height: 90px;
          color: white;
          background: #6AA4FC;
          border-radius: 16px;
        }
      }

    }

    .close {
      width: 70rpx;
      height: 70rpx;
      position: absolute;
      bottom: 0;
      left: calc(50% - 35rpx);
    }

  }

}
</style>
