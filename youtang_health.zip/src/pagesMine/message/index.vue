<!--
Description：消息中心
Created on 2023/10/1
Author :  郭 -->
<template>
	<view class="msg_root">
		<nut-tabs class="tab" v-model="active" color="#64A4F5" background="#ffffff" @click="changeTab">
			<nut-tab-pane title="异常消息"></nut-tab-pane>
			<nut-tab-pane title="系统消息"></nut-tab-pane>
		</nut-tabs>
		<scroll-view :scroll-y="true" @scrollToLower="scroll" @scrollToUpper="refresh" :refresherThreshold="50" flexed
					 class="view_list" v-if="active === '0' "
					 :lowerThreshold="150">
			<view class="view_item_left" v-if="!isEmpty(inValidMessageList)" v-for="(item, index) in inValidMessageList" :key="index">
				<view class="item_header">
					<view>
						<text>{{ item.ymdWeek }}</text>
						<text>{{ item.ms }}</text>
					</view>
				</view>
				<view class="item_bottom">
					<view class="item_title_left">
						<img :src="item.icon"/>
						<view>{{ item.msgName }}
							<text>{{ item.stateName }}</text>
						</view>
					</view>
					<view class="item_content item_state_normal">
						<view v-if="item.type===3">
							糖化血红蛋白为
							<text class="item_state_high">{{ item.hba1cValue }}</text>
							%
						</view>
						<view v-else-if="item.type === 1">
							{{ getSugarTimeByType(item)?.value || '随机' }}血糖值为
							<text
								:class="item.sugarHighLow==1?'item_state_low':item.sugarHighLow==2?'item_state_high':'item_state_normal'">
								{{ item.sugarValue }}
							</text>
							mmol/L<img :src="item.sugarHighLow===2?up:down"
									   v-if="item.sugarHighLow === 1 ||item.sugarHighLow===2"
									   style="height: 15px;width: 15px" alt=""/>
						</view>
						<view v-if="item.type===2">
							收缩压
							<text
								:class="item.systolicHighLow===1?'item_state_low':item.systolicHighLow===2?'item_state_high':'item_state_normal'">
								{{ item.systolic }}
							</text>
							mmHg<img :src="item.systolicHighLow===2?up:down"
									 v-if="item.systolicHighLow === 1 ||item.systolicHighLow===2"
									 style="height: 15px;width: 15px" alt=""/>
							，舒张压
							<text
								:class="item.diastolicHighLow===1?'item_state_low':item.diastolicHighLow===2?'item_state_high':'item_state_normal'">
								{{ item.diastolic }}
							</text>
							mmHg<img :src="item.diastolicHighLow===2?up:down"
									 v-if="item.diastolicHighLow === 1 ||item.diastolicHighLow===2"
									 style="height: 15px;width: 15px" alt=""/>，心率{{ item.heartRate }}次/分
						</view>
					</view>
				</view>
			</view>
			<view v-else class="view_no_data">
				<nut-empty image="https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/common/nodata.png"
						   description="暂时还没有数据哦~"></nut-empty>
			</view>
		</scroll-view>
		<scroll-view :scroll-y="true" @scrollToLower="scroll" flexed class="view_list" v-if="active === '1'"
					 :lowerThreshold="150">
			<view class="view_item_right" v-if="!isEmpty(sysMessageList)" v-for="(item, index) in sysMessageList" :key="index">
				<view class="item_header">
					<view>
						<text>{{ item.ymdWeek }}</text>
						<text>{{ item.ms }}</text>
					</view>
				</view>
				<view class="item_bottom">
					<view class="item_title">
						{{ item.title }}
					</view>
					<view class="item_content">
						{{ item.content }}
					</view>
				</view>

			</view>
			<view v-else class="view_no_data">
				<nut-empty image="https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/common/nodata.png"
						   description="暂时还没有数据哦~"></nut-empty>
			</view>
		</scroll-view>

	</view>

</template>
<script setup lang="ts">
import {computed, reactive, ref} from "vue";
import MineApi, {InValidMessage} from "@/pagesMine/api/mine";
import {isEmpty} from "lodash";
import {formatDate2Hm, formatDate2YmdWeek} from "@/utils/dateUtils";
import {timeType} from "@/config/sugar/sugarConfig";
import {showToast} from "@/utils/toastUtils";

definePageConfig({
	navigationBarTitleText: '消息中心'
})

import imgUrlFormat from "@/utils/imgUtils";
import {getSugarTimeByType} from "@/utils/sugarUtils";

const up = imgUrlFormat('sugar/up.png')
const down = imgUrlFormat('sugar/down.png')

const StateArray = {
	stateLow: "偏低",
	stateHigh: "偏高",
	stateInvalid: "异常"
}

const MsgTypeArray = [
	{
		msgName: "血糖",
		icon: "https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/mine/msg_sugar.png",
	}, {
		msgName: "血压/心率",
		icon: "https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/mine/blood.png"
	}, {
		msgName: "糖化血红蛋白",
		icon: "https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/mine/protein.png"
	},
]

const active = ref('0')

const inValidMessageList = ref<Array<any>>([])

const sysMessageList = ref<Array<any>>([])

const inValidMessageState = reactive({
	page: 1,
	noMore: false
})

const sysMessageState = reactive({
	page: 1,
	noMore: false
})

const changeTab = (res) => {
	let {paneKey} = res
	console.log("index.vue.changeTab.paneKey=", paneKey, '; active=', active.value);
	if (paneKey == 0) {
		inValidMessageState.page = 1
		inValidMessageState.noMore = false
		getInvalidMessageList()
	} else if (paneKey == 1) {
		sysMessageState.page = 1
		sysMessageState.noMore = false
		getSysMessageList()
	}
}

const getInvalidMessageList = () => {
	if (inValidMessageState.noMore) {
		return
	}
	MineApi.invalidMessageList(inValidMessageState.page).then(res => {
		if (inValidMessageState.page == 1) {
			inValidMessageList.value = []
		}
		if (!isEmpty(res.data)) {
			let list = res.data.map(item => {
				return {
					...item,
					...formatMessageNameAndIcon(item),
					ymdWeek: formatDate2YmdWeek(item.addTime),
					ms: formatDate2Hm(item.addTime)
				}
			});
			inValidMessageList.value.push(...list)
		} else {
			inValidMessageState.noMore = true
			handleNoData(inValidMessageState.page)
		}
	})
}

const formatMessageNameAndIcon = (item: InValidMessage) => {
	let type = 0;
	if (item && item.type) {
		type = item.type - 1
		if (type >= MsgTypeArray.length || type < 0) {
			type = 0
		}
	}
	let msgType = MsgTypeArray[type];
	const stateName = item.type == 1 ? item.sugarHighLow == 1 ? StateArray.stateLow : StateArray.stateHigh : StateArray.stateInvalid
	return {
		...msgType,
		stateName,
	}
}

const itemStateClass = (valueState) => computed(() => {
	console.log("index.vue.itemStateClass .valueState=", valueState);
	if (valueState === 1) {
		console.log("index.vue.itemStateClass.low",);
		return 'item_state_low';
	} else if (valueState === 2) {
		console.log("index.vue.itemStateClass.high",);
		return 'item_state_high';
	} else {
		console.log("index.vue.itemStateClass.normal",);
		return 'item_state_normal';
	}
})

getInvalidMessageList()

const getSysMessageList = () => {
	if (sysMessageState.noMore) {
		return
	}
	MineApi.sysMessageList(sysMessageState.page).then(res => {
		if (sysMessageState.page == 1) {
			sysMessageList.value = []
		}
		if (!isEmpty(res.recordList)) {
			let list = res.recordList.map(item => {
				return {
					...item,
					ymdWeek: formatDate2YmdWeek(item.time),
					ms: formatDate2Hm(item.time)
				}
			});
			sysMessageList.value.push(...list)
		} else {
			sysMessageState.noMore = true
			handleNoData(sysMessageState.page)
		}
	})
}

const handleNoData = (page) => {
	if (page == 1) {
		showToast('暂时没有数据哦~')
	} else {
		showToast('没有更多数据了~')
	}
}

/**
 * loadmore
 */
const scroll = () => {
	if (active.value == '0') {
		inValidMessageState.page++;
		getInvalidMessageList()
	} else {
		sysMessageState.page++
		getSysMessageList()
	}
}

const refresh = () => {
	console.log("index.vue.refresh.",);
}

</script>

<style lang="less">
.msg_root {
	height: 100vh;

	.tab {
		width: 100%;
		height: 100px;
	}

	.view_list {
		height: calc(100vh - 100px);

		.view_item_left {
			border-radius: 20px;
			margin: 15px 30px;
			background: white;

			.item_header {

				view {
					margin-left: 20px;
					margin-right: 20px;
					display: flex;
					flex-direction: row;
					align-items: center;
					justify-content: space-between;
					padding: 30px 10px;
					border-bottom: #efefef solid 1px;
				}
			}

			.item_bottom {
				padding: 30px 20px;

				.item_title_left {
					display: flex;
					flex-direction: row;
					align-items: center;

					img {
						width: 60px;
						margin-right: 10px;
						height: 60px;
					}

					text {
						color: #e64a4a
					}
				}

				.item_content {
					margin-top: 20px;

					.item_state_low {
						color: #feb433;
						display: inline;
					}

					.item_state_normal {
						color: #333;
						display: inline;
					}

					.item_state_high {
						color: #e64a4a;
						display: inline;
					}
				}

			}

		}

		.view_item_right {
			border-radius: 20px;
			margin: 15px 30px;
			background: white;

			.item_header {

				view {
					display: flex;
					flex-direction: row;
					align-items: center;
					justify-content: space-between;
					margin-left: 20px;
					margin-right: 20px;
					padding: 30px 10px;
					border-bottom: #efefef solid 1px;
				}
			}

			.item_bottom {
				padding: 30px 20px;

				.item_title {
					font-weight: bold;
					color: #333333;
					font-size: 30px;
				}

				.item_content {
					margin-top: 20px;
				}

			}
		}
	}

	.view_no_data {
		height: 100vh;
		padding-top: 150px;

		.nut-empty__box {
			width: 440px;
			height: 260px
		}
	}
}
</style>
