<!--
Description：消息中心
Created on 2023/10/1
Author :  郭 -->
<template>
	<view class="report_root">
		<nut-tabs class="tab" v-model="active" color="#64A4F5" background="#ffffff" @click="changeTab">
			<nut-tab-pane title="五点血糖"></nut-tab-pane>
			<nut-tab-pane title="饮食评估"></nut-tab-pane>
		</nut-tabs>

		<view class="table  " v-if="active === '0' " style="margin: 10px 20px ; background-color: #fff; border-radius: 16px;padding: 16px">
				<nut-table :columns="columns" :data="recordTableList" bordered></nut-table>
		</view>
		<scroll-view :scroll-y="true" @scrollToLower="scroll" flexed class="view_list" v-if="active === '1'"
					 :lowerThreshold="150">
			<view  v-if="!isEmpty(nutritionList)" class="view_item_right" v-for="(item, index) in nutritionList" :key="index" @click.stop="goNutritionDetail(item)">
				<view class="item_header">
					<view>
						<text>{{item.ymdWeek}}</text>
						<text>{{item.ms}}</text>
					</view>

				</view>
				<view class="item_bottom">
					<view class="item_content">
						{{item.describe}}
					</view>
				</view>

			</view>
			<view v-else class="view_no_data">
				<nut-empty image="https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/common/nodata.png"
						   description="暂时还没有数据哦~"></nut-empty>
			</view>

		</scroll-view>

	</view>

</template>
<script setup lang="ts">
import MineApi, {FivePointReport, NutritionReport} from "@/pagesMine/api/mine";
import {reactive,ref,h} from "vue";
import {formatDate2Hm, formatDate2YmdWeek} from "@/utils/dateUtils";
import {isEmpty, isError} from "lodash";
import PageNavigation from "@/utils/pageNavigation";
import Taro from "@tarojs/taro";
import {createRender} from "@/utils/pubUtils";


definePageConfig({
	navigationBarTitleText: '健康评估'
})

const active = ref('0')

const columns = [
  {
    title: '日期',
    key: 'reportDate',
    stylehead: 'font-size:10px;color:#666666; background:#EBF6FF;',
    stylecolumn: 'font-size:10px;color:#666666;',
    align: "center",
    render: (record) => createRender(record.reportUrl,record.reportDate)
  },
  {
    title: '空腹',
    key: 'fbg',
    stylehead: 'font-size:10px;color:#666666; background:#EBF6FF;',
    stylecolumn: 'font-size:10px;color:#666;',
    align: "center",
    render: (record) => createRender(record.reportUrl,record.fbg)
  },
  {
    title: '餐后30min',
    key: 'sugarValue30',
    stylehead: 'font-size:10px;color:#666666; background:#EBF6FF;',
    stylecolumn: 'font-size:10px;color:#666;',
    align: "center",
    render: (record) => createRender(record.reportUrl,record.sugarValue30)
  },
  {
    title: '餐后1h',
    key: 'sugarValue1h',
    stylehead: 'font-size:10px;color:#666666; background:#EBF6FF;',
    stylecolumn: 'font-size:10px;color:#666;',
    align: "center",
    render: (record) => createRender(record.reportUrl,record.sugarValue1h)
  },
  {
    title: '餐后2h',
    key: 'sugarValue2h',
    stylehead: 'font-size:10px;color:#666666; background:#EBF6FF;',
    stylecolumn: 'font-size:10px;color:#666;',
    align: "center"
    , render: (record) => createRender(record.reportUrl,record.sugarValue2h)
  }, {
    title: '餐后3h',
    key: 'sugarValue3h',
    stylehead: 'font-size:10px;color:#666666; background:#EBF6FF;',
    stylecolumn: 'font-size:10px;color:#666;',
    align: "center",
    render: (record) => createRender(record.reportUrl,record.sugarValue3h)
  },
]

const recordTableList = ref<Array<any>>([] as FivePointReport[])

const nutritionList = ref<Array<any>>([])

const fivePointReportState = reactive({
	page: 1,
})
const nutritionReportState = reactive({
	page: 1,
})

const changeTab = (res) => {
	let {paneKey} = res
	console.log("index.vue.changeTab.paneKey=", paneKey, '; active=', active.value);
	if (paneKey == 0) {
		fivePointReportState.page=1
		fivePointList()
	} else if (paneKey == 1) {
		nutritionReportState.page=1
		nutritionReportList()
	}
}


const fivePointList = () => {
	MineApi.fivePointList(fivePointReportState.page).then(res => {
		console.log("index.vue..fivePointList.res=", JSON.stringify(res));
		if (fivePointReportState.page==1){
			recordTableList.value=[]
		}
		if(!isEmpty(res.data)){
			res.data.forEach(item=>{
				item.reportDate = item.reportDate && item.reportDate.substring(0,10)
				// recordTableList.value.push(item)
			})
			recordTableList.value.push(...res.data)
			console.log("index.vue.fiveList.",JSON.stringify(recordTableList.value));
		}
	})
}

fivePointList()

const nutritionReportList = () => {
	MineApi.nutritionReportList(nutritionReportState.page).then(res => {
		console.log("index.vue..nutritionReportList, res=", JSON.stringify(res));
		if (nutritionReportState.page==1){
			nutritionList.value=[]
		}
		if (!isError(res.data)){
			const list = res.data.map(item=>{
				return {
					...item,
					ymdWeek: formatDate2YmdWeek(item.reportTime),
					ms:formatDate2Hm(item.reportTime)
				}
			})
			nutritionList.value.push(...list);
			console.log("index.vue.nutritionList .",JSON.stringify(nutritionList.value));
			nutritionReportState.page++
		}
	})
}

/**
 * loadmore
 */
const scroll = () => {
	if (isFivePoint()) {
		fivePointReportState.page++;
		fivePointList()
	} else {
		nutritionReportState.page++
		nutritionReportList()
	}
}

const isFivePoint = () => {
	return active.value == '0'
}

const goNutritionDetail=(res)=>{
	PageNavigation.navigationToWebView(res.jumpUrl)
}


</script>

<style lang="less">
.report_root {
	height: 100vh;

	.tab {
		width: 100%;
		height: 100px;
	}

	.view_list {
		height: calc(100vh - 100px);

		.table {
			height: 200px;
			background: #6aa4fc;
		}

		.table_background{
			border-radius: 20px;
			margin: 15px 30px;
			background: white;
		}

		.view_item_right {
			border-radius: 20px;
			margin: 15px 30px;
			background: white;

			.item_header {

				flex-direction: row;
				align-items: center;

				view {
					margin-left: 20px;
					margin-right: 20px;
					padding: 30px 10px;
					display: flex;
					justify-content: space-between;
					border-bottom: #efefef solid 1px;
				}
			}

			.item_bottom {
				padding: 30px 20px;
			}

		}
	}

	.view_no_data {
		height: 100vh;
		padding-top: 150px;

		.nut-empty__box {
			width: 440px;
			height: 260px
		}
	}
}
</style>
