<!--
Description：
Created on 2023/10/1
Author :  郭 -->
<template>
	<view class="setting_root">
		<view class="view_bg">
			<view class="view_item" @click="onClickService">
				<text>服务协议</text>
				<RectRight></RectRight>
			</view>
			<view class="view_item" @click="onClickPrivate">
				<text>隐私条款</text>
				<RectRight></RectRight>
			</view>
			<!--			<view class="view_item" @click="onClickAboutUs">-->
			<!--				<text>关于我们</text>-->
			<!--				<RectRight></RectRight>-->
			<!--			</view>-->
		</view>

		<view class="view_version">版本号：{{ version }}</view>
		<view class="view_version">备案信息：鄂ICP备2021017662号-7X</view>
		<view class="view_version">版权所有：湖北优唐健康管理有限责任公司</view>
		<view class="view_version" @click="makePhoneCall">客服电话：{{ phone }}</view>

		<view class="view_exit" @click="onClickExit">
			退出登录
		</view>

	</view>
</template>
<script setup lang="ts">
import {RectRight} from '@nutui/icons-vue-taro';
import Taro from "@tarojs/taro";
import StoreUtils from "@/utils/storeUtils";
import PageNavigation from "@/utils/pageNavigation";
// import process from 'process'

definePageConfig({
	navigationBarTitleText: "系统设置"
})

const phone = process.env.CUSTOMER_SERVICE_PHONE

const version = process.env.VERSION

// /**
//  * 关于我们
//  */
// const onClickAboutUs = () => {
// 	PageNavigation.navigationToWebView('https://h5.youtang120.com/aboutus.html')
// }

/**
 * 隐私条款
 */
const onClickPrivate = () => {
	PageNavigation.openPrivacy()
}

/**
 * 服务协议
 */
const onClickService = () => {
	PageNavigation.openServiceItem()
}

const makePhoneCall = () => {
	Taro.makePhoneCall({
		phoneNumber: phone
	})
}

/**
 * 退出登录
 */
const onClickExit = () => {
	Taro.showModal({
		title: '提示',
		content: '确定要退出登录吗？',
		success: function (res) {
			if (res.confirm) {
				StoreUtils.clearCache()
				Taro.reLaunch({
					url: '/pages/index/index'
				})
			} else if (res.cancel) {
				console.log('用户点击取消')
			}
		}
	})
}
</script>

<style lang="less">
.setting_root {
	.view_bg {
		background: white;
		border-radius: 30px;
		margin: 30px;
		padding: 0 20px;

		.view_item {
			display: flex;
			flex-direction: row;
			align-items: center;
			padding: 40px 10px;
			border-bottom: #efefef solid 1px;
			justify-content: space-between;
		}


	}

	.view_version {
		display: flex;
		align-items: center;
		justify-content: center;
		margin-top: 30px;
		font-size: 25px;
		color: #666666;
	}

	.view_exit {
		width: 720px;
		color: white;
		background: #6aa4fc;
		border-radius: 10px;
		line-height: 80px;
		margin: 100px auto;
		margin-top: 500px;
		height: 80px;
		text-align: center;
	}
}
</style>
