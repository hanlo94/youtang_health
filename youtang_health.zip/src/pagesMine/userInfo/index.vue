<template>
  <view class="user_info">
    <view class="user_info_mobile">
      <view class="user_info_mobile_left">绑定手机号:</view>
      <view>{{ data.mobile }}</view>
    </view>
  </view>
</template>
<script setup lang="ts">
import Taro from "@tarojs/taro";
const data = Taro.getStorageSync("userInfo");
definePageConfig({
  navigationBarTitleText: "账户信息",
});
</script>

<style lang="less">
.user_info {
  margin: 30px;
  .user_info_mobile {
    display: flex;
    justify-content: space-between;
    border: 1px solid #fff;
    padding: 20px;
    background: #fff;
    border-radius: 8px;
  }
}
</style>
