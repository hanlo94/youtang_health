import {PAGE_SIZE, postCommonPatientRequest, postMessageRequest, postPatientRequest,} from '@/api/api'

const MineApi = {
	fivePointList(page, pageSize = PAGE_SIZE) {
		const params = {
			page: page,
			pageNum: page,
			pageSize: pageSize,
			actId: 110603,
		}
		return postPatientRequest<FivePointReport[]>(params)
	},

	nutritionReportList(page, pageSize = PAGE_SIZE) {
		const params = {
			serviceType: 1,
			type: 2,
			page: page,
			pageNum: page,
			pageSize: pageSize,
			actId: 110602,
		}
		return postPatientRequest<NutritionReport[]>(params)
	},

	invalidMessageList(page, pageSize = PAGE_SIZE) {
		const params = {
			page: page,
			pageNum: page,
			pageSize: pageSize,
			actId: 200109,
		}
		return postMessageRequest<InValidMessage[]>(params)
	},

	sysMessageList(page, pageSize = PAGE_SIZE) {
		const params = {
			page: page,
			pageNum: page,
			pageSize: pageSize,
			actId: 11102,
		}
		return postPatientRequest<SysMessage[]>(params)
	},

	/**
	 * 保存患者基础信息
	 * @param patientBaseInfo
	 */
	savePatientInfo(patientBaseInfo: PatientBaseInfo) {
		const params = {
			patientBaseInfo,
			actId: 110501,
		}
		return postPatientRequest(params)
	},


	/**
	 * 获取基础信息
	 */
	getPatientInfo() {
		return postCommonPatientRequest<PatientBaseInfo>(110502)
	},

	/**
	 * 获取基础信息和生活方式数据
	 */
	getPatientFullInfo() {
		return postCommonPatientRequest<PatientFullInfo>(100001)
	},

	getLifeWayInfo() {
		return postCommonPatientRequest(100005)
	},

	savePatientInfoAndLifeWay(patientInfo: PatientBaseInfo, lifeWay: LifeWay, complication: BaseComplication) {
		const param = {
			baseInfo: patientInfo,
			lifeWay,
			complication,
			actId: 100002
		}
		return postPatientRequest(param)
	}
}

export interface FivePointReport {
	reportId: number;
	reportDate: string;
	reportUrl: string;
	fbg: string;
	sugarValue30: string;
	sugarValue1h: string;
	sugarValue2h: string;
	sugarValue3h: string;
}

export interface NutritionReport {
	reportId: number;
	name: string;
	reportDate: string;
	serviceName: string;
	reportType: number;
	imgUrl: string;
	jumpUrl: string;
	reportTime: string;
	describe: string;
}

export interface InValidMessage {
	dataId: number;
	addUser: number;
	addTime: string;
	updateUser: number;
	updateTime: string;
	isDel: number;
	deleteTime: string;
	patientId: number;
	patientName: string;
	type: number;
	sugarValue: number;
	sugarValueType: number;
	sugarHighLow: number;
	systolic: number;
	diastolic: number;
	systolicHighLow: number;
	diastolicHighLow: number;
	heartRate: number;
	hba1cValue: number;
	isRead: number;
}

export interface SysMessage {
	id: number;
	title: string;
	content: string;
	type: number;
	time: string;
	isread: number;
	noreadNum: number;
	deviantId: number;
	deviantName: string;
	deviantNickname: string;
	deviantImg: string;
	deviantSex: number;
	messageType: number;
	messageTimeType: number;
	lowUp: number;
	abnormalValue: string;
	isAgree: number;
}

export interface PatientBaseInfo {
	name: string;
	gender: number;
	birth: string;
	avatar: string;
	diabetesType: number;
	height: number;
	weight: number;
	labourIntensity: number;
	sugarAge: string;
	sugarControlSituation: string;
	treatmentMethod: string;
	sleepSituation: string;
	healthAction: string;
	complication: string;
	labels: string;
	mobile: string;
	patientId: number;
	userPoint: string;
}

export interface LifeWay {
	dataId: number;
	patientId: number;
	familyHistory: number;
	smoking: number;
	smokingFrequency: number;
	drink: number;
	drinkingFrequency: number;
	drinkAmount: number;
	sport: number;
	sportFrequency: number;
	sportDuration: number;
}

export interface BaseComplication {
	dataId: number;
	patientId: number;
	hypertension: number;
	hypertensionDate: string;
	hyperlipemia: number;
	hyperlipemiaDate: string;
	nephropathy: number;
	nephropathyDate: string;
	neuropathy: number;
	neuropathyDate: string;
	ophthalmopathy: number;
	ophthalmopathyDate: string;
}

export interface PatientFullInfo{
	baseInfo:PatientBaseInfo;
	lifeWay:LifeWay;
	complication:BaseComplication
}

export default MineApi;
