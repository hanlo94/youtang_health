import {postSugarRequest} from '@/api/api'

const PointApi = {

    getPointGoods() {
        return postSugarRequest<PointGoods[]>({}, 'points/goods')
    },

    signIn() {
        return postSugarRequest<CycleSignInState>({}, 'points/signin')
    },

    getBalance() {
        return postSugarRequest<PointBalance>({}, 'points/balance')
    },

    getSignInCycleList() {
        return postSugarRequest<CycleSignInState>({}, 'points/signin/cycleList')
    },

    getTasks(count: number | null) {
        const request = {
            count: count
        }
        return postSugarRequest<PointTask[]>(request, 'points/tasks')
    },

    getPointHistoryList(page, pointType) {
        const request = {
            page: page,
            pageNum: page,
            pageSize: 20,
            pointType
        }
        return postSugarRequest<PageInfo<PointHistoryRecord>>(request, 'points/list')
    }
}

export interface PointBalance {
    avatar?: string | null;
    name?: string | null;
    point?: number | null;
    overduePoint?: number;
    overdueDate?: string;
    overdueClass?: string;
}

export interface PointGoods {
    goodsId?: string | null;
    goodsName?: string | null;
    goodsImage?: string | null;
    goodsPrice?: string | null;
    goodsPoint: number;
    goodsDiscountPrice?: string | null;
    goodsPagePath?: string | null;
    updateTime?: string | null;
}

export interface CycleSignInState {
    list?: Array<SignIn> | null;
    promptStr?: Array<string>;
    signInDays: number;
    difference: number;
    bonusValue: number;
    prompt?: string | null;
    point: number
}

export interface SignIn {
    addValue: number;
    bonusValue: number;
    signInDay: number;
    signed: boolean;
    today: boolean;
    signInDate?: string | null;
    // 自定义属性  仅页面展示
    icon: string,
    signinClass: string,
    signinValueClass: string,
    signInText: string
    signInTextClass: string
}

export interface PointHistoryRecord {
    userId?: number | null;
    recordDate?: string | null;
    changeValue?: string | null;
    remark?: string | null;
    dataId?: number | null;
    recordTime?: string | null;
    operationType?: number | null;
    pointsSource?: number | null;
    pointStatus?: number | null;
}

export interface PointTask {
    ruleName?: string | null;
    ruleDescription?: string | null;
    ruleImage?: string | null;
    ruleAddValue?: number | null;
    ruleReduceValue?: number | null;
    ruleTimeLimit?: number | null;
    ruleDayTimes?: number | null;
    ruleMonthTimes?: number | null;
    ruleOperation?: string | null;
    rulePointsOperationType: number;
    mpPagePath?: string | null;
    finishCount?: number | null;
    totalCount?: number | null;
    ruleOperationClass: string,
}

export interface PageInfo<T> {
    total: number;
    list: T[];
}

export const PointTimeConstants = {
    UNLIMITED: 0,
    LIMIT_ONCE: 1,
    DAILY_LIMIT: 2,
    DAILY_MONTHLY_LIMIT: 3,
    MONTHLY_LIMIT: 4,
};

export const PointRuleConstants = {
    POINT_OUT_DATE: 1,
    POINT_REWARDS: 2,
    POINT_DEDUCTION: 3,
    USER_REGISTER: 101,
    USER_COMPLETE_INFO: 102,
    USER_AVATAR: 104,
    USER_SIGNIN: 105,
    HEALTH_RECORD_SUGAR: 201,
    HEALTH_RECORD_DIET: 205,
    HEALTH_RECORD_BLOOD_PRESSURE: 202,
    HEALTH_RECORD_MEDICATION: 203,
    HEALTH_RECORD_SPORT: 204,
    HEALTH_RECORD_BODYFAT: 206,
    HEALTH_RECORD_DOSSIER: 207,
    HEALTH_RECORD_HEIGHT_WEIGHT: 208,
    DOSSIER_EXAM: 301,
    DOSSIER_HBA1C: 302,
    DOSSIER_BLOOD_FAT: 303,
    DOSSIER_RENAL: 304,
    DOSSIER_BIND_DEVICE: 305,
    DOSSIER_BODY_COMPOSITION: 306,
    USER_RECOMMEND: 103,
    ACADEMY_READ: 401,
    MARKET_SHARING: 402,
    SHOPPING: 501,
};

export default PointApi;
