<!--
Description：编辑个人资料
Created on 2023/10/1
Author :  郭 -->
<template>
	<view class="edit_root">
		<view class="view_bg">
			<view class="view_item_name">
				<text>真实姓名</text>
				<view class="arrow">
					<input placeholder="请输入" v-model="baseInfo.name"/>
					<RectRight></RectRight>
				</view>

			</view>
			<view class="view_item_gender">
				<text>性别</text>
				<view class="warp">
					<view :class=" item.value === baseInfo.gender ? 'check_true' :'check_false' "
						  v-for="(item ,index ) in genderList"
						  :key="item.value" @click="onChooseItem(item,'gender')">{{ item.label }}
					</view>
				</view>
			</view>
			<view class="view_item_birthday" @click="showBirthdayPop = true">
				<text>出生日期</text>
				<view class="arrow">
					<text>{{ baseInfo.birth }}</text>
					<RectRight></RectRight>
				</view>
			</view>

			<view class="view_item_type">
				<text>糖尿病类型</text>
				<view class="warp">
					<view :class=" item.value === baseInfo.diabetesType ? 'check_true' :'check_false' "
						  v-for="(item ,index ) in sugarList"
						  :key="item.value" @click="onChooseItem(item,'diabetesType')">{{ item.label }}
					</view>
				</view>
			</view>
			<view class="view_item_type">
				<text>劳动力强度</text>
				<view class="warp">
					<view :class=" item.value === baseInfo.labourIntensity ? 'check_true' :'check_false' "
						  v-for="(item ,index ) in labourList"
						  :key="item.value" @click="onChooseItem(item,'labourIntensity')">{{ item.label }}
					</view>
				</view>
			</view>

		</view>
		<view class="view_bg">
			<HealthScale :loading="false" :key="baseInfo.height"  v-model:value="baseInfo.height" :value="baseInfo.height" :min="heightState.min" :max="heightState.max" :int="true" title="身高" unit="cm"/>
			<HealthScale :loading="state.loadingWeight" :key="baseInfo.weight" v-model:value="baseInfo.weight" :value="baseInfo.weight" :min="state.min" :max="state.max" :int="true" title="体重" unit="kg"/>
		</view>
	<view v-if="!isCompleteBasicInfo">
		<view class="view_bg">
			<view class="view_item_gender">
				<text>家族史</text>
				<view class="warp">
					<view :class=" item.value === lifeWay.familyHistory ? 'check_true' :'check_false' "
						  v-for="(item ,index ) in yesOrNoList"
						  :key="item.value" @click="onChooseLifeWayItem(item,'familyHistory')">{{ item.label }}
					</view>
				</view>
			</view>
		</view>
		<view class="view_bg">
			<view class="view_item_gender">
				<text>是否吸烟</text>
				<view class="warp">
					<view :class=" item.value === lifeWay.smoking ? 'check_true' :'check_false' "
						  v-for="(item ,index ) in yesOrNoList"
						  :key="item.value" @click="onChooseLifeWayItem(item,'smoking')">{{ item.label }}
					</view>
				</view>
			</view>
			<view class="view_item_type" v-if="lifeWay.smoking===1">
				<text>吸烟频次</text>
				<view class="warp">
					<view :class=" item.value === lifeWay.smokingFrequency ? 'check_true' :'check_false' "
						  v-for="(item ,index ) in smokingFrequencyList"
						  :key="item.value" @click="onChooseLifeWayItem(item,'smokingFrequency')">{{ item.label }}
					</view>
				</view>
			</view>
			<view class="view_item_gender">
				<text>是否饮酒</text>
				<view class="warp">
					<view :class=" item.value === lifeWay.drink ? 'check_true' :'check_false' "
						  v-for="(item ,index ) in yesOrNoList"
						  :key="item.value" @click="onChooseLifeWayItem(item,'drink')">{{ item.label }}
					</view>
				</view>
			</view>
			<view class="view_item_type" v-if="lifeWay.drink===1">
				<text>饮酒频次</text>
				<view class="warp">
					<view :class=" item.value === lifeWay.drinkingFrequency ? 'check_true' :'check_false' "
						  v-for="(item ,index ) in drinkFrequencyList"
						  :key="item.value" @click="onChooseLifeWayItem(item,'drinkingFrequency')">{{ item.label }}
					</view>
				</view>
			</view>
			<view class="view_item_gender" v-if="lifeWay.drink===1">
				<text>饮酒量</text>
				<view class="warp">
					<view :class=" item.value === lifeWay.drinkAmount ? 'check_true_long' :'check_false_long' "
						  v-for="(item ,index ) in drinkAmountList"
						  :key="item.value" @click="onChooseLifeWayItem(item,'drinkAmount')">{{ item.label }}
					</view>
				</view>
			</view>
			<view class="view_item_gender">
				<text>是否运动</text>
				<view class="warp">
					<view :class=" item.value === lifeWay.sport ? 'check_true' :'check_false' "
						  v-for="(item ,index ) in yesOrNoList"
						  :key="item.value" @click="onChooseLifeWayItem(item,'sport')">{{ item.label }}
					</view>
				</view>
			</view>
			<view class="view_item_type" v-if="lifeWay.sport===1">
				<text>运动频次</text>
				<view class="warp">
					<view :class=" item.value === lifeWay.sportFrequency ? 'check_true' :'check_false' "
						  v-for="(item ,index ) in sportFrequencyList"
						  :key="item.value" @click="onChooseLifeWayItem(item,'sportFrequency')">{{ item.label }}
					</view>
				</view>
			</view>
			<view class="view_item_gender" v-if="lifeWay.sport===1">
				<text>运动时长</text>
				<view class="warp">
					<view :class=" item.value === lifeWay.sportDuration ? 'check_true_long' :'check_false_long' "
						  v-for="(item ,index ) in sportTimeList"
						  :key="item.value" @click="onChooseLifeWayItem(item,'sportDuration')">{{ item.label }}
					</view>
				</view>
			</view>
		</view>
		<view style="margin-left: 15px;">以下糖尿病合并症是否确诊：</view>
		<view class="view_bg">
			<view class="view_item_left" v-for="(complicationItem, index) in complicationList" :key="index">
				<view class="view_item_gender">
					<text>{{ complicationItem.name }}</text>
					<view class="warp">
						<view
							:class=" item.value === complication[complicationItem.field] ? 'check_true' :'check_false' "
							v-for="(item ,index ) in yesOrNoList"
							:key="item.value" @click="onChooseComplicationItem(item,complicationItem.field)">
							{{ item.label }}
						</view>
					</view>
				</view>
			</view>
			<!--			<view class="view_item_gender">-->
			<!--				<text>高血压</text>-->
			<!--				<view class="warp">-->
			<!--					<view :class=" item.value === form.hypertension ? 'check_true' :'check_false' "-->
			<!--						  v-for="(item ,index ) in yesOrNoList"-->
			<!--						  :key="item.value" @click="onChooseItem(item,'hypertension')">{{ item.label }}-->
			<!--					</view>-->
			<!--				</view>-->
			<!--			</view>-->
			<!--			<view class="view_item_gender">-->

			<!--				<text>高血脂</text>-->
			<!--				<view class="warp">-->
			<!--					<view :class=" item.value === form.hyperlipemia ? 'check_true' :'check_false' "-->
			<!--						  v-for="(item ,index ) in yesOrNoList"-->
			<!--						  :key="item.value" @click="onChooseItem(item,'hyperlipemia')">{{ item.label }}-->
			<!--					</view>-->
			<!--				</view>-->
			<!--			</view>-->
			<!--			<view class="view_item_gender">-->
			<!--				<text>糖尿病肾病</text>-->
			<!--				<view class="warp">-->
			<!--					<view :class=" item.value === form.nephropathy ? 'check_true' :'check_false' "-->
			<!--						  v-for="(item ,index ) in yesOrNoList"-->
			<!--						  :key="item.value" @click="onChooseItem(item,'nephropathy')">{{ item.label }}-->
			<!--					</view>-->
			<!--				</view>-->
			<!--			</view>-->
			<!--			<view class="view_item_gender">-->
			<!--				<text>糖尿病神经病变</text>-->
			<!--				<view class="warp">-->
			<!--					<view :class=" item.value === form.neuropathy ? 'check_true' :'check_false' "-->
			<!--						  v-for="(item ,index ) in yesOrNoList"-->
			<!--						  :key="item.value" @click="onChooseItem(item,'neuropathy')">{{ item.label }}-->
			<!--					</view>-->
			<!--				</view>-->
			<!--			</view>-->
			<!--			<view class="view_item_gender">-->
			<!--				<text>糖尿病眼病</text>-->
			<!--				<view class="warp">-->
			<!--					<view :class=" item.value === form.ophthalmopathy ? 'check_true' :'check_false' "-->
			<!--						  v-for="(item ,index ) in yesOrNoList"-->
			<!--						  :key="item.value" @click="onChooseItem(item)">{{ item.label }}-->
			<!--					</view>-->
			<!--				</view>-->
			<!--			</view>-->
		</view>
	</view>
		<view class="view_save" @click="onClickSave">
			保存
		</view>
		<view style="height: 50px;"></view>


		<nut-popup position="bottom" v-model:visible="showBirthdayPop" round>
			<nut-date-picker
				v-model="currentDate"
				:min-date="minDate"
				:max-date="maxDate"
				:is-show-chinese="true"
				@confirm="onDateConfirm"
				@cancel="showBirthdayPop = false"
			></nut-date-picker>
		</nut-popup>

	</view>

</template>
<script setup lang="ts">

import {onBeforeMount, onMounted, reactive, ref} from "vue";
import {RectRight} from "@nutui/icons-vue-taro";
import {
	drinkAmountList,
	drinkFrequencyList,
	genderList,
	ILabelItem,
	labourList,
	smokingFrequencyList, sportFrequencyList, sportTimeList,
	sugarList,
	yesOrNoList
} from "@/pagesMine/ts/dataUtils";
import HealthScale from "@/component/healthScale/index.vue";
import {formatDate} from "@/utils/util";
import {difference} from "lodash";
import MineApi, {BaseComplication, LifeWay, PatientBaseInfo} from "@/pagesMine/api/mine";
import Taro from "@tarojs/taro";
import PageNavigation from "@/utils/pageNavigation";
import {getCurrentInstance} from "@tarojs/runtime";
import StoreUtils from "@/utils/storeUtils";


definePageConfig({
	navigationBarTitleText: "编辑资料"
})

const minDate = new Date(1920, 0, 1);
const maxDate = new Date();
let currentDate = new Date();

const showBirthdayPop = ref(false)

const state = reactive({
	min: 10,
	max: 250,
  loadingWeight: true,
})

onMounted(()=>{
  setTimeout(()=>{state.loadingWeight = false},1100)
})

const heightState = reactive({
	min: 30,
	max: 250,
})

const baseInfo = ref({
	// 基础信息
	height: 165,
	weight: 65,
	name: '匿名',
	gender: 1,
	birth: formatDate(new Date()),
	diabetesType: 1,
	labourIntensity: 1, //劳动力强度
} as PatientBaseInfo)

const lifeWay = ref({
	dataId: 0,
	patientId: 0,
	// 家族史
	familyHistory: 0,
	//生活方式
	smoking: 0,
	smokingFrequency: 1,
	drink: 0,
	drinkingFrequency: 1,
	drinkAmount: 1,
	sport: 0,
	sportFrequency: 1,
	sportDuration: 1,
} as LifeWay)

const complication = ref({
	// 并发症
	dataId: 0,
	/**
	 * 高血压
	 */
	hypertension: 0,
	/**
	 * 高血脂
	 */
	hyperlipemia: 0,
	/**
	 * 糖尿病肾病
	 */
	nephropathy: 0,
	/**
	 * 神经病变
	 */
	neuropathy: 0,
	/**
	 * 糖尿病眼病
	 */
	ophthalmopathy: 0
} as BaseComplication)


const complicationList = [
	{
		name: '高血压',
		field: 'hypertension',
	}, {
		name: '高血脂',
		field: 'hyperlipemia',
	}, {
		name: '糖尿病肾病',
		field: 'nephropathy',
	}, {
		name: '糖尿病神经病变',
		field: 'neuropathy',
	}, {
		name: '糖尿病眼病',
		field: 'ophthalmopathy',
	},
]

let isCompleteBasicInfo: any = false

onBeforeMount(() => {
	let params = getCurrentInstance().router?.params;
	console.log("index.vue.onBeforeMount.params=", JSON.stringify(params));
	isCompleteBasicInfo = params && params.baseInfo
	console.log("index.vue.onBeforeMount.dataId=", isCompleteBasicInfo);
})

onMounted(() => {
	getPatientInfo(isCompleteBasicInfo)
})

Taro.eventCenter.on('login', (item) => {
	console.log("index.vue..edit login ");
	getPatientInfo(isCompleteBasicInfo)
})

/**
 *  获取客户信息与生活方式信息
 * @param withLifeWay
 */
const getPatientInfo = (withLifeWay = true) => {
	if (withLifeWay) {
		console.log("index.vue.getPatientInfo.withLifeWay",);
		MineApi.getPatientFullInfo().then(res => {
			if (res && res.data) {
				initPatientInfo(res.data.baseInfo)
				// baseInfo.value = res.data.baseInfo
				// console.log("index.vue.getPatientInfo.",JSON.stringify(baseInfo.value));
				if (res.data.lifeWay) {
					lifeWay.value = res.data.lifeWay
				}
				if (res.data.complication) {
					complication.value = res.data.complication
				}
			}
		})
	} else {
		console.log("index.vue.getPatientInfo.with out lifeway",);
		MineApi.getPatientInfo().then(res => {
			console.log("index.vue.getPatientInfo.", JSON.stringify(res.data));
			if (res && res.data) {
				initPatientInfo(res.data)
			}
		})
	}
}

const initPatientInfo=(patient:PatientBaseInfo)=>{
	if (patient){
		if (!patient.height){
			patient.height = baseInfo.value.height
		}
		if (!patient.weight){
			patient.weight = baseInfo.value.weight
		}
		if (!patient.gender){
			patient.gender = baseInfo.value.gender
		}
		if (!patient.labourIntensity){
			patient.labourIntensity = baseInfo.value.labourIntensity
		}
		if (!patient.name || patient.name.trim().length==0){
			patient.name = baseInfo.value.name
		}
		if (patient.birth){
			currentDate = new Date(patient.birth)
		}
		console.log("index.vue.after handle .patient=",JSON.stringify(patient));
	}
	baseInfo.value = patient
	console.log("index.vue.final baseinfo=.",JSON.stringify(baseInfo.value));
}


/**
 * 日期弹窗 回调
 */
const onDateConfirm = ({selectedValue, selectedOptions}) => {
	console.log("index.vue.onDateConfirm.",JSON.stringify(selectedValue));
	baseInfo.value.birth = selectedValue[0] + "-" + selectedValue[1] + "-" + selectedValue[2];
	showBirthdayPop.value = false;
}

/**
 * 点击选择基础信息
 * @param item 数据项
 * @param field 字段名称
 */
const onChooseItem = (item: ILabelItem, field: string) => {
	baseInfo.value[field] = item.value;
	baseInfo.value[`${field}` + 'Value'] = item.label;
}

/**
 * 点击选择生活方式信息
 * @param item 数据项
 * @param field 字段名称
 */
const onChooseLifeWayItem = (item: ILabelItem, field: string) => {
	lifeWay.value[field] = item.value;
	lifeWay.value[`${field}` + 'Value'] = item.label;
}

/**
 * 选择并发症
 * @param item
 * @param field
 */
const onChooseComplicationItem = (item: ILabelItem, field: string) => {
	complication.value[field] = item.value;
	complication.value[`${field}` + 'Value'] = item.label;
}

/**
 * 保存
 */
const onClickSave = () => {
	console.log("index.vue.onClickSave.", JSON.stringify(baseInfo.value), '; lifeway=', JSON.stringify(lifeWay.value));
	MineApi.savePatientInfoAndLifeWay(baseInfo.value, lifeWay.value, complication.value).then(res => {
		StoreUtils.savePatientBirthday(baseInfo.value.birth)
		StoreUtils.savePatientGender(baseInfo.value.gender)
		StoreUtils.savePatientHeight(baseInfo.value.height)
		StoreUtils.savePatientWeight(baseInfo.value.weight)
		StoreUtils.savePatientLaborIntensity(baseInfo.value.labourIntensity)

		Taro.showToast({
			title: "保存成功",
			duration:800,
		})
		PageNavigation.notifyLastPage('minePage',true)
		setTimeout(()=>{
			Taro.navigateBack()
		},200)
	})
}

// const notifyLastPage=()=>{
// 	const page = Taro.getCurrentPages()
// 	const current = page[page.length - 1] /* 从堆栈中获取当前界面的属性 */
// 	const eventChannel = current.getOpenerEventChannel()
// 	// console.log("index.vue.notifyLastPage.page=", page, '; current=', current, '; eventChannel=', eventChannel);
// 	eventChannel.emit('minePage',true)
// }

</script>

<style lang="less">
.edit_root {
	.view_bg {
		background: white;
		border-radius: 30px;
		margin: 30px;
		padding: 0 20px;

		.view_item_name {
			display: flex;
			align-items: center;
			justify-content: space-between;
			padding: 30px 0;
			border-bottom: #efefef solid 1px;

			.arrow {
				display: flex;
				flex-direction: row;
				justify-content: center;
				align-items: center;
			}

			input {
				text-align: right;
			}
		}

		.view_item_gender {
			display: flex;
			align-items: center;
			justify-content: space-between;
			border-bottom: #efefef solid 1px;
			padding: 30px 0;

			.warp {
				display: flex;
				justify-content: center;
				align-items: center;
			}
		}

		.view_item_birthday {
			display: flex;
			align-items: center;
			justify-content: space-between;
			border-bottom: #efefef solid 1px;
			padding: 30px 0;

			.arrow {
				display: flex;
				flex-direction: row;
				justify-content: center;
				align-items: center;
			}
		}

		.view_item_type {
			display: flex;
			padding: 30px 0;
			flex-direction: column;
			border-bottom: #efefef solid 1px;

			.warp {
				display: flex;
				margin-top: 20px;
				flex-wrap: wrap;
			}
		}
	}
}

.check_true {
	width: 200px;
	height: 60px;
	border-radius: 30px;
	background: #6aa4fc;
	color: white;
	margin: 5px 5px;
	line-height: 60px;
	border: #6aa4fc solid 1px;
	text-align: center;
}

.check_false {
	width: 200px;
	height: 60px;
	border-radius: 30px;
	border: #6aa4fc solid 1px;
	background: white;
	color: #6aa4fc;
	margin: 5px 5px;
	line-height: 60px;
	text-align: center;
}

.check_true_long {
	width: 230px;
	height: 60px;
	border-radius: 30px;
	background: #6aa4fc;
	color: white;
	margin: 5px 5px;
	line-height: 60px;
	border: #6aa4fc solid 1px;
	text-align: center;
}

.check_false_long {
	width: 230px;
	height: 60px;
	border-radius: 30px;
	border: #6aa4fc solid 1px;
	background: white;
	color: #6aa4fc;
	margin: 5px 5px;
	line-height: 60px;
	text-align: center;
}

.view_save {
	width: 720px;
	color: white;
	background: #6aa4fc;
	border-radius: 10px;
	line-height: 80px;
	margin: 100px auto;

	height: 80px;
	text-align: center;
}

.nut-picker__confirm {
	color: #6aa4fc;
}

</style>
