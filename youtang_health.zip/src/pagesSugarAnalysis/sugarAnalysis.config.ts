export default definePageConfig({
    navigationBarTitleText: "血糖分析",
    usingComponents:{
        'ec-canvas':'@/component/ec-canvas/ec-canvas'
    }
});
