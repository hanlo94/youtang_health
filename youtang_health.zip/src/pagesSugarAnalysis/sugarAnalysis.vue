<!--
Description：
Created on 2023/9/9
Author :  郭 -->
<template>
  <view class="view_root">

    <nut-tabs class="tab" v-model="active" color="#64A4F5" background="#ffffff" @click="changeTab">
      <nut-tab-pane title="曲线"></nut-tab-pane>
      <nut-tab-pane title="列表"></nut-tab-pane>
    </nut-tabs>
    <view class="view_charts" v-if="active === '0' ">
      <view class="view_bg">
        <view class="view_btn">
          <nut-button :class=" buttonIndex === 2? 'btn_true' : 'btn_false'  " type="info"
                      @click="onClickFilter(2)">
            两周
          </nut-button>
          <nut-button :class=" buttonIndex === 3? 'btn_true' : 'btn_false'" type="info"
                      @click="onClickFilter(3)">
            一个月
          </nut-button>
          <nut-button :class=" buttonIndex === 5? 'btn_true' : 'btn_false'" type="info"
                      @click="onClickFilter(5)">
            三个月
          </nut-button>
        </view>
        <view class="latest_container">
          <view class="latest_record">{{sugar.recordTime}}{{sugar.timeType}}</view>
          <view style="display: flex; align-items: flex-end; text-align: end;vertical-align: bottom" >
            <view class="latest_record " :class="sugar.status" > {{ sugar.sugarValue }}</view>
            <view class="latest_record">mmol/L</view>
          </view>
          <view class="latest_record">{{sugar.recordStatue }}</view>
        </view>

        <view class="charts" v-if="!isEmpty(recordTableList) ">
          <ec-canvas id="chart-dom-area" canvas-id="chart-area" :ec="ec"
                     force-use-old-canvas="true"></ec-canvas>
        </view>
        <view v-else>
          <nut-empty image="https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/common/nodata.png"
                     description="暂时还没有数据哦~"></nut-empty>
        </view>
      </view>

      <view class="view_bg " style="margin-top: 20px">
        <text>血糖数据</text>
        <sugar-table class="sugar_tab" :recordList=recordTableList></sugar-table>
      </view>
    </view>
    <scroll-view :scroll-y="true" @scrollToLower="scroll" flexed class="view_list" v-if="active === '1'"
                 :lowerThreshold="150">
      <view v-if="!isEmpty(dataList)" class="view_item" v-for="(item, index) in dataList" :key="index">
        <view class="item_header">
          <text>{{ item.ymdWeek }}</text>
        </view>
        <view class="item_bottom" v-for="(childItem,childIndex) in item.list" :key="childIndex"
              @click.stop="onItemClick(childItem)">
          <text class="record_time">{{ childItem.ms }}</text>
          <text class="record_timetype">{{
              getSugarTimeByType(childItem.sugarValuesTimeTypeId)?.value || "随机"
            }}
          </text>
          <tag-text class="record_value"
                    :is-normal="formatSugarUpNormalLow(childItem.sugarValuesSugarValue,childItem.sugarValuesTimeTypeId)"
                    :sugarValue="childItem.sugarValuesSugarValue"
                    :show-unity="'mmol/L'"></tag-text>
        </view>
      </view>
      <view v-else class="view_no_data">
        <nut-empty image="https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/common/nodata.png"
                   description="暂时还没有数据哦~"></nut-empty>
      </view>
    </scroll-view>

  </view>
</template>
<script setup lang="ts">

import {computed, reactive, ref} from "vue";
import TagText from "@/component/tag-text/tag-text.vue";
import SugarTable from "@/component/sugar-table/sugar-table.vue";
import SugarApi from "@/api/modules/sugar";
import {chain, isEmpty, zipObject} from "lodash";
import {addDays, formatDate, formatDate2Hm, formatDate2YmdWeek} from "@/utils/dateUtils";
import {formatSugarUpNormalLow, getSugarTimeByType} from "@/utils/sugarUtils";
import * as echarts from "@/component/ec-canvas/echarts";
import {Chart} from "@/api/types";
import {SugarTableRecord, SugarValuePO} from "@/pagesSugarAnalysis/ts/types";
import {categoryChartOptions} from "@/utils/chartOption";
import Taro from "@tarojs/taro";

definePageConfig({
  navigationBarTitleText: '血糖记录'
})
const active = ref('0')
const sum = ref([]);
const pageNum = ref(1);

// const dataList = ref<Array<ISugarItem>>([] as ISugarItem[]);
const dataList = ref<Array<any>>([]);
/**
 * 切换button
 */
const buttonIndex = ref(2)

const recordTableList = ref<SugarTableRecord[]>([] as SugarTableRecord[])

const latestSugarRecord = ref<SugarValuePO>()

const chart = ref();

function initChart(canvas: any, width: any, height: any) {
  // echarts.init初始化
  chart.value = echarts.init(canvas, null, {
    width,
    height
  })
  // canvas.setChart(chart)
  requestTimePeriodData('from chart');
  return chart
}

// function initChart(canvas: any, width: any, height: any) {
//
//   // echarts.init初始化
//   const chart = echarts.init(canvas, null, {
//     width,
//     height
//   })
//   canvas.setChart(chart)
//   const option = {
//     xAxis: {
//       type: 'category',
//       boundaryGap: false,
//       data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
//     },
//     yAxis: {
//       type: 'value'
//     },
//     series: [
//       {
//         data: [820, 932, 901, 934, 1290, 1330, 1320],
//         type: 'line',
//         areaStyle: {}
//       }
//     ]
//   }
//
//   chart.setOption(option)
//   return chart
// }

const ec = reactive({
  onInit: initChart
})

const sugar = computed(() => {
  // sugar: {recordTime: "10/26 09:00", timeValue: 1, timeType: "早餐后", sugarValue: 6}
  // recordTime: "10/26 09:00"
  // sugarValue: 6
  // timeType: "早餐后"
  // timeValue: 1



  let sugarValue, timeType, recordTime,sugarStatus = 2, status,recordStatue
  let sugarRecord = latestSugarRecord.value;
  if (sugarRecord){
    sugarValue=sugarRecord.sugarValue
    if (!sugarRecord.recordState) {
      sugarStatus = formatSugarUpNormalLow(sugarValue, sugarRecord.timeValue);
    }else{
      sugarStatus=sugarRecord.recordState
    }
    console.log('sugarAnalysis.compute .sugarStatus=',sugarStatus,'; sugarRecord.recordState=',sugarRecord.recordState)
    if (sugarStatus == 1) {
      status = 'sugar_data_low'
      recordStatue='偏低'
    } else if (sugarStatus == 3) {
      status = 'sugar_data_high'
      recordStatue='偏高'
    } else {
      status = 'sugar_data_normal'
      recordStatue='正常'
    }
    timeType=sugarRecord.timeType
    recordTime=sugarRecord.recordTime+"   "
  } else {
    recordTime = '---'
    timeType = '--'
    status = ''
    sugarValue = '--'
    recordStatue = '--'
  }

  const res = {
    recordTime,
    timeType,
    status,
    sugarValue,
    recordStatue
  }
  return res;

})

/**
 * 切换曲线与列表标签
 */
const changeTab = (res) => {
  let {paneKey} = res
  if (paneKey == 0) {
    requestTimePeriodData('changeTab ')
  } else if (paneKey == 1) {
    pageNum.value = 1
    requestRecordList()
  }
}

/**
 * 点击按钮 切换状态 请求接口
 * @param index
 */
const onClickFilter = (index) => {
  buttonIndex.value = index;
  requestTimePeriodData('onClickFilter index=' + index)
}

/**
 * loadmore
 */
const scroll = () => requestRecordList();

const requestTimePeriodData = (from) => {
  console.log("sugarAnalysis.vue.requestTimePeriodData.from=", from);
  SugarApi.getTimePeriodSugarChart(buttonIndex.value).then(res => {
    // console.log("sugarAnalysis.vue..", JSON.stringify(res));
    if (!res) {
      return
    }
    latestSugarRecord.value=res.record

    recordTableList.value = res.recordList
    if (res.chart) {
      let chartData = res.chart as Chart
      loadChart(chartData)
    } else {
      loadChart()
    }
  })
}

requestTimePeriodData('mounted ')

Taro.eventCenter.on('login', (item) => {
  requestTimePeriodData('after login ')
})


const loadChart = (chartData?: Chart) => {
  let xAxisData = chartData?.dates.split(',');
  let yAxisData = chartData?.values.split(',');
  let currentDate = formatDate(new Date());
  // 为空时 设置假数据 占位 确保曲线中标线正常展示
  if (!xAxisData) {
    xAxisData = [];
    yAxisData = [];
    if (xAxisData.length == 0) {
      // 确保至少15以上 ，不超过18
      let periodCount = -13;
      if (buttonIndex.value == 2) {
        periodCount = -13;
      } else if (buttonIndex.value == 3) {
        periodCount = -29;
      } else {
        periodCount = -89;
      }
      for (let i = periodCount; i < 0; i++) {
        xAxisData.push(addDays(currentDate, i));
      }
      xAxisData.push(addDays(currentDate, 1));
      yAxisData[xAxisData.length - 1] = '16';
    }
  }
  if (chart && chart.value) {
    const option = categoryChartOptions(xAxisData, yAxisData, xAxisData[0], currentDate);
    chart.value.setOption(option)
  }
}

const requestRecordList = () => {
  SugarApi.getSugarList(pageNum.value).then(res => {
    if (pageNum.value === 1) dataList.value = [];
    if (!isEmpty(res.recordList)) {
      let list = res.recordList.map(item => {
        return {
          ...item,
          ymdWeek: formatDate2YmdWeek(item.sugarValuesRecordDate),
          ms: formatDate2Hm(item.sugarValuesRecordTime)
        }
      });
      dataList.value.push(...chain(list).groupBy('ymdWeek').toPairs().map(item => {
        return zipObject(['ymdWeek', 'list'], item)
      }).value())
      pageNum.value++;
    }
  })
}

const onItemClick = (item) => {
  // console.log("sugarAnalysis.vue.onItemClick.",JSON.stringify(item));
  Taro.navigateTo({
    url: '/pages/sugar/index?data=' + JSON.stringify(item)
  })
}


</script>
<style lang="less">
.view_root {
  background: #efefef;
  position: relative;
  height: 100vh;

  .tab {
    position: fixed;
    width: 100%;
    z-index: 10;
    height: 100px;
    top: 0;
  }

  .view_list {
    padding-top: 100px;
    height: calc(100% - 100px);

    .view_item {
      background: white;
      border-radius: 20px;
      display: flex;
      padding: 20px;
      flex-direction: column;
      margin: 20px 30px;

      .item_header {
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
        padding-bottom: 10px;
        color: #666666;
        border-bottom: #efefef 1px solid;;
      }

      .item_bottom {
        display: flex;
        margin-top: 20px;
        flex-direction: row;
        color: #333333;

        .record_time {
          width: calc(40%);
        }

        .record_timetype {
          width: calc(33%);
          text-align: left;
        }

        .record_value {
          width: calc(44%);
          text-align: right;
        }

      }

    }

  }

  .view_no_data {
    height: 100vh;
    padding-top: 150px;

    .nut-empty__box {
      width: 440px;
      height: 260px
    }
  }

  .view_charts {
    padding-top: 100px;
    height: 100vh;
    flex: 1;
    margin: 30px;

    .view_bg {
      display: flex;
      background: white;
      padding: 30px;
      border-radius: 15px;
      flex-direction: column;

      .view_btn {
        border: 10px;
        width: 100%;
        display: flex;
        justify-content: space-around;
        align-items: center;

        .btn_true {
          width: 160px;
          height: 70px;
          background: #0099ff;
          color: #ffffff;
          border: #0099ff solid 1px;
        }

        .btn_false {
          width: 160px;
          height: 70px;
          color: #0099ff;
          background: #ffffff;
          border: #0099ff solid 1px;
        }

      }

      .nut-empty__box {
        width: 330px;
        height: 195px
      }

      .charts {
        height: 480px;
      }

      .table {
      }

      .latest_container {
        display: flex;
        flex-direction: row;
        justify-content: space-around;
        margin-top: 20px;
        align-items: flex-end;
        text-align: center;

        .latest_record {
          text-align: center;
          color: #333333;
          display: inline-block;
          vertical-align: bottom;
          font-size: 30px;
        }

        .sugar_data_high {
          font-size: 40px;
          color: #e64a4a;
          font-weight: normal;
        }

        .sugar_data_low {
          font-size: 40px;
          color: #feb433;
          font-weight: normal;
        }

        .sugar_data_normal {
          font-size: 40px;
          color: #4aa4fc;
          font-weight: normal;
        }

      }


    }


  }

  .sugar_tab {
    margin-top: 20px;
  }

}

</style>
