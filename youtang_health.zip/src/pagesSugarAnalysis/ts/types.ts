/**
 * Description：
 * Created on 2023/7/20
 * Author :  郭
 */

export interface ISugarItem {
    dataId: number;
    sugarValuesRecordDate: string;
    sugarValuesRecordTime: string;
    sugarValuesRemarks: string;
    sugarValuesSourceType: number;
    sugarValuesSugarValue: number;
    sugarValuesTimeTypeId: number;
    sugarValuesType: number;
    sugarValuesUserId: number;
    child:ISugarItem;
}

export interface SugarRecord {
    id: number;
    time: string;
    value: number;
    remark: string;
    patientId: number;
    type: number;
    sugarvalueType: number;
}

export interface SugarTableRecord {
    date: string;
    formatDate: string;
    patientId: number;
    earlyMorningRecord: SugarRecord;
    beforeBreakfastRecord: SugarRecord;
    afterBreakfastRecord: SugarRecord;
    beforeLunchRecord: SugarRecord;
    afterLunchRecord: SugarRecord;
    beforeDinnerRecord: SugarRecord;
    afterDinnerRecord: SugarRecord;
    beforeSleepRecord: SugarRecord;
    randomTimeRecord: SugarRecord;
}

export class SugarValuePO {
    /**
     * 记录时间
     */
    recordTime: Date;

    /**
     * 测量时间类型值：0 - 8
     */
    timeValue: number;

    /**
     * 测量时间文字：如：早餐前 早餐后
     */
    timeType: string;

    /**
     * 血糖测量值
     */
    sugarValue: number;

    /**
     * 偏高偏低状态
     */
    recordState: number;

    /**
     * 偏高偏低文字
     */
    valueType: string;
}

