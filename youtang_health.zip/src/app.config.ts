export default defineAppConfig({
    pages: [
        "pages/index/index", //控糖
        "pages/mine/mine",  //我的
        "pages/mall/mall", //值得用
        // "pages/sugar/index",
        // "pages/sugarAnalysis/sugarAnalysis",
        "pages/drugstorage/drugstorage",
        "pages/academy/index", // 健康学院
        // "pages/webview/index",
        // "pages/login/login"
    ],
    subPackages: [
        {
            root: "pagesBmi",
            pages: ["add/index", "record/index"],
        },
        {
            root: "pagesHba1c",
            pages: ["add/index", "record/index"],
        },
        {
            root: "pagesBodyFat",
            pages: ["add/index", "record/index", 'details/index'],
        },
        {
            root: "pagesBodyMaterial",
            pages: ["compare/index", "list/index", 'detail/index'],
        },
        {
            root: "pagesComposite",
            pages: [ "list/index", 'index/index'],
        },
        {
            root: "pagesBp",
            pages: ["add/index", "record/index"],
        },
        {
            root: "pagesFood",
            pages: ["index/index", "add/index", "record/index", "analysis/index", "history/index", "historyDetail/index", 'phoneAdd/index', 'calories/index'],
        },
        {
            root: "pagesAcademy",
            pages: ['gi/index', 'food/index', 'drug/index', 'article/index'],
        },
        {
            root: "pagesSugar",
            pages: ['star/index']
        },
        {
            root: "pagesMine",
            pages: ['userInfo/index','message/index', "device/device", 'report/index', 'setting/index', 'edit/index', 'yasiGlm/add/index','points/index','points/history/index']
        },
        {
            root: "pagesCommon",
            pages: ['webview/landscape']
        },
        {
            root: "pagesActive",
            pages: ['index/index', 'add/index','basicinfo/index', 'disease/index', 'tool/index', 'medicine/index', 'life/index', 'food/index','health/index']
        },
        {
            root: "pagesTreatment",
            pages: ['index/index','info/index','record/index','statistics/index']
        },
        {
            root: "pagesChat",
            pages: ['index']
        },
        {
            root: "pagesMainSugar",
            pages: ['index']
        },
        {
            root: "pagesSugarAnalysis",
            pages: ['sugarAnalysis']
        },
        {
            root: "pageWebview",
            pages: ['index']
        },
        {
            root: "pagesLogin",
            pages: ['login']
        }, 
    ],
    window: {
        backgroundTextStyle: "light",
        navigationBarBackgroundColor: "#fff",
        navigationBarTitleText: "WeChat",
        navigationBarTextStyle: "black",
    },
    tabBar: {
        color: "#666",
        selectedColor: "#333",
        backgroundColor: "#fff",
        borderStyle: "black",
        list: [
            {
                pagePath: "pages/index/index",
                text: "控糖",
                iconPath: "assets/image/tabbar/home.png",
                selectedIconPath: "assets/image/tabbar/home_check.png",
            },
            {
                pagePath: "pages/academy/index",
                text: "健康学院",
                iconPath: "assets/image/tabbar/school.png",
                selectedIconPath: "assets/image/tabbar/school_check.png",
            },
            {
                pagePath: "pages/mall/mall",
                text: "值得用",
                iconPath: "assets/image/tabbar/shop.png",
                selectedIconPath: "assets/image/tabbar/shop_check.png",
            },
            {
                pagePath: "pages/mine/mine",
                text: "我的",
                iconPath: "assets/image/tabbar/mine.png",
                selectedIconPath: "assets/image/tabbar/mine_check.png",
            },
        ],
    },
    usingComponents: {
        'wxscale': '@/component/wx-scale/wx-scale',
    },
    plugins: {
        "QNBleApi": {
            "version": "4.8.0",
            "provider": "wx2a4ca48ed5e96748"
        },
        "WechatSI": {
            "version": "0.0.7",
            "provider": "wx069ba97219f66d99"
        }
        // "chartApi": {
        //     "version": "2.1.1",
        //     "provider": "wx1db9e5ab1149ea03"
        // },

    },
});
