<template>
  <view>
    <web-view :src='decodeSrc' @message="handleMessage"/>
  </view>
</template>

<script setup lang="ts">
import {getCurrentInstance} from "@tarojs/runtime";
import Taro from "@tarojs/taro";

const {src, title} = (getCurrentInstance().router?.params)
if (title) {
  Taro.setNavigationBarTitle({
    title
  })
}

let decodeSrc = decodeURIComponent(src)
if (decodeSrc.indexOf('http:')!=-1){
	decodeSrc= decodeSrc.replace('http:','https:')
}

console.log('url',decodeSrc,src)
const handleMessage = (e) => {
  console.log('msg', e)
}
</script>


<style scoped lang="less">

</style>
