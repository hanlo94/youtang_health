export default definePageConfig({
    pageOrientation: "landscape",
});
