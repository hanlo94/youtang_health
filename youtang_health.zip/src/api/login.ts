import {postXcxRequest} from "@/api/api";
import {PatientInfo, WxMaSessionInfo, WxMaUserInfo} from "@/api/types";

const BASE_PATH = "/auth/"

const LoginApi = {

	/**
	 * 创建微信session
	 * @param code
	 */
	code2Session(code) {
		return postXcxRequest<WxMaSessionInfo>({code: code}, BASE_PATH + "login")
	},

	decryptUserInfo(encryptedData, iv, openId: string | undefined, unionId: string | undefined) {
		return decrypt<WxMaUserInfo>({encryptedData, iv, openId, unionId}, BASE_PATH + "user");
	},

	decryptPhoneNo(encryptedData, iv, openId: string | undefined, unionId: string | undefined) {
		return decrypt<PatientInfo>({encryptedData, iv, openId, unionId}, BASE_PATH + "phone");
	},

	init(){

	}

}

/**
 * 数据界面
 * @param encryptedData
 * @param iv
 * @param rawData
 * @param signature
 */
function decrypt<T>(param: { encryptedData, iv, openId, unionId }, path) {
	return postXcxRequest<T>(param, path)
}

export default LoginApi
