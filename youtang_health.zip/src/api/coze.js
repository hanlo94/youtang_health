// src/services/api.js

import axios from "axios";

const ARO_APP_COZE_TOKE =
  "pat_XBd8iv4JAjFRJ5oHW02xqSgviYIQKcx6MDsirfa5V8xp57pE8UrMU2HBQv4k0vgD";
const botId = "7452643148675252276";

// 创建一个 axios 实例
const apiClient = axios.create({
  baseURL: "https://api.coze.cn/v3", // Coze API 基础 URL
  timeout: 5000, // 设置请求超时为 5 秒
  headers: {
    "Content-Type": "application/json",
  },
});

// 请求拦截器：在每个请求之前添加 Authorization 头
apiClient.interceptors.request.use(
  (config) => {
    // const accessToken = 'your_access_token'  // 假设 access_token 已经存储在本地或者是通过授权获得
    if (ARO_APP_COZE_TOKE) {
      config.headers["Authorization"] = `Bearer ${ARO_APP_COZE_TOKE}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// 响应拦截器：处理返回的数据或错误
apiClient.interceptors.response.use(
  (response) => {
    return response.data; // 返回响应数据
  },
  (error) => {
    return Promise.reject(error);
  }
);

// 调用 Coze API 发送智能对话消息

export const callCozeAPI = async (message) => {
  const res = await getCozeMsg(); // 调用获取消息的函数
  console.log(res, "vvvvvvvvvvvvvvvvvv");

  const resRetrie = await callRetrieve(res);  

//   const loop = async (res) => {
//     const resRetrie = await callRetrieve(res);
//     if (resRetrie.status === "completed") {
//       clearInterval(timer);
//     }
//   };

//   let timer = setInterval(() => {
//     loop(res);
//   }, 1000);
};

const getCozeMsg = async () => {
  const response = await apiClient.post("/chat", {
    bot_id: "7452643148675252276",
    user_id: "1234",
    stream: false,
    auto_save_history: true,
    additional_messages: [
      {
        role: "user",
        content: "糖尿病是什么",
        content_type: "text",
        //   role: "user",
        //   content: [{ type: "text", text: message }],
        //   content_type: "object_string",
      },
    ],
  });
  return response.data;
};

export const callRetrieve = async ({conversation_id, id}) => {
  console.log(conversation_id, id, "0000000000000000000000");
  return await apiClient.get("/chat/retrieve", {
    conversation_id,
    chat_id: id,
  });
};
