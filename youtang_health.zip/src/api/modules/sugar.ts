import api, {
	PAGE_SIZE,
	POST_URL_PATIENT,
	postCommonPatientRequest,
	postPatientRequest
} from "@/api/api";

import {DeviceBindState} from "@/config/device/deviceConfig";
import {
	BodyFatDataPo,
	BodyFatUpload,
	IBleGluUploadData,
	IDeviceItem,
	ISugarStarItem,
	SugarChartData
} from "@/api/types";
import {ISugarItem} from "@/pagesSugarAnalysis/ts/types";


function generateDeviceRequest(deviceBrand, deviceCategory, deviceSn = null, isBind) {
	return {
		bindState: isBind ? DeviceBindState.BIND : DeviceBindState.UNBIND,
		operation: isBind ? DeviceBindState.BIND : DeviceBindState.UNBIND,
		deviceBrand: deviceBrand,
		deviceType: deviceBrand,
		deviceCategory: deviceCategory,
		deviceMac: deviceSn,
		deviceSn: deviceSn,
		imei: deviceSn
	}
}

const SugarApi = {

	/**
	 * 获取控糖首页数据
	 */
	getMainPageData() {
		return postCommonPatientRequest(11030100)
	},

	/**
	 * 获取首页控糖明星
	 */
	getSugarStars() {
		return postCommonPatientRequest(300008)
	},

	/**
	 * 分页获取控糖明星
	 */
	getSugarStarList(page, pageSize = PAGE_SIZE) {
		const params = {
			page: page,
			pageNum: page,
			pageSize: pageSize,
			actId: 300006
		}
		return postPatientRequest<ISugarStarItem[]>(params)
	},

	/**
	 * 添加或修改血糖
	 * @param id  记录ID 新增为0
	 * @param value  记录值
	 * @param type 血糖时段  0-空腹
	 * @param valueType 记录状态  偏高  偏低 正常
	 * @param time  记录时间 yyyy-MM-dd HH:mm:ss
	 * @param remark 备注
	 * @returns {Promise | Promise<unknown>}
	 */
	addOrEditSugar(params: { value, type, sugarvalueType, time, remark, id?: number }) {
		const data = {
			sugarValueBean: {
				...params,
			},
			actId: 130101,
		}
		return postPatientRequest(data)
	},

	/**
	 * 血糖记录列表
	 * @param page
	 * @param pageSize
	 * @returns {Promise | Promise<unknown>}
	 */
	getSugarList(page, pageSize = PAGE_SIZE) {
		const data = {
			page: page,
			pageNum: page,
			pageSize: pageSize,
			actId: 20201,
		}
		return postPatientRequest<Array<ISugarItem>>(data)
	},

	/**
	 * 根据时间段获取血糖曲线数据，默认查询最近一月数据
	 * @param startDate 开始日期 yyyy-MM-dd
	 * @param endDate 结束日期  yyyy-MM-dd
	 */
	getTimePeriodSugarChart(period) {
		let param = {
			actId: 1012035,
			period
		};
		return postPatientRequest<SugarChartData>(param)
	},

	// region ********** 智能设备与体脂 **********

	/**
	 * 请求设备列表
	 */
	getDeviceList() {
		return api.post<IDeviceItem[]>(POST_URL_PATIENT + 'device/app/list')
	},

	/**
	 * 绑定设备
	 * @param deviceSn
	 * @param deviceBrand
	 * @param deviceCategory
	 */
	bindDevice(deviceSn, deviceBrand, deviceCategory) {
		let param = generateDeviceRequest(deviceBrand, deviceCategory, deviceSn, true)
		return api.post(POST_URL_PATIENT + 'device/bind', param)
	},

	// bindBiolandDevice(deviceSn, deviceBrand, deviceCategory) {
	// 	let param = generateDeviceRequest(deviceBrand, deviceCategory, deviceSn, true)
	// 	let data = {
	// 		...param,
	// 		actId: 130127
	// 	}
	// 	return postV4Request(data)
	// 	// return api.post(POST_URL_PATIENT + 'device/bind', data)
	// },
	//
	// unbindBiolandDevice(deviceCategory) {
	// 	let data = {
	// 		"deviceCategory": deviceCategory,
	// 		"actId": 130128,
	// 	}
	// 	return postV4Request(data)
	// },
	//
	// bindXty(imei) {
	// 	let data = {
	// 		"deviceCategory": 0,
	// 		"imei": imei,
	// 		"actId": 23100,
	// 	}
	// 	return postV2Request(data)
	// },
	//
	// unbindXtyDevice() {
	// 	let data = {
	// 		"actId": 23107,
	// 	}
	// 	return postV2Request(data)
	// },


	/**
	 * 解除绑定
	 * @param deviceBrand
	 * @param deviceCategory
	 */
	unBindDevice(deviceBrand, deviceCategory) {
		let param = generateDeviceRequest(deviceBrand, deviceCategory, null, false)
		return api.post(POST_URL_PATIENT + 'device/bind', param)
	},

	/**
	 * 上传体脂数据
	 * @param param
	 * @returns {Promise | Promise<unknown>}
	 */
	uploadBodyFatRecord(param: BodyFatUpload) {
		return api.post<any, any, BodyFatUpload>(POST_URL_PATIENT + 'device/qingniu/upload', param)
	},

	/**
	 * 获取体脂数据
	 * @param descFlag true 倒序 false正序
	 * @param type 1 两周 2 一月 3 三月
	 * @param page
	 * @param pageSize
	 */
	getBodyFatRecordList(descFlag, type?: number | undefined, page?: number, pageSize?: number) {
		const data = {
			actId: 11031201,
			descFlag,
			type,
			page,
			pageSize,
			pageNum: page,
		}
		return postPatientRequest<BodyFatDataPo[]>(data)
	},

	getBodyFatRecordInfo(dataId) {
		const data = {
			actId: 11031202,
			dataId
		}
		return postPatientRequest<BodyFatDataPo>(data)
	},

	/**
	 * 上传雅思GLM数据
	 * @param param
	 */
	uploadYasiBleRecord(param: IBleGluUploadData) {
		return api.post<any, any, IBleGluUploadData>(POST_URL_PATIENT + 'device/yasi/upload', param)
	},

	//endregion
}
export default SugarApi;
