import api from "@/api/api";

/**
 *Description：调查问卷相关接口
 *Created on 2024/5/5
 * xcxtest.youtang120.com/patient/api/tysExtHealthBaseInfo/search
 *Author :  郭
 */
const activeApi = {
    /**
     * 请求index msg列表
     */
    requestActiveMsgList(data: any) {
        return api.post('/patient/api/tysExtHealthAssessmentQuestionnaire/search', data)
    },
    /**
     * 请求列表
     */
    requestActiveList(profileId: number) {
        let data={}
        if (profileId && profileId>0){
            data={profileId,dataId:profileId}
        }
        return api.post('/patient/api/tysExtHealthAssessmentQuestionnaire/getModules',data)
    },
    /**
     * 请求全部提交
     */
    requestActiveListSubmit(dataId: number) {
        return api.post('/patient/api/tysExtHealthAssessmentQuestionnaire/allSubmit', {dataId})
    },


    /**
     * 获取详情
     * @param profileId
     */
    requestBasicInfo(profileId: number) {
        return api.post('/patient/api/tysExtHealthBaseInfo/loadByProfileId', {profileId})
    },
    /**
     * 新增保存
     * @param data
     */
    requestBasicInfoCreate(data: any) {
        return api.post('/patient/api/tysExtHealthBaseInfo/create', data)
    },
    /**
     * 编辑保存
     * @param data
     */
    requestBasicInfoEdit(data: any) {
        return api.post('/patient/api/tysExtHealthBaseInfo/update', data)
    },

    /**
     * 疾病详情 用于回显
     * @param profileId
     */
    requestDiseaseDetails(profileId: number) {
        return api.post('/patient/api/tysExtHealthDisInfo/loadByProfileId', {profileId})
    },
    /**
     * 疾病详情 编辑
     * @param data
     */
    requestDiseaseEdit(data: any) {
        return api.post('/patient/api/tysExtHealthDisInfo/update', data)
    },
    /**
     * 疾病详情 编辑
     * @param data
     */
    requestDiseaseCreate(data: any) {
        return api.post('/patient/api/tysExtHealthDisInfo/create', data)
    },
    // ------------------------------------------------------------------------------------
    /**
     * 工具疾病详情
     * @param profileId
     * @param conditionType 1工具 2药
     */
    requestToolDetails(profileId:number,conditionType:number){
        return api.post('/patient/api/tysExtHealthDrugTools/loadByProfileId',{profileId,conditionType})
    } ,
    /**
     * 工具疾病编辑
     * @param profileId
     * @param conditionType 1工具 2药
     */
    requestToolEdit(data:any){
        return api.post('/patient/api/tysExtHealthDrugTools/update',data)
    },
    /**
     * 工具疾病 草稿
     * @param profileId
     * @param conditionType 1工具 2药
     */
    requestToolCreate(data:any){
        return api.post('/patient/api/tysExtHealthDrugTools/create',data)
    },

    // ------------------------------------------------------------------------------------
    /**
     * 生活习惯 详情
     * @param profileId
     */
    requestLifeDetails(profileId:number){
        return api.post('/patient/api/tysExtHealthLifestyle/loadByProfileId',{profileId})
    } ,
    /**
     * 生活习惯 编辑
     * @param data
     */
    requestLifeEdit(data:any){
        return api.post('/patient/api/tysExtHealthLifestyle/update',data)
    },
    /**
     * 生活习惯 草稿
     * @param data
     */
    requestLifeCreate(data:any){
        return api.post('/patient/api/tysExtHealthLifestyle/create',data)
    },

    // ------------------------------------------------------------------------------------
    /**
     * 饮食 编辑
     * @param data
     */
    requestFoodEdit(data:any){
        return api.post('/patient/api/tysExtHealthDietarySurvey/update',data)
    },
    /**
     * 饮食 草稿
     * @param data
     */
    requestFoodCreate(data:any){
        return api.post('/patient/api/tysExtHealthDietarySurvey/create',data)
    },
    /**
     * 饮食 详情
     * @param profileId
     */
    requestFoodDetails(profileId:number){
        return api.post('/patient/api/tysExtHealthDietarySurvey/loadByProfileId',{profileId})
    }
}

export default activeApi;
