// import api, { URL_PATH_PATIENT } from "@/api/api";

// const path = URL_PATH_PATIENT + "vchat";
import {postSugarRequest, streamRequest} from '@/api/api'

/**
 * 发送消息
 * @param conversationID
 */
export const chatSendMsg = (data: chatSend) => {
    
    // setTimeout(() => {
    //     streamChat(data).then(response => {
    //     console.log("chat.response=..", response, '; response.data=', response.data);
    //     response.data && response.data.on('data', (chunk) => {
    //         // 处理流数据的逻辑
    //         console.log("chat.streamChat.data.chunk=", chunk, '; type of chunk=', (typeof chunk));
    //     });
    //
    //     response.data && response.data.on('end', (end) => {
    //         // 数据接收完成的逻辑
    //         console.log("chat.streamChat.end ", end)
    //     });
    // })
    // }, 3000);
    return postSugarRequest<any>(data, 'chat/send')
    // return api.post(path + "/send", data);
};
/**
 * 发送消息
 * @param conversationID
 */
// export const streamChat = (data: chatSend) => {
//     return streamRequest<any>(data, 'chat/stream')
// };

/**
 * 发送消息测试
 */
export const streamChat = (data: chatSend) => {
    return streamRequest<any>(data, 'chat/stream3')
};

/**
 * 删除对话
 */
export const chatclearMsg = (data: chatclear) => {
    return postSugarRequest<any>(data, 'chat/conversation/clear')
    // return api.post(path + "/conversation/clear", data);
};

/**
 * 创建对话
 */
export const chatCreate = (data: chatConversationId) => {
    return postSugarRequest<any>(data, 'chat/conversation/create')
};

/**
 * 查看智能体信息
 * 智能体信息包括图标 提示语  推荐问题那些
 */
export const chatBot = () => {
    return postSugarRequest<any>({}, 'chat/bot')
};

/**
 * 消息列表
 * @param conversationID
 */
export const getChatList = (data: chatList) => {
    return postSugarRequest<any>(data, 'chat/msg/list')
};

/**
 * 查询当前会话ID
 */
export const getchatConversationId = (data: chatConversationId) => {
    return postSugarRequest<any>(data, 'chat/conversation/id')
};

export const toggleLike = (data: toggleLike) => {
    return postSugarRequest<any>(data, 'chat/msg/toggleLike')
};

export const getHistory = (data: chatHistory) => {
    return postSugarRequest<any>(data, 'chat/conversation/list')
};

interface chatHistory {
    startId?: string | null
    // conversationId?: number | null;
    // pageNum?: number | null;
    pageSize?: number | 5;
}

interface toggleLike {
    msgId: string,
    isLike: number,
    conversationId: string
}


export interface chatSend {
    content: string | null;
    conversationId: string | null;
    images: string[] | null;
    beforeId : string | null;
}


export interface chatConversationId {
    userId: number | null;
}


export interface chatclear {
    userId: number | null;
    conversationId: string | null;
}

export interface chatList {
    conversationId: string | null
    beforeID?: string | null;
    afterID?: string | null;
    limit?: string | number;
    dataSource: string
}


