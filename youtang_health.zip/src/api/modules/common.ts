import api, {postCommonRequest, URL_PATH_PATIENT} from "@/api/api";

const CommonApi = {
	/**
	 * 获取字典数据
	 * code 6药品分类
	 */
	getDictionList(code:number) {
		const params = {
			code: code,
			actId: 10000102,
		}
		return api.post<IDictItem[]>(URL_PATH_PATIENT, params)
	},

	/**
	 * base64格式上传文件
	 * @param base64
	 */
	uploadFile(base64) {
		let param = {
			"fileBase64Code": base64,
			"fileExt": "jpg",
			"actId": 100101
		}
		return postCommonRequest(param)
	},

	/**
	 * 删除文件
	 * @param url
	 */
	delFile(url) {
		return postCommonRequest({actId: 9100101, url})
	}
}

export interface IDictItem	{
	value: string;
	key: number;
}

export default CommonApi;
