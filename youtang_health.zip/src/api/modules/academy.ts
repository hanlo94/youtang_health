import api, {
	PAGE_SIZE, postCommonPatientRequest, URL_PATH_PATIENT,
}
	from '@/api/api'

import {IAcademyItem, IGiItem, IWordListItem} from "@/api/types";

const AcademyApi = {
	/**
	 * 请求健康学院首页数据
	 */
	getAcademyIndexData() {
		return postCommonPatientRequest<IAcademyItem>(11020101)
		// return api.post<IAcademyItem>(URL_PATH_PATIENT, {
		// 	actId: 11020101
		// });
	},

	/**
	 * 猜你喜欢/糖友热搜
	 */
	changeYouLikeList() {
		return postCommonPatientRequest<IWordListItem[]>(11020103)
	},

	/**
	 * 文章列表
	 * @param wordType 文章类型 5:TOP3 6:TOP10
	 * @param keywords 搜索关键字
	 */
	getArticleList(wordType, keywords, page, pageSize = PAGE_SIZE) {
		const params = {
			page: page,
			pageNum: page,
			pageSize: pageSize,
			actId: 11020102,
			wordType: wordType || 0,
			keywords: '',
		}

		if (keywords) {
			params.keywords = keywords
		}

		return api.post<IArticleItem[]>(URL_PATH_PATIENT,params)
		// return postPatientRequest<IArticleItem[]>(params)

	},

	/**
	 * 食物gi速查
	 * @param categoryId 1 低升糖 2中升糖 3 高升糖
	 * @returns {Promise | Promise<unknown>}
	 */
	getFoodGiList(categoryId, foodName, page, pageSize = PAGE_SIZE) {
		const params = {
			page: page,
			pageNum: page,
			pageSize: pageSize,
			actId: 110701,
			foodName: foodName,
			categoryId: categoryId
		}

		return api.post<IGiItem[]>(URL_PATH_PATIENT, params)
	},

	/**
	 * 药品库
	 * @param category 药物类型
	 * @param page 页码
	 * @param keyword
	 * @returns {Promise | Promise<unknown>}
	 */
	getDrugList(category, page, keyword ) {
		console.log(keyword)
		const params = {
			page: page,
			pageNum: page,
			pageSize: PAGE_SIZE,
			actId: 10030401,
			category: category,
			useMode: 0,
			keyword: keyword
		}

		return api.post(URL_PATH_PATIENT,params)
	},

}

export interface IArticleItem {
	imgUrl: string
	wordBrowserNum: number
	wordId: number
	wordTime: string
	wordTitle: string
	wordUrl: string
}

export default AcademyApi;
