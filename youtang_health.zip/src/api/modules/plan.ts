import api from "@/api/api";

/**
 * description:所有相关接口
 * date:2024/10/30
 * create by:郭
 */

/**
 * 治疗仪个性化方案
 */
const planApi = {
    /**
     * 查询每十天周期治疗方案
     */
    requestCurrentPlan(data: any) {
        return api.post('/patient/device/composite/schedule/period/get', data)

    },
    /**
     * 生成治疗方案
     */
    requestCreatePlan(data: any) {
        return api.post('/patient/device/composite/schedule/generate', data)
    },

    /**
     * 方案列表
     */
    requestPlanList(pageNum: number,) {
        return api.post('/patient/device/composite/planList', {
            pageSize: 20,
            pageNum,
        })
    },
    /**
     * 治疗方案用户详情
     */
    requestPlanDetails(planId: number,) {
        return api.post('patient/device/composite/schedule/get', {planId,})
    },
     /**
     * 治疗方案统计
     */
    requestPlanStatistics(planId: number,) {
        return api.post('patient/device/composite/statistics', {planId,})
    },

    finishSchedule(planId: number, period: number, index: number, isMorning: number, time: string) {
        return api.post('patient/device/composite/schedule/finish', {planId,period,index,isMorning,time})
    }


}

export default planApi
