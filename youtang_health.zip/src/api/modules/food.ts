import api, {
    PAGE_SIZE, postPatientRequest, URL_PATH_PATIENT
}
    from '@/api/api'
import {formatDate} from "@/utils/util";
import {IFoodCategory} from "@/api/types";
import {IFoodHistoryDetails, IFoodHistoryDetailsItem} from "@/pagesFood/ts/types";

/**
 * 食物、菜谱、食谱列表
 * @param searchType
 * @param categoryId
 * @param cookCategory
 * @param page
 * @returns {Promise | Promise<unknown>}
 */
function foodList(categoryId, searchType, cookCategory, page, keyword?: string): Promise<any> | Promise<unknown> {

    const params = {
        page: page,
        pageNum: page,
        pageSize: PAGE_SIZE,
        actId: 101101,
        searchType: searchType,
        categoryId: categoryId,
        cookCategory: cookCategory,
        keyword: keyword
    }
    console.log(params)
    return api.post(URL_PATH_PATIENT, params)
}

// @ts-ignore
// @ts-ignore
// @ts-ignore
const FoodApi = {
    // 获取食品库列表
    getFoodList(categoryId: number | string, subCategoryId: number | string, page, keyword?: string) {
        const cateId = Number(categoryId)
        console.log(keyword)
        switch (cateId) {
            case 1:
                return FoodApi.getFoodMaterialList(subCategoryId, page, keyword);
            case 2:
                return FoodApi.getCookBookList(subCategoryId, page, keyword);
            case 3:
                return FoodApi.getRecipeList(subCategoryId, page, keyword);
        }
    },

    /**
     * 饮食首页-根据日期查询日历饮食记录
     */
    getCalendarDietRecordByDate(date: any = null) {
        if (!date) {
            date = formatDate(new Date())
        }
        let param = {
            "date": date,
            "actId": 11030306,
        }
        return postPatientRequest(param)
    },

    /**
     * 饮食首页-根据日期查询饮食数据
     * @param date
     */
    getDietRecordByDate(date: any = null) {
        if (!date) {
            date = formatDate(new Date())
        }
        let param = {
            "date": date,
            "actId": 11030304,
        }
        return postPatientRequest(param)
    },

    /**
     * 编辑饮食记录
     */
    editDietRecord(foodRecordId, foodAmount) {
        let param = {
            "foodAmount": foodAmount,
            "foodRelId": foodRecordId,
            "actId": 11030302,
        }
        return postPatientRequest(param)
    },

    /**
     * 删除食物记录
     */
    deleteFoodRecord(foodRecordId) {
        let param = {
            "foodRelId": foodRecordId,
            "actId": 11030303,
        }
        return postPatientRequest(param)
    },

    /**
     * 获取食材分类
     */
    getFoodMaterialCategory() {
        return api.post<IFoodCategory[]>(URL_PATH_PATIENT, {actId: 100710})
    },

    /**
     * 根据食材分类查询食材列表
     */
    getFoodMaterialList(categoryId, page, keyrowd) {
        return foodList(categoryId, 1, 0, page, keyrowd)
    },

    /**
     * 关键字搜索食材
     */
    searchFoodMaterialList(keyword, page) {
        return foodList(0, 1, 0, page, keyword)
    },

    /**
     * 获取菜谱分类
     * @returns {Promise | Promise<unknown>}
     */
    getCookBookCategory(): Promise<any> | Promise<unknown> {
        return api.post<IFoodCategory[]>(URL_PATH_PATIENT, {actId: 100716})
    },

    /**
     * 获取菜谱列表
     * @returns {Promise | Promise<unknown>}
     */
    getCookBookList(_cookCategoryId, page, keyword): Promise<any> | Promise<unknown> {
        return foodList(0, 2, 0, page, keyword)
    },

    /**
     * 食谱
     */
    getRecipeCategory() {
        return api.post<IFoodCategory[]>(URL_PATH_PATIENT, {actId: 100713})
    },

    /**
     * 获取食谱列表
     */
    getRecipeList(categoryId, page, keyword): Promise<any> | Promise<unknown> {
        const params = {
            page: page,
            pageNum: page,
            pageSize: PAGE_SIZE,
            actId: 101103,
            category: categoryId,
            keyword: keyword,
        }

        return api.post(URL_PATH_PATIENT, (params))
    },


    /**
     * 添加食材记录
     * @param calorieRecommend 推荐热量
     * @param date  记录日期
     * @param mealType 餐别类型
     * @param foodList 食材列表
     *{
     *        "amount": 100,
     *        "calorie": 383,
     *        "foodId": 1,
     *        "foodName": "谷子（龙谷）",
     *        "foodThumb": ""
     *    }
     */
    addDietRecord(data: any) {
        let param = {
            ...data,
            "actId": 11030301
        }
        return postPatientRequest(param)
    },

    /**
     * 饮食分析
     */
    dietAnalysis(date: any = null) {
        if (!date) {
            date = formatDate(new Date())
        }
        let param = {
            "date": date,
            "actId": 11030307
        }
        return postPatientRequest(param)
    },

    /**
     * 获取历史记录日期
     * @param page
     * @param pageSize
     */
    getHistoryRecord(page, pageSize = PAGE_SIZE) {
        let param = {
            "page": page,
            "pageNum": page,
            "pageSize": pageSize,
            "actId": 11030305,
        }
        return postPatientRequest(param)
    },

    /**
     * 查询从以前复制记录详情
     * @param date
     */
    getHistoryRecordDetailByDate(date) {
        let param = {
            "date": date,
            "type": "Copy",
            "actId": 11030304,
        }
        return postPatientRequest<IFoodHistoryDetails>(param)
    },


    /**
     * 从以前复制  点击确定复制按钮
     * @param calorieRecommend
     * @param mealType
     * @param foodList
     */
    requestSaveCopy(date:string,calorieRecommend:number,mealType:number,foodList:IFoodHistoryDetailsItem[]){
        let param = {
            date,
            calorieRecommend,
            isCopy: 1,
            mealType,
            foodList,
            actId: 11030301,
        }
        return postPatientRequest<IFoodHistoryDetails>(param)
    }
}


export default FoodApi
