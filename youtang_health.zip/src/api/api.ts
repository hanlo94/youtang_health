import axios from "axios";
import md5 from 'blueimp-md5'
import Taro from "@tarojs/taro";
import StoreUtils from "@/utils/storeUtils";
import PageNavigation from "@/utils/pageNavigation";
import {isEmpty} from "lodash";


export const URL_PATH_PATIENT = '/patient/v5/';
export const URL_PATH_SUGAR = '/sugar/v5/';
export const URL_PATH_COM = '/com/v5/';
export const POST_URL_PATIENT = "/patient/";
export const POST_URL_V4 = "/v4";
export const POST_URL_V2 = "/v2";
export const POST_URL_MESSAGE = "/message/v1/";


export const PAGE_SIZE = 20;


const BASE_URL = process.env.BASE_URL;

const appId = Taro.getAccountInfoSync().miniProgram.appId;
const appVersion = process.env.APP_VERSION
const version = process.env.VERSION
const versionCode = process.env.VERSION_CODE
const APP_SECRET = process.env.APP_SECRET

const api = axios.create({
    baseURL: BASE_URL,
})

export const postRequest = <T>(params, path) => {
    return api.post<T>(path, params)
}

export const postXcxRequest = <T>(params, path) => {
    return postRequest<T>(params, POST_URL_PATIENT + "ma" + path)
}

export const postMessageRequest = <T>(params) => {
    return postRequest<T>(params, POST_URL_MESSAGE)
}

export const postPatientRequest = <T>(params) => {
    return postRequest<T>(params, URL_PATH_PATIENT)
}
export const postSugarRequest = <T>(params, path) => {
    return postRequest<T>(params, URL_PATH_PATIENT + path)
}

export const requestParams = () => {
    let params:any = {}
    if (StoreUtils.readPatientId()) {
        // 在发送请求之前设置patientId
        params.patientId = StoreUtils.readPatientId();
        params.addUser = StoreUtils.readPatientId();
    }
    params.clientSn = 'xcx';
    params.accessOrigin = 'youtang'
    params.appId = appId
    params.appVersion = appVersion;
    params.versionCode = versionCode;
    params.sign = encode(params);
    return params;
}
export const streamRequest = <T>(params, path) => {   
    return Taro.request({
        url: BASE_URL + '/v5/' + path,
        // url: 'http://192.168.0.180:32019/v5/' + path,
        // url: 'http://139.155.158.129:32019/v5/' + path,
        // url: 'http://192.168.0.34:32019/v5/' + path,
        // url: ' http://chat.test.youtang120.com/v5/' + path,
        method: 'POST',
        header: {
            //'Authorization': 'Bearer pat_FPgAiSzeZ3HteZwKYAScjlmPqFb8vK7tWKnEppBZZYzdGR9aCPZJoJRpPDoKTS6M',
            'Content-Type': 'application/json'
        },
        data: {
            ...params,
            ...requestParams(),
            stream: true
        },
        responseType: 'text',
        enableChunked: true
    });
}

export const streamRequest1 = <T>(params, path) => {
  return Taro.request({
    url: 'https://api.coze.cn/v3/chat?conversation_id=7468199823636987955',
    method: 'POST',
    header: {
      'Authorization': 'Bearer pat_xTGwjL3K2b8xcUDQlJMXiS7zXHnGoCbDqeFK6COUoZgMjQb9R5NVctdEdURxx1UR',
      'Content-Type': 'application/json'
    },
    data: {
      bot_id: '7452643148675252276',
      user_id: '13565431',
      //conversation_id: '7468199823636987955', // 添加 conversation_id
      additional_messages: [
        {
          content: "贝塔素是什么",
          content_type: "object_string"
        }
      ],
      stream: true
    },
    responseType: 'text',
    enableChunked: true
  });
}



export const streamRequest2 = <T>(params, path = "/v3/chat?conversation_id=7468199823636987955") => {
    axios.create({
        baseURL: "https://api.coze.cn",
        responseType: 'stream',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Connection': 'keep-alive',
            'Transfer-Encoding': 'chunked',
            "Authorization": "Bearer pat_xTGwjL3K2b8xcUDQlJMXiS7zXHnGoCbDqeFK6COUoZgMjQb9R5NVctdEdURxx1UR"
        }
    }).post<T>(path, params)
}
export const postV4Request = <T>(params) => {
    return postRequest<T>(params, POST_URL_V4)
}
export const postV2Request = <T>(params) => {
    return postRequest<T>(params, POST_URL_V2)
}

export const postCommonPatientRequest = <T>(actId: number) => {
    return postPatientRequest<T>({actId: actId})
}
export const postCommonRequest = (params) => {
    return postRequest(params, URL_PATH_COM)
}

export const postCommonActRequest = (actId: number) => {
    return postCommonRequest({actId: actId})
}

// @ts-ignore
function encode(param) {
    // let array = [];
    // let key, value;
    // for (key in param) {
    //     value = param[key]
    //     // 过滤空参数  null  undefined 空字符串
    //     if (value || (typeof value === 'number' && value === 0) || (typeof value === 'string' && value.length > 0)) {
    //         array.push(key)
    //     }
    // }
    // // 数组默认按照ascii排序
    // array.sort();
    // let result = [];
    // //顺序kv拼接
    // array.forEach((key) => {
    //     let tmp = [];
    //     tmp[0] = key;
    //     let element = param[key];
    //     if (Array.isArray(element)) {
    //         let list = []
    //         element.forEach((item) => {
    //             list.push(sortObject(item))
    //         })
    //         tmp[1] = JSON.stringify(list)
    //         // console.log("api.js",'encode.json ',JSON.stringify(element),'\n join ',element.join(','),'\ntmp',tmp[1]);
    //     } else if (element instanceof Object) {
    //         tmp[1] = JSON.stringify(sortObject(element))
    //     } else {
    //         tmp[1] = element
    //     }
    //
    //     result.push(tmp.join('='))
    // });
    // result.push('key=' + APP_SECRET);

    // 对一级字段按键排序
    // const sortedKeys = Object.keys(param).sort();
    //
    let result2: string[] = [];
    const sortObject1 = sortObject(param);
    Object.keys(sortObject1).forEach((key) => {
        const value = sortObject1[key];
        if (value instanceof Object) {
            result2.push(`${key}=${JSON.stringify(value)}`)
        } else {
            result2.push(`${key}=${value}`)
        }
    });
    // let value = param[key];

    //
    // sortedKeys.forEach((key) => {
    //     let value = param[key];
    //
    //     // 过滤空参数  null  undefined 空字符串
    //     if (value === null || value === undefined || (typeof value === 'string' && value.trim() === '')) {
    //         return;
    //     }
    //     if (Array.isArray(value)) {
    //         // 对数组元素按键排序并拼接
    //         const sortedArray = value.map(item => {
    //             if (item !== null && item !== undefined && !(typeof item === 'string' && item.trim() === '')) {
    //                 if (item instanceof Object) {
    //                     return `${item}`;
    //                 } else {
    //                     return `${JSON.stringify(sortObject(item))}`;
    //                 }
    //             }
    //             return '';
    //         }).filter(item => item !== '');
    //         if (sortedArray.length > 0) {
    //             result2.push(`${key}=${JSON.stringify(Object.fromEntries(nestedResult.map(item => item.split('='))))}`);
    //         }
    //     } else if (value instanceof Object) {
    //         // 对嵌套对象按键排序并拼接
    //         // const nestedSortedKeys = Object.keys(value).sort();
    //         // const nestedResult: string[] = nestedSortedKeys.map(nestedKey => {
    //         //     const nestedValue = value[nestedKey];
    //         //     return `${nestedKey}=${nestedValue}`;
    //         // }).filter(item => item !== '');
    //
    //         // if (nestedResult.length > 0) {
    //         //     result2.push(`${key}=${JSON.stringify(Object.fromEntries(nestedResult.map(item => item.split('='))))}`);
    //         // }
    //         console.log("api.encode..alue is object sort it ",value);
    //         sortObject(value);
    //         result2.push(`${key}=${JSON.stringify(sortObject(value))}`);
    //     } else {
    //         result2.push(`${key}=${value}`);
    //     }
    // });
    result2.push(`key=${APP_SECRET}`);

    // let finalStr = result.join('&');

    let finalStr2 = result2.join('&');
    // console.log('sort.js result=', result, '; finalStr= ', finalStr, ';md5=', md5(finalStr).toUpperCase(), ';\nresult2=', result2, '; finalStr2=', finalStr2, ';md52=', md5(finalStr2).toUpperCase());
   // console.log('sort.js result2=', JSON.stringify(result2), '; finalStr2=', finalStr2, ';md52=', md5(finalStr2).toUpperCase());
    //转md5
    // console.log('sort.js', '.sort', md);
    return md5(finalStr2).toUpperCase();
}

function sortObject(obj: Record<string, any>): Record<string, any> {
    // 递归排序对象的键值对
    return Object.keys(obj)
        .sort()
        .filter(key => {
            const value = obj[key];
            // if (value == 0) {
            //     console.log("api.sortObject.filter.value is 0  key=", key, '; value =', value);
            // }
            return value !== null && value !== undefined && !(typeof value === 'string' && value.trim() === '');
        })
        .reduce((sorted, key) => {
            const value = obj[key];
            // console.log("api.sortObject.reduce.key=", key, '; value=', value);
            if (Array.isArray(value)) {
                // 处理数组，确保数组中的每个对象都被排序
                sorted[key] = value.map(item => {
                    if (typeof item === 'object') {
                        return sortObject(item);
                    }
                    return item;
                });
            } else if (typeof value === 'object') {
                // 递归排序嵌套对象
                sorted[key] = sortObject(value);
                // console.log("api.sortObject..source value=", value, '; sorted[key]=', sorted[key]);
            } else {
                sorted[key] = value;
            }
            return sorted;
        }, {} as Record<string, any>);
}

// const obj = {
//     "appVersion": 42,
//     "clientSn": "xcx",
//     "sugarValueBean": {
//         "sugarvalueType": 2,
//         "remark": "",
//         "time": "2024-12-17 14:35:53",
//         "id": 0,
//         "type": 3,
//         "value": "5"
//     },
//     "appId": "wxe32487b6637566a6",
//     "actId": 130101,
//     "accessOrigin": "youtang",
//     "versionCode": "8"
// };

// function sortObject(obj) {
//     if (Array.isArray(obj)) {
//         return obj.map(element => {
//             if (typeof element === 'object') {
//                 return sortObject(element);
//             }
//             return element;
//         });
//     } else if (typeof obj === 'object' && obj !== null) {
//         return Object.keys(obj)
//             .sort()
//             .reduce((sorted, key) => {
//                 sorted[key] = sortObject(obj[key]);
//                 return sorted;
//             }, {});
//     }
//     return obj;
// }

function convertToQueryString(obj) {
    const sortedObj = sortObject(obj);
    const array = Object.keys(sortedObj)
        .sort()
        .map(key => {
            const value = sortedObj[key];
            if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
                return `${key}=${JSON.stringify(value)}`;
            } else if (Array.isArray(value)) {
                return `${key}=${JSON.stringify(value)}`;
            } else {
                return `${key}=${value}`;
            }
        });
    array.push(`key=${APP_SECRET}`);
    return array.join('&');
}

// 添加请求拦截器
api.interceptors.request.use(function (config) {
    if (!config.data) {
        config.data = {}
    }
    // console.log("api.ts.interceptors. patientId=", StoreUtils.readPatientId(), '; isEmpty(patientId)=', isEmpty(StoreUtils.readPatientId()), '; ', (StoreUtils.readPatientId() > 0 || (StoreUtils.readPatientId() + "").length > 0));
    if (StoreUtils.readPatientId()) {
        // 在发送请求之前设置patientId
        config.data.patientId = StoreUtils.readPatientId();
        config.data.addUser = StoreUtils.readPatientId();
    }
    config.data.clientSn = 'xcx';
    config.data.accessOrigin = 'youtang'
    config.data.appId = appId
    config.data.appVersion = appVersion;
    config.data.versionCode = versionCode;
    // console.log("api.data..versionCode", versionCode, '; appVersion', appVersion, '; version', version, '; app secret=', APP_SECRET);
    let data = config.data;
    config.data.sign = encode(data);

    // 设置请求头
    let systemInfo = Taro.getSystemInfoSync();
    config.headers = {
        ...config.headers,
        appVersion: appVersion,
        Client: 'patient',
        version: version,
        platform: systemInfo.platform,
        model: systemInfo.model,
        sysTemVersion: systemInfo.version,
        brand: systemInfo.brand,
        system: systemInfo.system,
    };

    // let systemInfo = Taro.getSystemInfoSync();
    // config.data.platform = systemInfo.platform
    // config.data.model = systemInfo.model
    // config.data.sysTemVersion= systemInfo.version
    // config.data.brand= systemInfo.brand
    // config.data.system= systemInfo.system

    return config;
}, function (error) {
    // 对请求错误做些什么
    return Promise.reject(error);
});

// 添加响应拦截器
api.interceptors.response.use(function (response) {
    if (response.headers["content-type"].indexOf("stream") !== -1) {
        //  流式接口直接返回数据
        return response.data;
    }
    // 2xx 范围内的状态码都会触发该函数。
    // 对响应数据做点什么
    if (response.data.code == 10000 || response.data.code == 1) {
        return response.data;
    } else if (response.data.code === 401) {
        StoreUtils.clearCache()
        Taro.showToast({
            title: '未登录，请先登录',
            icon: 'none',
            duration: 1000
        })
        setTimeout(() => {
            goLogin()
        }, 1200)
        return Promise.reject('未登录，请先登录');
    } else {
        console.log("api.ts.failure reject .", JSON.stringify(response), ';  ', (response.data.msg || response.data.errMsg) ?? '请求失败，请返回重试');
        return Promise.reject((response.data.msg || response.data.errMsg) ?? '请求失败，请返回重试');
    }
}, function (error) {
    // 超出 2xx 范围的状态码都会触发该函数。
    // 对响应错误做点什么
    console.log("api.ts.response.error.", error);
    if (error.response.status) {
        switch (error.response.status) {
            case 400:
                return Promise.reject('安全校验失败，请稍后重试');
            case 401:
            case 403:
                // Forbidden 此处视为登录状态失效  需清空缓存数据  前往登录
                // 未登录 需登录
                StoreUtils.clearCache()
                goLogin()
                break

                StoreUtils.clearCache()
                goLogin()
                break
            case 404:
                break
        }
    }
    return Promise.reject(error);
});

function goLogin() {
    PageNavigation.navigationToLogin()
}

export default api;
