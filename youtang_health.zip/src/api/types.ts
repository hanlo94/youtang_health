import {SugarTableRecord} from "@/pagesSugarAnalysis/ts/types";

export interface IMainIndex {
    diastolic: number;
    systolic: number;
    calorie: number;
    weight: null;
    bodyFatData: { bindState: number; bodyFatRate: number };
    fibre: number;
    hba1c: number;
    height: null;
    bmi: null;
}

export interface IDeviceItem {
    bindState: number;
    categoryId: number;
    categoryName: null;
    deviceBrand: number;
    deviceDesc: string;
    deviceName: string;
    imgUrl: string;
    jumpUrl: string;
    layoutType: number;
    userFlag: null;
    xcxPage: string;
    deviceSnMinLength: number;
    deviceSnMaxLength: number;
    deviceAction:number;
    deviceSn:string;
}

export interface ISugarStarItem {
    afterManaged: string;
    beforeManaged: string;
    age: number;
    confirmTime: string;
    dataId: number;
    diabetesType: string;
    feedback: string;
    gender: number;
    joinTime: string;
    name: string;
    sickLength: string;
    thumb: string;
    url: string;
    wish: string;
}

export interface Chart {
    chartType: string;
    dates: string;
    values: string;
    upLimit: number;
    lowLimit: number;
}

export interface SugarChartData {
    code: number;
    recordList: SugarTableRecord[]
    errMsg: string;
    chart: Chart;
    statistics: any;
}

export interface IWordListItem {
    wordType: number;
    wordTypeName: string;
    currentDayList: IWordItem[]
}

export interface IYouLikeItem {
    youLikeName: string;
    youLikeList: IWordListItem[];
}

export interface IWordItem {
    wordId: number;
    wordTitle: string;
    imgUrl: string;
    wordTime: string;
    wordBrowserNum: number;
    wordUrl: string;
}

export interface IAcademyItem {
    bannerList: any[];
    secondTitle: {
        imgUrl: string;
        titleId: number;
        titleName: string;
    }[];
    thirdTitle: {
        imgUrl: string;
        titleId: number;
        titleName: string;
    }[];
    currentDayList: IWordItem[];
    publicClass: {
        publicName: string;
        wordLists: IWordListItem[];
    };
    hotSort: {
        hotSortName: string;
        hotCollectTop3Url: string;
        top3Type: number;
        hotCollectTop10Url: string;
        top10Type: number;
    };
    youLike: IYouLikeItem;
    vipCourseList: any[];
}

export interface IGiItem {
    gi: number
    name: string
    thumb: string
    id: number
}

// region ********** 蓝牙配置 *********

export interface BLeDevice {
    name: string,
    mac: string
}

// endregion

// 食物库分类
export interface IFoodCategory {
    categoryCache: null;
    categoryCreateTime: string;
    categoryDesc: string;
    categoryName: string;
    categoryThumb: string;
    foods: null;
    heatTemp: null;
    id: number;
}


// region ********** 配置体脂秤数据 **********

/**
 * 体脂信息
 */
interface BodyFat {
    /**
     * 测量时间：yyyy-MM-dd HH:mm:ss
     */
    recordTime: string;

    /**
     * 体重:Kg
     */
    weight: number;

    /**
     * 体重状态：
     * [0-未知,1-严重偏低,2-偏低,3-标准,4-偏高,5-严重偏高]
     */
    weightState: number;

    weightStateDesc: string;

    /**
     * bmi
     */
    bmi: number;

    /**
     * bmi状态：[0-未知,1-偏低,2-标准,3-偏高]
     */
    bmiState: number;

    bmiStateDesc: string;

    /**
     * 体脂率:%
     */
    bodyFatRate: number;

    /**
     * 体脂率状态：[0-未知,1-偏低,2-标准,3-偏高,4-严重偏高]
     */
    bodyFatRateState: number;

    bodyFatRateStateDesc: string;

    /**
     * 皮下脂肪率：%
     */
    subcutaneousFat: number;

    /**
     * 皮下脂肪率状态：[0-未知,1-偏低,2-标准,3-偏高]
     */
    subcutaneousFatState: number;

    subcutaneousFatStateDesc: string;

    /**
     * 内脏脂肪等级
     */
    visceralFat: number;

    /**
     * 内脏脂肪等级状态：[0-未知,1-标准,2-偏高,3-严重偏高]
     */
    visceralFatState: number;

    visceralFatStateDesc: string;

    /**
     * 身体水分率：%
     */
    bodyWaterRate: number;

    /**
     * 身体水分率状态： [0-未知,1-充足,2-标准,3-偏低]
     */
    bodyWaterRateState: number;

    bodyWaterRateStateDesc: string;

    /**
     * 骨骼肌率：%
     */
    muscleRate: number;

    /**
     * 骨骼肌率状态：[0-未知,1-偏低,2--标准,3-偏高]
     */
    muscleRateState: number;

    muscleRateStateDesc: string;

    /**
     * 骨量：Kg
     */
    boneMass: number;

    /**
     * 骨量状态：[0-未知,1-偏低,2-标准,3-偏高]
     */
    boneMassState: number;

    boneMassStateDesc: string;

    /**
     * 基础代谢率：Kcal
     */
    bmr: number | string;

    /**
     * 体型
     */
    bodyType: number;

    /**
     * 体型状态：
     * [0-未知,1-无体型值,2-隐形肥胖型,3-运动不足型,4-偏瘦型,5-标准型,
     * 6-偏瘦肌肉型,7-肥胖型,8-偏胖型,9-标准肌肉型,10-非常肌肉型]
     */
    bodyTypeState: number;

    bodyTypeStateDesc: string;

    /**
     * 蛋白质：%
     */
    protein: number;

    /**
     * 蛋白质状态：[0-未知,1-充足,2-标准,3-偏低]
     */
    proteinState: number;
    proteinStateDesc: string;

    /**
     * 去脂体重：Kg
     */
    leanBodyWeight: number;

    /**
     * 去脂体重：[0-未知，1-标准]
     */
    leanBodyWeightState: number;
    leanBodyWeightStateDesc: string;

    /**
     * 肌肉量：Kg
     */
    muscleMass: number;

    /**
     * 肌肉量状态：
     * [0-未知,1-偏低,2-标准,3-充足]
     */
    muscleMassState: number;
    muscleMassStateDesc: string;

    /**
     * 体年龄：岁
     */
    metabolicAge: number | string;

    /**
     * 体年龄状态：
     * [0-未知,1-达标,2-不达标]
     */
    metabolicAgeState: number;

    metabolicAgeStateDesc: string;

    /**
     * 健康分数
     */
    healthScore: string | number;

    /**
     * 综合评价
     */
    comprehensiveEvaluation?: string;

    /**
     * 心率
     */
    heartRate?: number;

    /**
     * 心率状态：
     * [0-未知,1-偏低,2--标准,3-偏高]
     */
    heartRateState?: number;
    heartRateStateDesc?: string;
}

/**
 * 上传体脂数据
 */
export interface BodyFatUpload extends BodyFat {

    /**
     * 设备地址
     */

    deviceMac: string;

    /**
     * 身高:cm
     */
    height: number;
}

/**
 * 体脂数据详情
 */
export interface BodyFatDataPo extends BodyFat {

    dataId: number;

    /**
     * 体重
     */
    weightStateName: string;
    weightStateTip: string;

    /**
     * bmi
     */
    bmiStateName: string;
    bmiStateTip: string;

    /**
     * 体脂
     */
    bodyFatRateStateName: string;
    bodyFatStateTip: string;

    /**
     * 心率
     */
    heartRateStateName: string;
    heartRateStateTip: string;

    /**
     * 皮下脂肪
     */
    subcutaneousFatStateName: string;
    subcutaneousFatStateTip: string;

    /**
     * 内脏脂肪
     */
    visceralFatStateName: string;
    visceralFatStateTip: string;

    /**
     * 体水分
     */
    bodyWaterRateStateName: string;
    bodyWaterRateStateTip: string;

    /**
     * 骨骼肌量
     */
    muscleRateStateName: string;
    muscleRateStateTip: string;

    /**
     * 骨骼量
     */
    boneMassStateName: string;
    boneMassStateTip: string;

    /**
     * 体型
     */
    bodyTypeStateName: string;
    bodyTypeStateTip: string;

    /**
     * 蛋白质
     */
    proteinStateName: string;
    proteinStateTip: string;

    /**
     * 去脂体重
     */
    leanBodyWeightStateName: string;
    leanBodyWeightStateTip: string;

    /**
     * 肌肉量
     */
    muscleMassStateName: string;
    muscleMassStateTip: string;

    /**
     * 体年龄
     */
    metabolicAgeStateName: string;
    metabolicAgeStateTip: string;

    /**
     * 脂肪重量
     */
    fatWeight: string | number;


}

// endregion

// region ********** 微信登录 **********
export interface Watermark {
    timestamp: string;
    appid: string;
}

/**
 * 微信用户信息
 */
export interface WxMaUserInfo {
    nickName: string;
    gender: string;
    language: string;
    city: string;
    province: string;
    country: string;
    avatarUrl: string;
    unionId: string;
    watermark: Watermark;
}

/**
 * 微信手机号
 */
export interface WxMaPhoneNumberInfo {
    phoneNumber: string;
    purePhoneNumber: string;
    countryCode: string;
    watermark: Watermark;
}

export interface WxMaSessionInfo {
    sessionKey: string;
    openid: string;
    unionid: string;
}

export interface PatientInfo {
    name: string;
    gender: number;
    birth: string;
    avatar: string;
    diabetesType: number;
    height: number;
    weight: number;
    labourIntensity?: any;
    sugarAge?: any;
    sugarControlSituation?: any;
    treatmentMethod?: any;
    sleepSituation?: any;
    healthAction?: any;
    complication?: any;
    labels?: any;
    mobile?: any;
    patientId: number;
}

// endregion

export interface WeekItem<T> {
    ymdWeek: string,
    ms: string,
    item: T

}

/**
 * BLE血糖仪上报数据
 */
export interface IBleGluUploadData {
    recordValue: number,
    recordTime: string,
    timeType: number,
    deviceSn: string
}
