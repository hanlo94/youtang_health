export default definePageConfig({
  navigationBarTitleText: "控糖",
  enableShareAppMessage:true,
  enableShareTimeline:true,
  usingComponents:{
    'ec-canvas':'../../component/ec-canvas/ec-canvas',
    // "echart": "plugin://echarts/chart"
  }
});
