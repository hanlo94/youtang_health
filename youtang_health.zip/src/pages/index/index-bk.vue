<template>
  <view class="container_index">
    <!--		顶部曲线图-->
    <view class="chart_container round space" @click="goSugarDetail">
      <view class="top">
        <image class="img" mode="heightFix" :src="imgUrlFormat('sugar/week.png')" alt=""></image>
        <!--				<view class="nums">10次</view>-->
      </view>
      <cover-view class="bottom round">
        <ec-canvas id="chart-dom-area" canvas-id="chart-area" :ec="ec" force-use-old-canvas="true"></ec-canvas>
      </cover-view>
    </view>

    <view class="card_blue">
      <view class="blue_left">
        <view class="status"><img :src="btIcon">{{ btTitle }}</view>
        <view class="desc">{{ btContent }}</view>
      </view>
      <view :class="bleBtnClass()" @click="onRetryBtnClick">{{ btButton }}</view>
    </view>


    <view class="round point_task vertical-container">
      <view class="horizon-container">
        <view class="horizon-container">
          <image class="image-icon" :src="imgUrlFormat('sugar/sugar.png')" mode="widthFix" alt=""></image>
          <view class="name">赚积分兑好礼</view>
        </view>
        <view @click.stop="goPoint">更多</view>
      </view>
      <view v-for="(item, index) in tasks" :key="index" class="round point-task horizontal ">
        <image class="task_img" :src="item.ruleImage" mode="aspectFill"></image>
        <view class="vertical-container task-value-content">
          <view class="horizon-container vertical-center">
            <view class="vertical-container">
              <view class="horizontal vertical-center">
                <text class="task_name">{{ item.ruleName }}</text>
                <view class="horizontal vertical-center" style="margin-left: 10rpx">
                  <image class="task_value_icon" :src="imgUrlFormat('point/integral2.png')" mode="scaleToFit"></image>
                  <text class="task_value">{{ item.ruleAddValue }}</text>
                </view>
              </view>
              <text class="task_desc">{{ item.ruleDescription }}</text>
            </view>
            <view @click.stop="onTaskItemClick(item)" v-if="item.ruleOperation">
              <text :class="item.ruleOperationClass">{{ item.ruleOperation }}</text>
            </view>
          </view>
          <!-- 添加间隔线 -->
          <view class="divider"></view>
        </view>
      </view>

    </view>


    <!--		中部血糖记录入口-->
    <view class="blood_sugar_box space">
      <navigator class="blood_sugar_left round" url="/pages/sugar/index" hover-class="none">
        <view class="horizon-container">
          <image class="image-icon" :src="imgUrlFormat('sugar/sugar.png')" mode="widthFix" alt=""></image>
          <view class="name">记血糖</view>
        </view>
        <view class="sugar_intro_box">
          <view :class="sugar.status">{{ sugar.sugarValue }}</view>
          <view :class="sugar.timetypeStatus">{{ sugar.timeType }}</view>
        </view>
      </navigator>
      <view class="blood_sugar_right">
        <navigator class="analyse_box round" url="/pagesSugarAnalysis/sugarAnalysis" hover-class="none">
          <image class="image-icon" :src="imgUrlFormat('sugar/analyse.png')" mode="widthFix" alt=""></image>
          <view class="name">血糖分析</view>
        </navigator>
        <navigator class="device_box round" url="/pagesMine/device/device" hover-class="none">
          <image class="image-icon" :src="imgUrlFormat('sugar/device.png')" mode="widthFix" alt=""></image>
          <view class="name">智能设备</view>
        </navigator>
      </view>

    </view>

    <!--		<comp_record_card-->
    <!--			class="record_card space"-->
    <!--			title="查看饮食记录"-->
    <!--			emptyText="掌握食物对血糖的影响规律～"-->
    <!--			addUrl="/pagesFood/index/index"-->
    <!--			recordUrl="/pagesFood/index/index"-->
    <!--		>-->
    <!--			<template #icon>-->
    <!--				<image class="icon" :src="imgUrlFormat('sugar/food/diet-2.png')" mode="widthFix"></image>-->
    <!--			</template>-->
    <!--			<view v-if="calorie.calorie>0">-->
    <!--				热量：-->
    <!--				<text :class="calorie.status">{{ calorie.calorie }}</text>-->
    <!--				/{{ calorie.calorieRecommend }}千卡-->
    <!--			</view>-->
    <!--		</comp_record_card>-->

    <view class="box record_card space" @click="onDietClick">
      <view class="left_box">
        <view class="title_box">
          <image class="icon" :src="imgUrlFormat('sugar/food/diet-2.png')" mode="widthFix"></image>
          <view>查看饮食记录</view>
        </view>
        <view v-if="calorie.calorie>0" class="slot">
          今天摄入了：{{ calorie.calorie }}/{{ calorie.calorieRecommend }}千卡
        </view>
        <view v-else class="slot">
          <slot>掌握食物对血糖的影响规律～</slot>
        </view>

      </view>
      <view class="right_box">
        <image mode="widthFix" class="add_icon" :src="imgUrlFormat('sugar/add_lg.png')"></image>
        <view class="add_text">添加</view>
      </view>
    </view>

    <comp_record_card
        class="record_card space"
        title="查看身高体重记录"
        emptyText="身高体重时医生为您提供服务的基础哦～"
        addUrl="/pagesBmi/add/index"
        recordUrl="/pagesBmi/record/index"
    >
      <template #icon>
        <image class="icon" :src="imgUrlFormat('sugar/height.png')" mode="widthFix"></image>
      </template>
      <view v-if="body.weight>0">
        体重：
        <text style="margin-right:27.67px;">{{ body.weight }}</text>
        BMI：
        <text :class="body.status">{{ body.bmi }}</text>
      </view>
    </comp_record_card>
    <comp_record_card
        class="record_card space"
        title="查看健康档案记录"
        emptyText="及时记录，档案完整，助力健康。"
        addUrl="/pagesActive/add/index?type=1"
        recordUrl="/pagesActive/index/index"
    >
      <template #icon>
        <image class="icon" :src="imgUrlFormat('sugar/dossier.png')" mode="widthFix"></image>
      </template>
      <view v-if="body.weight>0">
        体重：
        <text style="margin-right:27.67px;">{{ body.weight }}</text>
        BMI：
        <text :class="body.status">{{ body.bmi }}</text>
      </view>
    </comp_record_card>
    <comp_record_card
        class="record_card space"
        :bindStatus="indexData.bodyFatData?.bindState || 2"
        title="查看体脂记录"
        emptyText="监测营养吸收，评估身体健康状况～"
        addUrl="/pagesBodyFat/add/index"
        recordUrl="/pagesBodyFat/record/index"
    >
      <template #icon>
        <image class="icon" :src="imgUrlFormat('sugar/fat.png')" mode="widthFix"></image>
      </template>
      <view v-if="fat.bodyFatRate>0">
        体脂：
        <text class="fat.status">{{ fat.bodyFatRate }}</text>
      </view>
    </comp_record_card>
    <comp_record_card
        class="record_card space"
        title="查看血压记录"
        emptyText="监控血压变化，谨防伴发疾病～"
        addUrl="/pagesBp/add/index"
        recordUrl="/pagesBp/record/index"
    >
      <template #icon>
        <image class="icon" :src="imgUrlFormat('sugar/blood.png')" mode="widthFix"></image>
      </template>
      <view v-if="bp.diastolic>0">
        收缩压：
        <text class="bp.diastolicStatus" style="margin-right:27.67px;">{{ bp.systolic }}</text>
        舒张压：
        <text class="bp.diastolicStatus">{{ bp.diastolic }}</text>
      </view>
    </comp_record_card>
    <comp_record_card
        class="record_card space"
        title="查看糖化血红蛋白"
        emptyText="还没有添加糖化血红蛋白记录哦～"
        url="/pages/hba1crecord/index"
        addUrl="/pagesHba1c/add/index"
        recordUrl="/pagesHba1c/record/index"
    >
      <template #icon>
        <image class="icon" :src="imgUrlFormat('sugar/protein.png')" mode="widthFix"></image>
      </template>
      <view v-if="hba1c.hba1c">糖化血红蛋白：
        <text :class="hba1c.status">{{ hba1c.hba1c }}%</text>
      </view>
    </comp_record_card>
    <!--		控糖明星-->
    <comp_title_box title="控糖明星" action-type="navigator" url="/pagesSugar/star/index"/>
    <view class="sugar_star_box">
      <view class="scroll-view_x">
        <view class="scroll_box">
          <comp_sugar_star_card class="scroll_item" :item="item" v-for="(item, idx) in sugarStar" :key="idx"/>
        </view>
      </view>
    </view>
    <nut-popup @update:visible="onDialogVisible" v-model:visible="showInfoDialog" position="bottom"
               :style="{ height: '60%' }" overlay-class="info_dialog"
               style="background: transparent;  ">
      <!--        低1  中 2  高3-->
      <view class="dialog">
        <img src="https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/common/info_pic.png"/>
        <view class="dialog_content">
          <view class="content">
            为了更好地为您提供服务，请您完善性别、出生日期、糖尿病类型、劳动力强度、身高、体重等个人信息。
          </view>
          <view class="btn" @click="goInfo">立即完善</view>
        </view>
      </view>

    </nut-popup>

  </view>
</template>
<script lang="ts" setup>
import comp_record_card from '@/component/recordCard'
import comp_title_box from '@/component/titleBox'
import comp_sugar_star_card from '@/component/sugarStarCard'
import * as echarts from '@/component/ec-canvas/echarts.js'

import {computed, onMounted, reactive, ref, onUnmounted} from "vue";
import {Chart, IMainIndex} from "@/api/types";
import SugarApi from "@/api/modules/sugar";
import Taro from "@tarojs/taro";
import {useDidShow} from '@tarojs/taro'
import {addDays, formatDate} from "@/utils/dateUtils";
import {categoryChartOptions} from "@/utils/chartOption";
import imgUrlFormat from "@/utils/imgUtils";
import StoreUtils, {useMainPageStore} from "@/utils/storeUtils";
import {call, isEmpty} from "lodash";
import {formatSugarUpNormalLow} from "@/utils/sugarUtils";
import PageNavigation from "@/utils/pageNavigation";
import {showShareMenu} from "@tarojs/plugin-platform-h5/dist/dist/definition.json";
import {showToast, showToastLong} from "@/utils/toastUtils";

import {ScaleMeasure} from "@/config/device/bodyfat";
import {BleScanMeasureState, DeviceUUID} from "@/pagesMine/yasiGlm/config/YasiGluConstants";
import {formatCurrentIndex, formatTime} from "@/utils/util";
import {IBleGluUploadData} from "@/api/types";
import PointApi, {PointTask, PointTimeConstants} from "@/pagesMine/api/points";

const scaleMeasureState = ref<ScaleMeasure>()
const bindState = ref<boolean>(true)

// 是否已连接
const connected = ref<boolean>(false)
const connecting = ref<boolean>(false)
const scanning = ref<boolean>(false)

const upload = ref<IBleGluUploadData>()

const connectedDevice = ref()

const timer = ref<number>(0)

const logger = () => {
  const realTimeLogger = Taro.getRealtimeLogManager && Taro.getRealtimeLogManager()
  const wxLogger =
      Taro.getLogManager &&
      Taro.getLogManager({
        level: 0,
      });
  const log = (...params) => {
    console.log(...params);
    realTimeLogger && realTimeLogger.info(...params)
    wxLogger && wxLogger.log(...params);
  };
  return {
    log,
  };
};

let patientId = StoreUtils.readPatientId();

//蓝牙标题
const btTitle = ref("");
//蓝牙描述
const btContent = ref("为数据上传成功，请持续开启蓝牙。请勿关闭。");
//按钮状态
const btButton = ref("连接仪器");
//蓝牙图标  imgUrlFormat('sugar/sugar.png')
const btIcon = ref(imgUrlFormat('sugar/bluetooth_false.png'));

const bleBtnClass = () => {
  if (scaleMeasureState.value?.state == BleScanMeasureState.BLE_DISABLE.state) {
    return "ble_disable"
  } else {
    return "ble_normal"
  }
}


const tasks = ref<PointTask[]>([] as PointTask[]);

const chart = ref();

function initChart(canvas: any, width: any, height: any, dpr) {
  console.log(width, height)
  chart.value = echarts.init(canvas, null, {
    width,
    height,
    devicePixelRatio: dpr
  })
  // chart.value=echart
  // canvas.setChart(chart.value)
  sugarChart()

  return chart.value
}


const ec = reactive({
  onInit: initChart
})

const showInfoDialog = ref(false);

const mainPageStore = useMainPageStore();

const indexData = ref<IMainIndex>({} as IMainIndex);
const sugarStar = ref();

const calorie = computed(() => {
  const n = indexData.value.calorie || 0;
  const res = {
    calorie: n,
    calorieRecommend: indexData.value?.calorieRecommend || 0
  }
  return res;
})

const body = computed(() => {
  const weight = indexData.value.weight || 0;
  const bmi = indexData.value.bmi || 0;
  const res = {
    status: 'default',
    weight,
    bmi
  }

  switch (true) {
    case bmi > 20:
      res.status = 'warning';
      break;
    default:
      res.status = 'success'
      break;
  }
  return res;

})

const sugar = computed(() => {
  // sugar: {recordTime: "10/26 09:00", timeValue: 1, timeType: "早餐后", sugarValue: 6}
  // recordTime: "10/26 09:00"
  // sugarValue: 6
  // timeType: "早餐后"
  // timeValue: 1

  let sugarValue, timeType, sugarStatus = 2, timetypeStatus
  if (indexData.value?.sugar) {
    sugarValue = indexData.value?.sugar.sugarValue
    timeType = indexData.value?.sugar.timeType
    sugarStatus = formatSugarUpNormalLow(sugarValue, timeType);
    sugarValue += "mmol/L"
  } else {
    sugarValue = "还没有添加血糖记录哦～"
    timeType = "致力于糖友优质健康生活"
    timetypeStatus = 'intro'
  }
  let status
  if (sugarStatus == 1) {
    status = 'sugar_data_low'
  } else if (sugarStatus == 3) {
    status = 'sugar_data_high'
  } else {
    status = 'no_sugar_data'
  }
  const res = {
    status,
    timetypeStatus,
    sugarValue,
    timeType
  }
  return res;

})

const fat = computed(() => {
  const fat = indexData.value?.bodyFatData || {bindState: 0, bodyFatRate: 0};

  const res = {
    status: 'default',
    bindState: fat?.bindState || 0,
    bodyFatRate: fat?.bodyFatRate || 0,
  }

  switch (true) {
    case fat.bodyFatRate > 20:
      res.status = 'warning';
      break;

    default:
      res.status = 'success'
      break;
  }
  return res;
})

const bp = computed(() => {
  const res = {
    diastolic: indexData.value?.diastolic || 0,
    diastolicStatus: 'default',
    systolic: indexData.value?.systolic || 0,
    systolicStatus: 'default'
  }

  return res;
})

const hba1c = computed(() => {
  const res = {
    hba1c: indexData.value.hba1c || 0,
    status: 'default'
  }
  return res;
})

const roundClassName = () => {
  let value = keyBoardValue.value
  if (isEmpty(value)) {

    return "view_round_blue"
  } else {
    value = parseFloat(value)
    if (value <= 4.4) {

      return "view_round_orange"
    } else {
      let limitUp = active.value === 1 ? 7 : 10;
      if (value > 4.4 && value < limitUp) {

        return "view_round_blue"
      } else {

        return "view_round_red"
      }
    }
  }
}

useDidShow((options) => {
  if (!patientId) {
    patientId = StoreUtils.readPatientId();
  }
  mainPageStore.refreshPage()
  pageData()
  sugarChart()
  getTasks()

  // const systemSetting = Taro.getSystemSetting()
  // let bluetoothEnabled = systemSetting.bluetoothEnabled;
  // let locationEnabled = systemSetting.locationEnabled;
  // logger().log("ble=" + bluetoothEnabled + "; location=" + locationEnabled + "; state=" + scaleMeasureState.value?.state)
  // if (bluetoothEnabled && locationEnabled) {
  //   if (scaleMeasureState.value?.state!! == BleScanMeasureState.LOCATION_CLOSE.state) {
  //     checkBlePermission(true)
  //   } else if (scaleMeasureState.value?.state!! == BleScanMeasureState.BLE_DISABLE.state) {
  //     checkBlePermission(true)
  //   } else if (scaleMeasureState.value?.state!! == BleScanMeasureState.BLE_AUTHORIZE.state) {
  //     // 未授权时
  //     console.log('index.useDidShow.BleScanMeasureState.BLE_AUTHORIZE')
  //     checkBlePermission(true)
  //   } else {
  //     console.log('index.useDidShow.state=', scaleMeasureState.value)
  //   }
  // }
})

const getTasks = () => {
  PointApi.getTasks(2).then(res => {
    if (res.data && res.data.length > 0) {
      res.data.forEach(task => {
        let totalCount
        if (task.ruleTimeLimit != null && PointTimeConstants.UNLIMITED != task.ruleTimeLimit) {
          if (PointTimeConstants.LIMIT_ONCE == task.ruleTimeLimit) {
            totalCount = 1;
          } else if (PointTimeConstants.DAILY_LIMIT == task.ruleTimeLimit) {
            totalCount = task.ruleDayTimes;
          } else if (PointTimeConstants.MONTHLY_LIMIT == task.ruleTimeLimit) {
            totalCount = task.ruleMonthTimes;
          }
          if (totalCount > 0) {
            task.ruleDescription += "（" + task.finishCount + "/" + totalCount + "）"
          }
          if (totalCount && task.finishCount == totalCount) {
            task.ruleOperationClass = 'task_operation_finish'
            task.ruleOperation = '已完成'
          } else {
            task.ruleOperationClass = 'task_operation'
          }
        } else {
          task.ruleOperationClass = 'task_operation'
        }
      })
    }
    tasks.value = res.data
  }).catch(err => {
    console.log('index.getTasks. err = ', JSON.stringify(err))
  })
}

const onTaskItemClick = (item) => {
  if (item) {
    if (item.ruleOperation == '已完成') {
      // 已完成 点击不做处理
    } else {
      if (item.rulePointsOperationType == PointRuleConstants.ACADEMY_READ) {
        Taro.switchTab({url: item.mpPagePath})
      } else if (item.rulePointsOperationType == PointRuleConstants.SHOPPING) {
        goDeduction()
      } else if (item.rulePointsOperationType == PointRuleConstants.MARKET_SHARING) {

      } else if (item.mpPagePath) {
        Taro.navigateTo({
          url: item.mpPagePath
        })
      }
    }
  }
}

const pageData = () => {
  if (patientId) {
    SugarApi.getMainPageData().then(res => {
      indexData.value = res.data;
    });
  }

  SugarApi.getSugarStars().then(res => {
    sugarStar.value = res.recordList;
  });
}

const sugarChart = () => {
  if (!patientId) {
    loadChart()
    return
  }
  let response = SugarApi.getTimePeriodSugarChart(3);
  if (response) {
    response.then((res) => {
      // console.log("index.vue...success", JSON.stringify(res));
      loadChart(res.chart)
    }, (failure) => {
      console.log("index.vue...failure", failure)
    }).catch((error) => {
      console.log("index.vue...error", error);
    })
  }
}

const loadChart = (chartData?: Chart) => {
  // console.log('chart', chartData)
  let xAxisData = chartData?.dates.split(',');
  let yAxisData = chartData?.values.split(',');
  let currentDate = formatDate(new Date());
  // 为空时 设置假数据 占位 确保曲线中标线正常展示
  if (!xAxisData) {
    xAxisData = [];
    yAxisData = [];
    // 确保至少15以上 ，不超过18
    let periodCount = -13;
    for (let i = periodCount; i < 0; i++) {
      xAxisData.push(addDays(currentDate, i));
    }
    xAxisData.push(addDays(currentDate, 1));
    yAxisData[xAxisData.length - 1] = '16';
  }

  const option = categoryChartOptions(xAxisData, yAxisData, xAxisData[0], currentDate);
  if (chart.value) {
    chart.value.setOption(option)
  }
}

const goSugarDetail = () => {
  Taro.navigateTo({
    url: '/pagesSugarAnalysis/sugarAnalysis'
  })
}

const onDietClick = () => {
  if (!patientId) {
    Taro.showToast({
      title: '未登录，请先登录',
      icon: 'none',
      duration: 1000
    })
    setTimeout(() => {
      PageNavigation.navigationToLogin()
    }, 600)
    return
  }
  if (isInfoComplete()) {
    Taro.navigateTo({
      url: '/pagesFood/index/index'
    })
  } else {
    showInfoDialog.value = true
  }
}

const onDialogVisible = (res) => {
}

const isInfoComplete = () => {

  let height = StoreUtils.readPatientHeight();
  let weight = StoreUtils.readPatientWeight();
  let laborIntensity = StoreUtils.readPatientLaborIntensity();
  if (!laborIntensity) {
    return false;
  } else if (!height) {
    return false;
  } else if (!weight) {
    return false;
  }
  return true
}

const goInfo = () => {
  Taro.navigateTo({
    url: '/pagesMine/edit/index?baseInfo=true'
  })
  showInfoDialog.value = false
}

const goPoint = () => {
  Taro.navigateTo({
    url: '/pagesMine/points/index'
  })
}

Taro.showShareMenu({
  withShareTicket: true
})


// region 页面生命周期


onMounted(() => {
  // updateState(BleScanMeasureState.BIND_TO_SCAN)

  checkBlePermission()
})

onUnmounted(() => {
  stopBle()
})

// endregion

// region 蓝牙权限与蓝牙适配器状态操作

/**
 * 检验蓝牙授权状态
 */
const checkBlePermission = (silent: boolean = false) => {
  Taro.getSetting({
    success(res) {
      logger().log("index.vue.checkBlePermission.getSetting.success.res.authSetting=", res.authSetting);
      if (!res.authSetting['scope.bluetooth']) {
        Taro.authorize({
          scope: 'scope.bluetooth',
          success: (res) => {
            // showShortToast('蓝牙授权成功')
            logger().log("checkBlePermission.authorize.success.", JSON.stringify(res));
            openBluetoothAdapter()
          },
          fail: (res) => {
            // showShortToast('蓝牙授权失败')
            logger().log('蓝牙授权失败', JSON.stringify(res))
            if (!silent) {
              showBleAuthorizeModal()
            }
            onBleAuthorize()
          }
        })
      } else {
        // checkBleAdapterState()
        openBluetoothAdapter()
      }
    },
    fail(res) {
      console.log('index.checkBlePermission.fail.', JSON.stringify(res))
      if (!silent) {
        showBleAuthorizeModal()
      }
      onBleAuthorize()
    }
  })
}

/**
 * 校验蓝牙适配器状态
 */
const checkBleAdapterState = () => {
  Taro.getBluetoothAdapterState({
    success: (res) => {
      console.log("index.vue.checkBleAdapterState.success.", JSON.stringify(res));
      // startScan()
    },
    fail: (failure) => {
      console.log("index.vue.checkBleAdapterState.fail.", JSON.stringify(failure));
      // openBluetoothAdapter()
    }
  })
}

/**
 * 打开蓝牙适配器
 */
const openBluetoothAdapter = () => {
  const systemSetting = Taro.getSystemSetting()
  const bleEnabled = systemSetting.bluetoothEnabled;
  const locationEnabled = systemSetting.locationEnabled;
  Taro.openBluetoothAdapter({
    success: (res) => {
      logger().log("index.vue.openBluetoothAdapter.success.", JSON.stringify(res));
      if (locationEnabled) {
        startScan()
        updateState(bindState.value ? BleScanMeasureState.BIND_TO_SCAN : BleScanMeasureState.UNBIND)
      } else {
        updateState(BleScanMeasureState.LOCATION_CLOSE)
        showBleDisableModal(BleScanMeasureState.LOCATION_CLOSE.subState)
      }
    },
    fail: (res) => {
      logger().log("index.vue.openBluetoothAdapter.fail.", JSON.stringify(res), '; JSON.stringify(res).indexOf(\'openBluetoothAdapter:fail already opened = ', JSON.stringify(res).indexOf('openBluetoothAdapter:fail already opened'));
      if (JSON.stringify(res).indexOf('openBluetoothAdapter:fail already opened') != -1) {
        if (locationEnabled) {
          startScan()
          updateState(bindState.value ? BleScanMeasureState.BIND_TO_SCAN : BleScanMeasureState.UNBIND)
        } else {
          updateState(BleScanMeasureState.LOCATION_CLOSE)
          showBleDisableModal(BleScanMeasureState.LOCATION_CLOSE.subState)
        }
      } else {
        let str
        if (!bleEnabled && !locationEnabled) {
          str = '手机蓝牙、定位未打开，请先打开手机蓝牙、定位权限'
        } else if (!bleEnabled) {
          str = BleScanMeasureState.BLE_DISABLE.subState
          // str = JSON.stringify(res)
        } else {
          str = BleScanMeasureState.LOCATION_CLOSE.subState
        }
        showBleDisableModal(str)
        onBleDisable()
      }
    },
    complete: () => {
      onBleAdapterState()
    }
  })
}

const closeBluetoothAdapter = () => {
  Taro.closeBluetoothAdapter({
    success: (res) => {
      logger().log("index.vue.closeConnect.success.", JSON.stringify(res));
    },
    fail: (res) => {
      logger().log("index.vue.closeConnect.fail.", JSON.stringify(res));
    }
  })
}

const onBleAdapterState = () => {
  Taro.onBluetoothAdapterStateChange(res => {
    if (res.available) {
      // 蓝牙适配器可用
      logger().log("onBluetoothAdapterStateChange 蓝牙适配器可用");
      // startScan()
      if (scaleMeasureState.value?.state !! == BleScanMeasureState.BLE_DISABLE.state) {
        const systemSetting = Taro.getSystemSetting()
        if (systemSetting.locationEnabled) {
          updateState(bindState.value ? BleScanMeasureState.BIND_TO_SCAN : BleScanMeasureState.UNBIND)
          restart()
        } else {
          updateState(BleScanMeasureState.LOCATION_CLOSE)
          showToastLong("位置信息未开启，请先打开")
        }
      }
    } else {
      // 蓝牙适配器不可用
      logger().log("onBluetoothAdapterStateChange 蓝牙适配器不可用");
      stopBle(false)
      onBleDisable()
    }
  })
}

//
const onBleDisable = () => {
  updateState(BleScanMeasureState.BLE_DISABLE)
}

const onBleAuthorize = () => {
  updateState(BleScanMeasureState.BLE_AUTHORIZE)
}

// endregion

// region  扫描与连接

const startScan = () => {
  if (!patientId) {
    // 未登录 不扫描
    logger().log('index.startScan.patientId=', patientId, '; 未登录，无法扫描')
    return;
  }
  Taro.startBluetoothDevicesDiscovery({
    allowDuplicatesKey: false,
    services: [
      DeviceUUID.SERV_GLUCOSE_UUID,
      DeviceUUID.SERV_GLUCOSE_UUID_UPPER,
      DeviceUUID.SERV_DEVINFO_UUID,
      DeviceUUID.SERV_DEVINFO_UUID_UPPER
    ],
    complete: (res) => {
      // 扫描结束
      logger().log("startScan 开启扫描 complete ", JSON.stringify(res));
    },
    success: (res) => {
      scanning.value = true
      onBluetoothDeviceFound(res)
      updateState(bindState.value ? BleScanMeasureState.BIND_SCANING : BleScanMeasureState.UNBIND_SCANING)
      timer.value = startTimer(timeOut);
      showToastLong("开始扫描仪器")
    },
    fail: (res) => {
      logger().log("index.vue.startScan.fail.", JSON.stringify(res), '; res.errMsg=', res.errMsg, ';res.errMsg.indexOf(\'already discovering devices\') != -1=', (res.errMsg.indexOf('already discovering devices') != -1));
      if (res.errMsg && res.errMsg.indexOf('already discovering devices') != -1) {
        // 已开启扫描
        console.log('index.startScan.fail.already stop then start ')
      } else {
        updateState(bindState.value ? BleScanMeasureState.BIND_SCAN_FAILURE : BleScanMeasureState.UNBIND_SCAN_FAILURE)
        console.log('index.start scan fail. update state', scaleMeasureState.value?.mainState)
      }
    }
  })
}

const stopScan = (callback: ActionCallback | null = null) => {
  console.log('index.stopScan.scanning.value=', scanning.value)
  if (scanning.value) {
    console.log('index.stopScan.scanning.value=', scanning.value)
    Taro.stopBluetoothDevicesDiscovery({
      success: (res) => {
        logger().log("index.vue.stopScan.success.", JSON.stringify(res));
        scanning.value = false
        callback && callback()
      },
      fail: (res) => {
        logger().log("index.vue.stopScan.fail.", JSON.stringify(res));
      },
      complete: (res) => {
        console.log('index.complete.stopBluetoothDevicesDiscovery', JSON.stringify(res))
      }
    })
  } else {
    callback && callback()
  }
}

/**
 * 扫描发现设备监听
 * @param res
 */
const onBluetoothDeviceFound = (res) => {
  console.log('index.onBluetoothDeviceFound.', JSON.stringify(res))
  Taro.onBluetoothDeviceFound((res) => {
    res.devices.forEach(device => {
      if (!device.name && !device.localName) {
        console.log('index.onBluetoothDeviceFound 过滤设备名称为空')
        return
      }
      if (device.name.indexOf("未知") != -1) {
        console.log('index.onBluetoothDeviceFound 过滤 设备名称异常')
        return;
      }
      if (!device.advertisServiceUUIDs || device.advertisServiceUUIDs.length === 0) {
        console.log('index.onBluetoothDeviceFound 过滤开放服务为空 deviceId=', device.deviceId)
        return
      }
      //     "00001808-0000-1000-8000-00805f9b34fb",
      //     "0000180a-0000-1000-8000-00805f9b34fb"
      if (device.advertisServiceUUIDs.indexOf(DeviceUUID.SERV_GLUCOSE_UUID) != -1 || device.advertisServiceUUIDs.indexOf(DeviceUUID.SERV_GLUCOSE_UUID_UPPER) != -1) {
        console.log('index.onBluetoothDeviceFound index of 发现匹配服务', device.advertisServiceUUIDs)
      } else {
        console.log('index.onBluetoothDeviceFound index of 未找到匹配服务', device.advertisServiceUUIDs)
        return;
      }
      console.log('onBluetoothDeviceFound device=', JSON.stringify(device), '; connectedDevice.value=', connectedDevice.value)
      if (!connectedDevice.value) {
        connectedDevice.value = device
        updateState(BleScanMeasureState.BIND_SCAN_SUCCESS)
      }
      stopScan()
      startConnect()
      // const foundDevices = this.data.devices
      // const idx = inArray(foundDevices, 'deviceId', device.deviceId)
      // const data = {}
      // if (idx === -1) {
      //   data[`devices[${foundDevices.length}]`] = device
      // } else {
      //   data[`devices[${idx}]`] = device
      // }

    })
  })
}

const startConnect = () => {
  if (connected.value) {
    // 已连接
    logger().log("startConnect 已连接 不重复连接")
    return
  }
  if (!connecting.value) {
    connecting.value = true
  } else {
    // 连接中
    logger().log("startConnect 连接中不重复连接")
    return
  }
  updateState(BleScanMeasureState.CONNECTING)
  console.log('index.startConnect.device.value=', connectedDevice.value)
  let {deviceId} = connectedDevice.value
  Taro.createBLEConnection({
    deviceId,
    success: function (res) {
      console.log('index.createBLEConnection.success.', JSON.stringify(res))
      onConnectionStateChange()
    },
    fail: function (res) {
      console.log('index.startConnect.createBLEConnection.fail.', JSON.stringify(res))
      updateState(BleScanMeasureState.CONNECT_FAILURE)
    }
  })

}

const onConnectFailure = () => {
  logger().log("onConnectFailure.")
  connected.value = false
  connecting.value = false
  updateState(BleScanMeasureState.LOST_CONNECT)
}

const onConnectSuccess = () => {
  console.log('index.onConnectSuccess.')
  connected.value = true
  connecting.value = false
  updateState(BleScanMeasureState.CONNECT_SUCCESS)
  startMeasure()
}

const onConnectionStateChange = () => {
  console.log('index.onConnectionStateChange.')
  Taro.onBLEConnectionStateChange((res) => {
    console.log('onConnectionStateChange', `device ${res.deviceId} state has changed, connected: ${res.connected}`)
    if (res.connected) {
      onConnectSuccess()
    } else {
      onConnectFailure()
    }
  })
}

const offBLEConnectionStateChange = () => {
  Taro.offBLEConnectionStateChange((res) => {
    console.log('onConnectionStateChange', `device ${res.deviceId} state has changed, connected: ${res.connected}`)
  })
}

const startMeasure = () => {
  console.log('index.startMeasure.')
  let {deviceId} = connectedDevice.value
  Taro.getBLEDeviceServices({
    deviceId,
    success: (res) => {
      console.log('index.getBLEDeviceServices.success.', JSON.stringify(res))
      // 查找特定服务 ，找到继续查找特征值，找不到直接反馈失败
      let bleService;
      if (res.services && res.services.length > 0) {
        bleService = res.services.find(service =>
            service.uuid.indexOf(DeviceUUID.SERV_GLUCOSE_UUID_PREFIX) != -1
        );
      }
      if (bleService) {
        updateState(BleScanMeasureState.BIND_MEASURING)
        showToastLong("开始测量")
        getBleCharacteristics(deviceId, bleService.uuid)
      } else {
        updateState(BleScanMeasureState.SERVICE_NOT_FOUND)
      }

    },
    fail: (res) => {
      logger().log('index.getBLEDeviceServices.fail.', JSON.stringify(res))
      updateState(BleScanMeasureState.SERVICE_NOT_EXIST)
    }
  })
}

const getBleCharacteristics = (deviceId: string, serviceId: string) => {
  Taro.getBLEDeviceCharacteristics({
    deviceId,
    serviceId,
    success: (res) => {
      console.log('index.getBLEDeviceCharacteristics.success.', JSON.stringify(res))
      let characteristic
      if (res.characteristics && res.characteristics.length > 0) {
        characteristic = res.characteristics.find(characteristic =>
            characteristic.uuid.toUpperCase().indexOf(DeviceUUID.GLUCOSE_MEAS_UUID) != -1
        );
      }
      if (characteristic) {
        // 找到特征值
        console.log('index.getBLEDeviceCharacteristics.success. 找到特征值', JSON.stringify(characteristic))
        // 开始读特征值
        notifyCharacteristicValueChange(deviceId, serviceId, characteristic.uuid)
      } else {
        updateState(BleScanMeasureState.SERVICE_NOT_FOUND)
      }
    },
    fail: (res) => {
      logger().log('index.getBLEDeviceCharacteristics.fail.', JSON.stringify(res))
      updateState(BleScanMeasureState.SERVICE_NOT_EXIST)
    }
  })
}

const notifyCharacteristicValueChange = (deviceId: string, serviceId: string, uuid: string) => {
  Taro.notifyBLECharacteristicValueChange({
    state: true,
    deviceId,
    serviceId,
    characteristicId: uuid,
    success: (res) => {
      logger().log('index.notifyBLECharacteristicValueChange.success.', JSON.stringify(res))
      onCharacteristicValueChange()
    },
    fail: (res) => {
      logger().log('index.notifyBLECharacteristicValueChange.fail.', JSON.stringify(res))
    }
  })
}

const onCharacteristicValueChange = () => {
  logger().log("onCharacteristicValueChange.")
  Taro.onBLECharacteristicValueChange((res) => {
    let hexString = ab2hex(res.value);
    logger().log(`onBLECharacteristicValueChange.characteristic ${res.characteristicId} has changed, now is ${res.value}`, '; parseValue=', hexString)
    // 470000e707011e0408240000f08a11
    analysisData(hexString)
  })
}

const offCharacteristicValueChange = () => {
  logger().log("offCharacteristicValueChange.")
  Taro.offBLECharacteristicValueChange((res) => {
    logger().log('index.onBLECharacteristicValueChange', JSON.stringify(res))
  })
}


const disConnect = () => {
  logger().log("disConnect.", connectedDevice.value)
  const {deviceId} = connectedDevice.value
  offBLEConnectionStateChange()
  Taro.closeBLEConnection({
    deviceId,
    success: (res) => {
      logger().log('index.closeBLEConnection.success.', JSON.stringify(res))
      connected.value = false
      connecting.value = false
      connectedDevice.value = null
    },
    fail: (res) => {
      logger().log('index.closeBLEConnection.fail.', JSON.stringify(res))
    }
  })
}


/**
 * 停止蓝牙活动
 * 1、
 * 2、关闭连接
 * 3、停止扫描
 * 4、关闭蓝牙适配器
 */
const stopBle = function (closeBleAdapter: boolean = true) {
  if (connected.value) {
    offCharacteristicValueChange()
    disConnect()
  }
  clearTimer()
  stopScan()
  if (closeBleAdapter) {
    closeBluetoothAdapter()
  }
}

/**
 * 刷新蓝牙
 */
const restart = () => {
  console.log('index.restart.')
  if (connected.value) {
    offCharacteristicValueChange()
    disConnect()
  }
  stopScan(() => {
    startScan()
  })
}

// endregion

// region 计时器
/**
 * 扫描计时器
 * @param callback
 * @param timeout 默认10s超时
 */
const startTimer = (callback: ActionCallback | null = null, timeout: number = 10000) => {
  console.log('index.startTimer.current time is ', Date.now())
  return setInterval(() => {
    callback && callback()
  }, timeout)
}

const timeOut: ActionCallback = () => {
  console.log('index.timeOut.', scaleMeasureState.value, '; current time is ', Date.now())
  if (!connectedDevice.value) {
    updateState(BleScanMeasureState.BIND_SCAN_TIMEOUT)
    showToastLong("扫描失败，请重新点击连接仪器")
    stopScan()
  }
  clearTimer()
}

interface ActionCallback {
  (): void
}

const clearTimer = () => {
  if (timer.value) {
    clearInterval(timer.value)
    timer.value = 0
  }
}


// endregion

// region 页面逻辑操作

// ArrayBuffer转16进度字符串示例
function ab2hex(buffer) {
  const hexArr = Array.prototype.map.call(
      new Uint8Array(buffer),
      function (bit) {
        return ('00' + bit.toString(16)).slice(-2)
      }
  )
  return hexArr.join('');
}


const analysisData = (hexString) => {
  logger().log("analysisData.", '构造前', JSON.stringify(hexString));
  const sugarValue = parseSugarValue(hexString.substring(hexString.length - 6, hexString.length - 2));
  // 获取当前时间
  let date = new Date();
  const recordTime = formatTime(date)
  // 根据当前时间获取默认时段
  let timeIndex = formatCurrentIndex(date.getHours())
  // 方法返回值与实际定义的时段不一致，凌晨实际为7，其余项需要减去1  肖 2024-01-30 10:26:50
  if (timeIndex == 0) {
    timeIndex = 7;
  } else {
    timeIndex -= 1
  }
  let {deviceId} = connectedDevice.value
  logger().log("index.vue.analysisData.deviceId=", deviceId);

  const uploadTmp: IBleGluUploadData = {
    recordValue: sugarValue,
    recordTime,
    timeType: timeIndex,
    deviceSn: deviceId
  }
  upload.value = uploadTmp
  uploadData()
}

function parseSugarValue(valueHexStr: string): number {
  const n: number = parseInt(valueHexStr.charAt(1) + valueHexStr.charAt(0), 16);
  const m: number = parseInt(valueHexStr.substring(2), 16);
  logger().log(`parseSugarValue: valueStr=${valueHexStr};n=${n}; m =${m}`);
  return m * Math.pow(10, n - 16);
}

const uploadData = () => {
  console.log('index.uploadData.', JSON.stringify(upload.value))
  let response = SugarApi.uploadYasiBleRecord(upload.value!!);
  if (response) {
    response.then((res) => {
      logger().log("index.vue.uploadData..success", JSON.stringify(res));
      showToastLong('测量成功')
      updateState(BleScanMeasureState.BIND_MEASURE_SUCCESS)
      mainPageStore.refreshPage()
      stopBle()
      goSugarDetail()
      // Taro.redirectTo({
      //   url: '/pages/pagesSugarAnalysis/sugarAnalysis'
      // })
    }, (failure) => {
      logger().log("index.vue.uploadData..failure", failure)
      updateState(BleScanMeasureState.BIND_MEASURE_FAILURE)
    }).catch((error) => {
      console.log("index.vue.uploadData..error", error);
    })
  }
}

// endregion

// region 页面更新、响应页面事件
const onRetryBtnClick = () => {
  console.log('index.onRetryBtnClick.scaleMeasureState.value=', scaleMeasureState.value)
  if (!patientId) {
    //
    showToastLong("未登录，请先登录")
    setTimeout(() => {
      PageNavigation.navigationToLogin()
    }, 600)
    return;
  }
  switch (scaleMeasureState.value?.state) {
    case BleScanMeasureState.BIND_TO_SCAN.state:
    case BleScanMeasureState.UNBIND.state:
      if (!scanning.value) {
        updateState(BleScanMeasureState.BIND_TO_SCAN)
        checkBlePermission()
      } else {
        restart()
      }
      break;
    case BleScanMeasureState.LOCATION_CLOSE.state:
      const systemSetting = Taro.getSystemSetting()
      const locationEnabled = systemSetting.locationEnabled;
      if (locationEnabled) {
        checkBlePermission()
      } else {
        showBleDisableModal(BleScanMeasureState.LOCATION_CLOSE.subState)
      }
      break;
    case BleScanMeasureState.BIND_SCAN_FAILURE.state:
    case BleScanMeasureState.BIND_SCAN_TIMEOUT.state:
    case BleScanMeasureState.UNBIND_SCAN_TIMEOUT.state:
    case BleScanMeasureState.UNBIND_SCAN_FAILURE.state:
    case BleScanMeasureState.LOST_CONNECT.state:
    case BleScanMeasureState.CONNECT_FAILURE.state:
    case BleScanMeasureState.BIND_MEASURE_SUCCESS.state:
      updateState(bindState.value ? BleScanMeasureState.BIND_TO_SCAN : BleScanMeasureState.UNBIND)
      // restart()
      checkBlePermission()
      break;
    case BleScanMeasureState.BIND_MEASURE_FAILURE.state:
      uploadData()
      break;
    case BleScanMeasureState.BLE_DISABLE.state:
      showBleDisableModal()
      break;
    case BleScanMeasureState.BLE_AUTHORIZE.state:
      logger().log('index.onRetryBtnClick.BLE_AUTHORIZE')
      Taro.openSystemBluetoothSetting({
        success: (res) => {
          console.log('index.onRetryBtnClick.BLE_AUTHORIZE.success.res=', JSON.stringify(res))
        }
      })
      break;
    case BleScanMeasureState.UNBIND_SCANING.state:
    case BleScanMeasureState.BIND_SCANING.state:
      showToastLong("正在扫描仪器，请稍候")
      break;
    default:
      console.log('index.onRetryBtnClick.default')
      goSugarDetail()
      break;
  }
}

const showBleDisableModal = (str: string | null = null) => {
  Taro.showModal({
    content: str || '手机蓝牙未开启，请先打开手机蓝牙',
    showCancel: false,
    confirmText: '知道了'
  })
}

const showBleAuthorizeModal = () => {
  Taro.showModal({
    content: BleScanMeasureState.BLE_AUTHORIZE.subState,
    showCancel: false,
    confirmText: '知道了',
    success: (res) => {
      Taro.openSystemBluetoothSetting({
        success: (res) => {
          console.log('index.showBleAuthorizeModal.BLE_AUTHORIZE.success.res=', JSON.stringify(res))
        }
      })
      // Taro.openSetting({
      //   success: (res) => {
      //     console.log('index.showBleAuthorizeModal.BLE_AUTHORIZE.success.res=', JSON.stringify(res))
      //   }
      // })
    }
  })
}

const updateState = (state) => {
  console.log("index.vue.updateState.", JSON.stringify(state));
  scaleMeasureState.value = state
  showPageBleState()
}

const showPageBleState = () => {
  console.log('index.showPageBleState. state =', scaleMeasureState.value)
  // if (scaleMeasureState.value?.retryBtnText) {
  btButton.value = scaleMeasureState.value?.retryBtnText!!
  // }
  if (!btButton.value || btButton.value == '重新扫描') {
    btButton.value = "连接仪器"
  }
  switch (scaleMeasureState.value?.state) {

    case BleScanMeasureState.BLE_AUTHORIZE.state:
      btIcon.value = imgUrlFormat('sugar/bluetooth_false.png');
      btTitle.value = ""
      btContent.value = "请先打开小程序设置，允许蓝牙授权"
      break;
    case BleScanMeasureState.LOCATION_CLOSE.state:
      btIcon.value = imgUrlFormat('sugar/bluetooth_false.png');
      btTitle.value = ""
      btContent.value = BleScanMeasureState.LOCATION_CLOSE.subState
      break;
    case BleScanMeasureState.BLE_DISABLE.state:
      btIcon.value = imgUrlFormat('sugar/bluetooth_false.png');
      btTitle.value = ""
      btContent.value = "请先开启手机蓝牙"

      break;
    case BleScanMeasureState.BIND_TO_SCAN.state:
    case BleScanMeasureState.UNBIND.state:
      btIcon.value = imgUrlFormat('sugar/bluetooth_false.png');
      btContent.value = "为数据上传成功，请持续开启蓝牙。请勿关闭。"
      break;
    case BleScanMeasureState.BIND_SCANING.state:
    case BleScanMeasureState.UNBIND_SCANING.state:
      // 开启扫描成功

      break;
    case BleScanMeasureState.BIND_SCAN_FAILURE.state:
    case BleScanMeasureState.UNBIND_SCAN_FAILURE.state:
      // // 开启扫描失败
      // btIcon.value = imgUrlFormat('sugar/bluetooth_false.png');
      // btContent.value = "请扫描仪器蓝牙"
      // break;
    case BleScanMeasureState.BIND_SCAN_TIMEOUT.state:
      btIcon.value = imgUrlFormat('sugar/bluetooth_false.png');
      btContent.value = "连接仪器失败，请重新扫描仪器蓝牙"
      break;
    case BleScanMeasureState.SERVICE_NOT_EXIST.state:
    case BleScanMeasureState.SERVICE_NOT_FOUND.state:
      // 设备服务异常
      btIcon.value = imgUrlFormat('sugar/bluetooth_false.png');
      btContent.value = "设备异常，请联系客服"
      showToastLong("设备异常")
      break
    case BleScanMeasureState.CONNECT_FAILURE.state:
      showToastLong("雅斯GLM-76L血糖仪连接失败");
    case BleScanMeasureState.LOST_CONNECT.state:
      btIcon.value = imgUrlFormat('sugar/bluetooth_true.png');
      btTitle.value = "设备未连接"
      btContent.value = "为数据上传成功，请持续开启蓝牙。请勿关闭。"
      break
    case BleScanMeasureState.BIND_MEASURING.state:
      // 开始测量
      showToastLong("请开始测量");
      btContent.value = BleScanMeasureState.BIND_MEASURING.subState
      break
    case BleScanMeasureState.BIND_SCAN_SUCCESS.state:
      // 开始测量
      showToastLong("发现设备，开始扫描");
      break
    case BleScanMeasureState.CONNECT_SUCCESS.state:
      // 连接成功
      btIcon.value = imgUrlFormat('sugar/bluetooth_true.png');
      btTitle.value = "雅斯76L血糖仪设备已连接"
      btContent.value = BleScanMeasureState.CONNECT_SUCCESS.subState
      btButton.value = "查看数据"
      showToastLong("雅斯GLM-76L血糖仪连接成功");
      break;
    default:
      btContent.value = "为数据上传成功，请持续开启蓝牙。请勿关闭。"
      break;
  }
  // if (scaleMeasureState.value?.state!! >= BleScanMeasureState.CONNECT_SUCCESS.state) {
  //   btIcon.value = imgUrlFormat('sugar/bluetooth_true.png');
  //   btTitle.value = "雅斯76L血糖仪设备已连接"
  //   btButton.value = "查看数据"
  //   btContent.value = scaleMeasureState.value?.subState!!
  // } else {
  //   btIcon.value = imgUrlFormat('sugar/bluetooth_false.png');
  //   btTitle.value = "设备蓝牙未连接"
  //   btButton.value = "连接仪器"
  //   btContent.value = "为数据上传成功，请持续开启蓝牙。请勿关闭。"
  // }
}

// endregion


</script>

<style lang="less">
* {
  box-sizing: border-box;
}

/**index.wxss**/
.container_index {
  box-sizing: border-box;
  padding: 27.78px 20.83px;

  .chart_container {
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 470.14px;
    background: var(--status_normal);
    padding: 0 5.55px 5.55px 5.55px;


    .top {
      width: 100%;
      height: 92.36px;
      display: flex;
      justify-content: space-between;
      align-items: center;

      .img {
        height: 36.81px;
      }

      .nums {
        font-size: 30.56px;
        font-weight: normal;
        color: white;
      }
    }

    .bottom {
      width: 100%;
      height: 372px;
      background: white;
    }
  }
}

.space {
  margin-bottom: 27.78px;
}

image {
  width: 130px;
}

.card_blue {
  background: white;
  height: 172px;
  display: flex;
  padding: 30px 20px;
  width: 709px;
  align-items: center;
  border-radius: 17px;
  margin: 27px auto;

  .ble_normal {
    background: #64A4F5;
    height: 57px;
    width: 148px;
    color: white;
    font-size: 29px;
    line-height: 57px;
    text-align: center;
    border-radius: 30px;
  }

  .ble_disable {
    background: #bbbbbb;
    height: 57px;
    width: 148px;
    color: white;
    font-size: 29px;
    line-height: 57px;
    text-align: center;
    border-radius: 30px;
  }

  .blue_left {
    display: flex;
    flex: 1;
    height: 100px;
    justify-content: space-between;
    flex-direction: column;

    .status {
      display: flex;
      align-items: center;
      color: #353535;
      font-weight: 600;
      font-size: 33px;

      img {
        width: 45px;
        height: 45px;
        margin-right: 11px;
      }
    }

    .desc {
      font-size: 29.17px;
      font-weight: normal;
    }
  }
}

.chart-week-container {
  padding: 15px;
  align-items: center;
}

.point_task {
  background-color: white;
  padding: 30px 20px;
  margin: 27px auto;

  .image-icon {
    width: 44.44px;
    height: 44.44px;
    margin-right: 11.11px;
  }

  .name {
    font-size: 33.33px;
    font-weight: 600;
  }

  .point-task {
    margin: 20rpx;
    background-color: white;
    padding: 20px;

    .vertical-center {
      align-items: center;
    }

    .task_img {
      width: 80rpx;
      height: 80rpx;
    }

    .task-value-content {
      margin-left: 8rpx;
      width: 88%;
      margin-top: 30rpx;

      .task_value_icon {
        width: 40rpx;
        height: 40rpx;
      }

      .task_name {
        color: #333;
        font-size: 32rpx;
        text-align: center;
      }

      .task_value {
        color: #ff770f;
        margin-left: 10rpx;
        font-size: 32rpx;
        font-weight: bold;
      }

      .task_desc {
        color: #555;
        margin-top: 16rpx;
        font-size: 24rpx;
      }

      .task_operation {
        color: #4aa4fc;
        font-size: 30rpx;
        border-radius: 20rpx;
        border: 1px solid #4aa4fc;
        padding-left: 24rpx;
        padding-right: 24rpx;
        box-sizing: border-box;
      }

      .task_operation_finish {
        background: #f9f9f9;
        color: #999;
        font-size: 30rpx;
        border-radius: 20rpx;
        border: 1px solid #f9f9f9;
        padding-left: 24rpx;
        padding-right: 24rpx;
        box-sizing: border-box;
      }

      .divider {
        margin-top: 30rpx;
        width: 100%;
        height: 1px;
        background-color: #f2f2f2;
      }
    }
  }
}

.flex-grow {
  flex-grow: 1;
  -webkit-flex-grow: 1;
}

/*记血糖*/
.blood_sugar_box {
  width: 100%;

  display: flex;
  flex-direction: row;
  justify-content: space-between;

  .blood_sugar_left {
    width: 377.78px;
    height: 255.56px;
    background: white;
    padding: 28px 21px;

    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: flex-start;
  }

  .blood_sugar_right {
    height: 255.56px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    align-items: center;
  }


  /*血糖分析*/

  .analyse_box {
    width: 309.72px;
    height: 100px;
    background: white;
    padding: 20.83px;
    display: flex;
    justify-content: flex-start;
    align-items: center;
  }

  /*智能设备*/

  .device_box {
    width: 309.72px;
    height: 133.33px;
    background: white;
    padding: 20.83px;

    display: flex;
    justify-content: flex-start;
    align-items: center;
  }

  .image-icon {
    width: 44.44px;
    height: 44.44px;
    margin-right: 11.11px;
  }

  .name {
    font-size: 33.33px;
    font-weight: 600;
  }

  .sugar_intro_box {

    .sugar_data_high {
      font-size: 40px;
      color: #e64a4a;
      font-weight: normal;
      margin-top: 25px;
    }

    .sugar_data_low {
      font-size: 40px;
      color: #feb433;
      font-weight: normal;
      margin-top: 25px;
    }

    .sugar_data_normal {
      font-size: 40px;
      color: #87ceea;
      font-weight: normal;
      margin-top: 25px;
    }

    .no_sugar_data {
      font-size: 29.17px;
      font-weight: normal;
      margin-top: 25px;
    }

    .intro {
      display: inline-block;
      border-radius: 52.08px;
      background: #EBF6FF;
      font-size: 22.22px;
      font-weight: normal;
      color: #64A4F5;
      padding: 11.11px 16.67px;
      margin-top: 16.67px;
    }
  }
}

/* 记录列表 */
.record_card {
  display: block;
  margin-top: 28px;
}

.box {
  width: 100%;
  height: auto;
  border-radius: 8.335px;
  background: #FFFFFF;

  padding: 33px 20px;

  box-sizing: border-box;

  display: flex !important;
  flex-direction: row;
  justify-content: space-between;

  .title_box {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: flex-start !important;

    font-size: 33px;
    font-weight: 600;

  }


  .left_box {
    flex: 1;
  }

  .icon {
    width: 44px;
    height: 44px;
    margin-right: 11px;
  }


  .bind {
    border-radius: 5.56px;

    /* 64A4F5主色调 */
    background: #64A4F5;
    color: white;
    font-size: 25px;
    padding: 2px 11px;
    margin-left: 11px;
  }

  .unbind {
    background: #BBBBBB;
    color: white;
    border-radius: 5.56px;
    font-size: 25px;
    padding: 2px 11px;
    margin-left: 11px;
  }

  .none {
    display: none;
  }

  .slot {
    font-size: 29.17px;
    font-weight: normal;
    margin-top: 26px;
  }

  .default {
    font-size: 29.17px;
    font-weight: normal;
    color: #5F5F5F;
    margin-top: 26px;
  }

  .right_box {
    width: 80px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
  }

  .add_icon {
    width: 65px;
    height: 65px;
  }

  .add_text {
    font-size: 29px;
    margin-top: 12px;
    color: #5F5F5F;
  }


}

.info_dialog {
  width: 100vh;
  height: 100vh;
  background: transparent;
}

.dialog {
  position: relative;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;

  img {
    width: 560px;
    height: 580px;
  }

  .dialog_content {
    display: flex;
    top: 260px;
    padding: 20px 100px;
    position: absolute;
    flex-direction: column;
    align-items: center;

    .content {
      font-size: 25px;
      height: 100px;
      margin: 20px;
      color: #5D5D5D;
    }

    .btn {
      width: 450px;
      margin: 60px auto;
      height: 80px;
      text-align: center;
      line-height: 80px;
      color: white;
      background: #6AA4FC;
      border-radius: 10px;
    }
  }
}

.sugar_star_box {
  .scroll-view_x {
    overflow-x: auto;
  }

  .scroll_box {
    display: inline-flex;
    flex-direction: row;
    flex-wrap: nowrap;
    align-items: center;
    padding: 27.78px 0;

    .scroll_item {
      margin-right: 20.83px;
    }
  }

}

.point-task {
  margin-top: 20rpx;
  background-color: #ff770f33;
  padding: 10px 20px;
  align-items: center;


  .task_img {
    width: 52rpx;
    height: 52rpx;
  }

  .task_value_icon {
    width: 30rpx;
    height: 30rpx;
  }

  .task_value {
    color: #ff770f;
    margin-left: 10rpx;
  }

  .task_operation {
    color: #ff770f;
    font-size: 22rpx;
    border-radius: 20rpx;
    border: 1px solid #ff770f;
    padding-left: 8rpx;
    padding-right: 8rpx;
    box-sizing: border-box;
  }

}

</style>
