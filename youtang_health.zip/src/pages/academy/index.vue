<template>
	<view class="container_academy">
		<view class="top_box space" style="margin-bottom:14px;">
			<navigator class="blood_sugar_left round" url="/pagesAcademy/gi/index"  hover-class="none">
				<view class="horizon-container">
					<image class="image-icon" :src="imgUrlFormat('sugar/gi.png')" mode="widthFix"/>
					<view class="name">食物GI速查表</view>
				</view>
				<view class="intro_box">
					<view class="no_sugar_data">保持血糖稳定，身体健康
					</view>
					<view class="intro">高升糖丨中升糖｜低升糖</view>
				</view>
			</navigator>
			<view class="blood_sugar_right">
				<navigator class="analyse_box round" url="/pagesAcademy/food/index"  hover-class="none">
					<image class="image-icon" :src="imgUrlFormat('sugar/food/diet-2.png')" mode="widthFix"/>
					<view class="name">食物库</view>
				</navigator>
				<navigator class="device_box round" url="/pagesAcademy/drug/index"  hover-class="none">
					<image class="image-icon" :src="imgUrlFormat('sugar/pill.png')" mode="widthFix"/>
					<view class="name">药品库</view>
				</navigator>
			</view>

		</view>

		<view class="top_like">
			<swiper class="top_like_swiper" indicator-color='#999'
					indicator-active-color='#333'
					@change="swiperIndexChange"
					:circular="true"
					:indicator-dots="false"
					:autoplay="false">
				<swiper-item class="top_like_item" v-for="item in topLike" :key="item">
					<view @click.stop="gotoArticlePage(item)">
						<view class="type">{{ item.title }}</view>
						<view class="item_box">
							<view class="left">
								<image :class="`cover_${idx}`" v-for="(img,idx) in item.cover" :src="img"
									   mode="scaleToFit"></image>
							</view>
							<view class="right">
								<view class="title_item" v-for="(article, index) in item.list.slice(0,3)">
									<view class="index" :style="likeColor[index]">{{ index + 1 }}</view>
									<view class="title shortened_text">{{ article.wordTitle }}</view>
								</view>
							</view>
						</view>
					</view>
				</swiper-item>
			</swiper>
			<view class="like_dots">
				<view v-for="(_,index) in topLike" :key="index" class="dot"
					  :class="{'dot_active':index==swiperIndex}"></view>
			</view>

		</view>


		<template v-if="currentDayList && currentDayList.length">
			<comp_title_box action-type="navigator" style="margin-bottom:14px;display:block" :title=" '近期更新' "
							:url="createArticlePageUrl(0,'')"/>
			<template v-for="child in currentDayList" :key="child.wordId">
				<div style="margin-bottom:14px;display:block">
					<comp_article_card :item="child" style=""/>
				</div>
			</template>
		</template>

		<template v-for="item in publicList" :key="item.wordTypeName">
			<comp_title_box action-type="navigator" style="margin-bottom:14px;display:block" :title="item.wordTypeName"
							:url="createArticlePageUrl(item.wordType,item.wordTypeName)"/>
			<template v-for="child in item.currentDayList" :key="child.wordId">
				<div style="margin-bottom:14px;display:block">
					<comp_article_card :item="child" style=""/>
				</div>
			</template>
		</template>

		<template v-if="youLike.youLikeList?.length">
			<comp_title_box
				:title="youLike.youLikeName"
				style="margin-bottom:14px;display:block" actionType="refresh" :func="changeHotSearch"/>
			<div style="margin-bottom:14px;display:block" v-for="item in youLike.youLikeList" :key="item">
				<comp_article_card :item="item"/>
			</div>
		</template>


	</view>
</template>
<script lang="ts" setup>
import comp_title_box from '@/component/titleBox'
import comp_article_card from '@/component/articleCard'
import AcademyApi, {IArticleItem} from "@/api/modules/academy";
import {onMounted, ref} from "vue";
import {IWordItem, IWordListItem, IYouLikeItem} from "@/api/types";
import Taro from "@tarojs/taro";
import imgUrlFormat from "@/utils/imgUtils";

onMounted(() => {
	requestMainData();
})

const publicList = ref<IWordListItem[]>([] as IWordListItem[]);
const currentDayList = ref<IWordItem[]>([] as IWordItem[]);


const likeColor = [
	{color: '#DD3542'}, {color: '#ED8E36'}, {color: '#64A4F5'}
];

const swiperIndex = ref(0);
const swiperIndexChange = (e) => {
	// console.log(e)
	swiperIndex.value = e.detail.current;
}

Taro.showShareMenu({
	withShareTicket: true
})

// top3 top10
let topLike: { title: string; list: IArticleItem[]; cover: string[] }[] = [];
const getTopLike = () => {
	return Promise.all([
		AcademyApi.getArticleList(5, '', 1, 3),
		AcademyApi.getArticleList(6, '', 1, 3)
	]).then(res => {
		topLike = res.map((r, index) => {
			let title = '本周收藏TOP3'
			let wordType = '5'

			if (index === 1) {
				title = '本周分享TOP10'
				wordType = '6'
			}
			return {
				title,
				wordType,
				list: r.data,
				cover: r.data.slice(0, 3).map(item => item.imgUrl)
			};
		})
	})
}

getTopLike();

const youLike = ref<IYouLikeItem>({} as IYouLikeItem);

const requestMainData = () => {
	let response = AcademyApi.getAcademyIndexData();

	response.then((res) => {
		publicList.value = res.data.publicClass.wordLists;
		youLike.value = res.data.youLike;
		currentDayList.value = res.data.currentDayList;
		console.log('youLike', res.data.youLike);
		// res.data.currentDayList  // 近期更新
		// res.data.publicClass.wordLists  包含营养师力荐、健管师力荐、医生力荐
		// res.data.youLike.youLikeList 糖友热搜
	}, (failure) => {
		console.log("academy.js.requestMainData..failure", failure)
	}).catch((error) => {
		console.log("academy.js.requestMainData..error", error);
	})

}

/**
 * 糖友热搜
 * 反馈结构同  {@link requestMainData 接口中糖友热搜}
 */
const changeHotSearch = () => {
	AcademyApi.changeYouLikeList().then((res) => {
		youLike.value.youLikeList = res.data;
	});
	// let response = AcademyApi.changeYouLikeList();
	// if (response) {
	//   response.then((res) => {
	//     console.log("academy.js.changeHotSearch..success", JSON.stringify(res));
	//   }, (failure) => {
	//     console.log("academy.js.changeHotSearch..failure", failure)
	//   }).catch((error) => {
	//     console.log("academy.js.changeHotSearch..error", error);
	//   })
	// }
}

const createArticlePageUrl = (wordType: string | number, title?: string) => {
	return `/pagesAcademy/article/index?wordType=${wordType}&title=${title}`
}

const gotoArticlePage = (item) => {
	console.log(item)
	const wordType = item.wordType;
	let title = '收藏列表'
	if (6 === Number(wordType)) {
		title = '分享列表'
	}
	Taro.navigateTo({
		url: createArticlePageUrl(wordType, title)
	})
}


</script>
<style lang="less">
.container_academy {
	width: 100%;
	height: 100%;
	padding: 27.78px 20.83px;

	.top_box {
		width: 100%;

		display: flex;
		flex-direction: row;
		justify-content: space-between;

		.blood_sugar_left {
			width: 377.78px;
			height: 255.56px;
			background: white;
			padding: 28px 21px;

			display: flex;
			flex-direction: column;
			align-items: flex-start;
			justify-content: flex-start;

			.no_sugar_data {
				font-size: 29.17px;
				color: #5F5F5F;
				font-weight: normal;
				margin-top: 25px;
			}
		}

		.blood_sugar_right {
			height: 255.56px;
			display: flex;
			flex-direction: column;
			justify-content: space-between;
			align-items: center;
		}


		/*血糖分析*/

		.analyse_box {
			width: 309.72px;
			height: 100px;
			background: white;
			padding: 20.83px;
			display: flex;
			justify-content: flex-start;
			align-items: center;
		}

		/*智能设备*/

		.device_box {
			width: 309.72px;
			height: 133.33px;
			background: white;
			padding: 20.83px;

			display: flex;
			justify-content: flex-start;
			align-items: center;
		}

		.image-icon {
			width: 44.44px;
			height: 44.44px;
			margin-right: 11.11px;
		}

		.name {
			font-size: 33.33px;
			font-weight: 600;
		}

		.intro_box {
			.intro {
				display: inline-block;
				border-radius: 52.08px;
				background: #EBF6FF;
				font-size: 22.22px;
				font-weight: normal;
				color: #64A4F5;
				padding: 11.11px 16.67px;
				margin-top: 16.67px;
			}
		}
	}

	.top_like {
		width: 708.33px;
		height: 276.39px;
		border-radius: 16.67px;
		background: white;
		margin-bottom: 28px;

		.top_like_swiper {
			width: 100%;
			height: 232px;
			display: inline-block;
			flex-direction: row;
		}

		.top_like_item {
			width: 708.33px;
			height: 230px !important;

			.type {
				height: 89px;
				font-size: 33.33px;
				font-weight: 600;
				color: #353535;
				margin-left: 20.83px;

				display: flex;
				align-items: center;
			}

			.item_box {
				height: 135px;
				display: flex;
				align-items: center;
				margin-left: 20.83px;


				.left {
					width: 220px;
					min-width: 220px;
					height: 135px;
					border-radius: 8.89px;
					margin-right: 10px;
					position: relative;

					.cover_0 {
						width: 177.78px;
						height: 135px;
						border-radius: 8.89px;
					}

					.cover_1, .cover_2 {
						position: absolute;
						bottom: 0;
					}

					.cover_1 {
						width: 155.56px;
						height: 116.67px;
						border-radius: 7.78px;
						right: 25px;
						z-index: -1;
					}

					.cover_2 {
						width: 133.33px;
						height: 100px;
						border-radius: 6.67px;
						right: 5px;
						z-index: -2;
					}
				}

				.right {
					display: flex;
					justify-content: space-between;
					align-items: center;
					flex-direction: column;

					.title_item {
						width: 465px;
						display: flex;
						align-items: center;

						.index {
							font-size: 29.17px;
							margin-right: 15px;
							font-feature-settings: 'tnum';
							text-align: center;
						}

						.title {
							font-size: 29.17px;
							color: #5F5F5F;
							margin-right: 20.83px;
						}
					}
				}
			}

		}

		.like_dots {
			height: 10px;
			display: flex;
			justify-content: center;
			align-items: center;

			.dot {
				width: 16.67px;
				height: 5.56px;
				border-radius: 5.56px;
				background: #BBBBBB;
				margin-right: 10px;
			}

			.dot_active {
				width: 41.67px;
				background: #64A4F5;
				animation: scale 0.3s;
			}

			@keyframes scale {
				0% {
					width: 5.56px
				}
				100% {
					width: 41.67px;
				}
			}
		}

	}
}

</style>
