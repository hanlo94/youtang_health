export default definePageConfig({
	navigationBarTitleText: "健康学院",
	enableShareAppMessage: true,
	enableShareTimeline: true
});
