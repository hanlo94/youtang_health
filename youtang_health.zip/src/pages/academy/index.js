// const {getAcademyIndexData, changeYouLikeList} = require("../../utils/academy");
// /**
//  * 1、页面说明
//  * 	1.1 除食物速查表-药品库三个入口以外，其余页面元素均为接口动态，应使用模板实现，如近期更新并非两条 而是跟随接口反馈数量显示，如无数据则不显示
//  * 	1.2 模块标题根据接口反馈展示
//  */
//
// Page({
// 	data: {
// 		doGetHotSearch() {
// 			//
// 			console.log('获取热搜')
// 			return new Promise((resolve, reject) => {
// 				setTimeout(() => {
// 					return resolve(true)
// 				}, 3000)
// 			})
// 		}
// 	},
// 	onLoad: function (options) {
// 		this.requestMainData()
// 		this.changeHotSearch()
// 	},
//
// 	/**
// 	 * "data": {
// 	 * 	  // 近期更新
// 	 * 		"currentType": 1,
// 	 * 		"currentNum": 2,
// 	 * 		"currentDayList": [{
// 	 * 				"wordId": 文章ID,
// 	 * 				"wordTitle": 文章标题,
// 	 * 				"imgUrl": 图片地址,
// 	 * 				"wordTime": 文章时间,
// 	 * 				"wordBrowserNum": 浏览量,
// 	 * 				"wordUrl": 详情地址
// 	 * 		}],
// 	 * 		"publicClass": {
// 	 * 			"publicName": "公开课",
// 	 * 			"wordLists": [{
// 	 * 				"wordType": 2,
// 	 * 				"wordTypeName": "营养师力荐",
// 	 * 				"currentDayList": [{}]
// 	 * 			}, {
// 	 * 				"wordType": 3,
// 	 * 				"wordTypeName": "健康管理师力荐",
// 	 * 				"currentDayList": [{}]
// 	 * 			}, {
// 	 * 				"wordType": 4,
// 	 * 				"wordTypeName": "医生力荐",
// 	 * 				"currentDayList": [{}]
// 	 * 			}]
// 	 * 		},
// 	 * 		"youLike": {
// 	 * 			"youLikeName": "糖友热搜",
// 	 * 			"youLikeList": [{
// 	 * 				"wordId": xxx,
// 	 * 				"wordTitle": xxx,
// 	 * 				"imgUrl": xxx,
// 	 * 				"wordTime": xxx,
// 	 * 				"wordBrowserNum": xxx,
// 	 * 				"wordUrl": xxx
// 	 * 			},]
// 	 * 		},
// 	 */
// 	requestMainData() {
// 		let response = getAcademyIndexData();
// 		if (response) {
// 			response.then((res) => {
// 				console.log("academy.js.requestMainData..success", JSON.stringify(res));
// 				// res.data.currentDayList  // 近期更新
// 				// res.data.publicClass.wordLists  包含营养师力荐、健管师力荐、医生力荐
// 				// res.data.youLike.youLikeList 糖友热搜
// 			}, (failure) => {
// 				console.log("academy.js.requestMainData..failure", failure)
// 			}).catch((error) => {
// 				console.log("academy.js.requestMainData..error", error);
// 			})
// 		}
// 	},
//
// 	/**
// 	 * 糖友热搜
// 	 * 反馈结构同	{@link requestMainData 接口中糖友热搜}
// 	 */
// 	changeHotSearch() {
// 		let response = changeYouLikeList();
// 		if (response) {
// 			response.then((res) => {
// 				console.log("academy.js.changeHotSearch..success", JSON.stringify(res));
// 			}, (failure) => {
// 				console.log("academy.js.changeHotSearch..failure", failure)
// 			}).catch((error) => {
// 				console.log("academy.js.changeHotSearch..error", error);
// 			})
// 		}
// 	},
//
// 	onClick() {
// 		wx.navigateTo({
// 			url: '/pages/articleList/articleList',
// 		})
// 	},
//
// });
