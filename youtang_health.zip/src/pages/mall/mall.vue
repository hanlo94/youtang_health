<template>
	<!--  <view class="container_mall">-->
	<!--    <view class="page-body">-->
	<view @click="onClick">
		<image class="scc" src="https://xcx.youtang120.com/shop_bg.png"/>
	</view>
	<!--    </view>-->
	<!--  </view>-->
</template>
<script setup lang="ts">
import Taro from "@tarojs/taro";

const onClick = () => {
	Taro.navigateToMiniProgram({
		appId: 'wx0f46682f8af98432',
		success(res) {
			// 打开成功
			console.log("mall.js.success.", JSON.stringify(res));
		},
		fail(res) {
			console.log("mall.js.fail.", JSON.stringify(res));
		}
	})
}
</script>
<style lang="less">
//.container_mall {
//  display: flex;
//  flex-direction: column;
//  min-height: 100%;
//  justify-content: space-between;
//
//  .page-body {
//    width: 100%;
//    flex-grow: 1;

.scc {
	width: 100%;
	height: 100vh;
}

//  }
//}


</style>
