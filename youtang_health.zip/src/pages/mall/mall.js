// // pages/mall/mall.js
// Page({
//
// 	/**
// 	 * 页面的初始数据
// 	 */
// 	data: {},
//
// 	onClick() {
// 		wx.navigateToMiniProgram({
// 			appId: 'wx0f46682f8af98432',
// 			success(res) {
// 				// 打开成功
// 				console.log("mall.js.success.", JSON.stringify(res));
// 			},
// 			fail(res) {
// 				console.log("mall.js.fail.", JSON.stringify(res));
// 			}
// 		})
// 	},
//
// })
