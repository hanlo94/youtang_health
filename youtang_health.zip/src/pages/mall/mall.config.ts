export default definePageConfig({
    navigationBarTitleText: "值得用",
    componentFramework: "glass-easel",
});
