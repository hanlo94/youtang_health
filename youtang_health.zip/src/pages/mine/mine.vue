<template>
	<view class="mine_root">
		<view class="view_user">
			<img class="img_header" :src="patient.avatar"/>
			<view class="user_info">
				<view class="info_header" @click="onLogin">
					<text>{{ patient.name }}</text>
					<view class="edit" @click.stop="onClickEdit">
						<text>编辑资料</text>
						<RectRight></RectRight>
					</view>
				</view>
				<view class="view_fen" @click="onClickPoint">积分：{{!patient.userPoint || patient.userPoint.trim().length == 0 ? "--" : patient.userPoint}}</view>
			</view>
		</view>
		<img class="img_vip" src="https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/mine/mine_m_bg.png"
			 @click="onClickService"/>
		<view class="view_list">
      <view class="view_item" @click="onClickRecord">
        <view style="display: flex;align-items: center">
          <img src="https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/mine/dossier.png"/>
          <text>健康档案</text>
        </view>
        <RectRight></RectRight>
      </view>
			<view class="view_item" @click="onClickReport">
				<view style="display: flex;align-items: center">
					<img src="https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/mine/report.png"/>
					<text>健康评估</text>
				</view>
				<RectRight></RectRight>
			</view>
			<view class="view_item" @click="onClickDevice">
				<view style="display: flex;align-items: center">
					<img src="https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/mine/device.png"/>
					<text>智能设备</text>
				</view>
				<RectRight></RectRight>
			</view>
			<view class="view_item" @click="onClickNotice">
				<view style="display: flex;align-items: center">
					<img src="https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/mine/notice.png"/>
					<text>消息中心</text>
				</view>
				<RectRight></RectRight>
			</view>

			<view class="view_item" @click="onClickUserInfo">
				<view style="display: flex;align-items: center">
					 <IconFont name="my" class="icons nut-icon-am-infinite"></IconFont>
					<text>账户信息</text>
				</view>
				<RectRight></RectRight>
			</view>

			<view class="view_item" @click="onClickSetting">
				<view style="display: flex;align-items: center">
					<img src="https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/mine/setting.png"/>
					<text>系统设置</text>
				</view>
				<RectRight></RectRight>
			</view>
		</view>
	</view>
</template>

<script setup lang="ts">
import Taro, {useDidShow} from "@tarojs/taro";
import {RectRight} from '@nutui/icons-vue-taro';
import PageNavigation from "@/utils/pageNavigation";
import {onMounted, ref} from "vue";
import MineApi, {PatientBaseInfo} from "@/pagesMine/api/mine";
import StoreUtils from "@/utils/storeUtils";
import { IconFont } from '@nutui/icons-vue-taro';

const patient = ref<PatientBaseInfo>({
	avatar: "https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/common/logo.png",
	name: "登录/注册",
	userPoint: "--"
} as PatientBaseInfo)


let patientId = StoreUtils.readPatientId()

onMounted(() => {
	getPatientInfo()
})

Taro.eventCenter.on('login', (item) => {
	console.log("mine.vue..login.",);
	patientId = StoreUtils.readPatientId()
	getPatientInfo()
})

Taro.eventCenter.once('loginonce', (item) => {
	console.log("mine.vue..loginonce.",);
	patientId = StoreUtils.readPatientId()
	getPatientInfo()
})

const getPatientInfo=()=>{
	if (patientId) {
		MineApi.getPatientInfo().then(res => {
			console.log("mine.vue.getPatientInfo.", JSON.stringify(res.data));
			if (!res.data.avatar || res.data.avatar.trim().length == 0) {
				res.data.avatar = patient.value.avatar
			}
			if (!res.data.name || res.data.name.trim().length == 0) {
				res.data.name = '匿名用户'
			}
			if (res.data.userPoint){
				res.data.userPoint+=""
			}
			patient.value = res.data
			console.log("mine.vue.getPatientInfo.", JSON.stringify(patient.value));
		})
	}
}

useDidShow(() => {
	if (!patientId) {
		patientId = StoreUtils.readPatientId()
	}else{
		getPatientInfo()
	}
})

const onLogin=()=>{
	if (!patientId) {
		PageNavigation.navigationToLogin()
	}else{
		onClickEdit()
	}
}

/**
 * 点击编辑
 */
const onClickEdit = () => {
	Taro.navigateTo({
		url: '/pagesMine/edit/index',
		events: {
			// 为指定事件添加一个监听器，获取被打开页面传送到当前页面的数据
			minePage: function(data) {
				if (data){
					getPatientInfo()
				}
			},
		},
	})
}

const onClickPoint = () => {
  Taro.navigateTo({
    url: '/pagesMine/points/index'
  })
}

const onClickService = () => {
	PageNavigation.navigationToWebView(process.env.SERVICE_PACK)
}


/**
 * 健康档案
 */
const onClickRecord = () => {
  Taro.navigateTo({
    url: '/pagesActive/index/index'
  })
}
/**
 * 点击健康评估
 */
const onClickReport = () => {
	Taro.navigateTo({
		url: '/pagesMine/report/index'
	})
}


/**
 * 点击智能设备
 */
const onClickDevice = () => {
	Taro.navigateTo({
		url: '/pagesMine/device/device'
	})
}

/**
 * 点击账户信息
 */
const onClickUserInfo = () => {
	Taro.navigateTo({
		url: '/pagesMine/userInfo/index'
	})
}

/**
 * 点击消息中心
 */
const onClickNotice = () => {
	Taro.navigateTo({
		url: '/pagesMine/message/index'
	})
}


/**
 * 点击系统设置
 */
const onClickSetting = () => {
	Taro.navigateTo({
		url: '/pagesMine/setting/index'
	})
}


</script>
<style lang="less">

.mine_root {
	display: flex;
	flex-direction: column;

	.view_user {
		display: flex;
		background: white;
		border-radius: 30px;
		margin: 30px;
		padding: 30px;
		align-items: center;

		.img_header {
			border: #6aa4fc solid 1px;
			width: 164px;
			border-radius: 80px;
			height: 164px;
		}

		.user_info {
			display: flex;
			height: 150px;
			justify-content: space-between;
			margin-left: 20px;
			flex-direction: column;

			.info_header {
				display: flex;
				width: 450px;
				align-items: center;
				justify-content: space-between;

				.edit {
					display: flex;
					align-items: center;
					color: #666666;
					font-size: 25px;
				}
			}

			.view_fen {
				background: #EBF6FF;
				height: 50px;
				font-size: 25px;
				line-height: 50px;
				display: inline-block;
				min-width:130px;
				padding-left: 10px;
				padding-right: 10px;
				align-self: start;
				text-align: start;
				color: #6aa4fc;
				border-radius: 30px;
			}
		}
	}

	.img_vip {
		margin: 0 auto;
		width: 690px;
		height: 140px;
	}

	.view_list {
		border-radius: 30px;
		background: white;
		margin: 30px;
		padding: 0 20px;

		.view_item {
			display: flex;
			flex-direction: row;
			padding: 30px 20px;
			border-bottom: #efefef solid 1px;
			align-items: center;
			justify-content: space-between;
			.icons{
				font-size: 44px;
				margin-right: 20px ;
			}
			img {
				width: 44px;
				margin-right: 20px;
				height: 44px;
			}

		}

	}
}
</style>
