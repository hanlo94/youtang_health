<template>
  <view class="container_drugstorage">
    <!--pages/drugstorage/drugstorage.wxml-->
    <text>pages/drugstorage/drugstorage.wxml</text>
  </view>
</template>
<script setup lang="ts">
import CommonApi from "@/api/modules/common";
import AcademyApi from "@/api/modules/academy";

const drugCategory = [
  {
    "value": "降糖药",
    "key": 1,
  },
  {
    "value": "降压药",
    "key": 2,
  }, {
    "value": "调脂药",
    "key": 3,
  }]

const getDrugCategory = () => {
  let response = CommonApi.getDictionList(6);
  response.then((res) => {
    // 显示接口数据
    console.log("drugstorage.js.getDrugCategory..success", JSON.stringify(res));
  }, (failure) => {
    // 请求失败 显示默认数据
    console.log("drugstorage.js.getDrugCategory..failure", failure)
  }).catch((error) => {
    // 加载异常  显示默认数据
    console.log("drugstorage.js.getDrugCategory..error", error);
  }).finally(() => {
    requestDrugList(drugCategory[0].key, 1)
  })
}

const requestDrugList = (category, page) => {
  let response = AcademyApi.getDrugList(category, page);

  response.then((res) => {
    // res.drugDetailUrl 详情地址，待拼接药品ID
    // res.recordList 药品列表

    console.log("drugstorage.js.requestDrugList..success", JSON.stringify(res));
  }, (failure) => {
    console.log("drugstorage.js.requestDrugList..failure", failure)
  }).catch((error) => {
    console.log("drugstorage.js.requestDrugList..error", error);
  })

}

// getDrugCategory();
</script>
<style lang="less">
.container_drugstorage {
}
</style>
