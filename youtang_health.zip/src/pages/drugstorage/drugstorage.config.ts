export default definePageConfig({
    navigationBarTitleText: "药品库",
});
