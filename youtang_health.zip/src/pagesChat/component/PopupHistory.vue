<template>
  <view class="history-popup">
  <nut-popup
    v-model:visible="visible"
    position="left"
    round
    close-on-click-overlay
    @close="handleClose"
    :style="{ width: '80%' }"
  >
  <scroll-view
    class="hide-scrollbar"
    style="height: 99.9vh"
    :scrollY="true"
    :show-scrollbar="false"
    :scroll-top="scrollTop"
    @scrolltolower="fetchHistoryData"
  >
    <view class="popup-content">
      <view v-if="loading" class="loading">加载中...</view>
      <view v-else-if="error" class="error">加载失败: {{ error }}</view>
      <template v-else>
        <view 
          v-for="group in historyData" 
          :key="group.title"
          class="history-group"
        >
          <view class="group-title" v-if="group.list && group.list.length > 0">{{ group.title }}</view>
          <view class="group-list">
            <view 
              v-for="item in group.list"
              :key="item.dataId"
              class="history-item"
              @click="handleItemClick(item.conversationId)"
               @longpress.stop="handleLongPress(item.conversationId)"
            >
              <view class="content-wrapper">
                <!-- 消息内容 -->
                <view class="message-content">
                  <view v-if="Array.isArray(item.msgContent)">
                    <view class="image-container">
                        <view v-for="(content, index) in item.msgContent" :key="index" class="content-item">
                          <image 
                            v-if="content.type === 'image'"
                            :src="content.file_url"
                            mode='aspectFill'
                            class="content-image"
                          />
                        </view>
                    </view>
                    
                    <text class="text-only" v-if="getLastText(item.msgContent)">
                      {{ getLastText(item.msgContent) }}
                    </text>
                  </view>
                  <text v-else class="text-only">{{ item.msgContent }}</text>
                </view>
              </view>
            </view>
          </view>
        </view>
      </template>
    </view>
  </scroll-view>  
  </nut-popup>

  <nut-popup
    :style="{ borderTopLeftRadius: '20px', borderTopRightRadius: '20px' }"
    v-model:visible="visibleDel"
    position="bottom"
  >
  <view class="action-content">
      <view
        class="action-item action-item-border"
        @click="handleAction"
      >
        删除会话
      </view>
      <view class="action-item" @click="close"> 取消 </view>
    </view>  
  </nut-popup>
</view>
</template>

<script setup lang="ts">
import { ref, computed, onMounted} from 'vue'
import { showToast } from '@tarojs/taro'
import { getHistory, chatclearMsg  } from "@/api/modules/chat";
import StoreUtils from "@/utils/storeUtils";

const props = defineProps<{
  visible: boolean
}>()

const emit = defineEmits<{
  (e: 'update:visible', value: boolean): void
  (e: 'item-click', id: string): void
}>()

// 响应式数据
const visible = computed({
  get: () => props.visible,
  set: (value) => emit('update:visible', value)
})

const historyData = ref<any[]>([])
const loading = ref(false)
const error = ref<string | null>(null)

const scrollTop = ref(0)
const hasMore = ref(true)
const lastDataId = ref<string | null>(null)
const loadingMore = ref(false)
const visibleDel = ref(false)
const conversationId = ref<string | null>(null)

// 监听 visible 变化发起请求
// watch(() => props.visible, async (newVal) => {
//   if (newVal) {
//     await fetchHistoryData()
//   }
// })

onMounted(() => {
  fetchHistoryData()
})

const getLastText = (content: any) => {
  if (!Array.isArray(content)) return content || ''
  const texts = content.filter(item => item.type === 'text')
  return texts.length > 0 ? texts[texts.length - 1].text : ''
}

const handleAction = async() => {
  visibleDel.value = false
  historyData.value = historyData.value.map(section => ({
    ...section,
    list: section.list.filter(item => item.conversationId !==  conversationId.value)
  }));
  console.log(conversationId.value, StoreUtils.readPatientId(), '---------------------')
  await chatclearMsg({ userId: StoreUtils.readPatientId(), conversationId: conversationId.value })
}

const handleLongPress = (id: string) => {

  visibleDel.value = true 
  conversationId.value = id
}

const close = () => {
  visibleDel.value = false
}

// 获取历史数据
const fetchHistoryData = async () => {
  if (!hasMore.value || loadingMore.value) return
 
  try {
    loading.value = true
    error.value = null
    loadingMore.value = true
    const startId = getLastDataId()
    const res:any = await getHistory({startId, pageSize: 15});
    const { code, data } = res;  
    if(code !== 10000) {
      return;
    }
    historyData.value = mergeData(transformData(data))
    lastDataId.value = getLastDataId()
    loadingMore.value = false
    hasMore.value = res.data.length >= 15  
    console.log( hasMore.value, res.data.length,  res.data.length >= 15  )
    if (data.length === 0) {
      hasMore.value = false
      return
    }
  } catch (err) {
    error.value = '数据加载失败'
    showToast({
      title: '加载失败',
      icon: 'none'
    })
  } finally {
    loading.value = false
  }
}

// 合并新旧数据
const mergeData = (newData: any[]) => {
  const mergedData = [...historyData.value]
  
  newData.forEach(newGroup => {
    const existingGroup = mergedData.find(g => g.title === newGroup.title)
    if (existingGroup) {
      existingGroup.list = [...existingGroup.list, ...newGroup.list]
    } else {
      mergedData.push(newGroup)
    }
  })
  
  return mergedData
}

// 获取最后一个dataId
const getLastDataId = () => {
  if (historyData.value.length === 0) return null
  const lastGroup = historyData.value[historyData.value.length - 1]
  if (lastGroup.list.length === 0) return null
  return lastGroup.list[lastGroup.list.length - 1].dataId
}


const isArrayString = (str) => {
  try {
    const parsed = JSON.parse(str);
    return Array.isArray(parsed);
  } catch (e) {
    return false;
  }
}

const transformData = (inputData) => {
  const groups = {};

  // 按 title 分组并转换结构
  inputData.forEach((item) => {
    const title = item.title;
    if (!groups[title]) {
      groups[title] = [];
    }

    if(isArrayString(item.msgContent)) {
      item.msgContent = JSON.parse(item.msgContent);
    }

    groups[title].push({
      dataId: item.dataId, 
      msgContent: item.msgContent,
      conversationId: item.conversationId,
      conversationTime: item.conversationTime.replace(/\.0$/, ""), // 去掉末尾的 .0
      msgId: item.msgId
    });
  });

  // 转换为目标格式
  return Object.keys(groups).map((title) => ({
    title: title,
    list: groups[title]
  }));
}
const handleClose = () => {
  visible.value = false
}

const handleItemClick = (id: string) => {
  emit('item-click', id)
  visible.value = false
}
</script>

<style lang="scss">
.history-popup{
  .action-item  {
    font-size: 36px;
    padding: 34px;
  }
  .action-item-border{
    border-bottom:10px solid #CECECE80 ;
  }
  .hide-scrollbar {
    ::-webkit-scrollbar {
      width: 0 !important; /* 隐藏滚动条滑块 */
      height: 0 !important;
      display: none !important; /* 隐藏滚动条 */
    }
    scrollbar-width: none; /* Firefox */
    -ms-overflow-style: none; /* IE 和 Edge */
  }
.popup-content {
  padding: 20px;
  height: 100vh;
  overflow-y: auto;
  text-align: left;
  font-size: 32px;
  
  .loading, .error {
    text-align: center;
    padding: 20px;
    color: #666;
  }

  .history-group {
    margin-bottom: 20px;
    .group-title {
      font-weight: bold;
      color: #A1A1A1;
      padding-top: 16px;
    }
  }

  .history-item {
    padding-top: 20px ;
    &:active {
      color:#3369FF;
    }

    .content-wrapper {
      .time {
        font-size: 12px;
        color: #999;
        margin-bottom: 4px;
      }

      .message-content {
        .image-container{
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
        }
        .content-item {
          margin: 4px 0;
          .content-image {
            width: 120px;
            height: 120px;
            border-radius: 8px;
          }

          .content-text {
            // font-size: 28px;
            line-height: 1.5;
          }
        }

        .text-only {
          display: block;
          width: 550px;
          // font-size: 28px;
          line-height: 1.5;
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
        }
      }
    }
  }
}
}
</style>