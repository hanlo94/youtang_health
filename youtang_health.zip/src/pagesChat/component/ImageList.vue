<template>
  <scroll-view
    class="image-scroll"
    :scroll-x="true"
    :scroll-left="scrollLeft"
    scroll-with-animation
    enable-flex
  >
    <view class="list-container">
      <!-- 图片项 -->
      <view
        v-for="(item, index) in files"
        :key="item.url + index"
        class="image-item"
      >
        <!-- 图片预览 -->
         <view  @click.stop="handlePreview(index)" class="preview-image-wrapper">
        <image
          :src="item.url"
          mode="aspectFill"
          class="preview-image"
        />
        </view>

        <!-- 删除按钮 -->
        <view class="delete-btn" @click.stop="handleDelete(index)">
            <IconFont name="circle-close" color="#fff" class=" nut-icon-am-infinite"></IconFont>
        </view>

        <!-- 上传状态 -->
        <view v-if="item.status !== 'done'" class="status-mask">
          <IconFont  v-if="item.status === 'uploading'" name="loading1" color="#fff" class="nut-icon-am-rotate nut-icon-am-infinite"></IconFont>
          <view
            v-if="item.status === 'error'"
            class="error-status"
            @click="$emit('retryImage', item, index)"
          >
            重试
          </view>
        </view>
      </view>
    </view>
  </scroll-view>
</template>

<script setup lang="ts">
import { ref, watch, nextTick } from "vue";
import type { PropType } from "vue";
import Taro from "@tarojs/taro";
import { IconFont } from "@nutui/icons-vue-taro";

interface ImageFile {
  url: string;
  status: "pending" | "uploading" | "done" | "error";
  progress: number;
}



const props = defineProps({
  files: {
    type: Array as PropType<ImageFile[]>,
    required: true,
  },
  // maxCount: {
  //   type: Number,
  //   default: 9
  // }
});

const emit = defineEmits(["deleteFiles", "retryImage"]);
const scrollLeft = ref(0);

// 处理删除操作
const handleDelete = (index: number) => {
  emit("deleteFiles", index);
  // Taro.showModal({
  //   title: '删除确认',
  //   content: '确定删除这张图片吗？',
  //   success(res) {
  //     if (res.confirm) {

  //     }
  //   }
  // })
};

const handlePreview = (index: number) => {
 console.log("handlePreview.index=",index, props.files)  
 const  url = props.files[index].url  
  Taro.previewImage({
    current: url,
    urls: [url],
    enablesavephoto: true,
    enableShowPhotoDownload: true,
  });
};

// 自动滚动到最右侧
  watch(() => props.files.length, (newVal, oldVal) => {
    if (newVal > oldVal) {
      nextTick(() => {
        scrollLeft.value += 1000 // 设置足够大的值确保滚动到最右
      })
    }
  })
</script>

<style lang="scss">
.image-scroll {
  width: 600px;
  white-space: nowrap;
  padding: 12px 20px 24px;

  .list-container {
    display: flex;
    gap: 12px;
  }

  .upload-card,
  .image-item {
    position: relative;
    width: 120px;
    height: 120px;
    flex-shrink: 0;
    border-radius: 14px;
    overflow: hidden;
    background: #f5f5f5;
  }
  .preview-image-wrapper{
    width: 100%;
    height: 100%;
  }

  .upload-card {
    border: 2px dashed #ebedf0;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;

    .item-count {
      margin-top: 8px;
      font-size: 12px;
      color: #999;
    }
  }

  .image-item {
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);

    .preview-image {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .delete-btn {
      position: absolute;
      top: 8px;
      right: 8px;
      width: 28px;
      height: 28px;
      border-radius: 50%;
      background: rgba(0, 0, 0, 0.6);
      display: flex;
      align-items: center;
      justify-content: center;
      backdrop-filter: blur(4px);
    }

    .status-mask {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.6);
      display: flex;
      align-items: center;
      justify-content: center;

      .progress {
        width: 60px !important;
        height: 60px !important;
      }

      .error-status {
        padding: 6px 12px;
        background: rgba(255, 255, 255, 0.9);
        border-radius: 16px;
        color: #f56c6c;
        font-size: 14px;
      }
    }
  }
}
</style>
