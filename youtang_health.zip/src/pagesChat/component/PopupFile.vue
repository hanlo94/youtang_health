<template>
  <nut-popup
    :visible="modelValue"
    position="bottom"
    round
    :overlay-style="overlayStyle"
    @click-overlay="close"
    @update:visible="handleVisibilityChange"
  >
    <view class="action-sheet">
      <view class="overlay-mask" @touchmove.prevent></view>

      <view class="action-content">
        <view
          v-for="(item, index) in actions"
          :key="index"
          class="action-item action-item-border"
          hover-class="action-item-active"
          @click="handleAction(item)"
        >
          {{ item.name }}
        </view>

        <!-- <view class="divider"></view> -->

        <view class="cancel-btn" @click="close"> 取消 </view>
      </view>
    </view>
  </nut-popup>
</template>

<script setup lang="ts">
import { withDefaults, computed } from "vue";

type ActionType = "camera" | "album" | "cancel";

interface ActionItem {
  name: string;
  type: ActionType;
}

const props = withDefaults(
  defineProps<{
    modelValue: boolean;
    actions?: ActionItem[];
  }>(),
  {
    actions: () => [
      { name: "拍照", type: "camera" },
      { name: "本地相册", type: "album" },
    ],
  }
);

const emit = defineEmits<{
  (e: "update:modelValue", value: boolean): void;
  (e: "select", type: ActionType): void;
}>();

const overlayStyle = computed(() => ({
  background: "rgba(0,0,0,0.6)",
  transition: "opacity 0.3s",
}));

const handleAction = (item: ActionItem) => {
  emit("select", item.type);
  close();
};

const close = () => {
  emit("update:modelValue", false);
};

const handleVisibilityChange = (visible: boolean) => {
  emit("update:modelValue", visible);
};
</script>

<style lang="scss">
.action-sheet {
  position: relative;
  background: #fff;

  .overlay-mask {
    position: absolute;
    top: -30%;
    left: 0;
    right: 0;
    height: 130%;
    // background: linear-gradient(
    //   to top,
    //   rgba(0, 0, 0, 0.5) 0%,
    //   rgba(0, 0, 0, 0.3) 50%,
    //   transparent 100%
    // );
    backdrop-filter: blur(4px);
  }

  .action-content {
    position: relative;
    z-index: 1;
    padding: 16px;
    background: rgba(255, 255, 255, 0.95);
    border-radius: 24px 24px 0 0;
  }
  .action-item-border {
    border-bottom: 1px solid rgba(0, 0, 0, 0.1);
  }
  .action-item {
    padding: 18px 0;
    margin: 8px 0;
    background: rgba(255, 255, 255, 0.9);
    text-align: center;
    font-size: 32px;
    color: #333;
    transition: all 0.2s ease;

    &-active {
      background: #f0f0f0 !important;
      transform: scale(0.98);
    }
  }
  .cancel-btn {
    padding: 16px 0;
    color: #666;
    margin-top: 12px;
  }

  .divider {
    height: 1px;
    background: rgba(0, 0, 0, 0.1);
    margin: 16px 0;
  }
}
</style>
