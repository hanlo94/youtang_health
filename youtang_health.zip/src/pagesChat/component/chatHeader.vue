<template>
  <view class="chat-header-container">
    <view class="header">
      <view class="chat-icon">
        <!-- <image :src="imgUrlFormat('ai/chat_logo2.png')" mode="widthFix" alt="" /> -->
        <image :src="questionData.icon_url" mode="widthFix" />
      </view>
      <view class="title">{{ questionData.name }}</view>
      <view class="subtitle">
        <view class="subtitle-text">{{ questionData.description }}</view>
      </view>
    </view>

    <view v-if="questionData.questions && questionData.questions.length > 0">
      <view
        v-for="(question, index) in questionData.questions"
        :key="index"
        class="question-item"
        @click="handleQuestionClick(question)"
      >
        {{ question }}
      </view>
    </view>
  </view>
</template>

<script setup lang="ts">
interface questionData {
  name: string;
  icon_url: string;
  description: string;
  questions: string[];
}

const props = defineProps<{
  questionData: questionData;
  handleQuestionClick: (question: string) => void;
}>();
</script>

<style lang="less">
.chat-header-container {
  padding: 20px;
  .header {
    .chat-icon {
      image {
        width: 72px;
        height: 72px;
      }
    }
    .title {
      font-size: 32px;
      font-weight: bold;
      padding: 6px 0 20px;
    }
    .subtitle {
      display: flex;
      justify-content: center;
      margin-bottom: 32px;
      .subtitle-text {
        width: 79%;
      }
    }
  }

  .question-item {
    padding: 20px 0;
    margin-bottom: 16px;
    margin: 0px 20px 16px 20px;
    cursor: pointer;
    background-color: #f8f8f8;
    border-radius: 30px;
  }
}
</style>
