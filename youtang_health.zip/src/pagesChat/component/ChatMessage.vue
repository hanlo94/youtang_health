<template>
  <view class="chat-content">
    <scroll-view
      class="hide-scrollbar"
      style="height: 98vh"
      :scroll-top="scrollTop"
      @scrolltoupper="upper"
      @scrollToLower="handleToLower"
      :scrollY="true"
      @scroll="handleScroll"
      :show-scrollbar="false"
    >
      <!-- <view v-if="isLoading">
        <IconFont
          name="loading"
          color="#8A8484"
          class="nut-icon-am-rotate nut-icon-am-infinite"
        ></IconFont
      ></view> -->
      <!-- style="position: reactive" -->
      <view
        v-for="msg in messages"
        :key="msg.id"
        class="chat-message"
        :style="popStyle.chatMessageStyle"
      >
        <view class="user-style" v-if="msg.role === 'assistant'">
          <view class="def">
            <view style="display: flex">
              <image :src="stateObj.icon_url"></image>
            </view>
            <text>{{ stateObj.name }}</text>
          </view>

          <view
            class="content-msg-loading"
            v-if="!msg.loadFlag && !msg.topAnswerFlag"
          >
            <IconFont
              name="loading"
              color="#8A8484"
              class="nut-icon-am-rotate nut-icon-am-infinite"
            ></IconFont>
            <view> 努力加载中...</view>
          </view>
          <nut-popover
            custom-class="pop-content"
            v-model:visible="messagePop.visible[msg.id]"
            location="top"
            theme="dark"
            :list="messagePop.popList"
            @choose="(item) => handlePopoverClick(item, msg, '')"
            v-if="msg.content !== ''"
          >
            <template #reference>
              <view
                class="content-msg"
                @longpress.stop="handleLongPress(msg.content, msg.id)"
                @click="handleClick($event, msg.id)"
              >
                <rich-text
                  selectable="true"
                  class="rich-text"
                  :nodes="msg.content"
                />
                <!-- 添加复制图标和点赞图标 -->
                <view v-if="msg.iconFlag" class="icons">
                  <view
                    @click.stop="
                      handlePopoverClick({ name: '复制' }, msg, 'icon')
                    "
                  >
                    <image
                      :src="
                        imgUrlFormat(
                          messagePop.isCoypIcon[msg.id]
                            ? 'ai/copy_light.png'
                            : 'ai/copy.png'
                        )
                      "
                      mode="widthFix"
                    />
                  </view>

                  <view class="icon-copy" @click.stop="handleLike(msg)">
                    <image
                      :src="
                        imgUrlFormat(
                          msg.isLike === 1 ? 'ai/like_fill.png' : 'ai/like.png'
                        )
                      "
                      mode="widthFix"
                    />
                  </view>
                </view>
              </view>
            </template>
          </nut-popover>
        </view>
        <view class="assistant-style" v-if="msg.role === 'user'">
          <nut-popover
            custom-class="pop-content-user"
            v-model:visible="messagePop.visible[msg.id]"
            location="top"
            theme="dark"
            :list="messagePop.popList"
            @choose="(item) => handlePopoverClick(item, msg, '')"
          >
            <template #reference>
              <view class="question-content">
                <view
                  v-if="msg.content !== ''"
                  @longpress.stop="handleLongPress(msg.content, msg.id)"
                  @click="handleClick($event, msg.id)"
                  class="question-style"
                >
                  {{ msg.content }}
                </view>

                <!-- <view>
                  <view class="image-box"  @click.stop="handlePreview(item)"  v-for="(item, index) in msg?.images" :key="index"  >
                    <image
                      v-if="item"
                      :src="item"
                      mode="aspectFill"
                      class="preview-image"
                    />
                  </view>
              </view> -->
                <view
                  class="image-container"
                  :class="msg.images?.length === 1 && 'single-mode'"
                >
                  <view
                    v-for="(item, index) in msg.images"
                    :key="index"
                    class="image-box"
                    @click.stop="handlePreview(item)"
                  >
                    <image
                      :src="item"
                      :mode="
                        msg?.images?.length === 1 ? 'widthFix' : 'aspectFill'
                      "
                      class="preview-image"
                    />
                  </view>
                </view>
              </view>
            </template>
          </nut-popover>
        </view>
      </view>
      <view style="padding-bottom: 144rpx"></view>
    </scroll-view>
    <view
      class="scroll-to-bottom"
      v-if="showArrow"
      @click.stop="scrollToBottom"
      :style="{ bottom: textareaAHeight + 54 + 'px' }"
    >
      <image :src="imgUrlFormat('ai/chat_down.png')" mode="widthFix" />
    </view>
  </view>
</template>

<script setup lang="ts">
import {
  defineProps,
  ref,
  reactive,
  onMounted,
  watch,
  nextTick,
  defineExpose,
} from "vue";
import Taro from "@tarojs/taro";
import imgUrlFormat from "@/utils/imgUtils";
import { IconFont } from "@nutui/icons-vue-taro";
import { throttle } from "lodash";
import { parseMarkdown } from "@/utils/chatUtils";
//markdown格式转换，目前样式不生效，主要是小程序标签只有view text标签导致
import { toggleLike } from "@/api/modules/chat";
interface ChatMessage {
  id: string | number;
  role: "user" | "assistant";
  content: string;
  loadFlag?: boolean;
  iconFlag?: boolean; //当回答完毕后才显示复制点赞图标
  topAnswerFlag?: boolean;
  isLike: number; //1 点赞 2 未点赞
  images?: string[];
  parsed?: boolean;
}
interface Props {
  messages: ChatMessage[];
  stateObj: {
    isRefreshing: boolean;
    hasMore: boolean;
    name: string;
    icon_url: string;
  };
  scrollTops: number;
  conversationId: string;
  textareaAHeight: number;
}

const messagePop = reactive<{
  popList: { name: string }[]; // popover 的选项列表
  visible: Record<string | number, boolean>; // 每个消息的 popover 显示状态
  currentContent: string; // 当前需要复制的消息内容
  position: { top: number; left: number };
  currentId: string | number;
  isCoypIcon: Record<string | number, boolean>;
  // isCopy: string | null;
}>({
  popList: [{ name: "复制" }], // 复制选项
  visible: {}, // 初始化为空对象
  currentContent: "", // 初始化为空
  position: { top: 0, left: 0 },
  currentId: "",
  isCoypIcon: {},
  // isCopy: "",
});

const popStyle = reactive<{
  chatMessageStyle: Record<string, string>;
}>({
  chatMessageStyle: {}, // 默认空对象
});

const props = withDefaults(defineProps<Props>(), {
  messages: () => [],
  scrollTops: 10000,
  isRefreshing: false,
  conversationId: "",
  textareaAHeight: 0,
});

const emit = defineEmits<{
  (evnet: "updateConut", isLoading: boolean): void;
}>();

const showArrow = ref<boolean>(false);
const scrollTop = ref(999999); // 控制 scroll-top
const scrollScreenHeight = ref(0);
const isLoading = ref<boolean>(false);

const scrollCounter = ref(0);

// watch(
//   () => props.scrollTops,
//   () => {
//     scrollToBottom();
//   }
// );

// watch(
//   () => props.stateObj,
//   () => {
//     isLoading.value = props.stateObj.isRefreshing;
//   }
// );

onMounted(() => {
  Taro?.getSystemInfo({
    success: (res) => {
      console.log("获取系统信息成功:", res.screenHeight);
      scrollScreenHeight.value = res.screenHeight;
    },
    fail: (err) => {
      console.error("获取系统信息失败:", err);
    },
  });
});

const handleClick = (event: Event, id: string | number) => {
  event.stopPropagation(); // 阻止事件冒泡
  messagePop.visible[id] = false; // 确保弹窗不显示
};
const handlePopoverClick = (item: { name: string }, msg: any, type: string) => {
  const { content, id } = msg;
  // if (messagePop.isCopy === id) {
  //   return;
  // }
  // messagePop.isCopy = id;
  if (item.name === "复制") {
    Taro.setClipboardData({
      data: content, // 复制当前消息的内容
      success: () => {
        // Taro.showToast({
        //   title: "已复制",
        //   icon: "success",
        // });
      },
    });
  }
  messagePop.visible = {};
  if (type === "icon") {
    messagePop.isCoypIcon[id] = true;
    setTimeout(() => {
      messagePop.isCoypIcon[id] = false;
    }, 400);
  }
};

const handleLike = async ({ id, isLike }) => {
  // 更新点赞状态
  const msg: any = props.messages.find((m) => m.id === id);
  if (isLike === 2) {
    msg.isLike = 1;
  } else {
    msg.isLike = 2;
  }

  await toggleLike({
    msgId: id,
    isLike: msg.isLike,
    conversationId: props.conversationId,
  });
};

const handleLongPress = (content: string, id: string | number) => {
  messagePop.currentContent = content;
  messagePop.visible[id] = true;
  // 动态添加样式，处理内容超出屏幕pop不能跟随问题
  popStyle.chatMessageStyle = { position: "relative" };
};

const handleScroll = throttle((e) => {
  const { scrollHeight, scrollTop: currentScrollTop } = e.detail;
  const top = scrollHeight - scrollScreenHeight.value - 500;
  if (currentScrollTop < top) {
    if (!showArrow.value) {
      showArrow.value = true; // 如果还没滚动到底部，显示按钮
      scrollTop.value = currentScrollTop;
    }
  }
  // if(isAtBottom) {
  //   showArrow.value = false;
  // }
}, 200);

const scrollToBottom = async () => {
  scrollCounter.value += 1;
  scrollTop.value = scrollCounter.value * 10000 + +Math.random();

  // 延时隐藏按钮、导致频繁触发handlescroll、导致页面不停的抖动
  let timer = setTimeout(() => {
      clearTimeout(timer);
      showArrow.value = false;
    }, 1000);
};

const handleToLower = () => {
  if (showArrow.value) {
    showArrow.value = false;
    scrollTop.value = Math.floor(Math.random() * 100000) + 1;
  }
};
export interface ChildExpose {
  scrollToBottom: () => void;
}
// 暴露方法给父组件
defineExpose<ChildExpose>({ scrollToBottom });

const upper = (e) => {
  isLoading.value = true;
  emit("updateConut", isLoading.value);
};

const handlePreview = (url: string) => {
  console.log("handlePreview.url=", url);
  Taro.previewImage({
    current: url,
    urls: [url],
    enablesavephoto: true,
    enableShowPhotoDownload: true,
  });
};
</script>

<style lang="less">
.chat-content {
  .chat-message {
    padding-bottom: 20px;
    .pop-content {
      position: absolute;
      top: 0 !important;
    }
    .pop-content-user {
      position: absolute;
      top: -90px !important;
    }
    .icons {
      display: flex;
      align-items: center;
      margin-top: 14px;
      view {
        display: flex;
        padding: 10px;
        background-color: rgba(51, 105, 255, 0.1);
        border-radius: 10px;
      }
      image {
        width: 40px;
        height: 40px;
      }
      .icon-copy {
        margin-left: 14px;
      }
    }
  }
  // height: 100vh;
  .hide-scrollbar {
    ::-webkit-scrollbar {
      width: 0 !important; /* 隐藏滚动条滑块 */
      height: 0 !important;
      display: none !important; /* 隐藏滚动条 */
    }
    scrollbar-width: none; /* Firefox */
    -ms-overflow-style: none; /* IE 和 Edge */
  }
  padding: 20px 30px 0 30px;
  background: #fff;
  font-size: 30px;
  .user-style {
    text-align: left;
    .def {
      display: flex;
      align-items: center;
      margin-bottom: 20px;
      image {
        margin-right: 12px;
        width: 48px;
        height: 48px;
        border-radius: 50%;
      }
    }

    .content-msg {
      // width: 600px;
      padding: 20px;
      background: #f8f8f8;
      border-radius: 50px;
    }
    .content-msg-loading {
      display: flex;
      align-items: center;
      width: 250px;
      padding: 20px;
      background: #f8f8f8;
      border-radius: 50px 50px 50px 0;
      font-size: 28px;
    }
  }
  .assistant-style {
    display: flex;
    justify-content: flex-end;
    text-align: left;
    // margin: 32px 0;
    color: #fff;

    .question-content {
      display: flex;
      flex-direction: column;
      align-items: flex-end;
    }
    .question-style {
      max-width: 600px;
      display: inline-block;
      padding: 20px;
      background: #3369ff;
      border-radius: 50px 0 50px 50px;
    }

    .image-container {
      /* 多图模式 - 4列网格布局 */
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      direction: rtl;
      gap: 24px;
      padding-top: 20px;
      // padding: 16px 32px;

      .image-box {
        /* 正方形比例 */
        display: flex;
        justify-content: flex-end;
        direction: ltr;
        border-radius: 20px;
        padding-bottom: 20px;
        .preview-image {
          width: 150px;
          height: 150px;
          border-radius: 20px;
        }
      }

      /* 单图模式 */
      &.single-mode {
        padding-top: 20px;
        grid-template-columns: 1fr !important;
        .image-box {
          // aspect-ratio: 16/9; /* 宽屏比例 */
          max-height: 600px;
          .preview-image {
            object-fit: contain; /* 完整显示图片 */
          }
        }
      }
    }
  }

  .scroll-to-bottom {
    position: fixed;
    right: 32px;
    z-index: 100;
    display: flex;
    justify-content: center;
    align-items: center;
    background: #fff;
    border-radius: 50%;
    image {
      width: 54px;
      height: 54px;
    }
  }
}
</style>
