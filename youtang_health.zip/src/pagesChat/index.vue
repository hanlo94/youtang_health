<template>
  <view class="chat-container" v-if="!zoomPageFlag">
    <chatHeader
      v-if="isHeadershow"
      :questionData="questionData"
      :handleQuestionClick="handleQuestionClick"
    />

    <ChatMessage
      ref="childRef"
      :messages="messages"
      :scrollTops="scrollTop"
      :stateObj="stateObj"
      :conversationId="conversationId"
      :textareaAHeight="textareaAHeight"
      @updateConut="handleUpdataCount"
      v-if="messages.length !== 0"
    />
    <view
      class="input-bottom"
      :style="{ position: 'fixed', bottom: stateObj.keyboardHeight + 'px' }"
    >
    <view class="history-img"  v-if="!historyIconFlag">
      <img @click="showHistoryFn" :src="imgUrlFormat('vector.png')" />
    </view>
      <view class="input-top">
        <!-- 列表删除功能 -->
        <!-- <view class="del" @click="delMessage">
          <image
            :src="
              imgUrlFormat(
                !clearFlag ? 'ai/chat_default_delete.png' : 'ai/chat_delete.png'
              )
            "
          ></image>
        </view> -->
        <view class="right-content">
          <ImageList
            v-if="filesData.length !== 0"
            :files="filesData"
            @deleteFiles="handleDeleteFiles"
            @retryImage="handleRetryImage"
          />
          <view class="right-content-text" v-if="filesData.length > 0"> </view>
          <view
            :style="{
              display: 'flex',
              borderRadius: '50px',
              backgroundColor: !inputObj.pressState ? '#ffffff' : '#EBF6FF',
            }"
          >
            <view
              class="left-icon"
              v-if="!inputObj.pressState"
              @click.stop="swithchIpunt"
            >
              <image
                :src="
                  imgUrlFormat(
                    !inputObj.inputType
                      ? 'ai/mic_line.png'
                      : 'ai/keyboard_box.png'
                  )
                "
              ></image>
            </view>
            <view
              class="voice"
              v-if="inputObj.inputType"
              @touchstart.stop="handleTouchStart"
              @touchend.stop="handleTouchEnd"
            >
              <text v-show="!inputObj.pressState">按下 说话</text>
              <text v-show="inputObj.pressState">说话中...</text>
              <!-- <image
                v-else
                :src="imgUrlFormat('ai/chat_zoom.png')"
                style="height: 50px"
              /> -->
            </view>
            <view
              v-else
              class="right"
              :style="{ height: textareaAHeight + 30 + 'px' }"
            >
              <textarea
                class="area-style"
                v-model="inputMessage"
                :placeholder="inputParams.placeholder"
                @blur="handleInputBlur"
                @input="handleInput"
                :style="{ height: textareaAHeight + 'px' }"
                @linechange="handleLineChange"
                :show-confirm-bar="false"
                placeholder-style="font-size: 16px;"
                maxlength="-1"
                adjust-position
              ></textarea>
              <view class="rigth-icon">
                <view
                  class="zoom"
                  v-if="zoomFlag"
                  @click="handleZoom"
                  :style="{ paddingBottom: textareaAHeight / 2 + 'px' }"
                >
                  <image :src="imgUrlFormat('ai/chat_zoom.png')" />
                </view>

                <view class="set-send">
                  <!-- <view class="upload-icon" @click="showPopup = true">上传</view> -->
                  <view class="send" @click.stop="sendMessage">
                    <view :class="[!sendFlag ? 'default-send' : 'chat-send']"
                      >发送</view
                    >
                  </view>
                </view>
              </view>
            </view>
          </view>
        </view>
      </view>
    </view>

    <PopupFile v-model="showPopup" @select="handleSourceSelect" />
    <PopupHistory v-model:visible="popupVisible"  @item-click="handleHistorySelect" />
  </view>
  <view class="zoom-container" v-if="zoomPageFlag">
    <view class="zoom-in" @click.stop="handleZoomIn">
      <image :src="imgUrlFormat('ai/chat_downsize.png')" />
    </view>

    <textarea
      class="text-box"
      v-model="inputMessage"
      placeholder-style="font-size: 16px;"
      @input="handleInput"
      maxlength="-1"
      :cursor-spacing="10"
      adjust-position
    ></textarea>
    <view class="send-zoom" @click.stop="sendMessageVisable">
      <view :class="[!sendFlag ? 'default-send' : 'chat-send']">发送</view>
    </view>
  </view>
</template>

<script setup lang="ts">
import { ref, onMounted, reactive, watch, onUnmounted } from "vue";
import chatHeader from "./component/chatHeader.vue";
import ChatMessage, { type ChildExpose } from "./component/ChatMessage.vue";
import PopupFile from "./component/PopupFile.vue";
import ImageList from "./component/ImageList.vue";
import PopupHistory from "./component/PopupHistory.vue";
import { useImageUpload } from "@/utils/uploadImage";
import StoreUtils from "@/utils/storeUtils";
import {
  extractAndConcatenateContent,
  bufferToStrings,
  parseMarkdown,
} from "@/utils/chatUtils";
import { useMainPageStore } from "@/utils/storeUtils";
import {
  chatclearMsg,
  chatCreate,
  chatBot,
  getChatList,
  getchatConversationId,
  streamChat,
} from "@/api/modules/chat";
import imgUrlFormat from "@/utils/imgUtils";
import Taro from "@tarojs/taro";
import { debounce } from "lodash";

const usePageStore = useMainPageStore();
const maxCount = 10;
let { files, chooseImage, uploadFile, deleteImage, clearImage } =
  useImageUpload(maxCount);

const messages = ref<any[]>([]),
  inputMessage = ref<string>(""),
  scrollTop = ref<number>(0),
  clearFlag = ref<boolean>(false),
  sendFlag = ref<boolean>(false),
  zoomFlag = ref<boolean>(false),
  zoomPageFlag = ref<boolean>(false),
  question = ref<string>(""),
  sendingFlag = ref<boolean>(false),
  isRefreshing = ref<boolean>(true),
  isHeadershow = ref<boolean>(false),
  patientId = ref<number>(0),
  textareaAHeight = ref(40),
  spacingCount = ref(24),
  filesData = ref<any>([]),
  beforeId = ref<string | null>(null),
  loadFlag = ref<boolean>(false);

const childRef = ref<ChildExpose | null>(null);

const inputParams = reactive({
  placeholder: "请输入您的问题",
});

//上传
const showPopup = ref<boolean>(false);

const state = reactive({
  firstId: null,
  firstMore: false,
  lastId: null,
});
const stateObj = reactive({
  isRefreshing: false,
  hasMore: false,
  name: "",
  icon_url: "",
  keyboardHeight: 0,
});

const inputObj = reactive({
  inputType: false,
  pressState: false,
});

let conversationId = ref<string>("");
const topContent = {
  id: "1234567890",
  role: "assistant",
  topAnswerFlag: true,
  content:
    "你好，我是优小唐-智能AI助手，专门解答你在糖尿病健康管理过程中遇到的问题。",
};

let questionData = ref({
  name: "",
  icon_url: "",
  description: "",
  questions: [],
});

//语音识别
const recordTimer = ref<NodeJS.Timeout | null>(null);;
const isRecognizing = ref(false);
const hasStarted = ref(false);
const manager = ref(null);
const voiceDuration = 30000;

//历史会话记录
const popupVisible = ref(false);
const historyIconFlag = ref(false);


onMounted(() => {
  patientId.value = StoreUtils.readPatientId();
  // getMessageList();
  getBotData();

  // 监听键盘高度变化
  Taro.onKeyboardHeightChange((res) => {
    stateObj.keyboardHeight = res.height - 1;
  });

   //语音识别
  initPlugin();
});

// 3. 销毁监听
onUnmounted(() => {
  Taro.offKeyboardHeightChange();
});

watch(
  () => files.length,
  () => {
    filesData.value = files;
  }
);

/**
 * 处理初始化页面数据
 */
const setBotData = (bot) => {
  questionData.value = {
    icon_url: bot.icon_url,
    name: bot.name,
    description: bot.prologue,
    questions: bot.suggested_questions,
  };
  stateObj.name = bot.name;
  stateObj.icon_url = bot.icon_url;
  Taro.setNavigationBarTitle({
    title: bot.name,
  });
};

const getBotData = async () => {
  const botData = await chatBot();
  const { code, data } = botData;
  if (code === 10000) {
    setBotData(data);
    isHeadershow.value = true;
  }
};

const getMessageList = async (id) => {
  try {
    conversationId.value = id
    if (conversationId.value) {
      //获取消息列表接口
      if (conversationId.value) {
        const megLength = await getChatMsgList(null);
        // //处理当数据为空获取bot信息
        if (!megLength) {
          isHeadershow.value = true;
          return
        } 
        isHeadershow.value = false;
        historyIconFlag.value = true;

      } else {
        //创建对话
        const createConver = await chatCreate({
          userId: patientId.value,
        });

        if (createConver.code === 10000) {
          conversationId.value = createConver.data;
          isHeadershow.value = true;
        } else {
          Taro.showToast({
            title: "创建对话失败，请重试",
            icon: "none",
            duration: 2000,
          });
        }
      }
    } else {
      Taro.showToast({
        title: "请求失败，请先登录",
        icon: "none",
        duration: 2000,
      });
    }
  } catch (error) {
    console.error("请求失败");
  }
};

/**
 * 获取历史消息列表
 */
const getChatMsgList = async (isLoad) => {
  if (stateObj.hasMore) {
    return;
  }

  // 显示加载弹窗
  !isLoad &&
    Taro.showLoading({
      title: "加载中...",
      mask: true, // 防止用户点击屏幕
    });

  try {
    const msgListRes = await getChatList({
      conversationId: conversationId.value,
      beforeID: state.lastId,
      afterID: null,
      limit: 10,
      dataSource: "remote",
    });

    const { code, data = [] } = msgListRes;
    stateObj.isRefreshing = false;

    if (data?.length <= 0) {
      stateObj.hasMore = true;
    }
    if (code === 10000 && data.length > 0) {
      const addLoadFlags = data
        .map((item) => {
          item.loadFlag = true;
          item.iconFlag = true;
          if (item.content_type === "object_string") {
            item.images = [];
            JSON.parse(item.content)?.map((contentObj) => {
              if (contentObj.type === "image") {
                item.images.push(contentObj.file_url);
              }
              if (contentObj.type === "text") {
                item.content = contentObj.text;
              }
            });
          }
          //处理当没有被解析的md格式数据
          if (item.role === "assistant" && !item.parsed) {
            item.content = parseMarkdown(item.content);
          }
          return item;
        })
        .reverse();
      beforeId.value = data[0].id;
      let arr = [...addLoadFlags, ...messages.value];
      const hasIdOne = arr.some((item) => item.id === topContent.id);
      arr = hasIdOne ? arr.filter((item) => item.id !== topContent.id) : arr;
      // 添加默认头部信息
      arr.unshift(topContent);
      messages.value = arr;

      state.firstId = null;
      state.lastId = data[data.length - 1].id;
      clearFlag.value = messages.value.length ? true : false;
    } else {
      stateObj.isRefreshing = true;
    }

    return data.length;
  } catch (error) {
    Taro.showToast({
      title: "获取消息列表失败，请重试",
      icon: "none",
      duration: 2000,
    });
  } finally {
    // 隐藏加载弹窗
    Taro.hideLoading();
  }
};

/**
 * 点击问题发送消息
 */
const handleQuestionClick = async (data: string) => {
  sendFlag.value = true;
  question.value = data;
  const conversationData = await getchatConversationId({ userId: patientId.value });
  if(conversationData.code === 10000) {
    conversationId.value = conversationData?.data;
  }
  historyIconFlag.value = true;
  sendMessage();
};

/*
 *  删除会话
 */
const delMessage = async () => {
  if (!clearFlag.value) return;

  const res = await chatclearMsg({
    userId: patientId.value,
    conversationId: conversationId.value,
  });
  const {
    code,
    data: { bot, conversationId: chatId },
  } = res;
  isHeadershow.value = true;
  if (code === 10000) {
    loadFlag.value = false;
    messages.value = [];
    clearFlag.value = false;
    conversationId.value = chatId;
    setBotData(bot);
  }
};

/**
 * 发送消息
 */
const sendMessage = async () => {
  let sendErr = false;
  let sendErrMsg = {
    id: "123",
    role: "assistant",
    content: `获取数据出现错误、请提出关于糖尿病相关问题`,
    loadFlag: true,
  };
  let content = inputMessage.value;
  if (question.value !== "") {
    content = question.value;
  }
  //主要为了控制不能连续输入，处理先判断sendFlag的字段，再去判断是否有输入内容
  if (!sendFlag.value && content.length <= 0) {
    return;
  }
  let images: any = [];
  if (filesData.value.length > 0) {
    images = filesData.value.map((file) => file.url);
    content.length <= 0 && (content = "分析下图图片内容");
  }

  if (!isSomeId()) {
    messages.value.unshift(topContent);
  }
  messages.value.push({ role: "user", content, images });

  messages.value.push({
    role: "assistant",
    content: "",
    loadFlag: false,
    iconFlag: false,
    id: Date.now(),
  });
  const messageIndex = messages.value.length - 1;
  // 主要是当发送回到底部
  scrollToBottom();
  clearAll();
  // inputMessage.value = "";
  //没办法做比对，重置上传图片count,
  usePageStore.setFilesCount(0);

  let timer = setTimeout(() => {
    if (!sendErr) {
      messages.value[messages.value.length - 1] = sendErrMsg;
      sendFlag.value = true;
    }
    clearTimeout(timer);
  }, 60001);

  try {
    const task = streamChat({
      conversationId: conversationId.value,
      content,
      images,
      beforeId: beforeId.value,
    });
    let strData = "";
    task?.onChunkReceived((response) => {
      const chunkStr = bufferToStrings(response.data);
      // console.log("chunkStr+++++++++++++++++++++++++",chunkStr);
      const { content: deltaContent, metadata } =
        extractAndConcatenateContent(chunkStr);
      beforeId.value = metadata?.id as string;
      if (deltaContent) {
        messages.value = messages.value.map((msg, i) => {
          if (i === messageIndex) {
            strData = strData + deltaContent;
            const htmlContent = parseMarkdown(strData);
            return {
              ...msg,
              content: htmlContent,
              // 强制生成新对象引用
              _version: (msg._version || 0) + 1,
              _isParsed: false,
              ...metadata,
              isLike: 2,
              loadFlag: true,
            };
          }
          return msg;
        });

        // 实时滚动到底部
        scrollToBottom();
        // 触发视图更新
        messages.value = [...messages.value];
      }
    });
    // 等待请求完成
    const completeResponse = await task;
    console.log("完整响应：", completeResponse.data);
    // 标记消息完成
    messages.value[messageIndex].iconFlag = true;
    clearFlag.value = true;
    // 重置发送状态
    sendingFlag.value = false;
    question.value = "";
    sendErr = true;
  } catch (error) {
    console.error("请求失败:", error);
    // 处理请求失败的情况
    messages.value[messages.value.length - 1] = sendErrMsg;
    sendFlag.value = true;

    // 显示错误提示
    Taro.showToast({
      title: "请求失败，请重试",
      icon: "none",
      duration: 2000,
    });
  } finally {
    clearTimeout(timer);
    sendingFlag.value = false;
    scrollToBottom();
  }
};

const isSomeId = () => {
  return messages.value.some((item) => item.id === topContent.id);
};

/**
 * 输入事件
 */
const handleInput = debounce((e) => {
  if (!inputMessage.value.length) {
    sendFlag.value = false;
    return;
  }
  !sendingFlag.value && (sendFlag.value = true);
}, 200);

const handleZoom = () => {
  zoomPageFlag.value = true;
  spacingCount.value = 0;
};
const handleZoomIn = () => {
  zoomPageFlag.value = false;
  zoomFlag.value = false;
  spacingCount.value = 24;
};

const scrollToBottom = () => {
  if (childRef.value) {
    childRef.value?.scrollToBottom();
  }
};

const handleInputBlur = () => {
  stateObj.keyboardHeight = 0;
};

const handleUpdataCount = (data) => {
  isRefreshing.value = data;
  getChatMsgList("isLoad");
};

const sendMessageVisable = () => {
  zoomPageFlag.value = !zoomFlag.value;
  sendMessage();
};

// 处理行数变化
const handleLineChange = (e) => {
  const { height } = e.detail;

  textareaAHeight.value = height;
  if (height >= 101) {
    zoomFlag.value = true;
    textareaAHeight.value = 101;
    return;
  }
  zoomFlag.value = false;
};

// 显示弹窗
const handleSourceSelect = (type: "camera" | "album") => {
  // console.log(type, "bbbbbbbbbbbbbbbbbbbbbbbbbb");
  inputParams.placeholder = "分析下图图片内容";
  chooseImage(type === "camera" ? ["camera"] : ["album"]);
  !sendingFlag.value && (sendFlag.value = true);
};

//删除图片
const handleDeleteFiles = (index: number) => {
  console.log(files, "files");
  deleteImage(index);
  if (filesData.value <= 0) {
    inputParams.placeholder = "请输入您的问题";
  }
};

// 重试
const handleRetryImage = (item, index) => {
  uploadFile(item, index);
};

// 清空图片
const clearAll = () => {
  isHeadershow.value = false;
  zoomFlag.value = false;
  sendFlag.value = false;
  clearFlag.value = false;
  sendingFlag.value = true;
  inputMessage.value = "";
  if (filesData.value.length !== 0) {
    clearImage();
    inputParams.placeholder = "请输入您的问题";
    filesData.value = [];
  }
};

const swithchIpunt = () => {
  inputObj.inputType = !inputObj.inputType;
};

const initPlugin = () => {
  try {
    //微信语音插件
    const plugin = Taro.requirePlugin("WechatSI");
    const recognitionManager = plugin.getRecordRecognitionManager();

    //实时识别结果
    recognitionManager.onRecognize = (res) => {
      console.log("实时识别结果:", res.result);
      inputMessage.value = res.result; // 实时更新输入内容
    };

    //结束后的回调函数
    recognitionManager.onStop = (res: { result: string }) => {
      // 清理定时器
      if (recordTimer.value) {
        clearTimeout(recordTimer.value);
        recordTimer.value = null;
      }
      
      // 更新识别结果
      const finalResult = res.result?.trim();
      if (finalResult) {
        inputMessage.value = finalResult;
        sendMessage(); // 自动发送消息
        uploadFile({url: res?.tempFilePath}, 0, "audios");
      } else {
        Taro.showToast({ title: '未识别到内容', icon: 'none' });
      }
      isRecognizing.value = false;
      hasStarted.value = false;
    };

    // 开始录音回调
    recognitionManager.onStart = () => {
      hasStarted.value = true;
      inputMessage.value = ''; // 清空之前内容

      recordTimer.value = setTimeout(() => {
        if (manager.value && hasStarted.value) {
          manager.value.stop();
          Taro.showToast({ title: '已达到最长录音时间', icon: 'none' });
        }
      }, voiceDuration);
    };

    recognitionManager.onError = (res) => {
      hasStarted.value = false;
      isRecognizing.value = false;
      Taro.showToast({ title: "识别失败，请重试", icon: "none" });
    };

    manager.value = recognitionManager;
  } catch (e) {
    Taro.showToast({ title: "语音功能不可用", icon: "none" });
  }
};

const handleTouchStart = () => {
  inputObj.pressState = true;
  Taro.getSetting({
    success(res) {
      if (!res.authSetting["scope.record"]) {
        Taro.authorize({
          scope: "scope.record",
          success() {
            startRecording();
          },
          fail() {
            Taro.showToast({ title: "请授权麦克风权限", icon: "none" });
            Taro.openSetting(); // 开启麦克风
          },
        });
      } else {
        startRecording();
      }
    },
  });
};

const startRecording = () => {
  if (manager.value && !isRecognizing.value) {
    isRecognizing.value = true;
    manager.value.start({
      duration: voiceDuration, // 语音时长
      lang: "zh_CN",
    });
  }
};

const handleTouchEnd = () => {
  inputObj.pressState = false;
  manager.value && manager.value.stop();
  isRecognizing.value = false;
};

const showHistoryFn = () => {
  popupVisible.value = true;
};

const handleHistorySelect = (id) => {
  getMessageList(id)
};

</script>

<style lang="less">
page {
  background-color: #fff !important;
}

/* 仅针对 iOS 的调整 */
@supports (-webkit-overflow-scrolling: touch) {
  .del {
    padding: 0 8px 30px 0px;
    image {
      width: 48px;
      height: 48px;
    }
  }
}

.chat-container {
  width: 100%;
  color: #353535;
  text-align: center;
  font-size: 28px;

  .input-bottom {
    // position: fixed;
    // bottom: 0;
    width: 100%;
    padding-bottom: 32px;
    text-align: center;
    background: #fff;
    image {
      width: 48px;
      height: 48px;
    }
    .history-img{
      display: flex;
      justify-content: flex-end;
      margin: 0 40px 16px 0;
    
    }
    .input-top {
      display: flex;
      justify-content: center; /* 水平方向居中 */
      align-items: flex-end;
      padding: 0px 30px;
      .del {
        padding: 0 8px 22px 0px;
        image {
          width: 48px;
          height: 48px;
        }
      }
      .right-content {
        width: 100%;

        box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.2);
        border-radius: 50px;
        .right-content-text {
          height: 1px;
          background-color: #e2e0e0;
        }
        .left-icon {
          display: flex;
          align-items: center;
          padding-left: 20px;
          image {
            width: 48px;
            height: 48px;
          }
        }

        .voice {
          width: 100%;
          font-weight: 600;
          height: 100px;
          line-height: 100px;
          border-radius: 50px;
          padding-right: 50px;
          font-size: 30px;
          image {
            height: 100px;
          }
        }

        .right {
          display: flex;
          justify-content: center; /* 水平方向居中 */
          align-items: center;
          // height: 120px;
          width: 100%;
          padding: 0 20px;
          .area-style {
            width: 100%;
            font-size: 32px;
            text-align: left;
          }
          .nut-textarea {
            // padding-bottom: 4px;
            padding: 20px 10px 4px 10px;
          }
          //暂时去掉图片识别功能，样式调整，
          .rigth-icon {
            // width: 190px;
            width: 72px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;

            .zoom {
              image {
                width: 48px;
                height: 48px;
              }
            }

            .set-send {
              display: flex;
              width: 100%;
              font-size: 32px;
              font-weight: 600;
              .upload-icon {
                width: 100%;
                color: #3369ff;
                margin-right: 8px;
              }
              .send {
                width: 100%;
                image {
                  width: 48px;
                  height: 48px;
                }
              }
            }
          }
        }
      }
    }
    .imput-foot {
      padding: 20px 0;
      color: #a1a1a1;
      display: block; // 确保显示
      height: auto; // 确保高度自适应
    }
  }
}
.default-send {
  color: #a1a1a1;
  font-weight: 600;
}
.chat-send {
  color: #3369ff;
  font-weight: 600;
}
.zoom-container {
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  padding: 10px 30px;
  background-color: #fff;
  color: #353535;
  .text-box {
    height: calc(100vh - 200px);
    width: 100%;
    text-align: left;
  }
  .area-zoom {
    width: 100%;
  }
  image {
    width: 40px;
    height: 40px;
    margin: 10px;
  }
  .send-zoom {
    font-size: 32px;
    padding: 20px 20px 0 0;
    background: #fff;
  }
}
</style>
