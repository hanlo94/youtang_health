export default definePageConfig({
  navigationBarTitleText: "食物库",
  enableShareAppMessage: true,
  enableShareTimeline: true
});
