export default definePageConfig({
  navigationBarTitleText: "近期更新",
  enableShareAppMessage: true,
  enableShareTimeline: true
});
