

<template>
  <view class="container_food">
    <nut-searchbar class="search" v-model="state.keyword" placeholder="搜索文章" @change="doSearch">
      <template v-slot:leftin>
        <Search2 color="#BBBBBB"/>
      </template>
    </nut-searchbar>

    <scroll-view class="search_list" :scrollY="true" @scrollToLower="scroll" flexed>
      <template v-for="item in list" :key="item.id">
        <comp_article_card :item="item" style=""  />
      </template>


      <NoData v-if="showEmpty"></NoData>
      <view v-else v-show="showFinish" class="on_the_bottom">已经到底了</view>
    </scroll-view>

  </view>

</template>
<script setup lang="ts">
import {computed, reactive, ref} from "vue";
import {Search2} from '@nutui/icons-vue-taro';
import AcademyApi from "@/api/modules/academy";
import {IGiItem} from "@/api/types";
import debounce from "lodash/debounce";
import Taro from "@tarojs/taro";
import comp_article_card from '@/component/articleCard'
import NoData from '@/component/noData/index.vue'


const  params = Taro.getCurrentInstance().router?.params;
console.log('params',params)
const title = params?.title;
if(title){
  Taro.setNavigationBarTitle({
    title
  })
}

const state = reactive({
  showTab: true,
  wordType: Number(params?.wordType),
  keyword: '',
  page: 1,
  pageSize: 20,
  finished: false,
  detailUrl: ''
})

Taro.showShareMenu({
	withShareTicket: true
})

// 食物gi列表
const list = ref<IGiItem[]>([] as IGiItem[]);

const showEmpty = computed(()=>{
  return state.page === 1 && state.finished === true && list.value.length===0;
})

const showFinish = computed(()=>{
  return state.finished===true;
})

// 获取食物gi速查
const getArticleList = ()=>{
  if (state.page === 1) {
    list.value = [];
    state.finished = false;
  }
  if(state.finished){
    return;
  }

  AcademyApi.getArticleList(state.wordType, state.keyword, state.page, state.pageSize).then(res=>{
    if(res.data.length === 0){
      state.finished = true;
      return;
    }

    list.value.push(...res.data)
  })
}

getArticleList();

// 搜索search(
const doSearch = () => {
  list.value = [];

  if (state.keyword.length > 0) {
    state.showTab = false;
    state.page = 1;
  } else {
    state.showTab = true;
    state.page = 1;
  }
  search();
}

const search = debounce(getArticleList, 500);


const scroll = () => {
  state.page++;
  getArticleList();
}
</script>
<style lang="less">
.container_food {
  height: 100vh;
  padding: 21px;
  display: flex;
  flex-direction: column;

  .search {
    height: 50px;
    padding: 0;
    margin-bottom: 28px;
    background: none;

    .nut-searchbar__search-input {
      background: white;
    }
  }

  > .content {
    height: 120px;

    .tab {
      .nut-tabs__list {
        background: white;
        border-radius: 16.67px;
      }

      .nut-tabs__content {
        display: none;
      }

      .nut-tabs__titles-item {
        color: #5F5F5F;
      }

      .active {
        .nut-tabs__titles-item__text {
          color: #64A4F5;
        }

        .nut-tabs__titles-item__line {
          background: #64A4F5;
          width: 70px;
          bottom: 1px;
        }
      }

    }
  }


  .list {
    flex: 1;
    min-height: 100vh;
    //overflow-y: auto;
    //padding: 28px 0;
    .item {
      margin-bottom: 28px;
    }
  }

  .search_list {
    padding: 5px 0;
    flex: 1;
    overflow-y: auto;

    .item {
      margin-bottom: 28px;
    }
  }

  .ellipsis {
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }


}
</style>
