export default definePageConfig({
  navigationBarTitleText: "食物GI速查表",
  enableShareAppMessage: true,
  enableShareTimeline: true
});
