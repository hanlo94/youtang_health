<template>
  <view class="container_food">
    <nut-searchbar class="search" v-model="state.keyword" placeholder="搜索升糖指数" @change="doSearch">
      <template v-slot:leftin>
        <Search2 color="#BBBBBB"/>
      </template>
    </nut-searchbar>
    <view class="content">
      <view class="tab">
        <nut-tabs v-model="state.categoryId" @change="doTabClick">
          <nut-tab-pane pane-key="3" title="高升糖指数"></nut-tab-pane>
          <nut-tab-pane pane-key="2" title="中升糖指数"></nut-tab-pane>
          <nut-tab-pane pane-key="1" title="低升糖指数"></nut-tab-pane>
        </nut-tabs>
      </view>
    </view>

    <scroll-view class="search_list" :scrollY="true" @scrollToLower="scroll" flexed>
      <template v-for="item in list" :key="item.id">
        <comp_food_card class="item" :item="item">
          <template #default>
            <view class="ellipsis">GI：{{ item.gi }}</view>
          </template>
        </comp_food_card>
      </template>
      <NoData v-if="showEmpty"></NoData>
      <view v-else v-show="showFinish" class="on_the_bottom">已经到底了</view>
    </scroll-view>

  </view>

</template>
<script setup lang="ts">
import {computed, onMounted, reactive, ref, watch} from "vue";
import {Search2} from '@nutui/icons-vue-taro';
import {Tabs, TabPane} from '@nutui/nutui-taro';
import AcademyApi from "@/api/modules/academy";
import {IAcademyItem, IFoodCategory, IGiItem} from "@/api/types";
import debounce from "lodash/debounce";
import FoodApi from "@/api/modules/food";
import comp_food_card from '@/component/foodCard/index.vue';
import {showShortToast} from "@/utils/util";
import Taro from "@tarojs/taro";
import CommonApi, {IDictItem} from "@/api/modules/common";
import PageNavigation from "@/utils/pageNavigation";
import NoData from "@/component/noData/index.vue";

const state = reactive({
  showTab: true,
  categoryId: 3,
  keyword: '',
  page: 1,
  pageSize: 20,
  subCategoryId: 0,
  finished: false,
  detailUrl: ''
})


// 食物gi列表
const list = ref<IGiItem[]>([] as IGiItem[]);

const showEmpty = computed(() => {
  return state.page === 1 && state.finished === true && list.value.length===0;
})

const showFinish = computed(() => {
  return state.finished === true;
})

Taro.showShareMenu({
	withShareTicket: true
})

// 获取食物gi速查
const getGiList = () => {
  if (state.page === 1) {
    list.value = [];
    state.finished = false;
  }
  if (state.finished) {
    return;
  }

  AcademyApi.getFoodGiList(state.categoryId, state.keyword, state.page, state.pageSize).then(res => {
    if (res.data.recordList.length === 0) {
      state.finished = true;
      return;
    }

    const data = res.data.recordList.map(item => {
      return {
        gi: item.glycemicGi,
        id: item.id,
        name: item.glycemicName,
        thumb: item.glycemicThumb
      }
    })
    list.value.push(...data)
  })
}

getGiList();

// 点击tab
const doTabClick = () => {
  state.page = 1;

  getGiList();
}

// 搜索search(
const doSearch = () => {
  list.value = [];
  state.subCategoryId = 0;
  state.finished = false;

  if (state.keyword.length > 0) {
    state.showTab = false;
    state.page = 1;
  } else {
    state.showTab = true;
    state.page = 1;
  }
  search();
}

const search = debounce(getGiList, 500);

const scroll = () => {
  state.page++;
  getGiList();
}
</script>
<style lang="less">
.container_food {
  height: 100vh;
  padding: 21px;
  display: flex;
  flex-direction: column;

  .search {
    height: 50px;
    padding: 0;
    margin-bottom: 28px;
    background: none;

    .nut-searchbar__search-input {
      background: white;
    }
  }

  > .content {
    height: 120px;

    .tab {
      .nut-tabs__list {
        background: white;
        border-radius: 16.67px;
      }

      .nut-tabs__content {
        display: none;
      }

      .nut-tabs__titles-item {
        color: #5F5F5F;
      }

      .active {
        .nut-tabs__titles-item__text {
          color: #64A4F5;
        }

        .nut-tabs__titles-item__line {
          background: #64A4F5;
          width: 70px;
          bottom: 1px;
        }
      }

    }
  }


  .list {
    flex: 1;
    min-height: 100vh;
    //overflow-y: auto;
    //padding: 28px 0;
    .item {
      margin-bottom: 28px;
    }
  }

  .search_list {
    padding: 5px 0;
    flex: 1;
    overflow-y: auto;

    .item {
      margin-bottom: 28px;
    }
  }

  .ellipsis {
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }


}
</style>
