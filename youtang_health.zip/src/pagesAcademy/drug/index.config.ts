export default definePageConfig({
  navigationBarTitleText: "药品库",
  enableShareAppMessage: true,
  enableShareTimeline: true
});
