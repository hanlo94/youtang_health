<template>
  <view class="comp_progress">
    <view class="progress_metrics">
      <view class="item" v-for="item in metrics" :key="item">{{ item }}</view>
    </view>
    <view class="current_num">
      <TriangleDown class="triangle" size="10px" :color="state.color" :style="state.percentStyle"/>
    </view>
    <view class="range_block">
      <view class="item" v-for="item in blockItems" :key="item" :style="item"></view>
    </view>
    <view class="rang_num">
      <view class="item" v-for="item in rangeNum.slice(1,3)" :key="item">{{ item }}</view>
    </view>
  </view>
</template>
<script setup lang="ts">
import {computed, onMounted, ref} from "vue";
import {TriangleDown} from '@nutui/icons-vue-taro';
import {BodyFatIndicator, QnScaleIndicator} from "@/config/device/bodyfat";
import StoreUtils from "@/utils/storeUtils";
import {isEmpty} from "lodash";

type Props = {
  type: QnScaleIndicator,
  current: number,
}

const props = withDefaults(defineProps<Props>(), {})

const gender = StoreUtils.readPatientGender()
const height = StoreUtils.readPatientHeight()
const obj = BodyFatIndicator.getQnScaleIndicatorData(props.type);
let rangeNum = obj.dataRange
const metrics = obj?.style?.map(item => item.label)
const colors = obj?.style?.map(item => item.color)

console.log("progress.vue.out Mounted. name=", obj?.displayName, "; rangeNum=", JSON.stringify(rangeNum));
onMounted(() => {
  let range
  let min = obj?.min
  let max = obj?.max
  switch (props.type) {
    case QnScaleIndicator.TYPE_WEIGHT:
      range = BodyFatIndicator.getWeightRange(gender, height);
      break;
    case QnScaleIndicator.TYPE_BMI:
      range = BodyFatIndicator.getBmiRange();
      break;
    case QnScaleIndicator.TYPE_BODY_FAT_RATE:
      range = BodyFatIndicator.getBodyFatRateRange(gender);
      break;
    case QnScaleIndicator.TYPE_BMI:
      range = BodyFatIndicator.getBmiRange();
      break;
    case QnScaleIndicator.TYPE_VISFAT:
      range = BodyFatIndicator.getVisFatRange();
      break;
    case QnScaleIndicator.TYPE_BODY_WATER_RATE:
      range = BodyFatIndicator.getBodyWaterRange(gender);
      min = range[0] / 2
      max = range[1] * 2
      break;
    case QnScaleIndicator.TYPE_MUSCLE_RATE:
      range = BodyFatIndicator.getMuscleRateRange(gender);
      min = range[0] / 2
      max = range[1] * 2
      break;
    case QnScaleIndicator.TYPE_MUSCLE_MASS:
      range = BodyFatIndicator.getMuscleMassRange(gender, height);
      min = range[0] / 2
      max = range[1] * 2
      break;
    case QnScaleIndicator.TYPE_PROTEIN:
      range = BodyFatIndicator.getProteinRange(gender);
      min = range[0] / 2
      max = range[1] * 2
      break;
    case QnScaleIndicator.TYPE_HEALTH_RATE:
      range = BodyFatIndicator.getHeartRateRange();
      break;
    case QnScaleIndicator.TYPE_SUB_FAT:
      range = BodyFatIndicator.getSubFatRange(gender);
      min = range[0] / 2
      max = range[1] * 2
      break;
  }

  // console.log("progress.vue.onMounted. name=", obj?.displayName, "; range=", JSON.stringify(range));
  rangeNum = [min, range[0].toFixed(1), range[1].toFixed(1), max];
  // console.log("progress.vue.onMounted. name=", obj?.displayName, "; rangeNum=", JSON.stringify(rangeNum));
})

const state = computed(() => {
  let index = 0; // 箭头位置
  let percent = 0;
  let style = {};
  if (props.current < rangeNum[1]) {
    // left
    index = 0;
    percent = (props.current) / (rangeNum[1]) * 100 * 0.333;
  } else if (props.current > rangeNum[2]) {
    // right
    index = 2;
    percent = 66.66 + (props.current - rangeNum[2]) / (rangeNum[3] - rangeNum[2]) * 100 * 0.333
  } else {
    // center
    index = 1;
    percent = 33.33 + (props.current - rangeNum[1]) / (rangeNum[2] - rangeNum[1]) * 100 * 0.333
  }
  let percentStyle = {
    left: `${percent}%`,
  }
  let color = colors[index]

  return {index, percent, color, percentStyle}
})

const blockItems = computed(() => {
  return colors?.map(item => {
    return {
      background: item
    }
  })
})

</script>
<style lang="less">
.comp_progress {
  width: 100%;

  margin: 0 auto;

  .progress_metrics {
    width: 100%;
    height: 30px;

    display: flex;
    justify-content: space-between;
    align-items: center;

    .item {
      width: 33.3%;
      text-align: center;
      color: #5F5F5F;
      font-size: 22.22rpx;
    }
  }

  .current_num {
    width: 100%;
    height: 20px;
    margin-left: -10px;

    .triangle {
      position: relative;
      bottom: 10px;
    }
  }

  .range_block {
    width: 100%;
    height: 6px;
    display: flex;
    justify-content: space-between;
    align-items: center;

    .item {
      width: 33.33%;
      height: 6px;
    }
  }

  .rang_num {
    width: 100%;
    height: 35px;

    display: flex;
    justify-content: center;
    align-items: center;
    margin-top: 10px;

    .item {
      width: 100px;
      color: #5F5F5F;
      text-align: center;
      font-feature-settings: 'tnum';
    }

    .item:first-child {
      margin-right: 18.5%;
    }
  }
}
</style>
