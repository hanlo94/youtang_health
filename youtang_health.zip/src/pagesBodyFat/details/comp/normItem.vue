<template>
  <view class="comp_normal_item">
    <view class="label">{{ label }}</view>
    <view class="value">{{ value }}</view>
  </view>
</template>

<script setup lang="ts">
type Props = {
  label: string;
  value: string | number;
}
const props = withDefaults(defineProps<Props>(), {})
</script>


<style lang="less">
.comp_normal_item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 26rpx 27rpx;

  .label {
    font-weight: normal;
    color: #282828;
    font-size: 28rpx;
  }

  .value {
    font-weight: normal;
    color: rgba(0, 0, 0, 0.45);
    font-size: 30rpx;
  }
}
</style>
