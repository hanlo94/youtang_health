<!--
Description：
Created on 2023/9/19
Author :  郭 -->
<template>
  <view class="view_fat_details">
    <nut-collapse>
      <view class="view_item">
        <NormalItem label="测量时间" :value="record.recordTime"/>
      </view>
      <view class="view_item">
        <NormalItem label="分数" :value="record.healthScore"/>
      </view>
      <view class="view_item">
        <nut-collapse-item title="体型" :name="3" :value="record.bodyTypeStateName" :icon="RectRight" :rotate="90">
          {{ record.bodyTypeStateDesc }}
        </nut-collapse-item>
      </view>
      <view class="view_item">
        <nut-collapse-item title="体重 (kg)" :name="4" :icon="RectRight" :rotate="90">
          <template #value>
            <view class="view_solt">
              <view class="view_tag"
                    :class="getColorClass(record.weightState,record.weightStateName)"
              >{{ record.weightStateName }}
              </view>
              <view>{{ record.weight }}</view>
            </view>
          </template>
          <SProgress class="sp" :type="QnScaleIndicator.TYPE_WEIGHT" :current="record.weight"/>
          <view class="item_desc">
            {{ record.weightStateDesc }}
          </view>
        </nut-collapse-item>
      </view>
      <view class="view_item">
        <nut-collapse-item title="BMI" :name="5" :icon="RectRight" :rotate="90">
          <template #value>
            <view class="view_solt">
              <view class="view_tag"
                    :class="getColorClass(record.bmiState,record.bmiStateName)"
              >{{ record.bmiStateName }}
              </view>
              <view>{{ record.bmi }}</view>
            </view>
          </template>
          <SProgress class="sp" :type="QnScaleIndicator.TYPE_BMI" :current="record.bmi"/>
          <view class="item_desc">
            {{ record.bmiStateDesc }}
          </view>
        </nut-collapse-item>
      </view>
      <view class="view_item">
        <nut-collapse-item title="体脂率 (%)" :name="6" :icon="RectRight" :rotate="90">
          <template #value>
            <view class="view_solt">
              <view class="view_tag"
                    :class="getColorClass(record.bodyFatRateState,record.bodyFatRateStateName)"
              >{{ record.bodyFatRateStateName }}
              </view>
              <view>{{ record.bodyFatRate }}</view>
            </view>
          </template>
          <SProgress class="sp" :type="QnScaleIndicator.TYPE_BODY_FAT_RATE" :current="record.bodyFatRate"/>
          <view class="item_desc">
            {{ record.bodyFatRateStateDesc }}
          </view>
        </nut-collapse-item>
      </view>
      <view class="view_item">
        <nut-collapse-item title="内脏脂肪等级" :name="7" :icon="RectRight" :rotate="90">
          <template #value>
            <view class="view_solt">
              <view class="view_tag"
                    :class="getColorClass(record.visceralFatState,record.visceralFatStateName)"
              >
                {{ record.visceralFatStateName }}
              </view>
              <view>{{ record.visceralFat }}</view>
            </view>
          </template>
          <SProgress class="sp" :type="QnScaleIndicator.TYPE_VISFAT" :current="record.visceralFat"/>
          <view class="item_desc">
            {{ record.visceralFatStateDesc }}
          </view>
        </nut-collapse-item>
      </view>
      <view class="view_item">
        <nut-collapse-item title="体水分 (%)" :name="8" :icon="RectRight" :rotate="90">
          <template #value>
            <view class="view_solt">
              <view class="view_tag"
                    :class="getColorClass(record.bodyWaterRateState,record.bodyWaterRateStateName)"
              >{{ record.bodyWaterRateStateName }}
              </view>
              <view>{{ record.bodyWaterRate }}</view>
            </view>
          </template>
          <SProgress class="sp" :type="QnScaleIndicator.TYPE_BODY_WATER_RATE" :current="record.bodyWaterRate"/>
          <view class="item_desc">
            {{ record.bodyWaterRateStateDesc }}
          </view>
        </nut-collapse-item>
      </view>
      <view class="view_item">
        <nut-collapse-item title="骨骼肌率 (%)" :name="9" :icon="RectRight" :rotate="90">
          <template #value>
            <view class="view_solt">
              <view class="view_tag"
                    :class="getColorClass(record.muscleRateState,record.muscleRateStateName)"
              >{{ record.muscleRateStateName }}
              </view>
              <view>{{ record.muscleRate }}</view>
            </view>
          </template>
          <SProgress class="sp" :type="QnScaleIndicator.TYPE_MUSCLE_RATE" :current="record.muscleRate"/>
          <view class="item_desc">
            {{ record.muscleRateStateDesc }}
          </view>
        </nut-collapse-item>
      </view>
      <view class="view_item">
        <NormalItem label="基础代谢率 (kcal)" :value="record.bmr"></NormalItem>
      </view>

      <!--			<view class="view_item">-->
      <!--				<nut-collapse-item title="骨量(kg)" :name="10">-->
      <!--					<template #value>-->
      <!--						<view class="view_solt">-->
      <!--							<view class="view_tag_blue">{{ record.boneMassStateName }}</view>-->
      <!--							<view>{{ record.boneMass }}</view>-->
      <!--						</view>-->
      <!--					</template>-->
      <!--					<nut-progress percentage="30" :stroke-color="getStrokeColor(record.boneMassState)"></nut-progress>-->
      <!--					<view class="item_desc">-->
      <!--						{{ record.boneMassStateDesc }}-->
      <!--					</view>-->
      <!--				</nut-collapse-item>-->
      <!--			</view>-->
      <view class="view_item">
        <nut-collapse-item title="肌肉量 (kg)" :name="11" :icon="RectRight" :rotate="90">
          <template #value>
            <view class="view_solt">
              <view class="view_tag"
                    :class="getColorClass(record.muscleMassState,record.muscleMassStateName)"
              >{{ record.muscleMassStateName }}
              </view>
              <view>{{ record.muscleMass }}</view>
            </view>
          </template>
          <SProgress class="sp" :type="QnScaleIndicator.TYPE_MUSCLE_MASS" :current="record.muscleMass"/>
          <view class="item_desc">
            {{ record.muscleMassStateDesc }}
          </view>
        </nut-collapse-item>
      </view>
      <view class="view_item">
        <nut-collapse-item title="身体年龄 (岁)" :name="12" :value="record.metabolicAge" :icon="RectRight" :rotate="90">
          {{ record.metabolicAgeStateDesc }}
        </nut-collapse-item>
      </view>
      <view class="view_item">
        <nut-collapse-item title="蛋白质 (%)" :name="13" :icon="RectRight" :rotate="90">
          <template #value>
            <view class="view_solt">
              <view class="view_tag"
                    :class="getColorClass(record.proteinState, record.proteinStateName)"
              >{{ record.proteinStateName }}
              </view>
              <view>{{ record.protein }}</view>
            </view>
          </template>
          <SProgress class="sp" :type="QnScaleIndicator.TYPE_PROTEIN" :current="record.protein"/>
          <view class="item_desc">
            {{ record.proteinStateDesc }}
          </view>
        </nut-collapse-item>
      </view>
      <view class="view_item">
        <nut-collapse-item title="心率 (次/分钟)" :name="14" :icon="RectRight" :rotate="90">
          <template #value>
            <view class="view_solt">
              <view class="view_tag"
                    :class="getColorClass(record.heartRateState,record.heartRateStateName)"
              >{{ record.heartRateStateName }}
              </view>
              <view>{{ record.heartRate }}</view>
            </view>
          </template>
          <SProgress class="sp" :type="QnScaleIndicator.TYPE_HEALTH_RATE" :current="record.heartRate"/>
          <view class="item_desc">
            {{ record.heartRateStateDesc }}
          </view>
        </nut-collapse-item>
      </view>
      <view class="view_item">
        <nut-collapse-item title="皮下脂肪 (%)" :name="15" :icon="RectRight" :rotate="90">
          <template #value>
            <view class="view_solt">
              <view class="view_tag"
                    :class="getColorClass(record.subcutaneousFatState,record.subcutaneousFatStateName)"
              >{{ record.subcutaneousFatStateName }}
              </view>
              <view>{{ record.subcutaneousFat }}</view>
            </view>
          </template>
          <SProgress class="sp" :type="QnScaleIndicator.TYPE_SUB_FAT" :current="record.subcutaneousFat"/>
          <view class="item_desc">
            {{ record.subcutaneousFatStateDesc }}
          </view>
        </nut-collapse-item>
      </view>
      <view class="view_item">
        <NormalItem label="去脂体重 (kg)" :value="record.leanBodyWeight"/>
      </view>
      <view class="view_item">
        <NormalItem label="脂肪重量 (kg)" :value="record.fatWeight"/>
      </view>
    </nut-collapse>
  </view>
</template>
<script setup lang="ts">

import {RectRight} from '@nutui/icons-vue-taro';

import {onBeforeMount, onMounted, ref} from "vue";
import SugarApi from "@/api/modules/sugar";
import {getCurrentInstance} from "@tarojs/runtime";
import {BodyFatDataPo} from "@/api/types";
import NormalItem from './comp/normItem.vue'
import SProgress from './comp/progress.vue'
import {QnScaleIndicator} from "@/config/device/bodyfat";

let dataId

const record = ref<BodyFatDataPo>({} as BodyFatDataPo)


definePageConfig({
  navigationBarTitleText: '体脂详情'
})

/**
 * 1-偏低 黄,2--标准 蓝,3-偏高 红
 * @param type
 */
const getColorClass = (type: number, state: string) => {
  if (!state) {
    return '';
  } else {
    if (state.includes('低')) {
      return 'view_tag_orange'
    }
    if (state.includes('高')) {
      return 'view_tag_red'
    }
    return 'view_tag_blue'
  }
}

onBeforeMount(() => {
  let params = getCurrentInstance().router?.params;
  console.log("index.vue.onBeforeMount.params=", JSON.stringify(params));
  dataId = params && params.dataId
  console.log("index.vue.onBeforeMount.dataId=", dataId);
})

onMounted(() => {
  getRecordDetail()
})

const getRecordDetail = () => {
  let response = SugarApi.getBodyFatRecordInfo(dataId);
  if (response) {
    response.then((res) => {
      record.value = res.data
      record.value.healthScore += ""
      record.value.bmr += ""
      record.value.metabolicAge += ""
      record.value.fatWeight = (record.value.weight * record.value.bodyFatRate / 100).toFixed(1)

      console.log("index.vue.getRecordDetail.", JSON.stringify(record.value));
    }, (failure) => {
      console.log("index.vue.getRecordDetail..failure", failure)
    }).catch((error) => {
      console.log("index.vue.getRecordDetail..error", error);
    })
  }
}

</script>

<style lang="less">
.view_fat_details {
  padding-bottom: 15px;

  .nut-collapse-item .nut-collapse-item__title {
    padding: 30px 21px;
    border-radius: 17px;

    .nut-collapse-item__title-mtitle {
      color: #282828;
    }

    .nut-collapse-item__title-sub {
      color: rgba(0, 0, 0, 0.45);
      right: 75rpx;
      font-size: 30rpx;
    }


  }

  .nut-collapse__item-wrapper__content {
    padding: 28px 21px !important;
  }

  .view_item {
    background: white;
    margin: 20px 20px;
    border-radius: 17px;
  }

  .view_solt {
    display: flex;
    align-items: center;
  }

  .view_tag {
    color: white;
    border-radius: 20px;
    text-align: center;
    height: 40px;
    width: 80px;
    margin-right: 10px;
    font-size: 23rpx;
    line-height: 40px;
  }

  .view_tag_blue {
    background: #6AA4FC;
  }

  .view_tag_red {
    background: #FF403D;
  }

  .view_tag_orange {
    background: #FFA94F;
  }

  .item_desc {
    margin-top: 20px;
  }

  .sp {
    margin: 0 auto;
  }
}

</style>
