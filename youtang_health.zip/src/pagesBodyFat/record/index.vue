<!--
Description：
Created on 2023/9/9
Author :  郭 -->
<template>
	<view class="view_root">

		<nut-tabs class="tab" v-model="active" color="#64A4F5" background="#ffffff" @click="changeTab">
			<nut-tab-pane title="曲线">
			</nut-tab-pane>
			<nut-tab-pane title="列表">
			</nut-tab-pane>
		</nut-tabs>
		<view class="view_charts" v-if="active === '0'">
			<view class="view_bg">
				<view class="view_btn">
					<nut-button :class=" buttonIndex === 1? 'btn_true' : 'btn_false'  " type="info"
								@click="onClickFilter(1)">
						两周
					</nut-button>
					<nut-button :class=" buttonIndex === 2? 'btn_true' : 'btn_false'" type="info"
								@click="onClickFilter(2)">
						一个月
					</nut-button>
					<nut-button :class=" buttonIndex === 3? 'btn_true' : 'btn_false'" type="info"
								@click="onClickFilter(3)">
						三个月
					</nut-button>
				</view>
				<view class="charts" v-if="!isEmpty(recordTableList) ">
					<ec-canvas id="chart-dom-area" canvas-id="chart-area" :ec="ec"
							   force-use-old-canvas="true"></ec-canvas>
				</view>
				<view v-else>
					<nut-empty image="https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/common/nodata.png" description="暂时还没有数据哦~"></nut-empty>
				</view>
			</view>
			<view class="view_bg " style="margin-top: 20px">
				<text>体脂数据</text>
				<view class="view_notify"><span></span>偏低、严重偏低、不达标、偏瘦</view>
				<view class="view_notify"><span style="background: #DD3542"></span>偏高、严重偏高、偏胖</view>
				<view class="table">
					<nut-table :columns="columns" :data="recordTableList" bordered>
						<template #nodata>
							<div class="no-data"> 暂时还没有数据哦~</div>
						</template>
					</nut-table>
				</view>
			</view>
		</view>
		<scroll-view class="view_list" v-if="active ===  '1'" :scroll-y="true" @scrollToLower="scroll" flexed>
			<view v-if="!isEmpty(recordList)" class="view_item" v-for="(item, index) in recordList" :key="index" @click="onClickItem(item.dataId)">
				<view class="item_header">
					<text>{{ item.recordTime }}</text>
				</view>
				<view class="item_bottom">
					<text>体重</text>
					<tag-text :sugarValue="item.weight" :show-unity="'Kg'"></tag-text>
				</view>
				<view class="item_bottom">
					<text>BMI</text>
					<tag-text :sugarValue="item.bmi"></tag-text>
				</view>
				<view class="item_bottom">
					<text>体脂率</text>
					<tag-text :sugarValue="item.bodyFatRate" :show-unity="'%'"></tag-text>
				</view>
				<view class="item_bottom">
					<text>心率</text>
					<tag-text :sugarValue="item.heartRate" :show-unity="'次/分'"></tag-text>
				</view>
				<view class="item_bottom">
					<text>体型</text>
					<tag-text :sugarValue="item.bodyTypeStateName"></tag-text>
				</view>
			</view>
			<view v-else class="view_no_data">
				<nut-empty image="https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/common/nodata.png"
						   description="暂时还没有数据哦~"></nut-empty>
			</view>
		</scroll-view>

	</view>
</template>
<script setup lang="ts">

import {onMounted, h, ref, reactive} from "vue";
import TagText from "@/component/tag-text/tag-text.vue";
import Taro from "@tarojs/taro";
import {isEmpty} from "lodash";
import SugarApi from "@/api/modules/sugar";
import {BodyFatDataPo} from "@/api/types";
import * as echarts from "@/component/ec-canvas/echarts";
import {categoryBodyFatChartOptions, categoryHba1cChartOptions, generateBodyFatSeriesConfig} from "@/utils/chartOption";
import StoreUtils from "@/utils/storeUtils";
import {createRender} from "@/utils/pubUtils";

const active = ref('0')

const buttonIndex = ref(1)

const pageNum = ref(1);

const columns = [
	{
		title: '日期',
		key: 'recordTime',
		stylehead: 'font-size:10px;color:#666666; background:#EBF6FF;',
		stylecolumn: 'font-size:10px;color:#666666;',
		align: "center",
		render: (record) => createRender(record.dataId, record.recordTime, onClickItem)
	},
	{
		title: 'BMI',
		key: 'bmi',
		stylehead: 'font-size:10px;color:#666666; background:#EBF6FF;',
		stylecolumn: 'font-size:10px;color:red;',
		align: "center",
		render: (record) => createRender(record.dataId, record.bmi, onClickItem)
	},
	{
		title: '体重',
		key: 'weight',
		stylehead: 'font-size:10px;color:#666666; background:#EBF6FF;',
		stylecolumn: 'font-size:10px;color:red;',
		align: "center",
		render: (record) => createRender(record.dataId, record.weight, onClickItem)
	},
	{
		title: '体脂率',
		key: 'bodyFatRate',
		stylehead: 'font-size:10px;color:#666666; background:#EBF6FF;',
		stylecolumn: 'font-size:10px;color:red;',
		align: "center",
		render: (record) => createRender(record.dataId, record.bodyFatRate, onClickItem)
	},
]

const recordList = ref<BodyFatDataPo[]>([] as BodyFatDataPo[]);
const recordTableList = ref<BodyFatDataPo[]>([] as BodyFatDataPo[]);
const recordChartList = ref<BodyFatDataPo[]>([] as BodyFatDataPo[]);

const chart = ref()

function initChart(canvas: any, width: any, height: any) {

	// echarts.init初始化
	chart.value = echarts.init(canvas, null, {
		width,
		height
	})
	// canvas.setChart(chart)

	loadChart()

	return chart
}

const loadChart = () => {
	if (chart && chart.value && !isEmpty(recordChartList.value)) {
		// console.log("index.vue.loadChart.recordChartList=", JSON.stringify(recordChartList.value), '; recordTableList=', JSON.stringify(recordTableList.value));
		let list = recordChartList.value.reverse()
		// console.log("index.vue.loadChart.list=", JSON.stringify(list));
		const option = categoryBodyFatChartOptions(list, StoreUtils.readPatientGender())
		// console.log('option', option)
		chart.value.setOption(option)
	}
}

const ec = reactive({
	onInit: initChart
})

const changeTab = (res) => {
	let {paneKey} = res
	if (paneKey == 0) {
		getBodyFatTable()
	} else if (paneKey == 1) {
		getBodyFatList()
	}
}

/**
 * 点击按钮 切换状态 切换接口
 * @param index
 */
const onClickFilter = (index) => {
	buttonIndex.value = index;
	getBodyFatTable(true)
}

const onClickItem = (dataId) => {
	console.log("index.vue.onClickItem.", dataId);
	Taro.navigateTo({url: "/pagesBodyFat/details/index?dataId=" + dataId})
}


/**
 * 记录列表
 */
const getBodyFatList = () => {
	let response = SugarApi.getBodyFatRecordList(true, undefined, pageNum.value);
	if (response) {
		response.then((res) => {
			if (pageNum.value === 1) recordList.value = [];
			if (!isEmpty(res.data)){
				recordList.value?.push(...res.data)
				pageNum.value++;
			}

		}, (failure) => {
			console.log("index.vue.getBodyFatList..failure", failure)
		}).catch((error) => {
			console.log("index.vue.getBodyFatList..error", error);
		})
	}
}

/**
 * 记录表格与曲线
 */
const getBodyFatTable = (isLoadChart: boolean = false) => {
	let response = SugarApi.getBodyFatRecordList(false, buttonIndex.value, 0);
	if (response) {
		response.then((res) => {
			recordTableList.value = []
			recordTableList.value.push(...res.data)
			// recordChartList.value=[]
			recordChartList.value = res.data
			if (isLoadChart) {
				loadChart()
			}

		}, (failure) => {
			console.log("index.vue.getBodyFatTable..failure", failure)
		}).catch((error) => {
			console.log("index.vue.getBodyFatTable..error", error);
		})
	}
}

getBodyFatTable()

Taro.eventCenter.on('login', (item) => {
	getBodyFatTable()
})

const scroll = () => getBodyFatList();

</script>

<style lang="less">
.view_root {
	background: #efefef;
	position: relative;

	height: 100%;

	.tab {
		position: fixed;
		width: 100%;
		z-index: 10;
		height: 100px;
		top: 0;
	}

	.view_list {
		padding-top: 100px;

		.view_item {
			background: white;
			border-radius: 20px;
			display: flex;
			padding: 20px;
			flex-direction: column;
			margin: 20px 30px;

			.item_header {
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				align-items: center;
				padding-bottom: 10px;
				color: #666666;
				border-bottom: #efefef 1px solid;;
			}

			.item_bottom {
				display: flex;
				margin-top: 20px;
				flex-direction: row;
				justify-content: space-between;
				color: #333333;
			}

		}
	}

	.view_no_data {
		height:100vh;
		padding-top: 150px;
		.nut-empty__box {
			width: 440px;
			height: 260px
		}
	}

	.view_charts {
		padding-top: 100px;
		height: 100vh;
		flex: 1;
		margin: 30px;

		.view_bg {
			display: flex;
			background: white;
			padding: 30px;
			border-radius: 15px;
			flex-direction: column;

			.view_btn {
				border: 10px;
				width: 100%;
				display: flex;
				justify-content: space-around;
				align-items: center;

				.btn_true {
					width: 160px;
					height: 80px;
					background: #0099ff;
					color: #ffffff;
					border: #0099ff solid 1px;
				}

				.btn_false {
					width: 160px;
					height: 80px;
					color: #0099ff;
					background: #ffffff;
					border: #0099ff solid 1px;
				}
			}

			.nut-empty__box {
				width: 330px;
				height: 195px
			}

			.charts {
				position: relative;
				height: 480px;
			}

			.view_notify {
				display: flex;
				align-items: center;
				margin-top: 10px;
				font-size: 20px;
				color: #666666;

				span {
					background: #ED8E36;
					width: 20px;
					margin-right: 10px;
					height: 20px;
				}
			}


			.table {
				margin-top: 20px;
			}
		}


	}


}

</style>>

