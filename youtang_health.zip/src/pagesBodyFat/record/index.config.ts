export default definePageConfig({
    navigationBarTitleText: "体脂记录",
    usingComponents:{
        'ec-canvas':'../../component/ec-canvas/ec-canvas'
    }
});
