export default definePageConfig({
    navigationBarTitleText: "体脂秤",
});
