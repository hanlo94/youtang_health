<template>

	<view class="container_body_fat">
		<view class="card_bg">
			<view class="card">
				<view class="top_tips">
					<image class="icon" :src="measureState.icon" mode="widthFix"></image>
					<view>{{ measureState.mainState }}</view>
				</view>
				<view class="sub_tips">{{ measureState.subState }}</view>

				<view class="tips">
					注意事项：
					<ul>
						<li>1.注意将手机蓝牙打开，并踩亮体脂仪进行设备绑定/测量。</li>
						<li>2.请保持体脂仪干爽，脚掌过多的汗渍和水会影响检测结果。</li>
						<li>3.绑定和测量过程中请不要下秤。</li>
					</ul>
				</view>

				<!--        <view class="bt_list">-->
				<!--          <view class="item" v-for="i in 5">-->
				<!--            <view class="bt_card">-->
				<!--              <view class="left">-->
				<!--                <view class="device_name">CS@@@XXX</view>-->
				<!--                <view class="device_mac">D*:**:**:**:**</view>-->
				<!--              </view>-->
				<!--              <view class="right">-->
				<!--                <nut-button class="link_btn" plain type="info">连接</nut-button>-->
				<!--              </view>-->
				<!--            </view>-->
				<!--            <view class="block"></view>-->
				<!--          </view>-->
				<!--        </view>-->

				<!--    背景    -->
				<view class="round_box">
					<view class="round">
						<view class="round1">
							<view class="round2">
								<view class="round3">
									<image class="device_img" mode="heightFix"
										   :src="imgUrlFormat('sugar/bodyfat_pic.png')" alt=""/>
								</view>
							</view>
						</view>
					</view>
				</view>
			</view>
		</view>
		<!--  按钮  -->
		<view v-if="scaleMeasureState?.retryBtnText" class="retry" @click.stop="onRetryBtnClick">
			<nut-button type="info" class="btn">{{ scaleMeasureState?.retryBtnText }}</nut-button>
		</view>
    <point_dialog :show-point-dialog="showPointDialog" :rewards=rewardPoint @closeDialog="onClosePointDialog"/>
	</view>
</template>
<script lang="ts" setup>
import point_dialog from '@/component/point/index.vue'
import Taro from "@tarojs/taro";
import getReports from '@yolanda-qn/four-electrodes-report-lib-pe';
import {onMounted, ref, computed, onUnmounted, onBeforeMount} from "vue";
import {BodyFatIndicator, QnScaleIndicator, QnScaleMeasureState, ScaleMeasure} from "@/config/device/bodyfat";
import StoreUtils, {useMainPageStore} from "@/utils/storeUtils";
import SugarApi from "@/api/modules/sugar";
import {BodyFatUpload} from "@/api/types";
import {formatTime, showShortToast} from "@/utils/util";
import imgUrlFormat from "@/utils/imgUtils";
import {showToast} from "@/utils/toastUtils";
import {getCurrentInstance} from "@tarojs/runtime";

const showPointDialog=ref<boolean>(false)
const rewardPoint=ref<number>(1)
const dataId=ref<number>()

const {QNMPPlugin, QNConsts} = Taro.requirePlugin('QNBleApi');
// import getReports from '@yolanda-qn';

const scaleMeasureState = ref<ScaleMeasure>()
const bindState = ref<boolean>(false)

// 是否已连接
const connected = ref<boolean>(false)
const connecting = ref<boolean>(false)

const device = ref()
const measureState = computed(() => {
	const res = {
		icon: scaleMeasureState.value?.icon,
		mainState: scaleMeasureState.value?.mainState,
		subState: scaleMeasureState.value?.subState,
		retryBtn: scaleMeasureState.value?.retryBtnText
	}
	return res;
})

const logger = () => {
	const realTimeLogger = Taro.getRealtimeLogManager && Taro.getRealtimeLogManager()
	const wxLogger =
		Taro.getLogManager &&
		Taro.getLogManager({
			level: 0,
		});
	const log = (...params) => {
		console.log(...params);
		realTimeLogger && realTimeLogger.info(...params)
		wxLogger && wxLogger.log(...params);
	};
	return {
		log,
	};
};
const bleApi = new QNMPPlugin({
	appId: Taro.getAccountInfoSync().miniProgram.appId,
	mpwx: 'wx', // 非必须 连接广播称时需要
	logger: logger(), // 非必须，日志功能，最好有，方便排查问题，可以替换为客户自己的
});

const blePermission = () => {
	Taro.getSetting({
		success(res) {
			logger().log("index.vue.blePermission.getSetting.success.res.authSetting=", res.authSetting);
			if (!res.authSetting['scope.bluetooth']) {
				Taro.authorize({
					scope: 'scope.bluetooth',
					success: (res) => {
						// showShortToast('蓝牙授权成功')
						logger().log("blePermission.authorize.success.", JSON.stringify(res));
						// checkBlePermission()
						initSdk()
						// openBluetoothAdapter()
					},
					fail: (res) => {
						// showShortToast('蓝牙授权失败')
						logger().log('蓝牙授权失败', JSON.stringify(res))
						scaleMeasureState.value = QnScaleMeasureState.BLE_DISABLE
					}
				})
			} else {
				// checkBlePermission()
				initSdk()
				// openBluetoothAdapter()
			}
		}
	})
}

const checkBlePermission = () => {
	Taro.getBluetoothAdapterState(
		{
			success: (res) => {
				console.log("index.vue.checkBlePermission.success.", JSON.stringify(res));
			},
			fail: (failure) => {
				console.log("index.vue.checkBlePermission.fail.", JSON.stringify(failure));
			}
		}
	)
}

const openBluetoothAdapter = () => {
	Taro.openBluetoothAdapter({
		success: (res) => {
			// showShortToast('打开蓝牙适配器成功')
			logger().log("index.vue.openBluetoothAdapter.success.", JSON.stringify(res));
			initSdk()
		},
		fail: (res) => {
			logger().log("index.vue.openBluetoothAdapter.fail.", JSON.stringify(res), '; JSON.stringify(res).indexOf(\'openBluetoothAdapter:fail already opened = ', JSON.stringify(res).indexOf('openBluetoothAdapter:fail already opened'));
			if (JSON.stringify(res).indexOf('openBluetoothAdapter:fail already opened') != -1) {
				initSdk()
			} else {
				updateState(QnScaleMeasureState.BLE_DISABLE)
			}
		}
	})
}

onBeforeMount(() => {
	let {isBind} = getCurrentInstance().router?.params
	bindState.value = isBind
})

onMounted(() => {
	blePermission()
})

onUnmounted(() => {
	stopBle()
})

const initSdk = () => {
	// 错误监听
	bleApi.onError = (err) => {
		logger().log('捕捉到错误', err.detail);
		// updateState(QnScaleMeasureState.SDK_ERROR)
	};

	// 初始化回调
	bleApi.onReady = ({bleEnableState}) => {
		if (bleEnableState) {
			logger().log("index.vue.onReady.startBleDeviceDiscovery",);
			bleApi.startBleDeviceDiscovery();
			Taro.showLoading({
				title: "扫描中"
			})
			updateState(bindState.value ? QnScaleMeasureState.BIND_TO_SCAN : QnScaleMeasureState.UNBIND_SCANING)
		} else {
			// showShortToast('蓝牙是关闭状态')
			updateState(QnScaleMeasureState.BLE_DISABLE)
			logger().log('蓝牙状态为关闭');
		}
	};

	// 设置蓝牙监听事件
	bleApi.setBleEventListener(bleEventListener());

	// 初始化
	bleApi.init();
}

const handlerConnect = async (connectingDevice) => {
	if (connected.value) {
		// 已连接
		logger().log("handlerConnect 已连接 不重复连接")
		return
	}
	if (!connecting.value) {
		connecting.value = true
	} else {
		// 连接中
		logger().log("handlerConnect 连接中不重复连接")
		return
	}
	const user = {
		height: StoreUtils.readPatientHeight() || 170,
		gender: StoreUtils.readPatientGender() || 1,
		birthday: (StoreUtils.readPatientBirthday() || '1990-01-01'),
	};

	/**
	 * 调用连接成功后，会返回本次连接的设备访问对象，可以对设备进行一些蓝牙数据通讯
	 * 每次连接返回的都不一样，连接成功后，该对象开始可以操作，连接失败或断开后，该对象会失效
	 */
	logger().log("handlerConnect.. user=", JSON.stringify(user))
	// console.log('要连接的对象', connectingDevice);
	device.value = connectingDevice
	const deviceHandler = await bleApi.createBleConnection(connectingDevice, deviceEventListener(), {
		user,
		unit: 'Kg'
	});

}

// 蓝牙相关事件回调
const bleEventListener = () => {
	/**
	 * 监听扫描到设备的回调
	 */
	const onBleDeviceFound = (device) => {
		logger().log(JSON.stringify(device))
		// showShortToast('找到设备 ')
		// if (bindState.value) {
		//
		// } else {
		handlerConnect(device);
		// }
	};

	/**
	 * 监听蓝牙断开连接的回调
	 */
	const onDisconnected = (device) => {
		// showShortToast('onDisconnected ')
		logger().log("onDisconnected.", '设备连接已断开', device);
		connecting.value = false
		connected.value = false
		updateState(QnScaleMeasureState.LOST_CONNECT)
	};

	/**
	 * 监听蓝牙状态发生变化回调，连接成功或断开连接都会出触发
	 */
	const onBluetoothEnableChange = ({available}) => {
		if (available) {
			logger().log("onBluetoothEnableChange.", '蓝牙可用，空闲');
			// showShortToast('onBluetoothEnableChange 蓝牙可用 ')
			bleApi.startBleDeviceDiscovery();
		} else {
			logger().log("onBluetoothEnableChange.", '蓝牙不可用');
			// showShortToast('onBluetoothEnableChange 蓝牙不可用 ')
			updateState(QnScaleMeasureState.BLE_DISABLE)
		}
	};

	/**
	 *  监听设备连接成功回调
	 */
	const onConnected = (device) => {
		logger().log("index.vue.onConnected.设备已连接", device);
		// showShortToast('设备已连接')
		connected.value = true
		connecting.value = false
		updateState(QnScaleMeasureState.BIND_MEASURING)
	};

	/**
	 * 监听停止扫描的回调
	 */
	const onStopDiscoveryDevice = () => {
		logger().log("index.vue.onStopDiscoveryDevice . bindState", JSON.stringify(bindState), ' bindState.value=', bindState.value, '; (bindState ? \' test1 \' : \'test2\')=', (bindState ? ' test1 ' : 'test2'), '; (bindState.value ? \' test3 \' : \'test4\')=', (bindState.value ? ' test3 ' : 'test4'));
		// showShortToast('停止扫描')
		if (connected.value || connecting.value) {
			// 已连接设备或连接中 不做扫描超时处理
		} else {
			updateState(bindState.value ? QnScaleMeasureState.BIND_SCAN_TIMEOUT : QnScaleMeasureState.UNBIND_SCAN_TIMEOUT)
		}
	};

	/**
	 * 监听开始扫描设备的回调
	 */
	const onStartDiscoveryDevice = () => {
		logger().log("index.vue.onStartDiscoveryDevice.开始扫描 bindState.value=",bindState.value);
		showShortToast('开始扫描')
		updateState(bindState.value ? QnScaleMeasureState.BIND_SCANING : QnScaleMeasureState.UNBIND_SCANING)
	};

	return {
		onBleDeviceFound,
		onDisconnected,
		onBluetoothEnableChange,
		onConnected,
		onStopDiscoveryDevice,
		onStartDiscoveryDevice,
	};
}

// 秤端相关事件回调
const deviceEventListener = () => {
	/**
	 * 实时测量体重
	 */
	const onGetUnsteadyWeight = ({weight}) => {
		logger().log("index.vue.onGetUnsteadyWeight. 测量中 weight", weight);
		// showShortToast('测量中')
		updateState(QnScaleMeasureState.BIND_MEASURING)
	};
	/**
	 * 获取到了实时的稳定测量数据，在连接APP的情况下，进行测量，数据会进入到这个回调
	 * @param {object} measure 体脂秤测量数据
	 */
	const onGetScaleData = ({measure}) => {
		logger().log('测量结束', measure);
		// showShortToast('测量结束')
		updateState(QnScaleMeasureState.BIND_MEASURE_FINISH)
		analysisData(measure)
	};

	/**
	 * 请求算法接口错误回调，一般是因为用户信息的参数错误导致
	 */
	const onFetchScaleDataFail = (err) => {
		logger().log('请求算法接口出错了', err);
	};

	// 普通四电极蓝牙秤存储数据
	const onGetNormalBleScaleStoredData = (payload) => {
		logger().log('onGetNormalBleScaleStoredData', JSON.stringify(payload));
	};

	return {
		onGetUnsteadyWeight,
		onGetScaleData,
		onFetchScaleDataFail,
		onGetNormalBleScaleStoredData,
	};
}

/**
 * 停止蓝牙活动
 */
const stopBle = async function () {
	if (bleApi) {
		await bleApi.stop();
		await bleApi.releaseBleSource();
	}
}

/**
 * 刷新蓝牙
 */
const restart = () => {
	bleApi
		.stop()
		.then(() => {
			connected.value = false
			connecting.value = false
			bleApi.startBleDeviceDiscovery();
		})
		.catch((err) => {
			logger().log('停止扫描失败', err);
		});
}

const updateState = (state) => {
	console.log("index.vue.updateState.", JSON.stringify(state));
	scaleMeasureState.value = state
}

const onRetryBtnClick = () => {
	switch (scaleMeasureState.value) {
		case QnScaleMeasureState.BIND_SCAN_FAILURE:
		case QnScaleMeasureState.BIND_SCAN_TIMEOUT:
		case QnScaleMeasureState.UNBIND_SCAN_TIMEOUT:
		case QnScaleMeasureState.UNBIND_SCAN_FAILURE:
		case QnScaleMeasureState.BIND_MEASURE_FAILURE:
			restart()
			break;
		case QnScaleMeasureState.BLE_DISABLE:
			blePermission();
			break;
		default:
			break;
	}
}

const mainPageStore = useMainPageStore()

/**
 * 展示普通秤测量后的数据，仅供参考，
 */
const analysisData = (scaleData) => {
	const levelColor: Record<"ColorLowest" | "ColorLower" | "ColorStandard" | "ColorHigher" | "ColorHighest" | "ColorSufficient" | "ColorHigh01" | "ColorHigh02", string> = {
		ColorHigh01: "#ffffff",
		ColorHigh02: "#ffffff",
		ColorLowest: '',
		ColorLower: '',
		ColorStandard: '',
		ColorHigher: '',
		ColorHighest: '',
		ColorSufficient: ''
	}
	// // 配置信息
	const config = {
		weightUnit: 'kg', // 重量单位
		levelColors: levelColor
	};
	logger().log("analysisData.", '构造前', JSON.stringify(scaleData));
	let {weight, bmi, age, time} = scaleData
	let {deviceId, mac} = scaleData.device
	let {gender, height} = scaleData.user
	logger().log("index.vue.analysisData.deviceId=", deviceId, '; mac=', mac, ';  deviceId ?? mac=', (deviceId ?? mac));

	let indicatorData = BodyFatIndicator.getQnScaleIndicatorData(QnScaleIndicator.TYPE_BODY_FAT_RATE);
	if (!scaleData.bodyfat || scaleData.bodyfat < indicatorData?.min || scaleData.bodyfat > indicatorData?.max) {
		updateState(QnScaleMeasureState.BIND_MEASURE_FAILURE)
		return
	}
	let upload: BodyFatUpload = {
		deviceMac: deviceId ?? mac,
		height: height,
		recordTime: formatTime(new Date(time)),
		weight: weight,
		weightState: 0,
		weightStateDesc: '',
		bmi: bmi,
		bmiState: 0,
		bmiStateDesc: '',
		bodyFatRate: scaleData.bodyfat,
		bodyFatRateState: 0,
		bodyFatRateStateDesc: '',
		subcutaneousFat: scaleData.subfat,
		subcutaneousFatState: 0,
		subcutaneousFatStateDesc: '',
		visceralFat: scaleData.visfat,
		visceralFatState: 0,
		visceralFatStateDesc: '',
		bodyWaterRate: scaleData.water,
		bodyWaterRateState: 0,
		bodyWaterRateStateDesc: '',
		muscleRate: scaleData.muscle,
		muscleRateState: 0,
		muscleRateStateDesc: '',
		boneMass: scaleData.bone,
		boneMassState: 0,
		boneMassStateDesc: '',
		bmr: scaleData.bmr,
		bodyType: scaleData.bodyShape,
		bodyTypeState: 0,
		bodyTypeStateDesc: '',
		protein: scaleData.protein,
		proteinState: 0,
		proteinStateDesc: '',
		leanBodyWeight: scaleData.lbm,
		leanBodyWeightState: 0,
		leanBodyWeightStateDesc: '',
		muscleMass: scaleData.muscleMass,
		muscleMassState: 0,
		muscleMassStateDesc: '',
		metabolicAge: scaleData.bodyAge,
		metabolicAgeState: 0,
		metabolicAgeStateDesc: '',
		healthScore: scaleData.score,
		heartRate: scaleData.heartRate
	}


	let weightIndicate = BodyFatIndicator.getWeightIndicate(gender, height, weight);
	upload.weightState = weightIndicate.state
	upload.weightStateDesc = weightIndicate.tip
	let bmiIndicate = BodyFatIndicator.getBmiIndicate(bmi);
	upload.bmiState = bmiIndicate.state;
	upload.bmiStateDesc = bmiIndicate.tip;
	let bodyFatIndicate = BodyFatIndicator.getBodyFatIndicate(gender, upload.bodyFatRate);
	upload.bodyFatRateState = bodyFatIndicate.state;
	upload.bodyFatRateStateDesc = bodyFatIndicate.tip;
	let indicateBean = BodyFatIndicator.getBodyWaterIndicate(gender, scaleData.water);
	upload.bodyWaterRateState = indicateBean.state;
	upload.bodyWaterRateStateDesc = indicateBean.tip;
	indicateBean = BodyFatIndicator.getMuscleRateIndicate(gender, scaleData.muscle);
	upload.muscleRateState = indicateBean.state;
	upload.muscleRateStateDesc = indicateBean.tip;

	indicateBean = BodyFatIndicator.getBodyShapeIndicate(scaleData.bodyShape);
	upload.bodyTypeState = indicateBean.state;
	upload.bodyTypeStateDesc = indicateBean.tip;
	indicateBean = BodyFatIndicator.getProteinIndicate(gender, scaleData.protein);
	upload.proteinState = indicateBean.state;
	upload.proteinStateDesc = indicateBean.tip;
	indicateBean = BodyFatIndicator.getBodyAgeIndicate(age, scaleData.bodyAge);
	upload.metabolicAgeState = indicateBean.state;
	upload.metabolicAgeStateDesc = indicateBean.tip;
	indicateBean = BodyFatIndicator.getMuscleMassIndicate(gender, height, scaleData.muscleMass);
	upload.muscleMassState = indicateBean.state;
	upload.muscleMassStateDesc = indicateBean.tip;
	indicateBean = BodyFatIndicator.getHeartRateIndicate(scaleData.heartRate);
	upload.heartRateState = indicateBean.state;
	upload.heartRateStateDesc = indicateBean.tip;
	indicateBean = BodyFatIndicator.getSubFatIndicate(gender, scaleData.subfat);
	upload.subcutaneousFatState = indicateBean.state;
	upload.subcutaneousFatStateDesc = indicateBean.tip;
	indicateBean = BodyFatIndicator.getLbmIndicate();
	upload.leanBodyWeightState = indicateBean.state;
	indicateBean = BodyFatIndicator.getVisFatIndicate(scaleData.visfat);
	upload.visceralFatState = indicateBean.state;
	upload.visceralFatStateDesc = indicateBean.tip;
// region ******** 如下配置 仅用于数据存储，暂未在页面呈现 ********
	indicateBean = BodyFatIndicator.getBoneMassIndicate(weight, gender, scaleData.bone);
	upload.boneMassState = indicateBean.state;
	upload.boneMassStateDesc = indicateBean.tip;
	// console.log("index.vue.analysisData.", JSON.stringify(upload));

	// 这里只是拿到kg数据，尚未进行单位转换和小数位精度fixed处理
	// const reports = getReports(measureData, config)
	// 可以使用order字段来排序
	// .sort((a, b) => a.order - b.order)
	// toObject会进行单位转换和小数位精度处理，返回的是string类型，不应该使用这里的数据来进行额外计算
	// .map((item) => item.toObject());
	// console.log("index.vue.analysisData.", JSON.stringify(reports));
	uploadData(upload)
}

const uploadData = (upload) => {
	let response = SugarApi.uploadBodyFatRecord(upload);
	if (response) {
		response.then((res) => {
			logger().log("index.vue.uploadData..success", JSON.stringify(res));
			showToast('测量成功')
      mainPageStore.refreshPage()
      dataId.value=res.data
      if (res.data) {
        rewardPoint.value = res.data
        showPointDialog.value = true
      }else{
        onFinal()
      }
		}, (failure) => {
			logger().log("index.vue.uploadData..failure", failure)
			updateState(QnScaleMeasureState.BIND_MEASURE_FAILURE)
		}).catch((error) => {
			console.log("index.vue.uploadData..error", error);
		})
	}
}

const onClosePointDialog=()=>{
  console.log('index.onClosePointDialog.showPointDialog=', showPointDialog)
  showPointDialog.value=false
  onFinal()
}

const onFinal=()=>{
  Taro.redirectTo({
    url: '/pagesBodyFat/details/index?dataId=' + dataId.value
  })
}

</script>
<style lang="less">
.icon {
	width: 44px;
	height: 44px;
}

.container_body_fat {
	padding: 27.78px 20.84px;
	border-radius: 16.67px;

	.card_bg {
		background: white;
		z-index: -2;
		position: relative;
		min-height: 1150px;
		border-radius: 16.67px;

		.card {
			padding: 0 20.84px;

			.top_tips {
				font-size: 29.17px;
				font-weight: 600;

				display: flex;
				justify-content: center;
				align-items: center;

				padding-top: 120px;

				.icon {
					width: 27.78px;
					height: 27.78px;
					margin-right: 15px;
				}
			}

			.sub_tips {
				font-size: 29.17px;
				font-weight: 600;
				text-align: center;
				margin-top: 10px;
			}

			.tips {
				font-size: 25px;
				color: #5F5F5F;
				margin-top: 486px;
			}

			.bt_list {
				margin-top: 69px;

				.item {
					.bt_card {
						height: 106.25px;
						display: flex;
						justify-content: space-between;
						align-items: center;

						.left {
							.device_name {
								font-size: 33px;
								color: #353535;
							}

							.device_mac {
								font-size: 31.94px;
								color: #5F5F5F;
								margin-top: 28px;
							}
						}

						.right {
							.link_btn {
								width: 148.61px;
								height: 62.5px;
								border-radius: 51.39px;
								border-color: #64A4F5;

								font-size: 33.33px;
								color: #64A4F5;
								line-height: 30.28px;
							}
						}
					}

					.block {
						height: 35px;
						border-bottom: 1px solid #BBBBBB65;
						margin-bottom: 27.78px;
					}
				}
			}
		}


	}

	.btn {
		width: 666.67px;
		height: 97.22px;
		border-radius: 16.67px;
		background: #64A4F5;
		color: white;
		border: none;
		bottom: 50px;
		left: 41px;
		position: fixed;
	}

	.round_box {
		position: absolute;
		z-index: -1;
		top: 104px;
		left: 10px;

		display: flex;
		align-items: center;
		justify-content: center;

		.round {
			width: 694px;
			height: 694px;
			border-radius: 50%;
			border: 1px solid #64A4F550;
			display: flex;
			align-items: center;
			justify-content: center;

			.round1 {
				width: 555.56px;
				height: 555.56px;
				border-radius: 50%;
				border: 1px solid #64A4F550;
				display: flex;
				align-items: center;
				justify-content: center;

				.round2 {
					width: 416.67px;
					height: 416.67px;
					border-radius: 50%;
					border: 1px solid #64A4F550;
					display: flex;
					align-items: center;
					justify-content: center;

					.round3 {
						width: 277.78px;
						height: 277.78px;
						border-radius: 50%;
						border: 1px solid #64A4F550;
						display: flex;
						align-items: center;
						justify-content: center;
					}
				}
			}
		}
	}

	.device_img {
		width: 176.39px;
		height: 176.39px;
	}
}
</style>
