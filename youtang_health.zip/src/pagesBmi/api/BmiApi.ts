import {PAGE_SIZE, postPatientRequest} from "@/api/api";
import {BmiRecord} from "@/pagesBmi/ts/types";

const BmiAPi = {
	// region ********** 身高体重 *********

	/**
	 * 添加编辑身高体重记录
	 * @param height
	 * @param weight
	 * @param hip  臀围
	 * @param waist 腰围
	 * @param recordTime
	 * @param remark
	 * @param recordId
	 * @returns {Promise | Promise<unknown>}
	 */
	addOrEditBmi(params: {
		height: number,
		weight: number,
		hip: number,
		waist: number,
		recordTime: string|Date,
		remark: string,
		recordId?: number
	}) {
		const data = {
			actId: 11030601,
			record: params
		}
		return postPatientRequest(data)
	},


	/**
	 * 根据时间段类型查询身高体重记录
	 * @param type 1 两周 2 一月 3 三月
	 */
	getTimePeriodBmi(type) {
		const data = {
			actId: 11030604,
			type
		}
		return postPatientRequest<BmiRecord[]>(data)
	},

	/**
	 * 身高体重记录列表
	 * @param page
	 * @returns {Promise | Promise<unknown>}
	 */
	getBmiList(page, pageSize = PAGE_SIZE) {
		const data = {
			actId: 11030603,
			page,
			pageSize,
			pageNum: page,
		}
		return postPatientRequest<BmiRecord[]>(data)
	},

	// endregion
}

export default BmiAPi
