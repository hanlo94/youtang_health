export default definePageConfig({
    navigationBarTitleText: "身高体重记录",
    usingComponents:{
        'ec-canvas':'../../component/ec-canvas/ec-canvas'
    }
});
