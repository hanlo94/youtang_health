<!--
Description：
Created on 2023/9/9
Author :  郭 -->
<template>
	<view class="view_root">

		<nut-tabs class="tab" v-model="active" color="#64A4F5" background="#ffffff" @click="changeTab">
			<nut-tab-pane title="曲线">

			</nut-tab-pane>
			<nut-tab-pane title="列表">

			</nut-tab-pane>
		</nut-tabs>
		<view class="view_charts" v-if="active === '0'">
			<view class="view_bg">
				<view class="view_btn">
					<nut-button :class=" timePeriodIndex === 1? 'btn_true' : 'btn_false'  " type="info"
								@click="onTimePeriodChange(1)">
						两周
					</nut-button>
					<nut-button :class=" timePeriodIndex === 2? 'btn_true' : 'btn_false'" type="info"
								@click="onTimePeriodChange(2)">
						一个月
					</nut-button>
					<nut-button :class=" timePeriodIndex === 3? 'btn_true' : 'btn_false'" type="info"
								@click="onTimePeriodChange(3)">
						三个月
					</nut-button>
				</view>
				<view class="charts" v-if="!isEmpty(recordTableList) ">
					<ec-canvas id="chart-dom-area" canvas-id="chart-area" :ec="ec"
							   force-use-old-canvas="true"></ec-canvas>
				</view>
				<view v-else>
					<nut-empty image="https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/common/nodata.png"
							   description="暂时还没有数据哦~"></nut-empty>
				</view>
			</view>

			<view class="view_bg " style="margin-top: 20px">
				<text>身高体重数据</text>
				<view class="table">
					<nut-table :columns="columns" :data="recordTableList" bordered>
						<template #nodata>
							<div class="no-data"> 暂时还没有数据哦~</div>
						</template>
					</nut-table>
				</view>
			</view>
		</view>
		<scroll-view class="view_list" v-if="active ===  '1'" :scroll-y="true" @scrollToLower="scroll" flexed>
			<view v-if="!isEmpty(dataList)" class="view_item" v-for="(item, index) in dataList" :key="index">
				<view class="item_header">
					<text>{{ item.recordDate }}{{ item.recordWeek }}</text>
					<text></text>
				</view>
				<view class="item_content" v-for="(childItem,childIndex) in item.recordList"
					  :key="childItem.recordId">
					<view class="item_content_time">
						{{ childItem.recordTime }}
					</view>
					<view class="item_content_sub">
						<view class="item_bottom">
							<text>身高</text>
							<tag-text :is-normal="2" :sugarValue="childItem.height" :show-unity="'cm'"></tag-text>
						</view>
						<view class="item_bottom">
							<text>体重</text>
							<tag-text :is-normal="2" :sugarValue="childItem.weight" :show-unity="'kg'"></tag-text>
						</view>
						<view class="item_bottom">
							<text>BMI</text>
							<tag-text :is-normal="2" :sugarValue="childItem.bmi"></tag-text>
						</view>
						<view class="item_bottom">
							<text>腰围</text>
							<tag-text :is-normal="2" :sugarValue="childItem.waist" :show-unity="'cm'"></tag-text>
						</view>
						<view class="item_bottom">
							<text>腰臀比</text>
							<tag-text :is-normal="2" :sugarValue="childItem.whr"></tag-text>
						</view>
					</view>
				</view>

			</view>
			<view v-else class="view_no_data">
				<nut-empty image="https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/common/nodata.png"
						   description="暂时还没有数据哦~"></nut-empty>
			</view>
		</scroll-view>
	</view>
</template>
<script setup lang="ts">

import {reactive, ref} from "vue";
import TagText from "@/component/tag-text/tag-text.vue";
import {isEmpty} from "lodash";
import {BmiRecord, IBmiItem} from "@/pagesBmi/ts/types";
import BmiApi from "@/pagesBmi/api/BmiApi";
import * as echarts from "@/component/ec-canvas/echarts";
import {categoryBMIChartOptions, categoryHba1cChartOptions, categoryPressureChartOptions} from "@/utils/chartOption";
import {createRender} from "@/utils/pubUtils";
import {formatDate2Hm} from "@/utils/dateUtils";
import Taro from "@tarojs/taro";


const active = ref('0')

/**
 * 默认页码
 */
const pageNum = ref(1);
/**
 * 列表数据
 */
const dataList = ref<Array<IBmiItem>>([] as IBmiItem[]);

const columns = [
	{
		title: '日期',
		key: 'recordTime',
		stylehead: 'font-size:10px;color:#666666; background:#EBF6FF;',
		stylecolumn: 'font-size:10px;color:#666666;',
		align: "center",
		render: (record) => createRender(record.dataId, record.recordTime, onTableItemClick)
	},
	{
		title: '身高',
		key: 'height',
		stylehead: 'font-size:10px;color:#666666; background:#EBF6FF;',
		stylecolumn: 'font-size:10px;color:#666666;',
		align: "center",
		render: (record) => createRender(record.dataId, record.height, onTableItemClick)
	},
	{
		title: '体重',
		key: 'weight',
		stylehead: 'font-size:10px;color:#666666; background:#EBF6FF;',
		stylecolumn: 'font-size:10px;color:#666666;',
		align: "center",
		render: (record) => createRender(record.dataId, record.weight, onTableItemClick)
	},
	{
		title: 'BMI',
		key: 'bmi',
		stylehead: 'font-size:10px;color:#666666; background:#EBF6FF;',
		stylecolumn: 'font-size:10px;color:#666666;',
		align: "center",
		render: (record) => createRender(record.dataId, record.bmi, onTableItemClick)
	},
	{
		title: '腰围',
		key: 'waist',
		stylehead: 'font-size:10px;color:#666666; background:#EBF6FF;',
		stylecolumn: 'font-size:10px;color:#666666;',
		align: "center",
		render: (record) => createRender(record.dataId, record.waist, onTableItemClick)
	},
	{
		title: '臀围',
		key: 'hip',
		stylehead: 'font-size:10px;color:#666666; background:#EBF6FF;',
		stylecolumn: 'font-size:10px;color:#666666;',
		align: "center",
		render: (record) => createRender(record.dataId, record.hip, onTableItemClick)
	},
	{
		title: '腰臀比',
		key: 'whr',
		stylehead: 'font-size:10px;color:#666666; background:#EBF6FF;',
		stylecolumn: 'font-size:10px;color:#666666;',
		align: "center",
		render: (record) => createRender(record.dataId, record.whr, onTableItemClick)
	},
]

const recordTableList = ref<BmiRecord[]>([] as BmiRecord[])
const recordChartList = ref<BmiRecord[]>([] as BmiRecord[])

const chart = ref();

function initChart(canvas: any, width: any, height: any) {

	// echarts.init初始化
	chart.value = echarts.init(canvas, null, {
		width,
		height
	})

	loadChart()
	return chart
}

const loadChart = () => {
	if (chart && chart.value && !isEmpty(recordChartList.value)) {
		// console.log("index.vue.loadChart.recordChartList=", JSON.stringify(recordChartList.value), '; recordTableList=', JSON.stringify(recordTableList.value));
		let list = recordChartList.value
		// console.log("index.vue.loadChart.list=", JSON.stringify(list));
		const option = categoryBMIChartOptions(list);
		console.log("index.vue.bmi.loadChart.",JSON.stringify(option));
		chart.value.setOption(option)
	}
}

const ec = reactive({
	onInit: initChart
})

/**
 * 时间周期按钮筛选状态
 * 1 两周
 * 2 一月
 * 3 三月
 */
const timePeriodIndex = ref(1)


/**
 * 切换曲线与列表标签
 */
const changeTab = (res) => {
	let {paneKey} = res
	if (paneKey == 0) {
		requestTimePeriodBmi()
	} else if (paneKey == 1) {
		requestBmiList()
	}
}

/**
 * 切换时间周期
 * @param index
 */
const onTimePeriodChange = (index) => {
	timePeriodIndex.value = index;
	requestTimePeriodBmi(true)
}

/**
 * loadmore
 */
const scroll = () => requestBmiList();

/**
 * 请求列表数据
 */
const requestBmiList = () => {
	BmiApi.getBmiList(pageNum.value).then(res => {
		if (pageNum.value === 1) dataList.value = [];
		if (!isEmpty(res.data)) {
			res.data.forEach(item=>{
				item.recordList?.forEach(t=>{
					t.recordTime = formatDate2Hm(t.recordTime)
				})
			})
			dataList.value?.push(...res.data);
			pageNum.value++;
		}
	})
}

// 曲线和表格
const requestTimePeriodBmi = (isLoadChart: boolean = false) => {
	BmiApi.getTimePeriodBmi(timePeriodIndex.value).then(res => {
		console.log("requestTimePeriodBmi.res.data=.", JSON.stringify(res.data));
		recordTableList.value = []
		recordTableList.value.push(...res.data)
		recordTableList.value.reverse()
		// recordChartList.value=[]
		recordChartList.value = res.data
		if (isLoadChart) {
			loadChart()
		}
	})
}

requestTimePeriodBmi()

Taro.eventCenter.on('login', (item) => {
	requestTimePeriodBmi()
})


const onTableItemClick = (param) => {
	console.log("index.vue.onTableItemClick.", param);
}

</script>
<style lang="less">
.view_root {
	background: #efefef;
	position: relative;
	height: 100vh;

	.tab {
		position: fixed;
		width: 100%;
		z-index: 10;
		height: 100px;
		top: 0;
	}

	.view_list {
		padding-top: 100px;
		height: calc(100vh - 100px);

		.view_item {
			background: white;
			border-radius: 20px;
			display: flex;
			padding: 20px;
			flex-direction: column;
			margin: 20px 30px;

			.item_header {
				display: flex;
				flex-direction: row;
				justify-content: space-between;
				align-items: center;
				padding-bottom: 10px;
				color: #666666;
				border-bottom: #efefef 1px solid;;
			}

			.item_content {
				display: flex;
				flex-direction: row;
				color: #333333;
				border-bottom: #efefef 1px solid;;

				&:last-child:not(:first-child) {
					border-bottom: none;
				}

				.item_content_time{
					width: calc(33.33% - 10px);
					padding-top: 20px;
				}

				.item_content_sub {
					display: flex;
					width: calc(66.66% - 10px);
					flex-direction: column;
					justify-content: space-between;

					.item_bottom {
						display: flex;
						margin-top: 20px;
						flex-direction: row;
						justify-content: space-between;
					}
				}
			}
		}

	}

	.view_no_data {
		height: 100vh;
		padding-top: 150px;

		.nut-empty__box {
			width: 440px;
			height: 260px
		}
	}

	.view_charts {
		padding-top: 100px;
		height: 100vh;
		flex: 1;
		margin: 30px;

		.view_bg {
			display: flex;
			background: white;
			padding: 30px;
			border-radius: 15px;
			flex-direction: column;

			.view_btn {
				border: 10px;
				width: 100%;
				display: flex;
				justify-content: space-around;
				align-items: center;

				.btn_true {
					width: 160px;
					height: 70px;
					background: #0099ff;
					color: #ffffff;
					border: #0099ff solid 1px;
				}

				.btn_false {
					width: 160px;
					height: 70px;
					color: #0099ff;
					background: #ffffff;
					border: #0099ff solid 1px;
				}


			}

			.nut-empty__box {
				width: 330px;
				height: 195px
			}

			.charts {
				position: relative;
				height: 480px;
			}

			.table {

			}
		}


	}

	.sugar_tab {
		margin-top: 20px;
	}
}

.view_btn_bom {
	display: flex;
	justify-content: center;
	align-items: center;
	text-align: center;
	line-height: 60px;
	font-size: 30px;
	margin-top: 50px;

	.btn_left_round_true {
		border-radius: 35px 0 0 35px;
		background: #0099ff;
		height: 60px;
		width: 160px;
		color: white;
		border: #0099ff 1px solid;
	}

	.btn_left_round_false {
		border-radius: 35px 0 0 35px;
		background: white;
		color: #0099ff;
		height: 60px;
		width: 160px;
		border: #0099ff 1px solid;
	}

	.btn_m_round_true {
		background: #0099ff;
		color: white;
		height: 60px;
		border-radius: 0;
		width: 160px;
		border: #0099ff 1px solid;
	}

	.btn_m_round_false {
		background: white;
		color: #0099ff;
		border-radius: 0;
		height: 60px;
		width: 160px;
		border: #0099ff 1px solid;
	}

	.btn_r_round_true {
		border-radius: 0 35px 35px 0;
		background: #0099ff;
		color: white;
		height: 60px;
		width: 160px;
		border: #0099ff 1px solid;
	}

	.btn_r_round_false {
		border-radius: 0 35px 35px 0;
		background: white;
		height: 60px;
		width: 160px;
		color: #0099ff;
		border: #0099ff 1px solid;
	}
}

.table {
	margin-top: 20px;
}

</style>
