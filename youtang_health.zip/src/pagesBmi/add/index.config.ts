export default definePageConfig({
    navigationBarTitleText: "记身高体重",
});
