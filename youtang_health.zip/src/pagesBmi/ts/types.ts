/**
 * Description：
 * Created on 2023/7/20
 * Author :  郭
 */

export interface IBmiChildItem {
    recordId: number;
    recordTime: string;
    remark: string;
    height: number;//身高
    weight: number;//体重
    waist: number;//腰围
    hip: number;//臀围
    bmi: number;
    whr: number;//腰臀比
}


export interface IBmiItem {
    recordDate: string;
    recordWeek: string;
    recordList: IBmiChildItem[];
}

export interface BmiRecord {
    dataId: number;
    patientId: number;
    height?: number;
    weight?: number;
    bmi?: number;
    waist?: number;
    hip?: number;
    whr?: number;
    recordDate: string;
    recordTime: string;
    remark?: string;
}
