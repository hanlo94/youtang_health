<template>
  <view class="section_6-0">
    <view :class="statusClass()" v-if="status != undefined && status != -1">{{ statusDescription }}</view>
    <view class="value_group horizon_align">
      <text lines="1" class="text_normal">{{ label }}{{}}</text>
      <text lines="1" class="text_big ">{{ value }}</text>
      <text lines="1" :class="lower && upper ? 'text_normal' : 'text_gray'" v-if="rangeState">{{range()}}</text>
    </view>
  </view>
</template>

<script setup lang="ts">

type Props = {
  label: string;
  value: string | number;
  status?: number;
  statusDescription?: string;
  lower?: number | undefined;
  upper?: number | undefined;
  rangeState?: boolean;
}
const props = withDefaults(defineProps<Props>(), {
  rangeState: true,
})

const statusClass = () => {
  if (props.status ==undefined  || props.status == 1) {
    return 'mark mark_status_normal';
  } else {
    return 'mark mark_status_high';
  }
}

const range=()=>{
  if(props.upper && props.lower){
    return `正常范围 ：${props.lower}-${props.upper}`
  }else{
    return "  --- "
  }
}

</script>


<style lang="less">

.section_6-0 {
  background-color: #f8f8f8;
  border-radius: 16.67rpx;
  display: flex;
  width: 100%;
  margin-top: 20.83rpx;
  flex-direction: column;
}

.horizon_align {
  horiz-align: center;
}

.value_group {
  display: flex;
  flex-direction: column;
  margin-top: 29.17rpx;
  margin-bottom: 29.17rpx;
  justify-content: space-between;

  .text_big {
    overflow-wrap: break-word;
    color: #5F5F5F;
    font-size: 34.72rpx;
    text-align: center;
    margin-top: 12.5rpx;
    font-weight: 600;
    margin-bottom: 12.5rpx;
    white-space: nowrap;
  }

  .text_normal {
    overflow-wrap: break-word;
    color: #5F5F5F;
    font-size: 25rpx;
    text-align: center;
    white-space: nowrap;
  }
  .text_gray {
    overflow-wrap: break-word;
    color: #f8f8f8;
    font-size: 25rpx;
    text-align: center;
    white-space: nowrap;
  }

}

.mark {
  position: absolute;
  top: 20.83rpx;
  left: 0;
  border-radius: 16.67rpx 0 8rpx 0;
  font-size: 25rpx;
  padding-left: 6rpx;
  padding-right: 6rpx;
  color: white;
}

.mark_status_high {
  background-color: #DD3542;
}

.mark_status_normal {
  background-color: #64A4F5;
}

.test_item_view {
  display: flex;
  justify-content: center;
  background-color: #f8f8f8;
  border-radius: 16.67rpx;
  flex-direction: row;
  position: relative;

  .mark {
    position: absolute;
    margin-top: 20.83rpx;
    top: 0;
    left: 0;
    border-radius: 16.67rpx 0 8rpx 0;
    font-size: 25rpx;
    color: white;
  }

  .mark_status_high {
    background-color: #DD3542;
  }

  .mark_status_normal {
    background-color: #64A4F5;
  }

  .value_container {
    display: flex;
    position: absolute;
    left: 50%;
    transform: translateX(-50%);
    flex-direction: column;
    justify-content: center;
    justify-items: center;

    .label {

      color: #282828;
      font-size: 28rpx;
    }

    .value {

      color: rgba(0, 0, 0, 0.45);
      font-size: 30rpx;
    }

  }


}
</style>
