<template>
  <nut-circle-progress :progress="percentage" color="#4aa4fc" :stroke-width="10" :radius="70">
    <view class="vertical-container" >
      <text class="text-normal">您的评分</text>
      <text class="text-blue-big">{{ percentage }}</text>
      <text class="text-normal">{{ bodyShape }}</text>
    </view>
  </nut-circle-progress>
</template>

<script>
export default {
  name: 'CircularProgress',
  props: {
    percentage: {
      type: Number,
      required: true,
    },
    bodyShape: {
      type: String,
      required: true,
    },

  },
  computed: {}
};
</script>

<style >

.text-normal {
  font-size: 33rpx;
  color: #5F5F5F;
  text-align: center;
}

.text-blue-big{
  font-weight: 600;
  font-size: 56rpx;
  color: #64A4F5;
  margin-top: 32rpx;
  margin-bottom: 32rpx;
  line-height: 40rpx;
  text-align: center;
  font-style: normal;
  text-transform: none;
}

</style>
