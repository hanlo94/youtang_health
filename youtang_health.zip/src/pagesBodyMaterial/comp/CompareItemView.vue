<template>
  <!--  <view class="horizon-container ">-->
  <!--    <view class="vertical-container-center" style="width:37%">-->
  <!--      <text class="text-value">{{ item?.leftValue }}</text>-->
  <!--      <view class="horizon-container-center">-->
  <!--        <text class=" text-label text-color-white text-status-padding margin   width-auto"-->
  <!--              :class="stateColor(item?.leftValueState)"-->
  <!--              v-if="item?.leftValueStateDesc">-->
  <!--          {{ item?.leftValueStateDesc }}-->
  <!--        </text>-->
  <!--      </view>-->
  <!--      <view class="dashed-border margin" v-if="showDash"/>-->
  <!--    </view>-->

  <!--    <view class="vertical-container-center" style="width:36%">-->
  <!--      <text class="text-label text-normal">{{ item?.label }}</text>-->
  <!--      <view class="horizon-container-center margin">-->
  <!--        <IconFont size=13 :name="statusIcon()" v-if="item?.changeValue"></IconFont>-->
  <!--        <text class="text-label text-normal" style="margin-left: 12rpx">{{ wrapChangeValue(item?.changeValue) }}</text>-->
  <!--      </view>-->
  <!--    </view>-->

  <!--    <view class="vertical-container-center" style="width:37%">-->
  <!--      <text class="text-value">{{ item?.rightValue }}</text>-->
  <!--      <view class="horizon-container-center">-->
  <!--        <text class=" text-label text-color-white text-status-padding margin  width-auto"-->
  <!--              :class="stateColor(item?.rightValueState)"-->
  <!--              v-if="item?.rightValueStateDesc">-->
  <!--          {{ item?.rightValueStateDesc }}-->
  <!--        </text>-->
  <!--      </view>-->
  <!--      <view class="dashed-border margin" v-if="showDash"/>-->
  <!--    </view>-->

  <!--  </view>-->

  <view class="vertical-container ">
    <view class="horizon-container-center margin">
      <text class="text-value width-34">{{ item?.leftValue }}</text>
      <text class="text-label text-normal width-33">{{ item?.label }}</text>
      <text class="text-value width-34">{{ item?.rightValue }}</text>
    </view>
    <view class="horizon-container-center margin" v-if="item?.leftValueStateDesc || item?.rightValueStateDesc">
      <view class="horizon-container-center width-34" >
        <text class=" text-label text-color-white text-status-padding    width-auto"
              :class="stateColor(item?.leftValueState)"
              v-if="item?.leftValueStateDesc">
          {{ item?.leftValueStateDesc }}
        </text>
      </view>
      <view class="horizon-container-center width-33" >
        <IconFont size=13 :name="statusIcon()" v-if="item?.changeValue"></IconFont>
        <text class="text-label text-normal" style="margin-left: 12rpx">{{ wrapChangeValue(item?.changeValue) }}</text>
      </view>
      <view class="horizon-container-center width-34">
        <text class=" text-label text-color-white text-status-padding width-auto"
              :class="stateColor(item?.rightValueState)"  v-if="item?.rightValueStateDesc">
          {{ item?.rightValueStateDesc }}
        </text>
      </view>

    </view>
    <view class="horizon-container  margin" v-if="showDash">
      <view class="dashed-border width-34" />
      <view class="width-33"/>
      <view class="dashed-border width-34" />
    </view>

  </view>
</template>

<script>
import {IconFont} from "@nutui/icons-vue-taro";
import imgUrlFormat from "@/utils/imgUtils";
import {BmCompareItemSubItems} from "@/pagesBodyMaterial/types";

export default {
  name: 'CompareItemView',
  methods: {imgUrlFormat},
  components: {IconFont},
  props: {
    label: {
      type: String,
      required: false,
    },
    showDash: {
      type: Boolean,
      required: false,
      default: true
    },
    changeValue: {
      type: String,
      required: false,
    },
    leftValue: {
      type: String,
      required: false,
    },
    leftValueState: {
      type: Number,
      required: false,
    },
    leftValueStateDesc: {
      type: String,
      required: false,
    },
    rightValue: {
      type: String,
      required: false,
    },
    rightValueState: {
      type: Number,
      required: false,
    },
    rightValueStateDesc: {
      type: String,
      required: false,
    },
    item: {
      type: BmCompareItemSubItems
    }

  },
  computed: {},
  data() {
    return {
      statusIcon: () => {
        if (this.item?.changeValue > 0) {
          return imgUrlFormat('sugar/arrow_up.png')
        } else if (this.item?.changeValue < 0) {
          return imgUrlFormat('sugar/arrow_down.png')
        } else {
          return ''
        }
      },
      stateColor: (state) => {
        // noinspection EqualityComparisonWithCoercionJS
        if (state == undefined || state == 1) {
          return 'item-status-blue'
        } else {
          return 'item-status-red'
        }
      },
      wrapChangeValue: (changeValue) => {
        if (!this.item?.leftValue || !this.item?.rightValue) {
          return ''
        } else {
          if (!changeValue) {
            return ''
          } else {
            if (changeValue.toString().length > 4) {
              return changeValue.toFixed(2)
            } else {
              return changeValue
            }
          }
        }
      }
    }
  }
};
</script>


<style lang="less">
@import "../bm.less";

.dashed-border {
  border-width: 1px;
  border-color: #BBBBBB;
  border-bottom-style: dashed;
  height: 1px;
}

.width-33 {
  width: 33%;
}

.width-34 {
  width: 34%;
}

.text-status-padding {
  padding-left: 12rpx;
  padding-right: 12rpx;
}

.item-status-blue {
  border-radius: 24rpx;
  background-color: #4aa4fc;
}

.item-status-red {
  border-radius: 24rpx;
  background-color: #DD3542;
}

.text-value {
  font-size: 34.72rpx;
  color: var(text-color-dark-5f5f5f);
  font-weight: 600;
}

.text-label {
  font-size: 25rpx;
  color: var(text-color-dark-5f5f5f);
}

.margin {
  margin-top: 12rpx;
}

</style>