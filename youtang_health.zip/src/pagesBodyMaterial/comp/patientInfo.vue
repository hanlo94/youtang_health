<template>
  <view class="user-info">
    <nut-avatar size="large" shape="round">
      <img :src="avatar"/>
    </nut-avatar>
    <view class="info-container">
      <view class="name">{{ name }}</view>
      <view class="additional-info">
        <view class="gender">{{ gender == 1 ? "男" : "女" }} | {{ age }}岁 | 病程7年 | 2型</view>
      </view>
    </view>
  </view>
</template>

<script setup lang="ts">
type Props = {
  name: string;
  gender: string;
  age: number;
  avatar: string
}
const props = withDefaults(defineProps<Props>(), {})
</script>

<style lang="less">
.user-info {
  display: flex;
  align-items: center;

  .avatar {
    width: 100%;
    height: 100%;
    border-radius: 50%; /* 圆形头像 */
  }

  .info-container {
    flex: 1;
    margin-left: 16.67rpx;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
  }

  .name {
    font-weight: normal;
    color: #282828;
    font-size: 33.33rpx;
    line-height: 40rpx;
  }

  .additional-info {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;

    .gender
    {
      font-size: 29.17rpx;
      font-weight: normal;
      color: #5F5F5F;
    }
  }
}
</style>
