<template>
  <view class="test-title-container">
    <text>{{title}}</text>
<!--    <IconFont size=16 :name="imgUrlFormat('sugar/icon_tip_gray_circle.png')"></IconFont>-->
  </view>
</template>

<script setup lang="ts">
import imgUrlFormat from "@/utils/imgUtils";
import {IconFont} from "@nutui/icons-vue-taro";

type Props = {
  title: string;
}
const props = withDefaults(defineProps<Props>(), {})

</script>


<style lang="less">

.test-title-container {
  display: flex;
  flex-direction: row;
  justify-content: left;
  align-items: center;
  align-content: center;
  box-sizing: border-box;


  text {
    margin-right: 20rpx;
    font-size: 33.33rpx;
  }
}

</style>
