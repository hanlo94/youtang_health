export default definePageConfig({
    navigationBarTitleText: "人体成分分析",
    usingComponents:{

    }
});
