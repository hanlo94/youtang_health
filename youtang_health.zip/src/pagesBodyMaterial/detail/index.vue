<template>
  <view class="container_bm">
    <scroll-view class="bm_list" :scrollY="true" show-scrollbar="{{false}}" flexed>

<!--      <PatientInfoView :avatar="record.avatar" :name="record.name"-->
<!--                       :gender="record.gender"-->
<!--                       :age="record.age" class="item-shape-round-white item_divider"/>-->

      <view class="vertical-container item-shape-round-white item_divider health-score">
        <view class="horizon-container">
          <TestTitleView title="健康评分"/>
          <text class="record-time">{{ record.recordDateWeek }} {{ record.recordTime }}</text>
        </view>
        <view class="horizon-container health-score">
          <view class="info-view">
            <text class="text-label">年龄</text>
            <text class="text-value">{{ record.age }}</text>
          </view>
          <CircularProgress :percentage="record.score" :body-shape="record.bodyShapeDescription"/>
          <view class="info-view">
            <text class="text-label">身高</text>
            <text class="text-value">{{ record.height }}</text>
          </view>
        </view>
      </view>

      <view class="item-shape-round-white vertical-container item_divider">
        <TestTitleView title="身体成分"/>
        <nut-grid :column="2" :gutter="3" :border="false" :direction="'horizontal'" :column-num="2">
          <nut-grid-item class="override-grid-item">
            <TestItemView label="体重(kg)" :value="record.weight" :lower="record.stdWeightLower"
                          :upper="record.stdWeightUpper" :status="record.weightState"
                          :status-description="record.weightStateDescription"/>
          </nut-grid-item>
          <nut-grid-item class="override-grid-item">
            <TestItemView label="BMI(kg/㎡)" :value="record.bmi" :lower="record.stdBmiLower"
                          :upper="record.stdBmiUpper" :status="record.bmiState"
                          :status-description="record.bmiStateDescription"/>
          </nut-grid-item>
          <nut-grid-item class="override-grid-item">
            <TestItemView label="体脂率(%)" :value="record.bodyFat" :lower="record.stdBodyFatLower"
                          :upper="record.stdBodyFatUpper" :status="record.bodyFatState"
                          :status-description="record.bodyFatStateDescription"/>
          </nut-grid-item>
          <nut-grid-item class="override-grid-item">
            <TestItemView label="内脏脂肪等级" :value="record.visFatValue"
                          :upper="record.stdVisFatUpper" :status="record.visFatState"
                          :status-description="record.visFatStateDescription"/>
          </nut-grid-item>
          <nut-grid-item class="override-grid-item">
            <TestItemView label="骨骼肌(Kg)" :value="record.muscle" :lower="record.stdMuscleLower"
                          :upper="record.stdMuscleUpper" :status="record.muscleState"
                          :status-description="record.muscleStateDescription"/>
          </nut-grid-item>
          <nut-grid-item class="override-grid-item">
            <TestItemView label="基础代谢(kcal)" :value="record.bmr" :lower="record.stdBmrLower"
                          :upper="record.stdBmrUpper" :status="record.bmrState"
                          :status-description="record.bmrStateDescription"/>
          </nut-grid-item>
        </nut-grid>
      </view>

      <view class="item-shape-round-white vertical-container item_divider">
        <TestTitleView title="营养评估"/>
        <nut-grid :column="2" :gutter="3" :border="false" :direction="'horizontal'" :column-num="2">
          <nut-grid-item class="override-grid-item">
            <TestItemView label="体水分(L)" :value="record.water" :lower="record.stdWaterLower"
                          :upper="record.stdWaterUpper" :status="record.waterState"
                          :status-description="record.waterStateDescription"/>
          </nut-grid-item>
          <nut-grid-item class="override-grid-item">
            <TestItemView label="脂肪(kg)" :value="record.fat" :lower="record.stdFatLower" :upper="record.stdFatUpper"
                          :status="record.fatState" :status-description="record.fatStateDescription"/>
          </nut-grid-item>
          <nut-grid-item class="override-grid-item">
            <TestItemView label="蛋白质" :value="record.protein" :lower="record.stdProteinLower"
                          :upper="record.stdProteinUpper" :status="record.proteinState"
                          :status-description="record.proteinStateDescription"/>
          </nut-grid-item>
          <nut-grid-item class="override-grid-item">
            <TestItemView label="无机盐" :value="record.bone" :lower="record.stdBoneLower" :upper="record.stdBoneUpper"
                          :status="record.boneState" :status-description="record.boneStateDescription"/>
          </nut-grid-item>
        </nut-grid>
      </view>

      <view class="item-shape-round-white vertical-container item_divider human">
        <TestTitleView title="肌肉均衡"/>
        <view class="value-container">
          <image class="background" :src="imgUrlFormat('sugar/human.png')"/>
          <view class="horizon-container value">
            <view class="vertical-container left">
              <view class="vertical-container  align-left">
                <view class="test-item-container">
                  <IconFont size=13 :name="imgUrlFormat('sugar/icon_arm.png')"></IconFont>
                  <text class="value-text-default-big left-item-margin">左上肢</text>
                  <text class="text-color-white text-status value-text-default-middle"
                        :class="statusClass(record.leftArmMuscleState)">{{ record.leftArmMuscleStateDescription }}
                  </text>
                </view>
                <view class="test-item-container item-divider">
                  <text>与标准比：</text>
                  <text class="text-bold">{{ record.leftArmMuscleRatio }}%</text>
                </view>
                <view class="test-item-container ">
                  <text>肌肉量：</text>
                  <text class="text-bold">{{ record.leftArmMuscle }}Kg</text>
                </view>
              </view>

              <view class="vertical-container  align-left">
                <view class="test-item-container">
                  <IconFont size=13 :name="imgUrlFormat('sugar/icon_body.png')"></IconFont>
                  <text class="value-text-default-big left-item-margin">躯干</text>
                  <text class=" text-color-white text-status" :class="statusClass(record.torsoMuscleState)">
                    {{ record.torsoMuscleStateDescription }}
                  </text>
                </view>
                <view class="test-item-container item-divider">
                  <text>与标准比：</text>
                  <text class="text-bold">{{ record.torsoMuscleRatio }}%</text>
                </view>
                <view class="test-item-container ">
                  <text>肌肉量：</text>
                  <text class="text-bold">{{ record.torsoMuscle }}Kg</text>
                </view>
              </view>

              <view class="vertical-container align-left">
                <view class="test-item-container">
                  <IconFont size=13 :name="imgUrlFormat('sugar/icon_leg.png')"></IconFont>
                  <text class="value-text-default-big left-item-margin">左下肢</text>
                  <text class=" text-color-white text-status" :class="statusClass(record.leftLegMuscleState)">
                    {{ record.leftLegMuscleStateDescription }}
                  </text>
                </view>
                <view class="test-item-container item-divider ">
                  <text>与标准比：</text>
                  <text class="text-bold">{{ record.leftLegMuscleRatio }}%</text>
                </view>
                <view class="test-item-container ">
                  <text>肌肉量：</text>
                  <text class="text-bold">{{ record.leftLegMuscle }}Kg</text>
                </view>
              </view>
            </view>
            <view class="vertical-container right">
              <view class="vertical-container align-right">
                <view class="test-item-container">
                  <text class=" text-color-white text-status" :class="statusClass(record.rightArmMuscleState)">
                    {{ record.rightArmMuscleStateDescription }}
                  </text>
                  <text class="value-text-default-big right-item-margin">右上肢</text>
                  <IconFont size=13 :name="imgUrlFormat('sugar/icon_arm.png')"></IconFont>
                </view>
                <view class="test-item-container item-divider">
                  <text>与标准比：</text>
                  <text class="text-bold">{{ record.rightArmMuscleRatio }}%</text>
                </view>
                <view class="test-item-container ">
                  <text>肌肉量：</text>
                  <text class="text-bold">{{ record.rightArmMuscle }}Kg</text>
                </view>
              </view>
              <view class="vertical-container align-right">
                <view class="test-item-container">
                  <text class="text-color-white text-status" :class="statusClass(record.rightLegMuscleState)">
                    {{ record.rightLegMuscleStateDescription }}
                  </text>
                  <text class="value-text-default-big right-item-margin">右下肢</text>
                  <IconFont size=13 :name="imgUrlFormat('sugar/icon_leg.png')"></IconFont>
                </view>
                <view class="test-item-container item-divider">
                  <text>与标准比：</text>
                  <text class="text-bold">{{ record.rightLegMuscleRatio }}%</text>
                </view>
                <view class="test-item-container ">
                  <text>肌肉量：</text>
                  <text class="text-bold">{{ record.rightLegMuscle }}Kg</text>
                </view>
              </view>
            </view>
          </view>
        </view>
        <view class="horizon-container arm_leg">
          <view class="item-bg vertical-container divider">
            <text class="text-normal text-color-dark-5f5f5f">上肢</text>
            <text class=" text-color-white text-status-arm-leg" :class="statusClass(record.armSinewLimbBalance)">
              {{ record.armSinewLimbBalanceDescription }}
            </text>
          </view>
          <view class="item-bg vertical-container divider">
            <text class="text-normal text-color-dark-5f5f5f">下肢</text>
            <text class=" text-color-white text-status-arm-leg" :class="statusClass(record.legSinewLimbBalance)">
              {{ record.legSinewLimbBalanceDescription }}
            </text>
          </view>
          <view class="item-bg vertical-container ">
            <text class="text-normal text-color-dark-5f5f5f">上下肢</text>
            <text class=" text-color-white text-status-arm-leg" :class="statusClass(record.armLegSinewLimbBalance)">
              {{ record.armLegSinewLimbBalanceDescription }}
            </text>
          </view>
        </view>
      </view>

      <view class="item-shape-round-white vertical-container item_divider">
        <TestTitleView title="附加数据"/>
        <nut-grid :column="2" :gutter="3" :border="false" :direction="'horizontal'" :column-num="2">
          <nut-grid-item class="override-grid-item">
            <TestItemView label="皮下脂肪率(%)" :value="record.subFat" :lower="record.stdSubFatLower"
                          :upper="record.stdSubFatUpper" :status="record.subFatState"
                          :status-description="record.subFatStateDescription"/>
          </nut-grid-item>
          <nut-grid-item class="override-grid-item">
            <TestItemView label="去脂体重(kg)" :value="record.lbm" :lower="record.stdLbmLower"
                          :upper="record.stdLbmUpper" :status="record.lbmState"
                          :status-description="record.lbmStateDescription"/>
          </nut-grid-item>
          <nut-grid-item class="override-grid-item">
            <TestItemView label="肌肉量(kg)" :value="record.sinew" :lower="record.stdSinewLower"
                          :upper="record.stdSinewUpper" :status="record.sinewState"
                          :status-description="record.sinewStateDescription"/>
          </nut-grid-item>
          <nut-grid-item class="override-grid-item">
            <TestItemView label="体年龄(岁)" :value="record.bodyAge"/>
          </nut-grid-item>
        </nut-grid>
      </view>

      <view class="item-shape-round-white vertical-container item_divider">
        <TestTitleView title="控制指标"/>
        <nut-grid :column="2" :gutter="3" :border="false" :direction="'horizontal'" :column-num="2">
          <nut-grid-item class="override-grid-item">
            <TestItemView label="目标体重(Kg)" :rangeState="false" :value="record.weightTarget"/>
          </nut-grid-item>
          <nut-grid-item class="override-grid-item">
            <TestItemView label="体重控制(Kg)" :value="record.weightControl" :rangeState="false"/>
          </nut-grid-item>
          <nut-grid-item class="override-grid-item">
            <TestItemView label="脂肪控制(Kg)" :value="record.fatControl" :rangeState="false"/>
          </nut-grid-item>
          <nut-grid-item class="override-grid-item">
            <TestItemView label="肌肉控制(Kg)" :value="record.sinewControl" :rangeState="false"/>
          </nut-grid-item>
        </nut-grid>
      </view>

      <view class="item_divider">
        <text class="text-color-dark-5f5f5f item_declare">
          注:所有指标均是通过设备(体脂秤)测量人体生物电阻抗后，结合人体成分组成得出，数值仅作为控制体型和长期健身参考使用，不作为医疗诊断的依据。
        </text>
      </view>

    </scroll-view>

  </view>

</template>
<script setup lang="ts">
import {ref} from "vue";
import Taro from "@tarojs/taro";
import {IconFont} from '@nutui/icons-vue-taro';
import CircularProgress from '../comp/CircularProgress.vue'
import PatientInfoView from '../comp/patientInfo.vue'
import TestItemView from '../comp/testItemView.vue'
import TestTitleView from '../comp/testTitleView.vue'
import imgUrlFormat from "@/utils/imgUtils";
import {getCurrentInstance} from "@tarojs/runtime";
import {BodyMaterialApi} from "@/pagesBodyMaterial/bodyMaterial";
import {IBodyMaterialDetail} from "@/pagesBodyMaterial/types";
import {formatDate2Hm, formatDate2YmdWeek} from "@/utils/dateUtils";


const params = Taro.getCurrentInstance().router?.params;
console.log('params', params)

const {dataId} = (getCurrentInstance().router?.params)
console.log('detail.index..dataId=', dataId)

const record = ref<IBodyMaterialDetail>({} as IBodyMaterialDetail)

const getBmDetail = () => {

  BodyMaterialApi.getBodyMaterialDetail(dataId).then(res => {
        console.log('index.response=.', JSON.stringify(res))
        res.data.visFatValue = "等级" + res.data.visFat
        res.data.recordDateWeek = formatDate2YmdWeek(res.data.recordTime!)
        res.data.recordTime = formatDate2Hm(res.data.recordTime!)
        record.value = res.data
      }
  )
}

getBmDetail();

const statusClass = (state) => {
  if (state == undefined || state == 1) {
    return 'item-status-blue'
  } else {
    return 'item-status-red'
  }
}

</script>
<style lang="less">
.container_bm {
  height: 100vh;
  padding: 21px 28px 21px 28px;
  display: flex;
  background-color: #f8f8f8;
  flex-direction: column;

  .list {
    flex: 1;
    min-height: 100vh;
    //overflow-y: auto;
    //padding: 28px 0;
    .item {
      margin-bottom: 28px;
    }
  }

  .item-shape-round-white {
    border-radius: 16.67rpx;
    background-color: white;
    width: 100%;
    padding: 27.08rpx 20.83rpx;
    height: auto;
  }

  .item-status-blue {
    border-radius: 24rpx;
    background-color: #4aa4fc;
  }

  .item-status-red {
    border-radius: 24rpx;
    background-color: #DD3542;
  }

  .item_divider {
    margin-top: 28rpx;
  }

  .record-time {
    font-size: 29.17rpx;
    color: var(text-color-dark-5f5f5f)
  }

  .health-score {

    margin-top: 27rpx;

    .info-view {
      width: 25%;
      display: flex;
      flex-direction: column;
      box-sizing: border-box;
      justify-content: center;
      justify-items: center;
      justify-self: center;

      text {
        text-align: center;
        line-height: 40.28rpx;
      }

      .text-label {
        font-size: 33.33rpx;
        color: var(text-color-dark-5f5f5f)
      }

      .text-value {
        font-size: 34.72rpx;
        color: #4aa4fc;
        margin-top: 35.42rpx;
        font-weight: 600;
      }


    }
  }

  .override-grid-item {
    --nut-grid-item-content-padding: 0;
    --nut-grid-item-content-bg-color: rgba(0, 0, 0, 0);
  }

  .human {
    height: 960rpx;
    overflow: auto;


    .value-container {
      display: flex;
      position: relative;
      width: 100%;
      margin-top: 29.17rpx;
      height: 666rpx;

      .background {
        width: 100%;
        height: 663rpx;
        position: absolute;
        top: 0;
        left: 0;
      }

      .value {
        position: absolute;
        width: 100%;
        margin-top: 29.17rpx;
        height: 84%;
        top: 0;
        left: 0;

        text {
          color: var(text-color-dark-5f5f5f);
          font-size: 22.22rpx;
          line-height: 31.25rpx
        }

        .value-text-default-big {
          color: var(text-color-dark-5f5f5f);
          font-size: 29.17rpx;
        }

        .value-text-default-middle {
          font-size: 25rpx;
        }

        .text-bold {
          font-weight: 600;
        }

        .text-status {
          padding-left: 12rpx;
          padding-right: 12rpx;
        }

        .left-item-margin {
          margin-left: 6rpx;
          margin-right: 10rpx;
        }

        .right-item-margin {
          margin-left: 10rpx;
          margin-right: 6rpx;
        }


        .test-item-container {
          display: flex;
          flex-direction: row;
          box-sizing: border-box;
        }

        .item-divider {
          margin-top: 12rpx;
          margin-bottom: 10rpx;
        }

        .align-left {
          justify-content: flex-start;
          align-items: center;

          view {
            align-self: flex-start;
            align-items: center;
          }
        }

        .align-right {
          justify-content: flex-end;
          align-items: center;

          view {
            align-self: flex-end;
            align-items: center;
          }
        }


        .left {
          height: 100%;
          align-items: flex-start;
          align-content: flex-start;
          text-align: start;
        }

        .right {
          height: 100%;
          align-items: flex-end;
          align-content: flex-end;
          text-align: end;
        }

      }
    }

    .arm_leg {
      margin-top: 27rpx;
      width: 100%;
      align-items: center;
      align-content: center;


      .item-bg {
        background-color: #f8f8f8;
        border-radius: 16.67rpx;
        padding-top: 28rpx;
        width: 100%;
        display: flex;
        padding-bottom: 28rpx;
        align-content: center;
        align-items: center;
        flex-direction: column;

        .text-normal {
          font-size: 29.17rpx;
          text-align: center;
          align-content: center;
        }

        .text-status-arm-leg {
          padding-left: 16rpx;
          padding-right: 16rpx;
          align-content: center;
          margin-top: 29.17rpx;
          text-align: center;
          font-size: 25rpx;
          width: auto;
        }

      }

      .divider {
        margin-right: 20.83rpx;
      }

    }
  }

  .item_declare {
    font-size: 22.22rpx;
  }

}
</style>
