export default definePageConfig({
    navigationBarTitleText: "人体成分分析记录",
    usingComponents:{

    }
});
