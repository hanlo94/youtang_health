<template>
  <view class="container_bm">

    <view class="notice" v-if="showMulti">请选择2组数据进行对比，更好地了解自身身体状况</view>


    <img :src="imgCompare" class="floating-icon" v-if="!showMulti" @click="onShowMulti()"/>

    <view class="floating-btn" v-else-if="selList.length>0" @click="onSelection">
      开始对比{{ selList.length > 0 ? '(' + selList.length + ')' : '' }}
    </view>

    <scroll-view class="bm_list" :scrollY="true" show-scrollbar="{{false}}" @scrollToLower="scroll" flexed
                 @scrollToUpper="refresh" :refresherThreshold="50"
                 :lowerThreshold="150">
      <template v-for="item in list" :key="item.dataId">
        <view class="item" @click.stop="onItemSelect(item)">
          <view class="item_date_time">
            <view class="item_date_selector">
              <view v-if="showMulti">
                <img class="img_check" :src="imgCheckTrue" v-if="item.checked"/>
                <img class="img_check" :src="imgCheckFalse" v-else/>
              </view>
              <text>{{ item.ymdWeek }}</text>
            </view>
            <text>{{ item.hm }}</text>
          </view>

          <view class="item_divider_line"/>

          <view class="list_score">
            <text class="text_title">健康评分：</text>
            <text class="text_value">{{ item.score }}</text>
            <text class="text_title">/100分</text>
          </view>
          <view class=" text-wrapper">
            <text class="text_title">体重：</text>
            <text class="text_value">{{ item.weight }}</text>
            <text class="text_title">kg</text>
            <text class="text_title"> 体脂率：</text>
            <text class="text_value">{{ item.bodyFat }}</text>
            <text class="text_title">%</text>
          </view>
        </view>
      </template>

      <NoData v-if="showEmpty"></NoData>
      <view v-else v-show="showFinish" class="on_the_bottom">已经到底了</view>
    </scroll-view>

  </view>

</template>
<script setup lang="ts">
import {computed, onMounted, reactive, ref, watch} from "vue";
import debounce from "lodash/debounce";
import {showShortToast} from "@/utils/util";
import Taro from "@tarojs/taro";
import PageNavigation from "@/utils/pageNavigation";
import NoData from '@/component/noData/index.vue'
import imgUrlFormat from "@/utils/imgUtils";
import {BodyMaterialApi} from "@/pagesBodyMaterial/bodyMaterial";
import {formatDate2Hm, formatDate2YmdWeek} from "@/utils/dateUtils";
import {IBodyMaterialList} from "@/pagesBodyMaterial/types";

const imgCompare = imgUrlFormat('sugar/icon_pk_data.png')
const imgCheckTrue = imgUrlFormat('radio_checked.png')
const imgCheckFalse = imgUrlFormat('radio_default.png')

const params = Taro.getCurrentInstance().router?.params;
console.log('params', params)

const state = reactive({
  page: 1,
  pageSize: 20,
  finished: false,
  showMulti: false,
})

const selList = ref<Array<number>>([]);
const maxCount = 2;

// 数据列表
const list = ref<IBodyMaterialList[]>([] as IBodyMaterialList[]);

const showMulti = computed(() => {
  return state.showMulti;
})

const showEmpty = computed(() => {
  return state.page === 1 && state.finished === true && list.value.length === 0;
})

const showFinish = computed(() => {
  return state.finished === true;
})

const onShowMulti = () => {
  state.showMulti = !state.showMulti
}

const onSelection = () => {
  console.log('index.onSelection.selList=', JSON.stringify(selList.value))
  const id1 = selList.value[0]
  const id2 = selList.value[1]
  Taro.navigateTo({
    url: '/pagesBodyMaterial/compare/index?dataId1=' + Math.min(id1, id2) + "&dataId2=" + Math.max(id1, id2),
    success: res => {
      state.showMulti = false
      selList.value = []
      list.value.forEach((item) => {
        if (item.checked) {
          item.checked = false
        }
      });
    }
  })
}

//获取记录列表
const getRecordList = () => {
  if (state.page === 1) {
    list.value = [];
    state.finished = false;
  }
  if (state.finished) {
    return;
  }

  BodyMaterialApi.getBodyMaterialList(state.page).then(res => {
    if (!res.data || res.data.length === 0) {
      state.finished = true;
      return;
    }
    let tmpList = res.data.map(item => {
      return {
        ...item,
        ymdWeek: formatDate2YmdWeek(item.recordTime),
        hm: formatDate2Hm(item.recordTime)
      }
    });

    list.value.push(...tmpList)
  })
}

getRecordList();

const onItemSelect = (params) => {
  console.log('index.onItemSelect.params=', JSON.stringify(params))
  if (showMulti.value) {
    if (params.checked) {
      selList.value = selList.value.filter((item) => {
        return item !== params.dataId
      })
      params.checked = false
    } else {
      if (selList.value.length < maxCount) {
        params.checked = true
        selList.value.push(params.dataId)
      } else {
        showShortToast('最多只能选择2组数据进行对比')
      }
    }
  } else {
    Taro.navigateTo({
      url: '/pagesBodyMaterial/detail/index?dataId=' + params.dataId
    })
  }
}

const scroll = () => {
  if (state.finished) {
    showShortToast("没有更多了")
    return
  }
  state.page++;
  getRecordList();
}

const refresh = () => {
  console.log('index.refresh.')
  // state.page=1;
  // state.finished=false;
  // selList.value=[];
  // getRecordList();
}

</script>
<style lang="less">

.container_bm {
  height: 100vh;
  padding: 20.83rpx 28rpx 20.83rpx 28rpx;
  display: flex;
  font-size: 29rpx;
  color: #333333;
  box-sizing: border-box;
  background-color: #f8f8f8;
  flex-direction: column;

  .notice {
    color: #64A4F5;
    background-color: #EBF6FF;
    border-radius: 16.67rpx;
    padding: 16.67rpx 34.72rpx 16.67rpx 20.83rpx;
  }

  .bm_list {
    flex: 1;
    margin-top: 21rpx;
    min-height: 100vh;

    .item {
      background: #ffffff;
      border-radius: 17rpx 17rpx 17rpx 17rpx;
      margin-bottom: 27.08rpx;
      padding: 20.83rpx 20.83rpx 20.83rpx 20.83rpx;
    }

    .item_date_time {
      display: flex;
      justify-content: space-between;
      align-items: center;

      .item_date_selector {
        display: flex;
        justify-content: left;
        flex-direction: row;
        align-items: center;
      }

      .date-text{
        margin-left: 10rpx;
      }
    }

    .item_divider_line {
      background-color: rgba(187, 187, 187, 0.65);
      height: 1rpx;
      margin-top: 27.08rpx;
    }

    .list_score {
      overflow-wrap: break-word;
      text-align: left;
      white-space: nowrap;
      line-height: 15px;
      margin-top: 37.05rpx;

    }

    .text_title {
      overflow-wrap: break-word;
      font-size: 31.94rpx;
      line-height: 31.94rpx;
      text-align: left;
      color: var(text-color-dark-5f5f5f);
      white-space: nowrap;
    }

    .text_value {
      overflow-wrap: break-word;
      font-size: 41.67rpx;
      text-align: left;
      white-space: nowrap;
      color: #64A4F5;
      line-height: 41.67rpx;
    }

    .text-wrapper {
      overflow-wrap: break-word;
      text-align: left;
      white-space: nowrap;
      margin-top: 27.08rpx;
    }

  }

  .img_check {
    width: 31rpx;
    height: 31rpx;
    margin-top: 10rpx;
    margin-right: 4.08rpx;
  }

  .floating-icon {
    position: fixed; /* 设置为固定定位 */
    bottom: 29.17rpx; /* 从底部距离20px */
    right: 29.17rpx; /* 从左侧距离20px */
    z-index: 99; /* 确保它在其他元素之上显示 */
    /* 根据需求设置图标的样式 */
    width: 240rpx;
    height: 240rpx;
    border-radius: 50%;
    text-align: center;
  }

  .floating-btn {
    background: #64A4F5;
    border-radius: 16.67rpx;
    color: white;
    z-index: 99; /* 确保它在其他元素之上显示 */
    width: 93.3%;
    font-size: 34.72rpx;
    text-align: center;
    padding-top: 27.08rpx;
    padding-bottom: 27.08rpx;
    position: fixed;
    bottom: 20.83rpx;
  }

}
</style>
