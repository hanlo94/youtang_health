import {
    PAGE_SIZE,
    postPatientRequest
} from "@/api/api";
import {BmCompareResult, IBodyMaterialDetail, IBodyMaterialList} from "@/pagesBodyMaterial/types";

export const BodyMaterialApi = {
    getBodyMaterialList(page: number) {
        return postPatientRequest<IBodyMaterialList[]>({
            actId: 11031302,
            pageNum: page,
            pageSize: PAGE_SIZE,
            descFlag:true
        })
    },
    getBodyMaterialDetail(dataId: number) {
        return postPatientRequest<IBodyMaterialDetail>(
            {
                actId: 11031301,
                dataId
            }
        )
    },
    compareBodyMaterial(dataId: number, dataId2: number) {
        return postPatientRequest<BmCompareResult>(
            {
                actId: 11031305,
                dataIds: [dataId, dataId2]
            }
        )
    },


}