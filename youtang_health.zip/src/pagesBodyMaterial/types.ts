import {PatientBaseInfo} from "@/pagesMine/api/mine";


export interface IBodyMaterialTestItem {
    title: string;
    unit?: string;
    value?: string;
    lower?: string;
    upper?: string;
    state?: number;
    stateDescription?: string;
}

/**
 * 数据列表
 */
export interface IBodyMaterialList {
    dataId: number;
    score: number;
    weight: number;
    bodyFat: number;
    recordTime: string;
    ymdWeek: string;
    hm: string;
    checked?: boolean;
}


/**
 * 数据详情
 */
export interface IBodyMaterialDetail {
    // 自定义字段
    recordDateWeek?: string; // "2024-03-21 "
    name?: string;
    avatar?: string;
    memberCardName?: string;
    healthyManager?: string;
    visFatValue?: string; // 等级7

    // 记录基础信息
    dataId?: number; // 82
    recordTime?: string; // "2024-03-21 18:03:31"
    patientId?: number; // 12194298
    sn?: string; // "00276C"
    score?: number; // 66.4

    // 基本信息
    age?: number; // 29
    gender?: number; // 1 (男)
    genderDescription?: string; // "男"
    height?: number; // 174.0 (单位: 厘米)
    weight?: number; // 66.3 (单位: 千克)
    weightState?: number; // 1 (标准)
    weightStateDescription?: string; // "标准"
    stdWeightLower?: number; // 56.6 (单位: 千克)
    stdWeightUpper?: number; // 76.6 (单位: 千克)

    // 身体质量指数 (BMI)
    bmi?: number; // 21.9
    bmiState?: number; // 1 (消瘦)
    bmiStateDescription?: string; // "消瘦"
    stdBmiLower?: number; // 18.5
    stdBmiSevere?: number; // 27.9
    stdBmiUpper?: number; // 23.9

    // 基础代谢率 (BMR)
    bmr?: number; // 1435 (单位: 千卡/天)
    bmrState?: number; // 1 (标准)
    bmrStateDescription?: string; // "标准"
    stdBmrLower?: number; // 1464 (单位: 千卡/天)
    stdBmrUpper?: number; // 1709 (单位: 千卡/天)

    // 体水分
    water?: number; // 36.5 (单位: 千克)
    waterState?: number; // 0
    waterStateDescription?: string; // "缺乏"
    stdWaterLower?: number; // 37.4 (单位: 千克)
    stdWaterUpper?: number; // 45.7 (单位: 千克)

    // 身体脂肪与分布
    // 体脂
    bodyFat?: number; // 25.6 (单位: %)
    bodyFatState?: number; // 2 (轻度肥胖)
    bodyFatStateDescription?: string; // "轻度肥胖"
    stdBodyFatLower?: number; // 10.0 (单位: %)
    stdBodyFatSevere?: number; // 26.0 (单位: %)
    stdBodyFatUpper?: number; // 20.0 (单位: %)
    // 脂肪
    fat?: number; // 17.0 (单位: 千克)
    fatState?: number; // 2 (过量)
    fatStateDescription?: string; // "过量"
    stdFatLower?: number; // 8.0 (单位: 千克)
    stdFatUpper?: number; // 16.0 (单位: 千克)
    // 皮下脂肪
    subFat?: number; // 23.2 (单位: %)
    subFatState?: number; // 2 (偏高)
    subFatStateDescription?: string; // "偏高"
    stdSubFatLower?: number; // 8.6 (单位: %)
    stdSubFatUpper?: number; // 16.7 (单位: %)
    // 内脏脂肪指数
    visFat?: number; // 7
    visFatState?: number; // -1 (未知)
    visFatStateDescription?: string; // "未知"
    stdVisFatLower?: number; // 0
    stdVisFatUpper?: number; // 9

    // 肌肉量与分布
    // 骨骼肌
    muscle?: number; // 26.3 (单位: 千克)
    muscleState?: number; // 0 (偏低)
    muscleStateDescription?: string; // "偏低"
    stdMuscleLower?: number; // 28.6 (单位: 千克)
    stdMuscleUpper?: number; // 34.9 (单位: 千克)
    // 肌肉量
    sinew?: number; // 46.1 (单位: 千克)
    sinewState?: number; // 0 (偏低)
    sinewStateDescription?: string; // "偏低"
    stdSinewLower?: number; // 47.5 (单位: 千克)
    stdSinewUpper?: number; // 58.0 (单位: 千克)

    // 身体成分平衡
    // 上下肢
    armLegSinewLimbBalance?: number; // 1 (均衡)
    armLegSinewLimbBalanceDescription?: string; // "均衡"
    // 上肢
    armSinewLimbBalance?: number; // 1 (均衡)
    armSinewLimbBalanceDescription?: string; // "均衡"
    // 下肢
    legSinewLimbBalance?: number; // 1 (均衡)
    legSinewLimbBalanceDescription?: string; // "均衡"

    // 四肢肌肉量
    leftArmMuscle?: number; // 2.7 (单位: 千克)
    leftArmMuscleRatio?: number; // 89.0 (单位: %)
    leftArmMuscleState?: number; // 1 (标准)
    leftArmMuscleStateDescription?: string; // "标准"
    stdLeftArmMuscleLower?: number; // 2.6 (单位: 千克)
    stdLeftArmMuscleUpper?: number; // 3.5 (单位: 千克)

    rightArmMuscle?: number; // 2.6 (单位: 千克)
    rightArmMuscleRatio?: number; // 86.1 (单位: %)
    rightArmMuscleState?: number; // 1 (标准)
    rightArmMuscleStateDescription?: string; // "标准"
    stdRightArmMuscleLower?: number; // 2.6 (单位: 千克)
    stdRightArmMuscleUpper?: number; // 3.5 (单位: 千克)

    leftLegMuscle?: number; // 8.0 (单位: 千克)
    leftLegMuscleRatio?: number; // 92.9 (单位: %)
    leftLegMuscleState?: number; // 1 (标准)
    leftLegMuscleStateDescription?: string; // "标准"
    stdLeftLegMuscleLower?: number; // 7.7 (单位: 千克)
    stdLeftLegMuscleUpper?: number; // 9.4 (单位: 千克)

    rightLegMuscle?: number; // 8.0 (单位: 千克)
    rightLegMuscleRatio?: number; // 94.0 (单位: %)
    rightLegMuscleState?: number; // 1 (标准)
    rightLegMuscleStateDescription?: string; // "标准"
    stdRightLegMuscleLower?: number; // 7.7 (单位: 千克)
    stdRightLegMuscleUpper?: number; // 9.4 (单位: 千克)

    // 身体年龄与体型
    bodyAge?: number; // 34
    bodyShape?: number; // 7 (标准体重—肥胖型)
    bodyShapeDescription?: string; // "标准体重—肥胖型"

    // 瘦体重 去脂体重(LBM)
    lbm?: number; // 49.3 (单位: 千克)
    lbmState?: number; // 0 (标准)
    lbmStateDescription?: string; // "标准"
    stdLbmLower?: number; // 51.0 (单位: 千克)
    stdLbmUpper?: number; // 62.2 (单位: 千克)

    // 躯干肌肉量
    torsoMuscle?: number; // 22.6 (单位: 千克)
    torsoMuscleLower?: number; // 21.8 (单位: 千克)
    torsoMuscleRatio?: number; // 92.9 (单位: %)
    torsoMuscleState?: number; // 1 (标准)
    torsoMuscleStateDescription?: string; // "标准"
    torsoMuscleUpper?: number; // 26.7 (单位: 千克)

    // 蛋白质相关属性
    protein: number;
    stdProteinUpper: number;
    stdProteinLower: number;
    proteinState: number;
    proteinStateDescription: string;

// 无机盐相关属性
    bone: number;
    stdBoneUpper: number;
    stdBoneLower: number;
    boneState: number;
    boneStateDescription: string;

// 控制指标相关属性
    weightControl: number;
    fatControl: number;
    sinewControl: number;
    weightTarget: number;

}

/**
 * 数据对比结果
 */
// export interface BmCompareResult {
//     patientId: number;
//     name: string;
//     gender: string;
//     age: number;
//     sugarAge: string;
//     baseData: BmBaseData[];
//     ageChange: number;
//     heightChange: number;
//     scoreChange: number;
//     waterChange: number;
//     fatChange: number;
//     weightChange: number;
//     muscleChange: number;
//     bmiChange: number;
//     bodyFatChange: number;
//     visFatChange: number;
//     leftArmMuscleChange: number;
//     rightArmMuscleChange: number;
//     torsoMuscleChange: number;
//     leftLegMuscleChange: number;
//     rightLegMuscleChange: number;
//     subFatChange: number;
//     lbmChange: number;
//     sinewChange: number;
//     bmrChange: number;
//     bodyAgeChange: number;
// }
//
// export interface BmBaseData {
//     recordTime: string;
//     age: number;
//     height: number;
//     score: number;
//     water: number;
//     waterStateDesc: string;
//     fat: number;
//     fatStateDesc: string;
//     weight: number;
//     weightStateDesc: string;
//     muscle: number;
//     muscleStateDesc: string;
//     bmi: number;
//     bmiStateDesc: string;
//     bodyFat: number;
//     bodyFatStateDesc: string;
//     visFat: number;
//     visFatStateDesc: string;
//     leftArmMuscle: number;
//     leftArmMuscleStateDesc: string;
//     rightArmMuscle: number;
//     rightArmMuscleStateDesc: string;
//     torsoMuscle: number;
//     torsoMuscleStateDesc: string;
//     leftLegMuscle: number;
//     leftLegMuscleStateDesc: string;
//     rightLegMuscle: number;
//     rightLegMuscleStateDesc: string;
//     armBodyStrength: number;
//     armBodyStrengthStateDesc: string;
//     legBodyStrength: number;
//     legBodyStrengthStateDesc: string;
//     armLegBodyStrength: number;
//     armLegBodyStrengthStateDesc: string;
//     subFat: number;
//     subFatStateDesc: string;
//     lbm: number;
//     lbmStateDesc: string;
//     sinew: number;
//     sinewStateDesc: string;
//     bmr: number;
//     bmrStateDesc: string;
//     bodyAge: number;
// }

export interface BmCompareResult {
    patientBaseinfo: PatientBaseInfo;
    compareItems: BmCompareItem[];
    declare: string;
    recordDate1: string;
    recordDate2: string;
    healthScore: BmCompareItem;
    nutrition: BmCompareItem;
    muscleFat: BmCompareItem;
    fat: BmCompareItem;
    muscleBalance: BmCompareItem;
    others: BmCompareItem;
}

/**
 * 单项比较结果
 */
export class BmCompareItemSubItems {
    label: string;
    changeValue: number;
    leftValue: string;
    leftValueState: number;
    leftValueStateDesc: string;
    rightValue: string;
    rightValueState: number;
    rightValueStateDesc: string;
}

export class BmCompareItem {
    title: string;
    subItems: BmCompareItemSubItems[];
}

