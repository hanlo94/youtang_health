<template>
  <view class="container_bm">
    <scroll-view flexed>

<!--      <PatientInfoView :avatar="record.patientBaseinfo?.avatar" :name="record.patientBaseinfo?.name"-->
<!--                       :gender="record.patientBaseinfo?.gender"-->
<!--                       :age="record.patientBaseinfo?.birth" class="item-shape-round-white item_divider"/>-->

      <view class="horizon-container item-shape-round-white item_divider item-date-container">
        <text class="date-text">{{ record.recordDate1 }}</text>

        <view class="item-date-bg">
          <view class="line"/>
          <text class="item-status-blue text-color-white duration-text">
            历经{{ getDaysDifference(record.recordDate1, record.recordDate2) }}天
          </text>
          <view class="line"/>
        </view>

        <text class="date-text">{{ record.recordDate2 }}</text>
      </view>
      <template v-for="(compareItem, index) in recordList" :key="index">
        <view class="vertical-container item-shape-round-white item_divider compare-item-container">
          <text class="item-text-title">{{ compareItem?.title }}</text>
          <CompareItemView
              class="item_divider"
              v-for="(subItem, subIndex) in compareItem?.subItems"
              :key="`${index}-${subIndex}`"
              :item="subItem"
              :show-dash="subIndex !== compareItem?.subItems.length - 1"
          />
        </view>
      </template>

      <view class="item_divider">
        <text class="text-color-dark-5f5f5f item_declare">
          注:所有指标均是通过设备(体脂秤)测量人体生物电阻抗后，结合人体成分组成得出，数值仅作为控制体型和长期健身参考使用，不作为医疗诊断的依据。
        </text>
      </view>

    </scroll-view>

  </view>

</template>
<script setup lang="ts">
import {ref} from "vue";
import Taro from "@tarojs/taro";
import PatientInfoView from '../comp/patientInfo.vue'
import CompareItemView from '../comp/CompareItemView.vue'
import {BodyMaterialApi} from "@/pagesBodyMaterial/bodyMaterial";
import {BmCompareItem, BmCompareResult} from "@/pagesBodyMaterial/types";


// const params = Taro.getCurrentInstance().router?.params;
// console.log('params', params)
const {dataId1, dataId2} = Taro.getCurrentInstance().router?.params;
console.log('compare.index..dataId1 =', dataId1, ' dataId2=', dataId2)

const record = ref<BmCompareResult>({} as BmCompareResult)
const recordList = ref<BmCompareItem[]>([] as BmCompareItem[])

// 获取对比数据
const getCompareResult = () => {
  BodyMaterialApi.compareBodyMaterial(dataId1, dataId2).then(res => {
        console.log('compare.index.response=.', JSON.stringify(res))
        // console.log('index..res.data=',JSON.stringify(res.data))
        record.value = res.data
        recordList.value=record.value.compareItems
        // const tmpList = [record.value.healthScore, record.value.nutrition, record.value.muscleFat, record.value.fat, record.value.muscleBalance, record.value.others]
        // recordList.value.push(...tmpList)
        console.log('compare.index.record=', JSON.stringify(record.value))
        console.log('index.compare.', JSON.stringify(record.value.patientBaseinfo), '\n', JSON.stringify(record.value.healthScore), '\n', typeof record.value.healthScore)
      }
  )
}

getCompareResult();


const getDaysDifference = (date1, date2) => {
  // 确保日期实例化
  const d1 = new Date(date1);
  const d2 = new Date(date2);

  // 计算两个日期的时间戳差值（以毫秒为单位）
  const diffInMs = Math.abs(d2.getTime() - d1.getTime());

  // 将毫秒转换为天数（1天等于1000 * 60 * 60 * 24毫秒）
  const diffInDays = diffInMs / (1000 * 60 * 60 * 24);

  return Math.floor(diffInDays); // 取整数天数
}


</script>
<style lang="less">
.container_bm {
  height: 100vh;
  padding: 21px 28px 21px 28px;
  display: flex;
  background-color: #f8f8f8;
  flex-direction: column;

  .item-date-container {

    .date-text {
      font-size: 29.17rpx;
      color: var(text-color-dark-5f5f5f);
      font-weight: 600;
    }

    .item-date-bg {
      display: flex;
      flex-direction: row;
      box-sizing: border-box;
      justify-content: center;
      justify-items: center;
      align-items: center;

      .duration-text {
        font-size: 25rpx;
        padding-left: 12rpx;
        padding-right: 12rpx;
        margin-left: 12rpx;
        margin-right: 12rpx;
      }

      .line {
        width: 33.33rpx;
        height: 0.01rpx;
        align-items: center;
        align-content: center;
        background-color: #4aa4fc;
      }

    }
  }

  .item-shape-round-white {
    border-radius: 16.67rpx;
    background-color: white;
    width: 100%;
    padding: 27.08rpx 20.83rpx;
    height: auto;
  }

  .item-status-blue {
    border-radius: 24rpx;
    background-color: #4aa4fc;
  }

  .item-status-red {
    border-radius: 24rpx;
    background-color: #DD3542;
  }

  .item_divider {
    margin-top: 28rpx;
  }

  .record-time {
    font-size: 29.17rpx;
    color: var(text-color-dark-5f5f5f)
  }

  .compare-item-container {
    .item-text-title {
      text-align: center;
      font-size: 33.33rpx;
      color: var(text-color-dark-5f5f5f);
      font-weight: 600;
    }

  }


  .value-container {
    display: flex;
    position: relative;
    width: 100%;
    margin-top: 29.17rpx;
    height: 666rpx;

    .background {
      width: 100%;
      height: 663rpx;
      position: absolute;
      top: 0;
      left: 0;
    }

    .value {
      position: absolute;
      width: 100%;
      margin-top: 29.17rpx;
      height: 84%;
      top: 0;
      left: 0;

      text {
        color: var(text-color-dark-5f5f5f);
        font-size: 22.22rpx;
        line-height: 31.25rpx
      }

      .value-text-default-big {
        color: var(text-color-dark-5f5f5f);
        font-size: 29.17rpx;
      }

      .value-text-default-middle {
        font-size: 25rpx;
      }

      .text-bold {
        font-weight: 600;
      }

      .left-item-margin {
        margin-left: 6rpx;
        margin-right: 10rpx;
      }

      .right-item-margin {
        margin-left: 10rpx;
        margin-right: 6rpx;
      }


      .test-item-container {
        display: flex;
        flex-direction: row;
        box-sizing: border-box;
      }

      .item-divider {
        margin-top: 12rpx;
        margin-bottom: 10rpx;
      }

      .align-left {
        justify-content: flex-start;
        align-items: center;

        view {
          align-self: flex-start;
          align-items: center;
        }
      }

      .align-right {
        justify-content: flex-end;
        align-items: center;

        view {
          align-self: flex-end;
          align-items: center;
        }
      }


      .left {
        height: 100%;
        align-items: flex-start;
        align-content: flex-start;
        text-align: start;
      }

      .right {
        height: 100%;
        align-items: flex-end;
        align-content: flex-end;
        text-align: end;
      }

    }
  }


  .item_declare {
    font-size: 22.22rpx;
  }

}
</style>
