export default definePageConfig({
    navigationBarTitleText: "人体成分分析对比",
    usingComponents:{

    }
});
