<!--
Description：糖尿病个性化治疗方案
Created on 2024/10/23
Author :  郭 -->
<template>
  <view class="treat_root">
    <view class="card_top">
      请根据个人实际情况，认真填写以下信息，系统将为您定制专属的
      <text style="color: #64A4F5">60</text>
      天复合磁治疗仪方案。个性化千人千方，为糖友保驾护航。
    </view>
    <view class="card_form">

      <view class="card_item pbl30">
        <view class="item_name">真实姓名</view>
        <view class="arrow">
          <input placeholder="请输入" v-model="fromVal.customerName" maxlength="10"/>
          <RectRight></RectRight>
        </view>
      </view>
      <view class="card_item pbl30">
        <view class="item_name">性别</view>
        <nut-radio-group v-model="fromVal.customerGender" direction="horizontal">
          <nut-radio :label="1">男
            <template #icon>
              <IconFont name="check-normal"></IconFont>
            </template>
            <template #checkedIcon>
              <IconFont name="checked" color="#64A4F5"></IconFont>
            </template>

          </nut-radio>
          <nut-radio :label="2">女
            <template #icon>
              <IconFont name="check-normal"></IconFont>
            </template>
            <template #checkedIcon>
              <IconFont name="checked" color="#64A4F5"></IconFont>
            </template>

          </nut-radio>
        </nut-radio-group>
      </view>
      <view class="card_item pbl30" @click="showBirthdayPop = true">
        <view class="item_name">出生日期</view>
        <view class="arrow">
          <text>{{ fromVal.customerBirthday || '请选择' }}</text>
          <RectRight></RectRight>
        </view>
      </view>

      <view class="card_item_column pbl30 ">
        <view class="item_name">糖尿病类型</view>
        <view class="warp">
          <view :class=" item.value === fromVal.diabetesType ? 'check_true' :'check_false' "
                v-for="(item ,index ) in sugarList"
                :key="item.value" @click="onChooseItem(item,'diabetesType')">{{ item.label }}
          </view>
        </view>
      </view>

      <view class="card_item pbl30" @click="showConfirmDatePop = true">
        <view class="item_name">确诊日期</view>
        <view class="arrow">
          <text>{{ fromVal.confirmDate || '请选择' }}</text>
          <RectRight></RectRight>
        </view>
      </view>

      <view class="card_item pbl30">
        <view class="item_name">是否有并发症</view>
        <nut-radio-group v-model="fromVal.complication" direction="horizontal">
          <nut-radio :label="1">是
            <template #icon>
              <IconFont name="check-normal"></IconFont>
            </template>
            <template #checkedIcon>
              <IconFont name="checked" color="#64A4F5"></IconFont>
            </template>

          </nut-radio>
          <nut-radio :label="2">否
            <template #icon>
              <IconFont name="check-normal"></IconFont>
            </template>
            <template #checkedIcon>
              <IconFont name="checked" color="#64A4F5"></IconFont>
            </template>

          </nut-radio>
        </nut-radio-group>
      </view>

      <view class="card_item_column pbl30 " v-if="fromVal.complication == 1 ">
        <view class="item_name">并发症类型</view>
        <view class="warp">
          <view :class="item.checked ? 'check_true' :'check_false' "
                v-for="(item ,index ) in diabeticComplicationOptions"
                :key="item.value" @click="onClickComplication(item)">{{ item.label }}
          </view>
        </view>
      </view>
      <view class="card_item_column pbl30 " v-if="fromVal.complication == 1 ">
        <view class="item_name">并发症强度</view>
        <view class="warp">
          <view :class=" item.value === fromVal.complicationIntensity ? 'check_true' :'check_false' "
                v-for="(item ,index ) in complicationIntensityOptions"
                :key="item.value" @click="onChooseItem(item,'complicationIntensity')">{{ item.label }}
          </view>
        </view>
      </view>

      <view class="card_item pbl30">
        <view class="item_name">是否使用胰岛素</view>
        <nut-radio-group v-model="fromVal.useInsullin" direction="horizontal">
          <nut-radio :label="1">是
            <template #icon>
              <IconFont name="check-normal"></IconFont>
            </template>
            <template #checkedIcon>
              <IconFont name="checked" color="#64A4F5"></IconFont>
            </template>

          </nut-radio>
          <nut-radio :label="2">否
            <template #icon>
              <IconFont name="check-normal"></IconFont>
            </template>
            <template #checkedIcon>
              <IconFont name="checked" color="#64A4F5"></IconFont>
            </template>

          </nut-radio>
        </nut-radio-group>
      </view>

      <view class="card_item pbl30">
        <view class="item_name">是否用药</view>
        <nut-radio-group v-model="fromVal.useMedication" direction="horizontal" @change="onChange">
          <nut-radio :label="1">是
            <template #icon>
              <IconFont name="check-normal"></IconFont>
            </template>
            <template #checkedIcon>
              <IconFont name="checked" color="#64A4F5"></IconFont>
            </template>

          </nut-radio>
          <nut-radio :label="2">否
            <template #icon>
              <IconFont name="check-normal"></IconFont>
            </template>
            <template #checkedIcon>
              <IconFont name="checked" color="#64A4F5"></IconFont>
            </template>

          </nut-radio>
        </nut-radio-group>
      </view>
    </view>
    <view class="card_list" v-if="fromVal.useMedication ==1">
      <view class="list_item" v-for="(item,index) in medicineList" :key="index">
        <view class="title">
          <view>用药信息 {{ index + 1 }}</view>
          <view class="delete" @click="onDeleteMedicine(index)">删除</view>
        </view>
        <view class="card_form">
          <view class="card_item pbl30">
            <text>服用药物</text>
            <view class="arrow">
              <input placeholder="请输入" v-model="item.medicationName" maxlength="20"/>
              <RectRight></RectRight>
            </view>
          </view>
          <view class="card_item pbl30" @click="item.showFrequencyPop = true">
            <text>用药频次</text>
            <view class="arrow">
              <text>{{ item.medicationFrq || '请选择' }}</text>
              <RectRight></RectRight>
            </view>
          </view>
          <view class="card_item pbl30" @click="item.showDosagePop = true">
            <text>用药剂量</text>
            <view class="arrow">
              <text>{{ item.medicationDose || '请选择' }}</text>
              <RectRight></RectRight>
            </view>
          </view>
          <view class="add" v-if="index === medicineList.length -1" @click="onClickAddMedicine">
            <view class="icon">+</view>
            <view>增加用药</view>
          </view>

          <nut-action-sheet v-model:visible="item.showFrequencyPop" :menu-items="freqOptions"
                            @choose="(item,pos)=>chooseFrequency(item,pos,index)"
                            color="#6aa4fc"
                            :choose-tag-value="item.medicationFrq" cancel-txt="取消" title="请选择用药频次"/>

          <nut-action-sheet v-model:visible="item.showDosagePop" :menu-items="dosageOptions"
                            @choose="(item,pos)=>chooseDosage(item,pos,index)"
                            color="#6aa4fc"
                            :choose-tag-value="item.medicationDose" cancel-txt="取消" title="请选择用药剂量"/>

        </view>
      </view>

    </view>

    <nut-button class="btn" shape="square" @click="onSubmit" color="#64A4F5">生成我的专属方案</nut-button>
  </view>
  <nut-popup v-model:visible="showBirthdayPop" position="bottom" round>
    <nut-date-picker
        v-model="birthday"
        :min-date="min"
        :max-date="max"
        :three-dimensional="false"
        @confirm="onPopBirthConfirm"
        @cancel="showBirthdayPop = false"
        :is-show-chinese="true"
    ></nut-date-picker>
  </nut-popup>

  <nut-popup v-model:visible="showConfirmDatePop" position="bottom" round>
    <nut-date-picker
        v-model="confirmDate"
        :min-date="birthday"
        :max-date="max"
        :three-dimensional="false"
        @confirm="onPopConfirmConfirm"
        @cancel="showConfirmDatePop = false"
        :is-show-chinese="true"
    ></nut-date-picker>
  </nut-popup>

  <nut-popup v-model:visible="showDialog" position="bottom"
             :style="{ height: '70%' }" overlay-class="info_dialog"
             style="background: transparent;  ">
    <!--        低1  中 2  高3-->
    <view class="dialog">
      <view class="dialog-pop">
        <img src="https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/composite/pop3.png"/>
        <view class="dialog_content">
          <view class="content">
            <view>您的治疗仪专属方案已生成！</view>
            <view> 开启
              <text style="color:#64A4F5;">60</text>
              天的健康打卡吧~
            </view>
          </view>
          <view class="btn" @click="onClickOpen">点击开启</view>
        </view>
      </view>
      <img class="close" :src="imgUrlFormat('point/close.png')" @click.stop="onClickOpen"/>
    </view>
  </nut-popup>


</template>

<script setup lang="ts">

import {ref} from "vue";
import {IconFont, RectRight} from "@nutui/icons-vue-taro";
import {sugarList} from "@/pagesMine/ts/dataUtils";
import {IFormBaseInfo, ILabelItem, IMedicineItem} from "@/pagesTreatment/ts/types";
import {
  complicationIntensityOptions,
  diabeticComplicationOptions,
  dosageOptions,
  freqOptions
} from "@/pagesTreatment/ts/options";
import Taro from "@tarojs/taro";
import {ISelectOption} from "@/pagesActive/ts/types";
import planApi from "@/api/modules/plan";
import {isEmpty} from "lodash";
import {showToast} from "@/utils/toastUtils";
import dayjs from "dayjs";
import imgUrlFormat from "@/utils/imgUtils";

definePageConfig({
  navigationBarTitleText: '我的健康信息'
})

const planId = Number(Taro.getCurrentInstance().router?.params?.planId || 0)
const from = Number(Taro.getCurrentInstance().router?.params?.from || 0)
// const planId = 0

const min = new Date(1920, 0, 1)

const max = new Date()
const birthday = ref(new Date())
const confirmDate = ref(new Date())
const showBirthdayPop = ref(false)
//确诊日期
const showConfirmDatePop = ref(false)

const showDialog = ref(false);

/**
 * 用药信息
 */
const medicineList = ref<IMedicineItem[]>([{
  medicationName: null,//名称
  medicationFrq: null, //频次
  medicationDose: null, //剂量
  showFrequencyPop: false,
  showDosagePop: false
}])


const fromVal = ref<IFormBaseInfo>({
  customerName: null,
  customerGender: null,
  customerBirthday: null,
  diabetesType: null,
  confirmDate: null,
  useInsullin: 2,//是否胰岛素 1是 2否
  useMedication: 2,//是否用药 1是 2否
  complication: 2,//是否并发症
  complicationTypes: null,//并发正类型
  complicationIntensity: null,//并发正强度  1轻 2中 3重
  medications: null,//用药信息
} as IFormBaseInfo);

const onChange = (res) => {
  console.log("index..onChange.res=", JSON.stringify(res), '; useMedication=', fromVal.value.useMedication);
  if (fromVal.value.useMedication == 1 && medicineList.value.length == 0) {
    medicineList.value = [{
      medicationName: null,//名称
      medicationFrq: null, //频次
      medicationDose: null, //剂量
      showFrequencyPop: false,
      showDosagePop: false
    }]
  }
};

/**
 * 详情，回显
 */
const requestDetails = () => {
  console.log("index..requestDetails.before me=", JSON.stringify(medicineList.value));
  planApi.requestPlanDetails(planId).then(res => {
    console.log(res)
    fromVal.value = res?.data || {} as IFormBaseInfo;
    if (fromVal.value.customerBirthday) {
      birthday.value = dayjs(fromVal.value.customerBirthday).toDate()
    }
    if (!fromVal.value.useInsullin) {
      fromVal.value.useInsullin = 2
    }
    if (!fromVal.value.useMedication) {
      fromVal.value.useMedication = 2
    }
    if (!fromVal.value.complication) {
      fromVal.value.complication = 2
    }
    if (fromVal.value.complicationTypes) {
      // console.log("index.requestDetail..diabeticComplicationOptions=", JSON.stringify(diabeticComplicationOptions.value), '; typeof diabeticComplicationOptions.value=', (typeof diabeticComplicationOptions.value));
      diabeticComplicationOptions.value.forEach(item => {
        // console.log("index.requestDetail..item.value=",JSON.stringify(item),'; fromVal.value.complicationTypes=',fromVal.value.complicationTypes,'; fromVal.value.complicationTypes.indexOf(item.value)=',(fromVal.value.complicationTypes.indexOf(item.value)),'; include=',(fromVal.value.complicationTypes.includes(item.value)));
        if (fromVal.value.complicationTypes.indexOf(item.value) >= 0) {
          item.checked = true
        }
      });
      // console.log("index.requestDetail..finally diabeticComplicationOptions=",JSON.stringify(diabeticComplicationOptions.value));
    }
    if (res?.data?.medications) {
      medicineList.value = JSON.parse(res?.data?.medications) as IMedicineItem[];
    }
    console.log("index.medicineList.size=.", medicineList.value.length, '; medicineList=', JSON.stringify(medicineList.value));

  })
}
requestDetails()


const onClickComplication = (item) => {
  item.checked = !item.checked;
}

/**
 * 开启
 */
const onClickOpen = () => {
  if (from && from == 1) {
    Taro.navigateTo({
      url: '/pagesTreatment/index/index'
    })
  } else {
    Taro.navigateBack({delta: -1})
  }
};

const chooseDosage = (item: ISelectOption, pos: number, index: number) => {
  console.log(item, pos, index)
  medicineList.value[index].medicationDose = item.name;
}
const chooseFrequency = (item: ISelectOption, pos: number, index: number) => {
  console.log(item, pos, index)
  medicineList.value[index].medicationFrq = item.name;
}

const showReplaceDialog = () => {
  Taro.showModal({
    content: '您已有进行中的治疗仪方案 重新生成，将替换原有计划方案',
    confirmText: '重新生成',
    success(result) {
      if (result.confirm) {
        requestSubmit()
      } else if (result.cancel) {
      }
    },
  })
}

/**
 *
 * 1、选了糖尿病类型为 无，可以不选确诊日期，
 * 2、没有选并发症可以不填并发症信息
 * 3、用药信息只需要勾选有有无，具体信息不做判断，但如果药品名称、频次和剂量都没填这一项就不提交
 */
const checkInfo = (): boolean => {
  if (isEmpty(fromVal.value?.customerName)) {
    showToast('请输入真实姓名')
    return false;
  }
  if (fromVal.value.customerGender !== 1 && fromVal.value.customerGender !== 2) {
    showToast('请选择性别')
    return false;
  }
  if (isEmpty(fromVal.value.customerBirthday)) {
    showToast('请选择出生日期')
    return false;
  }

  if (fromVal.value.diabetesType === null) {
    showToast('请选择糖尿病类型')
    return false;
  }
  //如果为0 那么糖尿病相关的信息 不用填了
  if (fromVal.value.diabetesType !== 0) {
    if (isEmpty(fromVal.value?.confirmDate)) {
      showToast('请选择确诊日期')
      return false;
    }
    if (fromVal.value?.complication === 1) {
      if (diabeticComplicationOptions.value.filter(item => item.checked).length === 0) {
        showToast('请选择并发症类型')
        return false;
      }
      if (fromVal.value?.complicationIntensity === null) {
        showToast('请选择并发症强度')
        return false;
      }
    }
    if (!fromVal.value?.useInsullin) {
      showToast('请选择是否使用胰岛素')
      return false;
    }
    if (!fromVal.value?.useMedication) {
      showToast('请选择是否用药')
      return false;
    }
  }

  if (fromVal?.value?.useMedication && fromVal?.value?.useMedication == 1) {
    console.log("index..checkInfo.medicineList=", JSON.stringify(medicineList.value));
    let tmpList = medicineList.value.filter(item => item.medicationName !== null && item.medicationName.trim().length > 0 && item.medicationDose != null && item.medicationFrq != null);
    if (tmpList.length === 0 || tmpList.length < medicineList.value.length) {
      showToast('请完善用药信息')
      return false;
    }
    fromVal.value.medications = JSON.stringify(tmpList)
  }
  return true;
}

/**
 * 提交
 */
const requestSubmit = () => {
  let data = {
    ...fromVal.value,
    complicationTypes: diabeticComplicationOptions.value.filter(item => item.checked).map(item => item.value).join(',')
  }
  planApi.requestCreatePlan({plan: {...data}}).then(res => {
    showDialog.value = true
    Taro.eventCenter.trigger('planId', {planId: res.data})
  })

}

const onSubmit = () => {
  if (checkInfo()) {
    if (planId !== 0) {
      showReplaceDialog()
    } else {
      requestSubmit()
    }
  }


  // if(planId !== 0){
  //   showReplaceDialog()
  // }else{
  //   showDialog.value = true
  // }
}


/**
 * 新增一个用药
 */
const onClickAddMedicine = () => {
  medicineList.value = [...medicineList.value, {
    medicationName: null,
    medicationFrq: null,
    medicationDose: null,
    showFrequencyPop: false,
    showDosagePop: false
  }]
}

/**
 * 移除一个用药信息
 * @param pos
 */
const onDeleteMedicine = (pos: number) => {

  // Taro.showModal({
  //   title: '提示',
  //   content: '确定删除吗？',
  //   success: function (res) {
  // if (res.confirm) {
  //   console.log(pos)
  medicineList.value = medicineList.value.filter((item, index) => index != pos)
  console.log('index.onDeleteMedicine.length=', medicineList.value.length)
  if (medicineList.value.length == 0) {
    fromVal.value.useMedication = 2
  }
  // console.log('medicineList==.', medicineList.value)
  // } else if (res.cancel) {
  // }
  //   }
  // })
};


/**
 * 点击选择基础信息
 * @param item 数据项
 * @param field 字段名称
 */
const onChooseItem = (item: ILabelItem, field: string) => {
  fromVal.value[field] = item.value;
  fromVal.value[`${field}` + 'Value'] = item.label;
}
//生日
const onPopBirthConfirm = ({selectedValue}) => {
  fromVal.value.customerBirthday = selectedValue[0] + '-' + selectedValue[1] + '-' + selectedValue[2]
  showBirthdayPop.value = false
}
//确诊
const onPopConfirmConfirm = ({selectedValue}) => {
  fromVal.value.confirmDate = selectedValue[0] + '-' + selectedValue[1] + '-' + selectedValue[2]
  showConfirmDatePop.value = false
}


</script>

<style lang="less">
.treat_root {
  display: flex;
  flex-direction: column;

  .card_top {
    margin: 30px 20px;
    background: white;
    font-size: 32px;
    color: #353535;
    border-radius: 16px;
    padding: 30px 20px;
  }

  .card_form {
    border-radius: 16px;
    margin: 0 20px;
    background: white;
    padding: 0 20px;


    .pbl30 {
      padding: 30px 0;
      border-bottom: #efefef solid 1px;
    }

    .card_item {
      display: flex;
      flex-direction: row;
      justify-content: space-between;
      align-items: center;

      .item_name {
        color: #353535;
        font-size: 32px;
      }

    }

    .card_item_column {
      display: flex;
      flex-direction: column;

      .item_name {
        color: #353535;
        font-size: 32px;
      }

      .warp {
        display: flex;
        margin-top: 20px;
        flex-wrap: wrap;
      }

    }

    .add {
      display: flex;
      color: #64A4F5;
      padding: 30px 0;
      width: 100%;
      justify-content: center;
      align-items: center;

      .icon {
        width: 32px;
        height: 32px;
        border-radius: 50%;
        line-height: 32px;
        text-align: center;
        background: #64A4F5;
        padding-bottom: 8px;
        color: white;
        margin-right: 16px;
      }
    }
  }


  .arrow {
    display: flex;
    flex-direction: row;
    width: 300px;
    justify-content: flex-end;
    align-items: center;

    text {
      color: #5F5F5F;
    }

    input {
      text-align: right;
      color: #5F5F5F;
      border-bottom: none;
    }
  }
}


.check_true {
  width: 200px;
  height: 60px;
  border-radius: 30px;
  background: #64A4F5;
  color: white;
  margin: 10px 10px;
  line-height: 60px;
  border: #64A4F5 solid 1px;
  text-align: center;
}

.check_false {
  width: 200px;
  height: 60px;
  border-radius: 30px;
  border: #64A4F5 solid 1px;
  background: white;
  color: #64A4F5;
  margin: 10px 10px;
  line-height: 60px;
  text-align: center;
}

.card_list {
  .title {
    display: flex;
    margin: 20px;
    justify-content: space-between;
    align-items: center;
    padding: 0 20px;

    .delete {
      color: #64A4F5;
    }
  }
}

.card_bg {
  background: white;
  border-radius: 16px;
  margin: 15px 20px;


}

.btn {
  margin: 80px 20px 40px 20px;
  border-radius: 16px;
}

.dialog {
  display: flex;
  position: relative;
  flex-direction: column;
  align-items: center;
  justify-content: center;

  .dialog-pop {
    position: relative;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;

    img {
      width: 560px;
      height: 580px;
    }

    .dialog_content {
      display: flex;
      top: 260px;
      padding: 20px 100px;
      position: absolute;
      flex-direction: column;
      align-items: center;

      .content {
        font-size: 32px;
        height: 100px;
        margin: 20px;
        color: #5f5f5f;
      }

      .btn {
        width: 450px;
        margin: 60px auto;
        height: 80px;
        text-align: center;
        line-height: 80px;
        color: white;
        background: #6AA4FC;
        border-radius: 10px;
      }
    }
  }

  .close {
    width: 70rpx;
    height: 70rpx;
    margin-top: 26px;
    bottom: 0;
    left: calc(50% - 35rpx);
  }
}

</style>
