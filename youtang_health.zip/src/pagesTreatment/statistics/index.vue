<template xmlns="http://www.w3.org/1999/html">
  <view class="sta_root">
    <view class="card">
      <view class="top_tips">截至
        <text class="font_blue">{{ today }}</text>
        ，您的60天治疗仪个性化方案已开展至第
        <text class="font_blue">{{ result.persistDays }}</text>
        天。以下是数据统计结果。
      </view>
      <view class="data">
        <view class="data_item">
          <view class="num">{{ result.checkInDays }}</view>
          <view class="desc">打卡天数</view>
        </view>
        <view class="data_item">
          <view class="num">{{ result.completedTimes }}</view>
          <view class="desc">已完成次数</view>
        </view>
        <view class="data_item">
          <view class="num">{{ result.uncompletedTimes }}</view>
          <view class="desc">未完成次数</view>
        </view>
        <view class="data_item">
          <view class="num">{{ result.pendingTimes }}</view>
          <view class="desc">待完成次数</view>
        </view>
      </view>
    </view>
    <view class="card">
      <view class="tab_bar">
        <view :class=" index === currentIndex? 'tab_item_true' :  'tab_item' "
              v-for="(item,index) in result.scheduleList" :key="index"
              @click="onClickTab(index)">{{ item.periodName }}
        </view>
      </view>
      <view class="view_date">
        <view>{{ currentData?.dailyScheduleList[0]?.date?.replaceAll('-', '.') }} -
          {{ currentData?.dailyScheduleList[9]?.date.replaceAll('-', '.') }}
        </view>
        <view>完成
          <text class="font_blue">{{ currentData?.completeTimes || 0 }}</text>
          /{{ currentData?.totalTimes || 20 }}次
        </view>
      </view>
      <view class="table">
        <view class="table_title">
          <view>治疗天数</view>
          <view>上午</view>
          <view>下午</view>
        </view>
        <view :class=" childIndex % 2 === 0 ? 'table_item bg_white' : 'table_item bg_grey'  "
              v-for="(childItem,childIndex) in currentData?.dailyScheduleList"
              :key="childIndex">
          <view class="vertical">
            <view>第{{ childIndex + 1 }}天</view>
            <view>{{ childItem.date }}</view>
          </view>
          <view class="vertical">
            <view class="horizontal"><img class="icon" :src="getImage(childItem.morningState)"
                                          alt=""/>{{ getStatusStr(childItem.morningState) }}
            </view>
            <view v-if="childItem.morningTime">{{ childItem.morningTime }}</view>
          </view>
          <view class="vertical">
            <view class="horizontal"><img class="icon" :src="getImage(childItem.afternoonState)"
                                          alt=""/>{{ getStatusStr(childItem.afternoonState) }}
            </view>
            <view v-if="childItem.afternoonTime">{{ childItem.afternoonTime }}</view>
          </view>
        </view>
      </view>
    </view>
    <view class="notify">
      以上数据统计，根据您的个性化方案实际执行情况自动生成。如您在使用过程中，遇到任何问题，请联系您的健康管理师协助处理。
    </view>
  </view>

</template>

<script setup lang="ts">
import {ref} from "vue";
import imgUrlFormat from "@/utils/imgUtils";
import Taro from "@tarojs/taro";
import planApi from "@/api/modules/plan";
import {IPlanStatistics, IPlanStatisticsDay} from "@/pagesTreatment/ts/types";
import dayjs from "dayjs";

definePageConfig({
  navigationBarTitleText: '记录数据统计'
})

const planId = Number(Taro.getCurrentInstance().router?.params?.planId || 0)
/**
 * 默认选中第一个
 */
const currentIndex = ref(0);
/**
 * 今天
 */
const today = ref<string>(dayjs().format('MM月DD日'));


const result = ref<IPlanStatistics>({} as IPlanStatistics);

const currentData = ref<IPlanStatisticsDay>({dailyScheduleList: []} as IPlanStatisticsDay)

/**
 * 状态文本
 * @param status
 * 0 1待完成 ，2已完成，3终止 4未完成
 */
const getStatusStr = (status: number) => {
  if (status === 1 || status === 2) {
    return "待完成";
  } else if (status === 3) {
    return "进行中";
  } else if (status === 4) {
    return "已完成";
  } else if (status === 6) {
    return "已中止";
  } else if (status === 5) {
    return "未完成";
  } else {
    return "";
  }
}
/**
 * 状态图标
 * @param status
 * 0 1待完成 ，2已完成，3终止 4未完成
 */
const getImage = (status: number) => {
  if (status <= 3) {
    return imgUrlFormat('common/finish_yellow.png');
  } else if (status === 4) {
    return imgUrlFormat('common/finish_blue.png');
  } else if (status <= 6) {
    return imgUrlFormat('common/finish_grey.png');
  }
}

/**
 * 请求统计数据
 */
const requestData = () => {
  planApi.requestPlanStatistics(planId).then((res) => {
    result.value = res.data;
    today.value = res.data.finishDate;
    currentData.value = result.value.scheduleList[currentIndex.value];
  })
}
requestData();

//
// watch(() => currentIndex.value, (newVal, oldVal) => {
//   if (newVal !== oldVal) {
//     dataList.value = result.value.scheduleList[newVal].dailyScheduleList
//   }
// })

/**
 * 切换tab
 * @param index
 */
const onClickTab = (index: number) => {
  currentIndex.value = index;
  currentData.value = result.value.scheduleList[currentIndex.value];
};


</script>

<style lang="less">
.sta_root {
  display: flex;
  flex-direction: column;

  .card {
    padding: 30px 20px;
    margin: 30px 20px;
    background: #fff;
    border-radius: 16px;

    .top_tips {
      padding-bottom: 30px;
      color: #353535;
      font-size: 32px;
      border-bottom: 1px solid #efefef;
    }

    .data {
      display: flex;
      justify-content: space-between;
      align-items: center;

      .data_item {
        display: flex;
        padding-top: 40px;
        flex-direction: column;
        align-items: center;

        .num {
          font-size: 48px;
          color: #353535;
          font-weight: bold;
        }

        .desc {
          font-size: 28px;
          margin-top: 16px;
          color: #5F5F5F;
        }
      }
    }

    .tab_bar {
      display: flex;
      flex-direction: row;
      flex-wrap: nowrap;
      overflow: hidden;
      overflow-x: auto;


      .tab_item {
        border: 1px solid #64A4F5;
        height: 62px;
        line-height: 62px;
        border-radius: 62px;
        text-align: center;
        font-size: 32px;
        flex-shrink: 0;
        margin-right: 20px;
        width: 206px;
        background: #fff;
        color: #64A4F5;
      }

      .tab_item_true {
        border: 1px solid #64A4F5;
        height: 62px;
        flex-shrink: 0;
        line-height: 62px;
        margin-right: 20px;
        text-align: center;
        border-radius: 62px;
        background: #64A4F5;
        font-size: 32px;
        width: 206px;
        color: #fff;
      }
    }

    .view_date {
      display: flex;
      padding: 30px 0;
      flex-direction: row;
      justify-content: space-between;
      align-items: center;

      view {
        font-size: 28px;
        color: #353535;
      }
    }

    .table {
      display: flex;
      flex-direction: column;

      .table_title {
        display: flex;
        background: #EBF6FF;
        flex-direction: row;
        justify-content: space-around;
        align-items: center;
        font-size: 28px;
        color: #353535;

        view {
          flex: 1;
          height: 72px;
          line-height: 72px;
          text-align: center
        }
      }

      .table_item {
        display: flex;
        flex-direction: row;
        justify-content: space-around;
        align-items: center;
        font-size: 28px;
        color: #353535;

        view {
          flex: 1;
          display: flex;
          align-items: center;
          justify-content: center;
          text-align: center;
          padding-top: 4px;
          padding-bottom: 4px;

          .icon {
            width: 32px;
            margin-right: 10px;
            height: 32px;
          }
        }
      }
    }

  }

  .notify {
    padding: 0 20px 40px 20px;
    font-size: 28px;
    color: #979797;
  }

}

.font_blue {
  color: #64A4F5;
}

.bg_white {
  background: #fff;
}

.bg_grey {
  background: #F8F8F8;
}
</style>
