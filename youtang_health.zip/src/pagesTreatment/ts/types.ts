/**
 * description:
 * date:2024/10/24
 * create by:郭
 */

export interface ILabelItem {
    label: string;
    value: number;
}

export interface IMedicineItem {
    medicationName: string | null;//名称
    medicationDose: string | null;//频次
    medicationFrq: string | null;//剂量
    showDosagePop: boolean;
    showFrequencyPop: boolean;
}

export interface IPlanDateItem {
    //治疗模式
    mode: number;
    //当前方案日期
    date: string;
    //上午方案治疗强度
    morning: number;
    //上午方案治疗状态 1待完成，2进行总，3已完成，4未完成（已过期），5未完成（终止）
    morningState: number;
    //上午治疗时间 HH:mm:ss
    morningTime: string;
    //下午方案治疗强度
    afternoon: number;
    //下午方案治疗状态
    afternoonState: number;
    //下午治疗时间 HH:mm:ss
    afternoonTime: string;

    operationText:string

    pointClass:string
}


export interface IPlanDetails {
    period: number;
    periodName: string;
    planId: number;
    dailyScheduleList: IPlanDateItem[];
}


export interface IPlanRecordItem {
    dataId: number;
    planState: number,
    planStateName: string;
    planName: string;
    planTime: string;
}

export interface IFormBaseInfo {
    customerName: string | null;
    customerGender: number | null;
    customerBirthday: string | null;
    diabetesType: number | null;
    confirmDate: string | null;//确诊日期
    useInsullin: number | null;//是否胰岛素 1是 2否
    useMedication: number | null;//是否用药 1是 2否
    complication: number;//是否并发症
    complicationTypes: string | null;//并发正类型
    complicationIntensity: number | null;//并发正强度  1轻 2中 3重
    medications: string | null;//用药信息
}

export interface IPlanStatisticsDayItem {
    mode: number;
    date: string;
    morning: number;
    morningState: number;
    morningTime: string;
    afternoon: number;
    afternoonState: number;
    afternoonTime: string;
}

export interface IPlanStatisticsDay {
    period: number;
    periodName: string;
    planId: number;
    completeTimes: number;
    totalTimes: number;
    dailyScheduleList:IPlanStatisticsDayItem[]
}

export interface IPlanStatistics {
    planId: number;
    persistDays: number;
    checkInDays: number;
    completedTimes: number;
    uncompletedTimes: number;
    pendingTimes: number;
    scheduleList: IPlanStatisticsDay[];
}
