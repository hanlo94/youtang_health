/**
 * description:
 * date:2024/10/30
 * create by:郭
 */

/**
 * 阿拉伯数字格式化成中文数字
 * @param num
 */
export const formatNumber2String = (num: number) => {
    if (num === 1) {
        return '一';
    } else if (num === 2) {
        return '二';
    } else if (num === 3) {
        return '三';
    } else if (num === 4) {
        return '四';
    } else if (num === 5) {
        return '五';
    } else if (num === 6) {
        return '六';
    } else {
        return ''
    }
}
