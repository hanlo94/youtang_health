/**
 * description:
 * date:2024/10/24
 * create by:郭
 */


import {ref} from "vue";

/**
 * 糖尿病病变
 */
export const diabeticComplicationOptions = ref([
    {value: 1, label: '血管并发症', checked: false},
    {value: 2, label: '糖尿病眼病', checked: false},
    {value: 3, label: '肾脏病变', checked: false},
    {value: 4, label: '头晕失眠', checked: false},
    {value: 5, label: '神经病变', checked: false},
    {value: 6, label: '糖尿病足', checked: false},
    {value: 7, label: '其他', checked: false},
]);

/**
 * 并发症强度
 */
export const complicationIntensityOptions = [
    {
        value: 1,
        label: '轻度'
    },
    {
        value: 2,
        label: '中度'
    },
    {
        value: 3,
        label: '重度'
    },
]

export const mockNumberList = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];


/**
 * 频次
 */
export const freqOptions = [
    {name: '1天1次', id: 1,},
    {name: '1天2次', id: 2,},
    {name: '1天3次', id: 3,},
    {name: '1天4次', id: 4,},
    {name: '1天5次', id: 5,},
    {name: '1天6次', id: 6,}
]
/**
 * 剂量
 */
export const dosageOptions = [
    {name: '1天1粒（片）', id: 1,},
    {name: '1天2粒（片）', id: 2,},
    {name: '1天3粒（片）', id: 3,},
    {name: '1天4粒（片）', id: 4,},
    {name: '1天5粒（片）', id: 5,},
    {name: '1天6粒（片）', id: 6,}
]



