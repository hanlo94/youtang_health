<template>
  <view class="plan_root">
    <view class="header">
      <view class="card_btn" @click="onClickInfo">
        <img :src="imgUrlFormat('common/health_info_icon.png')" alt=""/>
        我的健康信息
      </view>
      <view class="card_btn" @click="onClickRecord">
        <img :src="imgUrlFormat('common/record_data_icon.png')" alt=""/>
        我的记录数据
      </view>
    </view>
    <view v-if="result">
      <view class="view_content">
        <view class="date_index">
          <view class="left" @click="onDateChange(1)"></view>
          <view class="content_index">{{ result.periodName }}</view>
          <view class="right" @click="onDateChange(2)"></view>
        </view>
        <view class="grid">
          <view class="grid_item" v-for="(item,index) in result.dailyScheduleList" :key="index"
                @click="onClickGridItem(index)">
            <view :class=" index === currentIndex  ? 'text_true' : 'text_false' ">第{{ index + 1 }}天</view>
            <view class="point">
              <view :class="getPointClass(item.morningState)"></view>
              <view :class="getPointClass(item.afternoonState)"></view>
            </view>
          </view>
        </view>

        <!--        <view class="view_arrow">-->
        <!--          <RectUp v-if="showPoint" color="#bbbbbb" @click="showPoint =false"></RectUp>-->
        <!--          <RectDown v-else color="#bbbbbb" @click="showPoint =true"></RectDown>-->
        <!--        </view>-->


      </view>
      <!--    1待完成，2进行总，3已完成，4未完成（已过期），5未完成（终止）-->
      <view class="plan">
        <view class="ampm">
          <view class="card_pm ">
            <view class="title">上午</view>
            <view class="status"
                  v-if="currentItemIndex.morningState  <= CompositePlanState.TOBEGIN">
              <img :src="imgUrlFormat('common/finish_yellow.png')" alt=""/>待完成
            </view>
            <view class="status"
                  v-else-if="currentItemIndex.morningState >= CompositePlanState.EXPIRED ">
              <img :src="imgUrlFormat('common/finish_grey.png')" alt=""/>
              未完成
            </view>
            <view class="status" v-else-if="currentItemIndex.morningState == CompositePlanState.FINISH">
              <img :src="imgUrlFormat('common/finish_blue.png')" alt=""/>
              {{ currentItemIndex.morningTime }} 已完成
            </view>
            <view class="status" v-else-if="currentItemIndex.afternoonState == CompositePlanState.NORMAL">
              <img :src="imgUrlFormat('common/finish_blue.png')" alt=""/>
              {{ currentItemIndex.afternoonTime }} 进行中
            </view>
          </view>
          <view class="card_pm ">
            <text class="title">下午</text>
            <view class="status"
                  v-if=" currentItemIndex.afternoonState <= CompositePlanState.TOBEGIN">
              <img :src="imgUrlFormat('common/finish_yellow.png')"
                   alt=""/>待完成
            </view>
            <view class="status"
                  v-else-if="currentItemIndex.afternoonState >= CompositePlanState.EXPIRED">
              <img :src="imgUrlFormat('common/finish_grey.png')" alt=""/>
              未完成
            </view>
            <view class="status" v-else-if="currentItemIndex.afternoonState == CompositePlanState.FINISH">
              <img :src="imgUrlFormat('common/finish_blue.png')" alt=""/>
              {{ currentItemIndex.afternoonTime }} 已完成
            </view>
            <view class="status" v-else-if="currentItemIndex.afternoonState == CompositePlanState.NORMAL">
              <img :src="imgUrlFormat('common/finish_blue.png')" alt=""/>
              {{ currentItemIndex.afternoonTime }} 进行中
            </view>
          </view>
        </view>
        <!--    view_btn blue 未完成灰色、已完成蓝色、待完成橘黄色-->
        <view :class="currentItemIndex.pointClass" @click="onRetryBtnClick">
          <view class="start">{{ currentItemIndex.operationText }}</view>
          <view class="date">{{ currentItemIndex.date }}</view>
        </view>

        <view class="notify">今天是为您健康助力的第
          <text style="color: #64A4F5">{{ dayStr }}</text>
          天
        </view>
        <view class="notify mt16">为了自己的身体，坚持就是胜利！</view>
      </view>
      <view class="bottom_text">
        点击“
        <text class="text_blue">开始治疗</text>
        ”，连接
        <text class="text_blue">复合磁治疗仪</text>
        ，系统根据您的身体情况，自动匹配对应模式及档位。请根据系统提示操作，每天前进一小步，为健康加油。
      </view>
    </view>
    <view v-else class="view_no_data">
      <nut-empty image="https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/common/nodata.png"
                 description="暂无进行中的个性化方案， 填写您的健康信息，定制专属方案吧！"></nut-empty>
    </view>
  </view>

</template>

<script setup lang="ts">
import {onUnmounted, ref, watch} from "vue";
import Taro from "@tarojs/taro";
import imgUrlFormat from "@/utils/imgUtils";
import planApi from "@/api/modules/plan";
import {IPlanDateItem, IPlanDetails} from "@/pagesTreatment/ts/types";
import {
  CMD_PREFIX_APP,
  CMD_SUFFIX,
  CompositePlanState,
  MAGNET_NAME_PREFIX,
  MagnetCmdState,
  MagnetDeviceUUID,
  MagnetRunningTimeReportCmd,
  MagnetScheduleState,
  MagnetStartMeasureCmd
} from "@/pagesComposite/MagnetConstants";
import {MagnetCommandProcessor} from "@/pagesComposite/MagnetProcessor";
import {realTimeLogger} from "@/component/realTimeLogger";
import {clearHeartCheck, clearTimer, startHeartCheck, startTimer} from "@/component/Timer";
import {ab2hex, closeBleAdapter, hex2ArrayBuffer} from "@/component/ble/Ble";
import {DeviceBrand, DeviceCategory} from "@/config/device/deviceConfig";
import {showToast, showToastLong} from "@/utils/toastUtils";
import {addMinutes, formatDate, formatDateTohms, formatFullDateToStr} from "@/utils/dateUtils";
import {MagnetApi, MagnetUpload} from "@/pagesComposite/MagnetApi";
import SugarApi from "@/api/modules/sugar";
import dayjs from "dayjs";

definePageConfig({
  navigationBarTitleText: "治疗仪个性化方案",
});

/**
 * 列表传入。默认0
 */
const planId = ref(0)
planId.value = Number(Taro.getCurrentInstance().router?.params?.planId || 0)

/**
 * grid选中 默认第一个
 */
const currentIndex = ref(0);
/**
 * 详情
 */
const result = ref<IPlanDetails>({} as IPlanDetails);

/**
 * 第几个十天 0为当天最新天数
 */
const currentDateIndex = ref(1);
//选中的item
const currentItemIndex = ref<IPlanDateItem>({} as IPlanDateItem);

const dayStr = ref('-')

Taro.eventCenter.on('planId', (e) => {
  planId.value = e.planId;
  currentDateIndex.value = 1;
  requestPeriodSchedule(currentDateIndex.value)
})

onUnmounted(() => {
  console.log("index...onUnmounted");
  Taro.eventCenter.off('planId');
  stopBle(false)
})

function updateItemState(operationText, pointClass) {
  currentItemIndex.value.operationText = operationText;
  currentItemIndex.value.pointClass = pointClass;
}

/**
 * button文案
 */
const changeButtonText = () => {
  const today = formatDate(new Date());
  if (dayjs(currentItemIndex.value.date).isSame(today)) {//今天
    // 1待完成，2进行中，3已完成，4未完成（已过期），5未完成（终止）
    if (isMorning()) {//上午
      if (currentItemIndex.value.morningState == CompositePlanState.FINISH) {
        updateItemState('已结束', 'view_btn grey')
      } else if (currentItemIndex.value.morningState == CompositePlanState.NORMAL) {
        updateItemState('治疗中', 'view_btn blue')
      } else if (currentItemIndex.value.morningState <= CompositePlanState.TOBEGIN) {
        updateItemState('开始治疗', 'view_btn blue')
      }
    } else {//下午
      if (currentItemIndex.value.afternoonState == CompositePlanState.FINISH) {
        updateItemState('已结束', 'view_btn grey')
      } else if (currentItemIndex.value.afternoonState == CompositePlanState.NORMAL) {
        updateItemState('治疗中', 'view_btn blue')
      } else if (currentItemIndex.value.afternoonState <= CompositePlanState.TOBEGIN) {
        updateItemState('开始治疗', 'view_btn blue')
      }
    }
  } else if (dayjs(currentItemIndex.value.date).isBefore(today)) {//过去的时间
    updateItemState("已结束", 'view_btn grey')
  } else { //未来的时间
    updateItemState("待开始", 'view_btn yellow')
  }
};

const isMorning = () => {
  const hh = Number(dayjs().format('HH'));
  return hh < 12;
};

/**
 *  给点赋颜色
 * @param status 1待完成，2进行中，3已完成，4未完成（已过期），5未完成（终止）
 */
const getPointClass = (status: number) => {
  if (status == CompositePlanState.TOBEGIN) {
    return 'pitem  yellow'
  } else if (status == CompositePlanState.NORMAL || status == CompositePlanState.FINISH) {
    return 'pitem  blue'
  } else if (status == CompositePlanState.EXPIRED || status == CompositePlanState.ABORT) {
    return 'pitem  grey'
  } else if (status == CompositePlanState.FUTURE) {
    return 'pitem  transparent'
  }
}

/**
 * 检测选中的变化 如果grid index变化，更新下面天数
 */
watch(() => currentIndex.value, (newVal, oldVal) => {
  if (newVal !== oldVal) {
    dayStr.value = String((currentDateIndex.value - 1) * 10 + (newVal + 1))
    currentItemIndex.value = result.value.dailyScheduleList[newVal];
    // console.log("index.watch.currentItemIndex..currentItemIndex.value.state=", currentItemIndex.value.afternoon);
    changeButtonText()
  }
});

/**
 * 请求数据
 */
const requestPeriodSchedule = (period: number) => {
  planApi.requestCurrentPlan({planId: planId.value, period}).then(res => {
    result.value = res.data;
    console.log("index.result..result=", JSON.stringify(result), '; res.data=', res.data);
    if (res.data) {
      let index = result.value.dailyScheduleList.findIndex((item) => item.date === dayjs().format('YYYY-MM-DD'))
      currentIndex.value = index === -1 ? 0 : index;
      if (res.data.period == 1 && currentIndex.value == 0) {
        dayStr.value = 1
      }
      currentItemIndex.value = result.value.dailyScheduleList[currentIndex.value];
      currentDateIndex.value = result.value.period;
      planId.value = result.value.planId;
      changeButtonText()
    }
  })
}

requestPeriodSchedule(currentDateIndex.value);


/**
 * 跳转记录页面
 */
const onClickRecord = () => {
  Taro.navigateTo({
    url: "/pagesTreatment/record/index",
  });
};
/**
 * 跳转我的健康信息
 */
const onClickInfo = () => {
  Taro.navigateTo({
    url: "/pagesTreatment/info/index?planId=" + planId.value,
  });
};

/**
 * date改变
 * @param type
 */
const onDateChange = (type: number) => {
  if (type === 1) {
    if (currentDateIndex.value > 1) currentDateIndex.value--;
  } else if (type === 2) {
    if (currentDateIndex.value < 6) currentDateIndex.value++;
  }
  //刷新数据
  requestPeriodSchedule(currentDateIndex.value)
  //选中状态归零
  currentIndex.value = 0;

};

/**
 * 切换选中状态
 * @param index
 */
const onClickGridItem = (index: number) => {
  currentIndex.value = index;
};


// region 蓝牙操作
const scaleMeasureState = ref<MagnetScheduleState>();

let deviceSn: string = '';

// 复合磁解析处理
const processor = new MagnetCommandProcessor();

// 是否已连接
const connected = ref<boolean>(false);
const connecting = ref<boolean>(false);
const scanning = ref<boolean>(false);

const connectedDevice = ref();

const logger = realTimeLogger();

// region 蓝牙权限与蓝牙适配器状态操作

/**
 * 检验蓝牙授权状态
 */
const checkBlePermission = (silent: boolean = false) => {
  console.log('index.checkBlePermission.silent=', silent);
  Taro.getSetting({
    success(res) {
      logger.log("index.vue.checkBlePermission.getSetting.success.res.authSetting=", res.authSetting);
      if (!res.authSetting['scope.bluetooth']) {
        Taro.authorize({
          scope: 'scope.bluetooth',
          success: (res) => {
            // showShortToast('蓝牙授权成功')
            logger.log("checkBlePermission.authorize.success.", JSON.stringify(res));
            openBluetoothAdapter()
          },
          fail: (res) => {
            // showShortToast('蓝牙授权失败')
            logger.log('蓝牙授权失败', JSON.stringify(res));
            if (!silent) {
              showBleAuthorizeModal()
            }
            onBleAuthorize()
          }
        })
      } else {
        openBluetoothAdapter()
      }
    },
    fail(res) {
      console.log('index.checkBlePermission.fail.', JSON.stringify(res));
      if (!silent) {
        showBleAuthorizeModal()
      }
      onBleAuthorize()
    }
  })
};

/**
 * 打开蓝牙适配器
 */
const openBluetoothAdapter = () => {
  const systemSetting = Taro.getSystemSetting();
  console.log("index..openBluetoothAdapter.setting=", JSON.stringify(systemSetting));
  const bleEnabled = systemSetting.bluetoothEnabled;
  const locationEnabled = systemSetting.locationEnabled;
  console.log("index..openBluetoothAdapter.bleEnabled=", bleEnabled, '; locationEnabled=', locationEnabled);
  Taro.openBluetoothAdapter({
    success: (res) => {
      logger.log("index.vue.openBluetoothAdapter.success.", JSON.stringify(res));
      if (locationEnabled) {
        startScan();
        updateState(MagnetScheduleState.BIND_TO_SCAN)
      } else {
        updateState(MagnetScheduleState.LOCATION_CLOSE);
        showBleDisableModal(MagnetScheduleState.LOCATION_CLOSE.subState)
      }
    },
    fail: (res) => {
      logger.log("index.vue.openBluetoothAdapter.fail.", JSON.stringify(res), '; JSON.stringify(res).indexOf(\'openBluetoothAdapter:fail already opened = ', JSON.stringify(res).indexOf('openBluetoothAdapter:fail already opened'));
      if (JSON.stringify(res).indexOf('openBluetoothAdapter:fail already opened') != -1) {
        console.log('index.openBluetoothAdapter,already opened.start scan');
        if (locationEnabled) {
          startScan();
          updateState(MagnetScheduleState.BIND_TO_SCAN)
        } else {
          updateState(MagnetScheduleState.LOCATION_CLOSE);
          showBleDisableModal(MagnetScheduleState.LOCATION_CLOSE.subState)
        }
      } else {
        console.log('index.openBluetoothAdapter,failed');
        let str;
        if (!bleEnabled && !locationEnabled) {
          str = '手机蓝牙、定位未打开，请先打开手机蓝牙、定位权限'
        } else if (!bleEnabled) {
          str = MagnetScheduleState.BLE_DISABLE.subState
        } else {
          str = MagnetScheduleState.LOCATION_CLOSE.subState
        }
        showBleDisableModal(str);
        onBleDisable()
      }
    },
    complete: () => {
      onBleAdapterState()
    }
  })
};

const onBleAdapterState = () => {
  Taro.onBluetoothAdapterStateChange(res => {
    if (res.available) {
      // 蓝牙适配器可用
      logger.log("onBluetoothAdapterStateChange 蓝牙适配器可用, scaleMeasureState.value?.state=", scaleMeasureState.value?.state);
      if (scaleMeasureState.value?.state == MagnetScheduleState.BLE_DISABLE.state) {
        const systemSetting = Taro.getSystemSetting();
        if (systemSetting.locationEnabled) {
          updateState(MagnetScheduleState.BIND_TO_SCAN);
          restart()
        } else {
          updateState(MagnetScheduleState.LOCATION_CLOSE);
          showToastLong("位置信息未开启，请先打开")
        }
      }
    } else {
      // 蓝牙适配器不可用
      logger.log("onBluetoothAdapterStateChange 蓝牙适配器不可用");
      stopBle(false);
      onBleDisable()
    }
  })
};

//
const onBleDisable = () => {
  showToast('蓝牙不可用')
  updateState(MagnetScheduleState.BLE_DISABLE)
};

const onBleAuthorize = () => {
  showToast('蓝牙未授权')
  updateState(MagnetScheduleState.BLE_AUTHORIZE)
};

// endregion

// region  扫描与连接

const startScan = () => {
  logger.log('index.startScan.');
  Taro.startBluetoothDevicesDiscovery({
    allowDuplicatesKey: false,
    services: [
      MagnetDeviceUUID.MAGNET_UUID,
      MagnetDeviceUUID.MAGNET_UUID_UPPER,
    ],
    complete: (res) => {
      // 扫描结束
      logger.log("startScan 开启扫描结束 ", JSON.stringify(res));
    },
    success: (res) => {
      logger.log('index.startScan.success.', JSON.stringify(res));
      scanning.value = true;
      onBluetoothDeviceFound(res);
      updateState(MagnetScheduleState.BIND_SCANNING);
      startScanTimer();
      showToastLong("开始扫描治疗仪")
    },
    fail: (res) => {
      logger.log("index.vue.startScan.fail.", JSON.stringify(res), '; res.errMsg=', res.errMsg, ';res.errMsg.indexOf(\'already discovering devices\') != -1=', (res.errMsg.indexOf('already discovering devices') != -1));
      if (res.errMsg && res.errMsg.indexOf('already discovering devices') != -1) {
        // 已开启扫描
        console.log('index.startScan.fail.already stop then start ')
      } else {
        updateState(MagnetScheduleState.BIND_SCAN_FAILURE);
        logger.log('index.start scan fail. update state', scaleMeasureState.value?.mainState)
      }
    }
  })
};

const stopScan = (callback: ActionCallback | null = null) => {
  console.log('index.stopScan.scanning.value=', scanning.value, '; time is ', Date.now());
  if (scanning.value) {
    console.log('index.stopScan.scanning.value=', scanning.value, '; time is ', Date.now());
    Taro.stopBluetoothDevicesDiscovery({
      success: (res) => {
        logger.log("index.vue.stopScan.success.", JSON.stringify(res));
        scanning.value = false;
        callback && callback()
      },
      fail: (res) => {
        logger.log("index.vue.stopScan.fail.", JSON.stringify(res));
      },
      complete: (res) => {
        console.log('index.complete.stopBluetoothDevicesDiscovery', JSON.stringify(res))
      }
    })
  } else {
    callback && callback()
  }
};

/**
 * 扫描发现治疗仪监听
 * @param res
 */
const onBluetoothDeviceFound = (res) => {
  console.log('index.onBluetoothDeviceFound.start', JSON.stringify(res));
  Taro.onBluetoothDeviceFound((res) => {
    console.log('index.Taro.onBluetoothDeviceFound.res=', JSON.stringify(res));
    res.devices.forEach(device => {
      console.log('index.onDeviceFound .deviceSn=', deviceSn, '; device.name=', device.name, (deviceSn && device.name != deviceSn));
      // console.log('index.onBluetoothDeviceFound.res.devices.forEach.device=',JSON.stringify(device))
      if (!device.name && !device.localName) {
        console.log('index.onBluetoothDeviceFound 过滤设备名称为空 name:', device.name, '; localName:', device.localName);
        return
      }
      if (device.name.indexOf(MAGNET_NAME_PREFIX) == -1) {
        console.log('index.过滤 设备名称前缀 deviceId=', device.deviceId, '; name=', device.name, ' ; localName=', device.localName, '; deviceSn=', deviceSn);
        return;
      } else {
        console.log('index.onBluetoothDeviceFound.res.devices.forEach.device.name=', device.name, '; device.localName=', device.localName, '; device.deviceId=', device.deviceId, '; device.name.indexOf(MAGNET_NAME_PREFIX)=', device.name.indexOf(MAGNET_NAME_PREFIX), '; ', MAGNET_NAME_PREFIX)
      }
      if (!device.advertisServiceUUIDs || device.advertisServiceUUIDs.length === 0) {
        console.log('index.onBluetoothDeviceFound 过滤开放服务为空 deviceId=', device.deviceId);
        return
      }
      // onBluetoothDeviceFound.res= {"devices":[{"deviceId":"20:24:4A:00:00:01","name":"YT:01000001","RSSI":-68,"connectable":true,"advertisData":{},"advertisServiceUUIDs":["0000FFF0-0000-1000-8000-00805F9B34FB"],"localName":"YT:01000001","serviceData":{}}]}
      // index.js:1 index.onDeviceFound .deviceSn= undefined ; device.name= YT:01000001 true
      // index.js:1 index.onBluetoothDeviceFound.res.devices.forEach.device.name= YT:01000001 ; device.localName= YT:01000001 ; device.deviceId= 20:24:4A:00:00:01 ; device.name.indexOf(MAGNET_NAME_PREFIX)= 0 ;  YT:01

      if (deviceSn != 'undefined' && deviceSn != undefined && deviceSn.length > 0 && deviceSn && device.name != deviceSn) {
        // 已绑定但扫描到其他设备
        console.log('index.onBluetoothDeviceFound 过滤 绑定设备名 deviceId=', device.deviceId, '; name=', device.name, ' ; localName=', device.localName, '; deviceSn=', deviceSn);
        return;
      }
      // notifyResultList.value.push("过滤服务" + device.advertisServiceUUIDs.join(","))
      if (device.advertisServiceUUIDs.join(",").toUpperCase().indexOf(MagnetDeviceUUID.MAGNET_UUID_PREFIX) != -1) {
        console.log('index.onBluetoothDeviceFound index of 发现匹配服务', device.advertisServiceUUIDs)
      } else {
        console.log('index.onBluetoothDeviceFound index of 未找到匹配服务', device.advertisServiceUUIDs);
        return;
      }
      // deviceList.value.push(device)
      console.log('onBluetoothDeviceFound device=', JSON.stringify(device), '; connectedDevice.value=', connectedDevice.value);
      if (!connectedDevice.value) {
        connectedDevice.value = device;
        showToast('扫描成功，找到匹配治疗仪');
        updateState(MagnetScheduleState.BIND_SCAN_SUCCESS)
      }
      stopScan();
      clearTimer();
      startConnect()
    })
  })
};

const startConnect = () => {
  if (connected.value) {
    // 已连接
    logger.log("startConnect 已连接 不重复连接");
    return
  }
  if (!connecting.value) {
    connecting.value = true
  } else {
    // 连接中
    logger.log("startConnect 连接中不重复连接");
    return
  }
  updateState(MagnetScheduleState.CONNECTING);
  // notifyResultList.value.push("找到设备，开始连接," + Date.now())
  console.log('index.startConnect.device.value=', connectedDevice.value);
  let {deviceId} = connectedDevice.value;
  startScanTimer();
  showToast('开始连接')
  Taro.createBLEConnection({
    deviceId,
    timeout: 5000,
    success: function (res) {
      console.log('index.createBLEConnection.success.', JSON.stringify(res));
      onConnectSuccess()
    },
    fail: function (res) {
      console.log('index.startConnect.createBLEConnection.fail.', JSON.stringify(res));
      // notifyResultList.value.push("连接失败" + prints(res))
      updateState(MagnetScheduleState.CONNECT_FAILURE);
      clearTimer()
    },
    complete: (res) => {
      // notifyResultList.value.push("建立连接调用结束," + Date.now())
      onConnectionStateChange()
    }
  })

};

const onLostConnect = () => {
  logger.log("onConnectFailure.");
  if (connectedDevice.value && scaleMeasureState.value === MagnetScheduleState.MEASURING) {
    disConnect(() => {
      startConnect()
    })
  } else {
    connected.value = false;
    connecting.value = false;
    if (scaleMeasureState.value === MagnetScheduleState.MEASURE_SUCCESS) {
      updateItemState("已结束", 'view_btn grey')
    } else {
      updateState(MagnetScheduleState.LOST_CONNECT);
    }
    uploadDeviceShutDown();
    clearTimer();
    clearHeartCheck()
  }
};

const onConnectSuccess = () => {
  console.log('index.onConnectSuccess.');
  connected.value = true;
  updateState(MagnetScheduleState.CONNECT_SUCCESS);
  startNotify();
  // notifyResultList.value.push("连接成功，开始监听服务")
  bindDevice();
  delayCall(() => {
    heartCheck()
  })
};

const onConnectionStateChange = () => {
  console.log('index.onConnectionStateChange.');
  Taro.onBLEConnectionStateChange((res) => {
    console.log('onConnectionStateChange', `device ${res.deviceId} state has changed, connected: ${res.connected}`);
    if (res.connected) {
      // onConnectSuccess()
      // heartCheck()
    } else {
      onLostConnect()
    }
  })
};

const offBLEConnectionStateChange = () => {
  Taro.offBLEConnectionStateChange((res) => {
    console.log('onConnectionStateChange', `device ${res.deviceId} state has changed, connected: ${res.connected}`)
  })
};


const startNotify = () => {
  console.log("index..startNotify.");
  let {deviceId} = connectedDevice.value;
  // startTimer(() => {
  //   notifyCharacteristicValueChange(deviceId, MagnetDeviceUUID.MAGNET_UUID_UPPER, MagnetDeviceUUID.SERV_MAGNET_UUID_UPPER)
  // }, 200)
  // // notifyResultList.value.push("直接对指定服务开始监听")

  Taro.getBLEDeviceServices({
    deviceId,
    success: (res) => {
      console.log('index.getBLEDeviceServices.success.', JSON.stringify(res));
      // 查找特定服务 ，找到继续查找特征值，找不到直接反馈失败
      if (res.services && res.services.length > 0) {
        deviceServiceId = res.services.find(service =>
            service.isPrimary && service.uuid.toUpperCase().indexOf(MagnetDeviceUUID.MAGNET_UUID_PREFIX) != -1
        );
        logger.log('getBLEDeviceServices deviceServiceId=', deviceServiceId)
      }
      if (deviceServiceId) {
        // notifyResultList.value.push("找到对应服务，正式准备开始监听")
        getBleCharacteristics(deviceId, deviceServiceId.uuid)
      } else {
        updateState(MagnetScheduleState.SERVICE_NOT_FOUND)
      }

    },
    fail: (res) => {
      logger.log('index.getBLEDeviceServices.fail.', JSON.stringify(res));
      updateState(MagnetScheduleState.SERVICE_NOT_EXIST)
    }
  })
};

let deviceServiceId: Taro.getBLEDeviceServices.BLEService | undefined,
    notifyCharacteristic: Taro.getBLEDeviceCharacteristics.BLECharacteristic | undefined,
    writeCharacteristic: Taro.getBLEDeviceCharacteristics.BLECharacteristic | undefined;

const getBleCharacteristics = (deviceId: string, serviceId: string) => {
  // serviceId :0000FFF0-0000-1000-8000-00805F9B34FB  MAGNET_UUID_UPPER
  Taro.getBLEDeviceCharacteristics({
    deviceId,
    serviceId,
    success: (res) => {
      console.log('index.getBLEDeviceCharacteristics.success.', JSON.stringify(res));
      if (res.characteristics && res.characteristics.length > 0) {
        notifyCharacteristic = res.characteristics.find(characteristic =>
            characteristic.uuid.toUpperCase().indexOf(MagnetDeviceUUID.SERV_MAGNET_UUID_PREFIX) != -1
        );
        logger.log("解析监听特征值：" + notifyCharacteristic?.uuid)
        // notifyResultList.value.push("解析监听特征值：" + notifyCharacteristic?.uuid)
        writeCharacteristic = res.characteristics.find(characteristic =>
            characteristic.uuid.toUpperCase().indexOf(MagnetDeviceUUID.SERV_MAGNET_WRITE_UUID_PREFIX) != -1
        );
        logger.log("解析写入特征值：" + writeCharacteristic?.uuid)
        // notifyResultList.value.push("解析写入特征值：" + writeCharacteristic?.uuid)
      }
      if (notifyCharacteristic) {
        // 找到特征值  SERV_MAGNET_UUID_UPPER   0000FFF1-0000-1000-8000-00805F9B34FB
        console.log('index.getBLEDeviceCharacteristics.success. 找到特征值', JSON.stringify(notifyCharacteristic));
        // 开始读特征值
        notifyCharacteristicValueChange(deviceId, serviceId, notifyCharacteristic.uuid)
        // notifyResultList.value.push("找到特征值 开始监听")
      } else {
        updateState(MagnetScheduleState.SERVICE_NOT_FOUND)
      }
    },
    fail: (res) => {
      logger.log('index.getBLEDeviceCharacteristics.fail.', JSON.stringify(res));
      updateState(MagnetScheduleState.SERVICE_NOT_EXIST)
    }
  })
};

const notifyCharacteristicValueChange = (deviceId: string, serviceId: string, uuid: string) => {
  Taro.notifyBLECharacteristicValueChange({
    state: true,
    deviceId,
    serviceId,
    characteristicId: uuid,
    success: (res) => {
      logger.log('index.notifyBLECharacteristicValueChange.success.', JSON.stringify(res));
    },
    fail: (res) => {
      logger.log('index.notifyBLECharacteristicValueChange.fail.', JSON.stringify(res))
    },
    complete: (res) => {
      logger.log('notifyCharacteristicValueChange.complete,', JSON.stringify(res));
      onNotify()
    }
  })
};

const onNotify = () => {
  console.log("index..onNotify.");
  onNotifyResponse();
  startMeasure();
  delayCall(() => {
    checkDevicePowerOn()
  }, 300)
};

const startMeasure = () => {
  console.log("index..startMeasure. sendScheme.");
  sendScheme();
};

const delayCall = (callback: ActionCallback, delay = 200) => {
  startTimer(() => {
    console.log("index...delayCall callback=", callback);
    callback && callback()
  }, delay)
};

/**
 * 监听蓝牙特征值反馈
 */
const onNotifyResponse = () => {
  logger.log("index..onNotifyResponse.");
  Taro.onBLECharacteristicValueChange((res) => {
    let hexString = ab2hex(res.value);
    logger.log(`onNotifyResponse.characteristic ${res.characteristicId} has changed `, '; parseValue=', hexString);
    // 470000e707011e0408240000f08a11
    let cmd = processor.analysisHexCmd(hexString);
    const cmdMode = cmd.control;
    logger.log("index.onNotifyResponse 控制字：" + cmdMode);
    if (cmdMode == MagnetCmdState.Measuring) {
      const startMeasureCmd = processor.analysisStartMeasure(cmd);
      console.log(`onNotifyResponse.onCharacteristicChanged.Measuring.startMeasureCmd=${startMeasureCmd}`);
      modeStrength = startMeasureCmd.modeStrength;
      // notifyResultList.value.push("startMeasureCmd 开始治疗：modeStrength:" + modeStrength)
      writeToDevice(CMD_PREFIX_APP + hexString.substring(2));
      uploadStartMeasure(startMeasureCmd);
      updateState(MagnetScheduleState.MEASURING);
    } else if (cmdMode == MagnetCmdState.MeasureFinish) {
      const magnetCmd = processor.analysisStopMeasure(cmd);
      // notifyResultList.value.push("MeasureFinish：治疗结束")
      updateState(MagnetScheduleState.MEASURE_SUCCESS);
      uploadMeasureFinish();
      console.log(`onNotifyResponse.onCharacteristicChanged.MeasureFinish.magnetCmd=${magnetCmd}`);
      finishSchedule();
      let ms;
      if (modeStrength == undefined || modeStrength.length == 0) {
        // 默认以控制血糖、强档 避免出现无反馈
        ms = "21";
      } else {
        ms = modeStrength;
      }
      const checkSum = MagnetCmdState.MeasureFinish + parseInt(ms, 16);
      writeToDevice(CMD_PREFIX_APP + MagnetCmdState.MeasureFinish.toString(16) + ms + "000000" + checkSum.toString(16) + CMD_SUFFIX);

    } else if (cmdMode == MagnetCmdState.ReportsStartUp) {
      const startUpCmd = processor.analysisStartupReport(cmd);
      console.log(`onNotifyResponse.onCharacteristicChanged: ReportsStartUp.startUpCmd=${startUpCmd}`);
      uploadDeviceStartUp(startUpCmd);
      // notifyResultList.value.push("ReportsStartUp：上报开机时间")
    } else if (cmdMode == MagnetCmdState.HeartCheck) {
      const heartCheck = processor.analysisHeartCheck(cmd);
      if (modeStrength == undefined || modeStrength.length == 0) {
        modeStrength = heartCheck.modeStrength;
      }
      if (scaleMeasureState.value?.state == MagnetScheduleState.CONNECT_SUCCESS.state) {
        if (parseInt(modeStrength) > 0 && parseInt(heartCheck.runningState) == 1) {
          // 当前模式非空且正在运行
          updateState(MagnetScheduleState.MEASURING);
        }
      }
      // notifyResultList.value.push("心跳检测 " + Date.now())
      // showToast("心跳检测反馈 " + hexString)
      logger.log("onNotifyResponse.onCharacteristicChanged: HeartCheck");
    } else if (cmdMode == MagnetCmdState.DeliveryScheme) {
      logger.log("onNotifyResponse.onCharacteristicChanged: DeliveryScheme");
      updateState(MagnetScheduleState.SEND_SCHEME)
    }
  })
};

const offCharacteristicValueChange = () => {
  logger.log("offCharacteristicValueChange.");
  Taro.offBLECharacteristicValueChange((res) => {
    logger.log('index.onBLECharacteristicValueChange', JSON.stringify(res))
  })
};

const writeToDevice = (content: string) => {
  if (connectedDevice.value) {
    let {deviceId} = connectedDevice.value;
    console.log("index..writeToDevice.content=", content, '; deviceId=', deviceId, '; connectedDevice=', connectedDevice.value);
    // writeList.value.push("writeToDevice " + content)
    Taro.writeBLECharacteristicValue({
      // 这里的 deviceId 需要在 getBluetoothDevices 或 onBluetoothDeviceFound 接口中获取
      deviceId,
      // 这里的 serviceId 需要在 getBLEDeviceServices 接口中获取
      // serviceId: MagnetDeviceUUID.MAGNET_UUID_UPPER,
      serviceId: deviceServiceId.uuid,
      // 这里的 characteristicId 需要在 getBLEDeviceCharacteristics 接口中获取
      // characteristicId: MagnetDeviceUUID.SERV_MAGNET_WRITE_UUID_UPPER,
      characteristicId: writeCharacteristic.uuid,

      value: hex2ArrayBuffer(content),
      success: function (res) {
        // writeList.value.push("writeToDevice success:" + prints(res))
        logger.log("writeToDevice success:", JSON.stringify(res))
      },
      fail: function (res) {
        logger.log("writeToDevice fail:" + prints(res))
        // writeList.value.push("writeToDevice fail:" + prints(res))
      },
      complete: (res) => {
        logger.log("writeToDevice complete:" + JSON.stringify(res))
        // writeList.value.push("writeToDevice complete:" + JSON.stringify(res))
      }
    })
  }
  // Taro.writeBLECharacteristicValue({
  //   // 这里的 deviceId 需要在 getBluetoothDevices 或 onBluetoothDeviceFound 接口中获取
  //   deviceId,
  //   // 这里的 serviceId 需要在 getBLEDeviceServices 接口中获取
  //   serviceId: deviceServiceId.uuid,
  //   // 这里的 characteristicId 需要在 getBLEDeviceCharacteristics 接口中获取
  //   characteristicId: writeCharacteristic.uuid,
  //   // 这里的value是ArrayBuffer类型
  //   value: new TextEncoder().encode(content).buffer,
  //   success: function (res) {
  //     writeList.value.push(JSON.stringify(res))
  //     console.log("writeBLECharacteristicValue success&", res.errMsg)
  //   }
  // })
};

const prints = (res) => {

  const keys: string[] = [];
  const values: string[] = [];
  if (res && res.keys) {
    res.keys.forEach((key) => {
      keys.push(key);
      values.push(res[key])
    })
  }
  // for (const key in jsonObject) {
  //   keys.push(key);
  //   values.push(jsonObject[key])
  // }
  return keys.join(",") + "\n" + values.join(",")
};

const disConnect = (callback?: () => void) => {
  logger.log("disConnect.", connectedDevice.value);
  const {deviceId} = connectedDevice.value;
  offBLEConnectionStateChange();
  Taro.closeBLEConnection({
    deviceId,
    success: (res) => {
      logger.log('index.closeBLEConnection.success.', JSON.stringify(res));
      connected.value = false;
      connecting.value = false;
      connectedDevice.value = null;
      callback && callback()
    },
    fail: (res) => {
      logger.log('index.closeBLEConnection.fail.', JSON.stringify(res))
    }
  })
};


/**
 * 停止蓝牙活动
 * 1、
 * 2、关闭连接
 * 3、停止扫描
 * 4、关闭蓝牙适配器
 */
const stopBle = function (closeBle: boolean = true) {
  if (connected.value) {
    offCharacteristicValueChange();
    console.log('index.stopBle.ready to disconnect');
    disConnect()
  }
  clearTimer();
  clearHeartCheck();
  stopScan();
  if (closeBle) {
    closeBleAdapter()
  }
};

/**
 * 刷新蓝牙
 */
const restart = () => {
  console.log('index.restart.');
  if (connected.value) {
    offCharacteristicValueChange();
    disConnect()
  }
  stopScan(() => {
    startScan()
  })
};

// const clear = () => {
//   // notifyResultList.value = []
//   writeList.value = []
// }

const checkDevicePowerOn = () => {
  writeToDevice("AB080000000008A5");
  // writeList.value.push("checkDevicePowerOn")
};

// endregion

// region 扫描计时器与心跳检测

/**
 * 扫描计时器
 */
const startScanTimer = () => {
  console.log('index.startScanTimer.current time is ', Date.now());
  startTimer(() => {
    if (!connectedDevice.value) {
      updateState(MagnetScheduleState.BIND_SCAN_TIMEOUT);
      showToastLong("扫描失败，请重新点击连接治疗仪");
      stopScan()
    }
  })
};

interface ActionCallback {
  (): void
}

const heartCheck = () => {
  startHeartCheck(() => {
    console.log('index.startHeartCheck.heartCheck timeout.', Date.now());
    writeToDevice("AB040000000004A5");
    // writeList.value.push("heartCheck")
    heartCheck();
  })
};

const sendScheme = () => {
  const prefix = 0x10;
  if (!modeStrength) {
    modeStrength = "21";
  }
  const ms = parseInt(modeStrength, 16);
  const time1 = 0x07;
  const time2 = 0x80;
  const result = prefix + ms + time1 + time2;
  console.log("index..sendScheme. ms=" + ms + "; prefix=" + prefix + "; result=" + result + "; hex=" + result.toString(16));
  const data: string = `AB${prefix.toString(16)}${modeStrength}078000${result.toString(16)}A5`;
  console.log("index..sendScheme.data=", data);
  writeToDevice(data);
  // writeToDevice("AB" + prefix + modeStrength + "078000" + parseInt(result,16) + "A5");
  // writeToDevice("AB102101000032A5");
};


// endregion

// region 页面逻辑操作
const bindDevice = () => {
  SugarApi.bindDevice(connectedDevice.value.name, DeviceBrand.MAGNET.brand, DeviceCategory.MAGNET.valueOf()).then((res) => {
    console.log("item.vue.bindDevice..success", JSON.stringify(res));
    Taro.eventCenter.trigger('bind', {})
    // showShortToast('绑定成功')
  }, (failure) => {
    showShortToast(failure)
  })
};

/**
 * 上报开机
 * @param startUpCmd
 */
const uploadDeviceStartUp = (startUpCmd: MagnetRunningTimeReportCmd) => {
  console.log('index.uploadDeviceStartUp.', JSON.stringify(startUpCmd));
  let request = new MagnetUpload();
  request.deviceSn = connectedDevice.value.name;
  request.deviceId = connectedDevice.value.deviceId;
  request.mode = 0;
  // 依据协议 时间单位 分
  const minutes = parseInt(startUpCmd.time1) * 100 + parseInt(startUpCmd.time2);
  if (minutes > 0) {
    request.time = addMinutes(new Date(), -minutes);
  }
  if (request.time == null) {
    request.time = formatFullDateToStr(new Date());
  }
  // notifyResultList.value.push("uploadDeviceStartUp=" + JSON.stringify(request))
  MagnetApi.uploadMagnetStartup(request)
};

/**
 * 上报关机
 */
const uploadDeviceShutDown = () => {
  console.log('index.uploadDeviceShutDown.');
  let request = new MagnetUpload();
  request.deviceSn = connectedDevice.value.name;
  request.deviceId = connectedDevice.value.deviceId;
  request.mode = 0;
  request.time = formatFullDateToStr(new Date());
  // notifyResultList.value.push("uploadDeviceShutDown=" + JSON.stringify(request))
  MagnetApi.uploadMagnetFinish(request);
  clearHeartCheck()
};

/**
 * 治疗结束
 */
const uploadMeasureFinish = () => {
  let request = new MagnetUpload();
  request.deviceId = connectedDevice.value.deviceId;
  request.deviceSn = connectedDevice.value.name;
  request.mode = currentMode;
  request.runTime = runTime;
  request.powerLevel = powerLevel;
  request.time = formatFullDateToStr(new Date());
  request.type = 1;
  // notifyResultList.value.push("uploadStartFinish=" + JSON.stringify(request))
  MagnetApi.uploadMagnetFinish(request).then(res => {

  })
};

let startTime;
let isMorningTime;
let modeStrength;
let currentMode;
let powerLevel;
let runTime;

/**
 * 开始治疗
 * @param startMeasureCmd
 */
const uploadStartMeasure = (startMeasureCmd: MagnetStartMeasureCmd) => {
  let request = new MagnetUpload();
  request.deviceSn = connectedDevice.value.name;
  request.deviceId = connectedDevice.value.deviceId;
  request.mode = parseInt(startMeasureCmd.mode);
  modeStrength = startMeasureCmd.modeStrength;
  currentMode = startMeasureCmd.mode;
  request.runTime = parseInt(startMeasureCmd.time1) * 100 + parseInt(startMeasureCmd.time2);
  request.powerLevel = parseInt(startMeasureCmd.strength);
  powerLevel = startMeasureCmd.strength;
  let date = new Date();
  request.time = formatFullDateToStr(date);
  startTime = formatDateTohms(date)
  // notifyResultList.value.push("uploadStartMeasure=" + JSON.stringify(request))
  MagnetApi.uploadMagnetStartup(request).then(res => {
    console.log('index.uploadMagnetStartup.response=', JSON.stringify(res))
  })
};

const finishSchedule = () => {
  planApi.finishSchedule(planId.value, currentDateIndex.value, currentIndex.value + 1, isMorningTime ? 1 : 0, startTime).then(res => {
    if (isMorningTime) {
      currentItemIndex.value.morningState = CompositePlanState.FINISH;
      currentItemIndex.value.morningTime = startTime
      result.value.dailyScheduleList[currentIndex.value].morningState = CompositePlanState.FINISH
    } else {
      currentItemIndex.value.afternoonState = CompositePlanState.FINISH;
      currentItemIndex.value.afternoonTime = startTime;
      result.value.dailyScheduleList[currentIndex.value].afternoonState = CompositePlanState.FINISH
    }
  })
};

// endregion

const startCureOperation = () => {
  console.log("index..startCureOperation.currentItemIndex=", JSON.stringify(currentItemIndex.value));
  let ms;
  isMorningTime = isMorning()
  if (isMorning()) {
    console.log("index..startCureOperation.isMorning");
    if (currentItemIndex.value.morningState <= CompositePlanState.TOBEGIN) {
      currentMode = currentItemIndex.value.mode;
      ms = "2" + currentItemIndex.value.morning;
    } else {
      console.log("index..startCureOperation.morning.state=", currentItemIndex.value.morningState, '; tobegin=', CompositePlanState.TOBEGIN, '; future=', CompositePlanState.FUTURE);
    }
  } else {
    console.log("index..startCureOperation.isAfternoon currentItemIndex.value.afternoonState=", currentItemIndex.value.afternoonState, '; currentItemIndex.value.afternoon == CompositePlanState.FUTURE', (currentItemIndex.value.afternoon == CompositePlanState.FUTURE), '; sss=', ((currentItemIndex.value.afternoon === CompositePlanState.FUTURE)), '; type=', typeof currentItemIndex.value.afternoon, '; toc =', (typeof CompositePlanState.FUTURE));
    if (currentItemIndex.value.afternoonState <= CompositePlanState.TOBEGIN) {
      currentMode = currentItemIndex.value.mode;
      ms = "2" + currentItemIndex.value.afternoon;
    } else {
      console.log("index..startCureOperation.afternoon.state=", currentItemIndex.value.afternoonState, '; tobegin=', CompositePlanState.TOBEGIN, '; future=', CompositePlanState.FUTURE);
    }
  }
  console.log("index..startCureOperation.modeStrength=" + ms + "; mode=" + currentItemIndex.value.mode + "; afternoon=" + currentItemIndex.value.afternoon + "; morning=" + currentItemIndex.value.morning);
  // if (ms && ms.length > 0) {
  checkBlePermission();
  // } else {
  //   console.log("index..startCureOperation.INIT_ERROR = ", MagnetScheduleState.INIT_ERROR, '; (typeof MagnetScheduleState)=', (typeof MagnetScheduleState));
  //   updateState(MagnetScheduleState.INIT_ERROR);
  // }
};

// region 页面更新、响应页面事件
const onRetryBtnClick = () => {
  console.log('index.onRetryBtnClick.scaleMeasureState.value=', scaleMeasureState.value);
  if (!scaleMeasureState.value && currentItemIndex.value.operationText && currentItemIndex.value.operationText.indexOf("开始治疗") != -1) {
    startCureOperation();
    return
  }
  switch (scaleMeasureState.value?.state) {
    case MagnetScheduleState.BIND_TO_SCAN.state:
    case MagnetScheduleState.LOCATION_CLOSE.state:
      const systemSetting = Taro.getSystemSetting();
      const locationEnabled = systemSetting.locationEnabled;
      if (locationEnabled) {
        checkBlePermission()
      } else {
        showBleDisableModal(MagnetScheduleState.LOCATION_CLOSE.subState)
      }
      break;
    case MagnetScheduleState.BIND_SCAN_TIMEOUT.state:
    case MagnetScheduleState.BIND_SCAN_FAILURE.state:
    case MagnetScheduleState.LOST_CONNECT.state:
    case MagnetScheduleState.CONNECT_FAILURE.state:
      updateState(MagnetScheduleState.BIND_TO_SCAN);
      // restart()
      checkBlePermission();
      break;
    case MagnetScheduleState.BLE_DISABLE.state:
      // let systemInfo = Taro.getSystemInfoSync();
      // if (systemInfo.platform === 'ios') {
      //   Taro.showModal({
      //     title: '提示',
      //     content: '请先打开手机蓝牙开关？',
      //     showCancel: false,
      //
      //   })
      // } else {
      //   Taro.openSystemBluetoothSetting(
      //       {
      //         success: (res) => {
      //           console.log("index.vue.updateState..success", res);
      //           checkBleAdapterState()
      //           onBleAdapterState()
      //         },
      //         fail: (res) => {
      //           console.log("index.vue.updateState..fail", res);
      //         }
      //       }
      //   );
      // }
      showBleDisableModal();
      // checkBlePermission();
      break;
    case MagnetScheduleState.BLE_AUTHORIZE.state:
      logger.log('index.onRetryBtnClick.BLE_AUTHORIZE');
      Taro.openSystemBluetoothSetting({
        success: (res) => {
          console.log('index.onRetryBtnClick.BLE_AUTHORIZE.success.res=', JSON.stringify(res))
        }
      });
      break;
    default:
      console.log('index.onRetryBtnClick.default');
      break;
  }
};

const showBleDisableModal = (str: string | null = null) => {
  Taro.showModal({
    content: str || '手机蓝牙未开启，请先打开手机蓝牙',
    showCancel: false,
    confirmText: '知道了'
  })
};

const showBleAuthorizeModal = () => {
  Taro.showModal({
    content: MagnetScheduleState.BLE_AUTHORIZE.subState,
    showCancel: false,
    confirmText: '知道了',
    success: (res) => {
      Taro.openSystemBluetoothSetting({
        success: (res) => {
          console.log('index.showBleAuthorizeModal.BLE_AUTHORIZE.success.res=', JSON.stringify(res))
        }
      })
      // Taro.openSetting({
      //   success: (res) => {
      //     console.log('index.showBleAuthorizeModal.BLE_AUTHORIZE.success.res=', JSON.stringify(res))
      //   }
      // })
    }
  })
};

const updateState = (state) => {
  console.log("index.vue.updateState.", JSON.stringify(state));
  scaleMeasureState.value = state
  if (state.subState) {
    showToast(state.subState)
  }
  currentItemIndex.value.operationText = state.mainState
  if (state == MagnetScheduleState.MEASURE_SUCCESS) {
    currentItemIndex.value.pointClass = 'view_btn blue'
  }
  console.log("index.value.updateState.text=", currentItemIndex.value.operationText, '; state=', state.mainState);

  // notifyResultList.value.push("updateState=" + state.mainState)
}

// endregion

// endregion

</script>


<style lang="less">
.plan_root {
  display: flex;
  flex-direction: column;

  .header {
    display: flex;
    flex-direction: row;
    padding: 30px 20px;
    justify-content: space-between;
    align-items: center;

    .card_btn {
      border-radius: 16px;
      background: white;
      display: flex;
      width: 345px;
      justify-content: center;
      align-items: center;
      font-size: 34px;
      line-height: 88px;
      text-align: center;
      height: 88px;
      flex-direction: row;

      img {
        width: 44px;
        height: 44px;
        margin-right: 16px;
      }
    }
  }

  .view_content {
    background: #fff;
    margin: 0 20px;
    border-radius: 16px;

    display: flex;
    flex-direction: column;

    .date_index {
      display: flex;
      flex-direction: row;
      color: #353535;
      font-size: 34px;
      padding: 30px 20px;
      justify-content: center;
      align-items: center;

      .left {
        width: 0;
        margin-right: 27px;
        height: 0;
        border-style: solid;
        border-width: 16px 32px 16px 0;
        border-color: transparent #bbbbbb transparent transparent;
      }

      .right {
        width: 0;
        height: 0;
        margin-left: 27px;
        border-style: solid;
        border-width: 16px 0 16px 32px;
        border-color: transparent transparent transparent #bbbbbb;
      }
    }

    .grid {
      display: grid;
      grid-template-columns: repeat(5, 1fr); /* 每列占据容器的1/3宽度 */

      .grid_item {
        display: flex;
        padding: 20px 0;
        align-items: center;
        justify-content: center;
        flex-direction: column;

        .text_true {
          width: 114px;
          height: 50px;
          text-align: center;
          line-height: 50px;
          padding-bottom: 5px;
          color: white;
          background: #64A4F5;
          border-radius: 50px;
        }

        .text_false {
          width: 114px;
          height: 50px;
          text-align: center;
          line-height: 50px;
          padding-bottom: 5px;
          color: #5F5F5F;
          background: white;
          border-radius: 50px;
        }

        .point {
          display: flex;
          margin-top: 16px;
          flex-direction: row;
          justify-content: center;
          align-items: center;

          .pitem {
            width: 12px;
            height: 12px;
            margin: 0 10px;
            border-radius: 50%;
          }
        }
      }
    }

    .view_arrow {
      display: flex;
      justify-content: center;
      align-items: center;
      margin-bottom: 25px;
    }


  }

  .plan {
    display: flex;
    background: #fff;
    margin: 30px 20px;
    align-items: center;
    padding: 30px 20px;
    border-radius: 16px;
    flex-direction: column;

    .ampm {
      display: flex;
      width: 100%;
      justify-content: space-between;
      align-items: center;


      .card_pm {
        display: flex;
        width: 325px;
        text-align: center;
        height: 124px;
        flex-direction: column;
        background: #F8F8F8;
        color: #5f5f5f;
        border-radius: 16px;

        .title {
          margin-bottom: 16px;
          font-size: 32px;
          margin-top: 16px;
          font-weight: bold;
        }

        .status {
          font-size: 28px;
          display: flex;
          justify-content: center;
          align-items: center;

          img {
            width: 32px;
            height: 32px;
            margin-right: 10px;
          }
        }


      }
    }

    .view_btn {
      height: 300px;
      width: 300px;
      margin-top: 60px;
      margin-bottom: 30px;
      display: flex;
      justify-content: center;
      align-items: center;
      flex-direction: column;
      color: white;
      border-radius: 50%;


      .start {
        font-size: 40px;
        font-weight: bold;


      }

      .date {
        margin-top: 16px;
        font-size: 30px;
      }
    }

    .notify {
      font-size: 30px;
      color: #5f5f5f;
    }

    .mt16 {
      margin-top: 16px;
    }

  }

  .bottom_text {
    font-size: 28px;
    color: #979797;
    margin: 30px 20px;
  }
}

.text_blue {
  color: #64A4F5;
}

.transparent {
  background: #00000000;
}

.blue {
  background: #64A4F5;
}

.yellow {
  background: #FFA94F;
}

.grey {
  background: #BBBBBB;
}

.view_no_data {
  height: 100vh;
  padding-top: 150px;

  .nut-empty__box {
    width: 440px;
    height: 260px
  }

  .nut-empty__description {
    text-align: center;
  }
}
</style>
