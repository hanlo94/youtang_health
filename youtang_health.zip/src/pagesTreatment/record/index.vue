<template>
  <view class="card_list">
    <scroll-view class="view_list" :scrollY="true" @scrollToLower="scroll" flexed v-if="dataList && dataList.length">
      <view class="card_item" v-for="(item, index) in dataList" :key="index" @click="onClickItem(item)">
        <view :class="getStatusClass(item.planState)">
          {{ item.planStateName }}
        </view>
        <view class="item_content">
          <view class="title">{{ item.planName }}</view>
          <view class="date">{{ item.planTime }}</view>
        </view>
        <view class="see">查看</view>
      </view>
    </scroll-view>
    <view v-else class="view_no_data">
      <nut-empty image="https://ut-image.oss-cn-wuhan-lr.aliyuncs.com/icon/common/nodata.png"
                 description="暂无记录"></nut-empty>
    </view>
  </view>
</template>

<script setup lang="ts">
import {ref} from "vue";
import {isEmpty} from "lodash";
import Taro from "@tarojs/taro";
import planApi from "@/api/modules/plan";
import {IPlanRecordItem} from "@/pagesTreatment/ts/types";

definePageConfig({
  navigationBarTitleText: '我的设备使用记录'
})
const pageNum = ref(1);
//最终的数据
const dataList = ref<IPlanRecordItem[]>([])


/**
 *
 * @param status
 * 1进行中 2已中止 3已结束
 */
const getStatusClass = (status: number) => {
  if (status <= 3) {
    return 'item_header blue'
  } else if (status === 6) {
    return 'item_header yellow'
  } else {
    return 'item_header grey'
  }
}

/**
 * 点击查看列表详情
 * @param item
 */
const onClickItem = (item: IPlanRecordItem) => {
  console.log(item, 'item')
  Taro.navigateTo({
    url: "/pagesTreatment/statistics/index?planId=" + item.dataId,
  })
}


/**
 * 上啦加载
 */
const scroll = () => {
  requestIndexMsgList()
}


/**
 * 请求列表
 */
const requestIndexMsgList = () => {
  planApi.requestPlanList(pageNum.value).then(res => {
    if (pageNum.value === 1) dataList.value = [];
    if (!isEmpty(res.data)) {
      dataList.value.push(...res.data);
      pageNum.value++;
    }
  })
}

requestIndexMsgList()


</script>


<style lang="less">
.card_list {
  display: flex;
  flex-direction: column;
  height: 100vh;
  background: #efefee;

  .view_list {
    display: flex;
    height: 100vh;
    flex-direction: column;
  }

  .card_item {
    display: flex;
    background: white;
    border-radius: 16px;
    align-items: center;
    justify-content: space-between;
    padding: 30px 20px;
    margin: 15px 20px;

    .item_header {
      width: 80px;
      height: 80px;
      border-radius: 50%;
      font-size: 20px;
      line-height: 80px;
      text-align: center;
      margin-right: 16px;
      color: #ffffff;

    }

    .item_content {
      display: flex;
      flex: 1;
      font-weight: normal;
      flex-direction: column;

      .title {
        font-size: 32px;
        color: #353535;
        font-weight: bold;
      }

      .date {
        font-size: 24px;
        padding-top: 16px;
        color: #5f5f5f;
      }
    }

    .see {
      width: 108px;
      height: 58px;
      border-radius: 58px;
      color: #64A4F5;
      margin-left: 16px;
      font-size: 30px;
      line-height: 58px;
      text-align: center;
      border: 1px solid #64A4F5;
    }
  }

  .view_no_data {
    height: 100vh;
    padding-top: 150px;

    .nut-empty__box {
      width: 440px;
      height: 260px
    }
  }
}

.blue {
  background: #64A4F5;
}

.grey {
  background: #BBBBBB;
}

.green {
  background: #66BA2A;
}

.yellow {
  background: #FFD595;
}
</style>
