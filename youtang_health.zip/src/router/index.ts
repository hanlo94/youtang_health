import { RouteLocationNormalized } from "vue-router";

// import {useSetTitle} from '@/hooks';
import router from "./router";

// @ts-ignore
router.beforeEach((to, from, next) => {
  // const appStore = useAppCoreStore();
  // const userStore = useUserStore();
  // if (to.meta?.auth === true) {
  //   if (!userStore.uuToken) {
  //     appStore.setRedirect(to.fullPath);
  //     appStore.appStatus.showLogin = true;
  //     next({ path: '/' });
  //     return;
  //   }
  // }
  // next();
});

// @ts-ignore
/**
 * 添加一个导航钩子，每次导航后被执行，返回一个用来移除该钩子的函数
*/
router.afterEach((to: RouteLocationNormalized) => {});

export default router;
